import os
import ctypes
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

FILE_ATTRIBUTE_HIDDEN = 0x2
INVALID_FILE_ATTRIBUTES = 0xFFFFFFFF

kernel32 = ctypes.windll.kernel32
kernel32.GetFileAttributesW.argtypes = [ctypes.c_wchar_p]
kernel32.GetFileAttributesW.restype = ctypes.c_uint32
kernel32.SetFileAttributesW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32]
kernel32.SetFileAttributesW.restype = ctypes.c_int


def get_attrs(path):
    attrs = kernel32.GetFileAttributesW(str(path))
    if attrs == INVALID_FILE_ATTRIBUTES:
        return None
    return attrs


def set_hidden(path, hidden=True):
    attrs = get_attrs(path)
    if attrs is None:
        return False

    if hidden:
        new_attrs = attrs | FILE_ATTRIBUTE_HIDDEN
    else:
        new_attrs = attrs & ~FILE_ATTRIBUTE_HIDDEN

    return bool(kernel32.SetFileAttributesW(str(path), new_attrs))


def normalize_ext(ext):
    ext = ext.strip()
    if not ext:
        ext = ".cutplan"
    if not ext.startswith("."):
        ext = "." + ext
    return ext.lower()


def choose_folder():
    folder = filedialog.askdirectory(title="Chọn thư mục chứa file")
    if folder:
        folder_var.set(folder)


def iter_target_files(folder, ext, recursive):
    if recursive:
        for root, dirs, files in os.walk(folder):
            for name in files:
                if name.lower().endswith(ext):
                    yield os.path.join(root, name)
    else:
        for name in os.listdir(folder):
            full = os.path.join(folder, name)
            if os.path.isfile(full) and name.lower().endswith(ext):
                yield full


def apply(hidden):
    folder = folder_var.get().strip()
    if not folder or not os.path.isdir(folder):
        messagebox.showwarning("Thiếu thư mục", "Hãy chọn thư mục hợp lệ.")
        return

    ext = normalize_ext(ext_var.get())
    recursive = recursive_var.get()

    total = 0
    success = 0
    failed = []

    try:
        for path in iter_target_files(folder, ext, recursive):
            total += 1
            if set_hidden(path, hidden):
                success += 1
            else:
                failed.append(path)
    except Exception as e:
        messagebox.showerror("Lỗi", str(e))
        return

    action = "Ẩn" if hidden else "Hiện lại"

    if total == 0:
        messagebox.showinfo("Kết quả", f"Không tìm thấy file {ext} trong thư mục đã chọn.")
        status_var.set(f"Không tìm thấy file {ext}")
        return

    msg = f"{action} thành công {success}/{total} file {ext}."
    if failed:
        msg += f"\nCó {len(failed)} file không xử lý được."

    messagebox.showinfo("Kết quả", msg)
    status_var.set(msg)


root = tk.Tk()
root.title("Ẩn / Hiện file theo đuôi")
root.geometry("620x290")
root.resizable(False, False)

main = ttk.Frame(root, padding=18)
main.pack(fill="both", expand=True)

ttk.Label(main, text="Thư mục chứa file:").grid(row=0, column=0, sticky="w", pady=(0, 6))

folder_var = tk.StringVar()
folder_entry = ttk.Entry(main, textvariable=folder_var, width=64)
folder_entry.grid(row=1, column=0, sticky="ew", padx=(0, 8))

ttk.Button(main, text="Chọn thư mục", command=choose_folder).grid(row=1, column=1)

ttk.Label(main, text="Đuôi file cần ẩn:").grid(row=2, column=0, sticky="w", pady=(18, 6))

ext_var = tk.StringVar(value=".cutplan")
ttk.Entry(main, textvariable=ext_var, width=20).grid(row=3, column=0, sticky="w")

recursive_var = tk.BooleanVar(value=True)
ttk.Checkbutton(
    main,
    text="Áp dụng cả thư mục con",
    variable=recursive_var
).grid(row=4, column=0, sticky="w", pady=(12, 0))

btn_frame = ttk.Frame(main)
btn_frame.grid(row=5, column=0, columnspan=2, pady=22, sticky="w")

ttk.Button(
    btn_frame,
    text="ẨN FILE",
    command=lambda: apply(True),
    width=18
).pack(side="left", padx=(0, 12))

ttk.Button(
    btn_frame,
    text="HIỆN LẠI FILE",
    command=lambda: apply(False),
    width=18
).pack(side="left")

status_var = tk.StringVar(
    value="File chỉ được đặt thuộc tính Hidden, không đổi tên và không xóa."
)
ttk.Label(
    main,
    textvariable=status_var,
    foreground="#555555",
    wraplength=560
).grid(row=6, column=0, columnspan=2, sticky="w")

ttk.Label(
    main,
    text="Lưu ý: nếu Windows đang bật 'Hidden items' thì file ẩn vẫn có thể nhìn thấy mờ.",
    foreground="#777777",
    wraplength=560
).grid(row=7, column=0, columnspan=2, sticky="w", pady=(8, 0))

main.columnconfigure(0, weight=1)

root.mainloop()
