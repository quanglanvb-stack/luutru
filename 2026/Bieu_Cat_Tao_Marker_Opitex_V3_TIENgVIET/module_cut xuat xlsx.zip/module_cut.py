"""
PHẦN MỀM QUẢN LÝ TÁC NGHIỆP CẮT 
Giao diện: Tkinter
Xuất file: Excel (.xlsx) + dự án (.cutplan)
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, Protection
from openpyxl.drawing.image import Image as XLImage
from openpyxl.formatting.rule import FormulaRule
import json
import os
import sys
import io
import math
import re
import unicodedata
import base64
import time
from itertools import combinations

try:
    from PIL import Image as PILImage, ImageTk
except ImportError:
    PILImage = None
    ImageTk = None


def _safe_filename_token(value, fallback=""):
    """Làm sạch một phần tên file để dùng an toàn trên Windows."""
    s = str(value or "").strip()
    # Windows không cho phép các ký tự này trong tên file.
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', '_', s)
    s = re.sub(r'\s+', '_', s)
    s = re.sub(r'_+', '_', s).strip(' ._')
    return s or fallback


def _style_last5(value):
    """Mã hàng khi đặt tên file: ưu tiên lấy đúng 5 chữ số cuối."""
    raw = str(value or "").strip()
    digits = ''.join(ch for ch in raw if ch.isdigit())
    if digits:
        return digits[-5:] if len(digits) >= 5 else digits
    # Mã hàng không có số: fallback 5 ký tự cuối để tên file vẫn có ý nghĩa.
    safe = _safe_filename_token(raw, 'MAHANG')
    return safe[-5:] if len(safe) > 5 else safe


def _suggest_excel_filename(prefix, style_code, batch):
    style_part = _style_last5(style_code) or 'MAHANG'
    batch_part = _safe_filename_token(batch, 'DOT')
    prefix_part = str(prefix or '').strip()
    return f"{prefix_part}_{style_part}_{batch_part}.xlsx"


class CuttingPlanApp:
    APP_VERSION = "V163-DAU-TAM-TUY-CHINH"
    YARD_TO_METER = 0.9144
    PROJECT_MAGIC = "CUTTING_PLAN_PROJECT"
    PROJECT_SCHEMA = 2

    # V77: chiều dài tối thiểu là sàn MỤC TIÊU khi tối ưu; không khóa xuất Excel nếu sản lượng thực tế không thể đạt sàn.
    FABRIC_MODE_LABELS = {
        'auto': 'TỰ ĐỘNG',
        'main': 'VẢI CHÍNH',
        'lining': 'VẢI LÓT',
        'interlayer': 'KẸP TẦNG',
        'interlining': 'DỰNG / MEX',
        'padding': 'BÔNG',
    }
    FABRIC_MODE_VALUES = ['TỰ ĐỘNG', 'VẢI CHÍNH', 'VẢI LÓT', 'KẸP TẦNG', 'DỰNG / MEX', 'BÔNG']
    # V154: giữ 2 kiểu cũ + thêm 10 kiểu tối ưu theo mục tiêu sản xuất.
    OPTIMIZER_LABELS = {
        'global': 'TOÀN CỤC',
        'sequential': 'TUẦN TỰ',
        'few_tables': 'ÍT BÀN NHẤT',
        'high_plies': 'LÁ CAO NHẤT',
        'long_marker': 'SƠ ĐỒ DÀI NHẤT',
        'size_mix': 'GHÉP CỠ TỐI ƯU',
        'balance': 'CÂN ÂM / DƯƠNG',
        'tail_opt': 'BÀN CUỐI TỐI ƯU',
        'lot_opt': 'TỐI ƯU THEO LOT',
        'fast': 'NHANH',
        'accurate': 'CHÍNH XÁC CAO',
        'production': 'TỐI ƯU SẢN XUẤT',
        'smart': 'TỰ ĐỘNG THÔNG MINH',
    }
    OPTIMIZER_VALUES = [
        'TOÀN CỤC',
        'TUẦN TỰ',
        'ÍT BÀN NHẤT',
        'LÁ CAO NHẤT',
        'SƠ ĐỒ DÀI NHẤT',
        'GHÉP CỠ TỐI ƯU',
        'CÂN ÂM / DƯƠNG',
        'BÀN CUỐI TỐI ƯU',
        'TỐI ƯU THEO LOT',
        'NHANH',
        'CHÍNH XÁC CAO',
        'TỐI ƯU SẢN XUẤT',
        'TỰ ĐỘNG THÔNG MINH',
    ]

    def __init__(self, root):
        self.root = root
        self.root.title("PHẦN MỀM TÁC NGHIỆP CẮT - CUTTING PLAN ")
        self.root.geometry("1200x800")
        self.root.configure(bg='#f0f0f0')
        
        # Dữ liệu
        self.po_list = []
        self.fabric_list = []
        # V47: Kho LOT/CÂY dùng chung. Mỗi dòng: LOT + LOT ghi trên cây + số cây + số mét.
        self.global_lot_rows = []
        # V38: file dự án .cutplan để lưu toàn bộ dữ liệu và mở lại lần sau.
        self.current_project_path = None
        self._last_project_error = ''
        # V107: cache kết quả tác nghiệp. Khi vừa XEM TRƯỚC rồi XUẤT EXCEL,
        # nếu dữ liệu không đổi thì không chạy lại bộ tối ưu toàn cục lần thứ hai.
        self._cut_plan_cache_key = None
        self._cut_plan_cache_results = None
        # V134: cache riêng từng loại vải để chỉ tính lại loại đang cần.
        self._fabric_preview_cache = {}
        self.MAX_OVER = 3  # Dương tối đa 3SP/cỡ
        self.MIN_PREFERRED_PLIES = 10  # Bàn ít lá: cố gắng rút gọn tỷ lệ để tăng số lá mà giữ nguyên sản lượng
        self.MIN_MARKER_LENGTH = 1.0  # V76: giá trị GỢI Ý mặc định khi thêm loại vải mới
        self.EXTRA_SURPLUS_ROWS = 3  # V86: gợi ý mặc định 3 dòng dư có công thức / LOT
        self.ROLL_EXTRA_BLANK_ROWS = 3  # V100: số dòng trống chừa thêm cho mỗi bàn trong PHÂN CÂY

        # V83: chế độ áp dụng % dương.
        # - enabled=False: không PO nào được cộng % dương.
        # - mode='all': tất cả PO được cộng % dương.
        # - mode='selected': chỉ PO được tích trong cột DƯƠNG % mới được cộng.
        self.increase_enabled_var = tk.BooleanVar(value=True)
        self.increase_mode_var = tk.StringVar(value='all')

        # Danh sách size động: đổi tên được và có thể thêm size mới
        self.sizes = [
            {'key': 'size1', 'name': 'XS', 'factor': 0.90, 'increase_pct': 0.0},
            {'key': 'size2', 'name': 'S',  'factor': 0.95, 'increase_pct': 0.0},
            {'key': 'size3', 'name': 'M',  'factor': 1.00, 'increase_pct': 0.0},
            {'key': 'size4', 'name': 'L',  'factor': 1.05, 'increase_pct': 0.0},
            {'key': 'size5', 'name': 'XL', 'factor': 1.10, 'increase_pct': 0.0},
        ]
        self.next_size_number = 6
        
        # Thông tin chung: V25 để trống, không còn dữ liệu gợi ý mẫu.
        self.info = {
            'customer': '',
            'style': '',
            'batch': '',
            'season': '',
            'color': '',
            'code': 'F-TECH-17',
            'date': '15/12/2023'
        }
        # Thông tin đơn hàng bổ sung do người dùng tự đặt tên + vị trí Excel.
        self.custom_info_list = []
        # Logo: tự nạp logo đã chọn lần trước; nếu chưa có cấu hình thì
        # tìm logo.png/logo.jpg đặt cạnh file .py hoặc .exe.
        self.logo_path = self._load_default_logo_path()
        # Giữ tham chiếu PhotoImage để Tkinter không giải phóng ảnh preview.
        self.logo_preview_photo = None
        
        self.create_widgets()
        self._apply_loaded_logo_to_ui()
    
    def create_widgets(self):
        """V149: giao diện giống mẫu nhưng giữ Notebook thật để không làm đơ/mất khả năng nhập liệu.

        Thanh menu trên:
        1 ĐƠN HÀNG -> 2 LOẠI VẢI -> 3 KHO CÂY -> 4 PHÂN SỐ CẮT & BIỂU 10

        Tab mặc định của ttk.Notebook được ẩn; Canvas chevron chỉ làm lớp điều hướng.
        """
        self.UI_BG = '#f3f6fa'
        self.UI_CARD = '#ffffff'
        self.UI_NAVY = '#103b70'
        self.UI_NAVY_DARK = '#0b4f83'
        self.UI_TEXT = '#1f3349'
        self.UI_MUTED = '#6d7f91'
        self.UI_BORDER = '#d6e0ea'
        self.UI_BLUE = '#3f67dc'
        self.UI_BLUE_LIGHT = '#eaf2ff'
        self.UI_GREEN = '#15945b'
        self.UI_PURPLE = '#6f42c1'
        self.UI_RED = '#d84a4a'

        self.root.configure(bg=self.UI_BG)
        try:
            self.root.geometry('1360x820')
            self.root.minsize(1080, 680)
        except Exception:
            pass

        self.status_var = tk.StringVar(value='Sẵn sàng | V163-DAU-TAM-TUY-CHINH')

        # ===== THEME =====
        style = ttk.Style()
        try:
            style.theme_use('clam')
        except tk.TclError:
            pass

        # Notebook vẫn tồn tại nhưng ẩn phần TAB.
        try:
            style.configure('HiddenMain.TNotebook', background=self.UI_BG, borderwidth=0)
            style.layout('HiddenMain.TNotebook.Tab', [])
            style.configure('HiddenWorkflow.TNotebook', background=self.UI_CARD, borderwidth=0)
            style.layout('HiddenWorkflow.TNotebook.Tab', [])
        except Exception:
            pass

        style.configure(
            'Treeview', font=('Segoe UI', 9), rowheight=25,
            background='white', fieldbackground='white',
            foreground=self.UI_TEXT, borderwidth=0, relief='flat'
        )
        style.configure(
            'Treeview.Heading', font=('Segoe UI', 8, 'bold'),
            background='#e7edf4', foreground=self.UI_TEXT,
            relief='flat', padding=(4, 5)
        )
        style.map(
            'Treeview',
            background=[('selected', '#dcecff')],
            foreground=[('selected', '#102a43')]
        )
        style.configure('TCombobox', font=('Segoe UI', 9), padding=2)
        style.configure('TScrollbar', arrowsize=11)

        # ============================================================
        # HEADER
        # ============================================================
        header = tk.Frame(self.root, bg=self.UI_NAVY_DARK, height=54)
        header.pack(fill='x', side='top')
        header.pack_propagate(False)

        # V152: khối tên phần mềm ngắn hơn.
        # Tiếng Việt là tiêu đề chính; tiếng Anh nhỏ ở dòng dưới.
        brand = tk.Frame(
            header, bg='#176da6', width=245,
            highlightthickness=1, highlightbackground='#65a7cf'
        )
        brand.pack(side='left', fill='y')
        brand.pack_propagate(False)

        tk.Label(
            brand, text='✂', font=('Segoe UI Symbol', 18),
            fg='white', bg='#176da6'
        ).pack(side='left', padx=(8, 4), pady=9)

        brand_text = tk.Frame(brand, bg='#176da6')
        brand_text.pack(side='left', fill='y', expand=True)

        tk.Label(
            brand_text, text='TÁC NGHIỆP CẮT',
            font=('Segoe UI', 13, 'bold'),
            fg='white', bg='#176da6'
        ).pack(anchor='w', pady=(7, 0))

        tk.Label(
            brand_text, text='CUTTING PLAN',
            font=('Segoe UI', 7),
            fg='#d8efff', bg='#176da6'
        ).pack(anchor='w', pady=(0, 1))

        tk.Label(
            brand, text='V163',
            font=('Segoe UI', 6, 'bold'),
            fg='white', bg='#5b8ff9',
            padx=5, pady=2
        ).pack(side='right', padx=(1, 4), pady=17)

        # Menu Canvas chevron.
        nav = tk.Canvas(
            header, bg=self.UI_NAVY_DARK,
            height=54, bd=0, highlightthickness=0,
            cursor='hand2'
        )
        nav.pack(side='left', fill='both', expand=True)
        self.top_nav_canvas = nav
        self._current_top_page = 0

        # V152: LƯU / MỞ là hai khối riêng biệt, tách hẳn khỏi menu.
        head_actions = tk.Frame(
            header, bg='#073f6c',
            highlightthickness=1, highlightbackground='#2e6f9f'
        )
        head_actions.pack(side='right', fill='y')

        save_block = tk.Frame(
            head_actions, bg='#0b5e9a', width=66,
            highlightthickness=1, highlightbackground='#4d86b2'
        )
        save_block.pack(side='left', fill='y', padx=(0, 2))
        save_block.pack_propagate(False)

        self.header_save_button = tk.Button(
            save_block, text='💾\nLƯU',
            command=self.save_project_manual,
            font=('Segoe UI', 7, 'bold'),
            bg='#0b5e9a', fg='white',
            activebackground='#1676b7', activeforeground='white',
            relief='flat', bd=0, cursor='hand2'
        )
        self.header_save_button.pack(fill='both', expand=True)

        open_block = tk.Frame(
            head_actions, bg='#114e79', width=66,
            highlightthickness=1, highlightbackground='#4d86b2'
        )
        open_block.pack(side='left', fill='y')
        open_block.pack_propagate(False)

        self.header_open_button = tk.Button(
            open_block, text='📂\nMỞ',
            command=self.load_project,
            font=('Segoe UI', 7, 'bold'),
            bg='#114e79', fg='white',
            activebackground='#1d6b9f', activeforeground='white',
            relief='flat', bd=0, cursor='hand2'
        )
        self.header_open_button.pack(fill='both', expand=True)

        # ============================================================
        # STATUS + ACTION BAR (tạo trước vùng content để pack ổn định)
        # ============================================================
        status_wrap = tk.Frame(
            self.root, bg='#e7edf4', bd=0,
            highlightthickness=1, highlightbackground='#c2cfdd'
        )
        status_wrap.pack(fill='x', side='bottom')
        status_wrap.grid_columnconfigure(0, weight=1)

        status_bar = tk.Label(
            status_wrap, textvariable=self.status_var,
            bd=0, anchor='w',
            bg='#e7edf4', fg=self.UI_MUTED,
            font=('Segoe UI', 8), padx=8, pady=3
        )
        status_bar.grid(row=0, column=0, sticky='ew')

        resize_grip = ttk.Sizegrip(status_wrap)
        resize_grip.grid(
            row=0, column=1, sticky='se',
            padx=(6, 4), pady=(2, 3),
            ipadx=6, ipady=6
        )
        self.main_resize_grip = resize_grip

        fixed_action_bar = tk.Frame(
            self.root, bg=self.UI_CARD, bd=0,
            highlightthickness=1, highlightbackground=self.UI_BORDER
        )
        fixed_action_bar.pack(fill='x', side='bottom')
        self.fixed_action_bar = fixed_action_bar
        fixed_action_bar.grid_columnconfigure(0, weight=1)

        self.export_status = tk.Label(
            fixed_action_bar, text='',
            font=('Segoe UI', 8),
            fg=self.UI_GREEN, bg=self.UI_CARD, anchor='w'
        )
        self.export_status.grid(
            row=0, column=0, sticky='ew',
            padx=(12, 8), pady=8
        )

        self.fixed_recalc_button = tk.Button(
            fixed_action_bar,
            text='↻  TÍNH TOÁN LẠI',
            command=self.recalculate_all_fabrics_dashboard,
            font=('Segoe UI', 9, 'bold'),
            bg='#2375c6', fg='white',
            activebackground='#1b62a8', activeforeground='white',
            padx=16, pady=7, relief='flat', bd=0, cursor='hand2'
        )
        self.fixed_recalc_button.grid(row=0, column=1, padx=4, pady=7)

        self.fixed_export_button = tk.Button(
            fixed_action_bar,
            text='📤  XUẤT EXCEL',
            command=self.export_excel,
            font=('Segoe UI', 9, 'bold'),
            bg=self.UI_GREEN, fg='white',
            activebackground='#107c4b', activeforeground='white',
            disabledforeground='white',
            padx=18, pady=7, relief='flat', bd=0, cursor='hand2'
        )
        self.fixed_export_button.grid(row=0, column=2, padx=4, pady=7)

        self.fixed_save_button = tk.Button(
            fixed_action_bar,
            text='💾  LƯU DỰ ÁN MỚI',
            command=self.save_project_as,
            font=('Segoe UI', 9, 'bold'),
            bg=self.UI_PURPLE, fg='white',
            activebackground='#5f36a8', activeforeground='white',
            padx=16, pady=7, relief='flat', bd=0, cursor='hand2'
        )
        self.fixed_save_button.grid(row=0, column=3, padx=4, pady=7)

        self.fixed_preview_button = tk.Button(
            fixed_action_bar,
            text='👁  XEM TRƯỚC',
            command=self.preview_calculation,
            font=('Segoe UI', 9, 'bold'),
            bg='#64748b', fg='white',
            activebackground='#526275', activeforeground='white',
            padx=16, pady=7, relief='flat', bd=0, cursor='hand2'
        )
        self.fixed_preview_button.grid(row=0, column=4, padx=(4, 12), pady=7)

        # ============================================================
        # NOTEBOOK THẬT - GIỮ NGUYÊN CƠ CHẾ WIDGET CỦA FILE GỐC
        # ============================================================
        notebook = ttk.Notebook(self.root, style='HiddenMain.TNotebook')
        notebook.pack(fill='both', expand=True, padx=7, pady=(7, 0))
        self.main_notebook = notebook

        tab_cut = tk.Frame(notebook, bg=self.UI_BG)
        notebook.add(tab_cut, text='MAIN')

        flow_card = tk.Frame(
            tab_cut, bg=self.UI_CARD,
            highlightthickness=1, highlightbackground=self.UI_BORDER
        )
        flow_card.pack(fill='both', expand=True, padx=5, pady=5)

        workflow = ttk.Notebook(flow_card, style='HiddenWorkflow.TNotebook')
        workflow.pack(fill='both', expand=True, padx=7, pady=7)
        self.workflow_notebook = workflow

        page_canvases = []
        page_bodies = []
        page_widgets = []

        def make_scroll_page(title):
            page = tk.Frame(workflow, bg=self.UI_BG)
            workflow.add(page, text=title)
            page_widgets.append(page)

            canvas = tk.Canvas(page, bg=self.UI_BG, highlightthickness=0)
            vbar = ttk.Scrollbar(page, orient='vertical', command=canvas.yview)
            canvas.configure(yscrollcommand=vbar.set)
            vbar.pack(side='right', fill='y')
            canvas.pack(side='left', fill='both', expand=True)

            body = tk.Frame(canvas, bg=self.UI_BG)
            win = canvas.create_window((0, 0), window=body, anchor='nw')

            def resize(event=None, c=canvas, w=win):
                try:
                    if event is not None and getattr(event, 'widget', None) == c:
                        c.itemconfigure(w, width=max(1, int(event.width)))
                    c.configure(scrollregion=c.bbox('all'))
                except Exception:
                    pass

            body.bind('<Configure>', resize)
            canvas.bind('<Configure>', resize)

            page_canvases.append(canvas)
            page_bodies.append(body)
            return page, body

        # 1 ĐƠN HÀNG
        page_order, body_order = make_scroll_page('1 ĐƠN HÀNG')
        self.create_info_tab(body_order)
        try:
            self.root.update_idletasks(); self.root.update()
        except Exception:
            pass
        self.create_po_tab(body_order)
        try:
            self.root.update_idletasks(); self.root.update()
        except Exception:
            pass

        # 2 LOẠI VẢI
        page_fabric, body_fabric = make_scroll_page('2 LOẠI VẢI')
        self.create_fabric_dashboard(body_fabric)
        try:
            self.root.update_idletasks(); self.root.update()
        except Exception:
            pass

        # 3 KHO CÂY
        page_lot, body_lot = make_scroll_page('3 KHO CÂY')
        self.create_lot_inventory_tab(body_lot)
        try:
            self.root.update_idletasks(); self.root.update()
        except Exception:
            pass

        # 4 PHÂN SỐ CẮT & BIỂU 10 - nằm ngay trong cùng workflow.
        page_aux = tk.Frame(workflow, bg=self.UI_BG)
        workflow.add(page_aux, text='4 PHÂN SỐ CẮT & BIỂU 10')
        page_widgets.append(page_aux)
        self.aux_cut_panel = AuxCutTablePanel(page_aux, mode='both', owner=self)
        self.aux_cut_panel.pack(fill='both', expand=True)
        self.aux_form10_panel = self.aux_cut_panel

        self._workflow_canvases = page_canvases
        self._workflow_bodies = page_bodies
        self._workflow_pages = page_widgets
        self.cut_main_canvas = page_canvases[0]
        self.cut_main_body = page_bodies[0]

        # ============================================================
        # MENU CHEVRON CHỈ CHUYỂN TAB CỦA NOTEBOOK THẬT
        # ============================================================
        nav_items = [
            ('Đơn hàng', 0),
            ('Loại vải', 1),
            ('Kho cây', 2),
            ('Phân số cắt & Biểu 10', 3),
        ]

        def _draw_nav(event=None):
            try:
                nav.delete('all')
                w = max(650, int(nav.winfo_width() or 650))
                h = max(48, int(nav.winfo_height() or 54))
            except Exception:
                return

            weights = [1.0, 1.0, 1.0, 1.58]
            total = sum(weights)
            overlap = 18
            arrow = 20
            usable = w + overlap * 3
            widths = [int(usable * x / total) for x in weights]
            widths[-1] += usable - sum(widths)

            normal = ['#2c6d9f', '#286796', '#23618f', '#1f5a87']
            selected = '#4568df'
            outline = '#4a83af'

            x = 0
            for i, ((label, idx), segw) in enumerate(zip(nav_items, widths)):
                x0 = x
                x1 = x0 + segw
                mid = h / 2

                if i == 0:
                    pts = [
                        x0, 0,
                        x1-arrow, 0,
                        x1, mid,
                        x1-arrow, h,
                        x0, h
                    ]
                    circle_x = x0 + 31
                else:
                    pts = [
                        x0, 0,
                        x1-arrow, 0,
                        x1, mid,
                        x1-arrow, h,
                        x0, h,
                        x0+arrow, mid
                    ]
                    circle_x = x0 + 42

                if idx == self._current_top_page:
                    fill = selected
                    fg = 'white'
                else:
                    fill = normal[i]
                    fg = '#eaf4ff'

                tag = f'topnav_{idx}'
                nav.create_polygon(
                    pts, fill=fill, outline=outline, width=1,
                    tags=(tag, 'topnav')
                )

                r = 10
                nav.create_oval(
                    circle_x-r, mid-r, circle_x+r, mid+r,
                    fill='#ffffff' if idx == self._current_top_page else '#d7e8f7',
                    outline='', tags=(tag, 'topnav')
                )
                nav.create_text(
                    circle_x, mid,
                    text=str(idx+1),
                    fill=selected if idx == self._current_top_page else '#315d82',
                    font=('Segoe UI', 7, 'bold'),
                    tags=(tag, 'topnav')
                )

                nav.create_text(
                    (x0+x1)/2 + (5 if i else 0), mid,
                    text=label,
                    fill=fg,
                    font=('Segoe UI', 9 if idx == self._current_top_page else 8, 'bold'),
                    tags=(tag, 'topnav')
                )

                # V151: chỉ bind click. Không redraw ở Enter/Leave vì có thể
                # tạo vòng lặp sự kiện Canvas trên Windows và làm cửa sổ Not Responding.
                nav.tag_bind(tag, '<Button-1>', lambda e, n=idx: show_page(n))
                x = x1 - overlap

        def show_page(index):
            if getattr(self, '_nav_switching', False):
                return
            if getattr(self, '_calculation_busy', False) or getattr(self, '_export_busy', False):
                try:
                    self.status_var.set('Đang xử lý, vui lòng chờ hoàn tất trước khi đổi trang.')
                except Exception:
                    pass
                return
            index = max(0, min(3, int(index)))
            if index == getattr(self, '_current_top_page', 0):
                return
            self._nav_switching = True
            try:
                workflow.select(index)
                self._current_top_page = index
                _draw_nav()
            except Exception:
                pass
            finally:
                self._nav_switching = False

        self.show_top_page = show_page
        self._draw_top_nav = _draw_nav

        def on_workflow_changed(event=None):
            try:
                idx = workflow.index(workflow.select())
                changed = (idx != getattr(self, '_current_top_page', -1))
                self._current_top_page = idx
                if changed and not getattr(self, '_nav_switching', False):
                    _draw_nav()

                if 0 <= idx < len(page_canvases):
                    self.cut_main_canvas = page_canvases[idx]
                    self.cut_main_body = page_bodies[idx]
                    page_canvases[idx].configure(
                        scrollregion=page_canvases[idx].bbox('all')
                    )
                    page_canvases[idx].yview_moveto(0)
                else:
                    self.cut_main_canvas = None
                    self.cut_main_body = None

                self.root.after(30, self._apply_responsive_heights)
            except Exception:
                pass

        workflow.bind('<<NotebookTabChanged>>', on_workflow_changed)
        nav.bind('<Configure>', _draw_nav)

        # Cuộn chuột.
        self.root.bind_all('<MouseWheel>', self._on_global_mousewheel, add='+')
        self.root.bind_all('<Button-4>', self._on_global_mousewheel, add='+')
        self.root.bind_all('<Button-5>', self._on_global_mousewheel, add='+')
        self.root.bind('<Configure>', self._on_root_responsive_configure, add='+')

        # Khởi động ở Đơn hàng.
        try:
            workflow.select(0)
        except Exception:
            pass
        self.root.after(50, _draw_nav)
        self.root.after(100, self._apply_responsive_heights)
        # V150: bỏ quét theme đệ quy sau khi mở cửa sổ để tránh đứng UI trên máy chậm.

    def create_fabric_dashboard(self, parent):
        """V134: dashboard loại vải dạng bảng tối giản.

        - Chọn loại vải bên trái -> toàn bộ thông tin chỉnh sửa hiện ngay bên phải.
        - Các trường lựa chọn dùng Combobox có mũi tên xổ xuống.
        - Có TÍNH TOÀN BỘ và TÍNH LẠI RIÊNG loại đang chọn.
        - Bảng kết quả kẻ ô như Excel và tô màu giống mẫu người dùng chọn.
        """
        outer = tk.Frame(parent, bg=self.UI_BG)
        outer.pack(fill='both', expand=True, padx=8, pady=8)

        main = tk.Frame(outer, bg=self.UI_CARD, highlightthickness=1,
                        highlightbackground=self.UI_BORDER)
        main.pack(fill='both', expand=True)

        # ===== CỘT TRÁI: DANH SÁCH LOẠI VẢI =====
        left = tk.Frame(main, bg='#f8fafc', width=225,
                        highlightthickness=1, highlightbackground=self.UI_BORDER)
        left.pack(side='left', fill='y')
        left.pack_propagate(False)

        left_head = tk.Frame(left, bg='#f8fafc')
        left_head.pack(fill='x', padx=8, pady=(8, 5))
        tk.Label(left_head, text='LOẠI VẢI', font=('Segoe UI', 10, 'bold'),
                 fg=self.UI_NAVY, bg='#f8fafc').pack(side='left')
        tk.Button(left_head, text='+ THÊM', command=self._toggle_fabric_management,
                  font=('Segoe UI', 8, 'bold'), bg=self.UI_BLUE, fg='white',
                  activebackground='#115bb8', activeforeground='white',
                  relief='flat', bd=0, padx=8, pady=4, cursor='hand2').pack(side='right')

        self.fabric_calc_all_button = tk.Button(
            left, text='↻  TÍNH TOÀN BỘ', command=self.recalculate_all_fabrics_dashboard,
            font=('Segoe UI', 8, 'bold'), bg='#0f766e', fg='white',
            activebackground='#0b5f59', activeforeground='white', relief='flat', bd=0,
            padx=8, pady=5, cursor='hand2')
        self.fabric_calc_all_button.pack(fill='x', padx=8, pady=(0, 6))

        self.fabric_nav_tree = ttk.Treeview(left, show='tree', selectmode='browse', height=18)
        self.fabric_nav_tree.column('#0', width=198, minwidth=110, stretch=True, anchor='w')
        self.fabric_nav_tree.pack(fill='both', expand=True, padx=8, pady=(0, 8))
        self.fabric_nav_tree.bind('<<TreeviewSelect>>', self._on_fabric_nav_selected)

        # ===== CỘT PHẢI =====
        right = tk.Frame(main, bg=self.UI_CARD)
        right.pack(side='left', fill='both', expand=True)

        title_row = tk.Frame(right, bg=self.UI_CARD)
        title_row.pack(fill='x', padx=12, pady=(8, 4))
        self.fabric_dash_title_var = tk.StringVar(value='Thông tin loại vải')
        tk.Label(title_row, textvariable=self.fabric_dash_title_var,
                 font=('Segoe UI', 11, 'bold'), fg=self.UI_NAVY,
                 bg=self.UI_CARD).pack(side='left')
        self.fabric_dash_cache_var = tk.StringVar(value='Chưa tính')
        tk.Label(title_row, textvariable=self.fabric_dash_cache_var,
                 font=('Segoe UI', 8, 'bold'), fg=self.UI_MUTED,
                 bg=self.UI_CARD).pack(side='right', padx=(8, 0))

        # ===== THÔNG TIN CHỈNH SỬA TRỰC TIẾP =====
        edit_box = tk.Frame(right, bg='#f8fafc', highlightthickness=1,
                            highlightbackground=self.UI_BORDER)
        edit_box.pack(fill='x', padx=12, pady=(2, 6))
        for c in range(5):
            edit_box.grid_columnconfigure(c, weight=1, uniform='fabedit')

        self.fabric_dash_edit_vars = {
            'name': tk.StringVar(), 'mode': tk.StringVar(), 'optimizer': tk.StringVar(),
            'po': tk.StringVar(), 'lot': tk.StringVar(), 'norm': tk.StringVar(),
            'min': tk.StringVar(), 'max': tk.StringVar(), 'maxsp': tk.StringVar(),
            'balance_pct': tk.StringVar(value='1'),
            # V163: tùy chỉnh quy tắc chừa đầu tấm theo từng loại vải.
            # Mặc định: nếu phần dư sau khi trải tối đa < 1.00 m thì bớt 1 lá.
            'reserve_m': tk.StringVar(value='1'),
            'reserve_plies': tk.StringVar(value='1'),
            'export_roll': tk.StringVar(), 'export_edit': tk.StringVar(),
        }
        self.fabric_dash_edit_widgets = {}

        def add_entry(label, key, row, col):
            tk.Label(edit_box, text=label, font=('Segoe UI', 7), fg=self.UI_MUTED,
                     bg='#f8fafc', anchor='w').grid(row=row*2, column=col, sticky='ew', padx=6, pady=(5,0))
            e = tk.Entry(edit_box, textvariable=self.fabric_dash_edit_vars[key],
                         font=('Segoe UI', 9), relief='solid', bd=1)
            e.grid(row=row*2+1, column=col, sticky='ew', padx=6, pady=(1,5), ipady=3)
            # V140: chỉ đánh dấu đã sửa; KHÔNG tự lưu khi FocusOut.
            # Tự lưu/refresh lúc rời ô làm widget bị vẽ lại ngay dưới con trỏ,
            # nên người dùng có cảm giác lúc bấm sửa được, lúc không.
            e.bind('<KeyRelease>', lambda ev: self._mark_fabric_dashboard_dirty())
            e.bind('<Return>', lambda ev: self._apply_fabric_dashboard_editors())
            self.fabric_dash_edit_widgets[key] = e
            return e

        def add_combo(label, key, values, row, col, normal=False):
            tk.Label(edit_box, text=label, font=('Segoe UI', 7), fg=self.UI_MUTED,
                     bg='#f8fafc', anchor='w').grid(row=row*2, column=col, sticky='ew', padx=6, pady=(5,0))
            cb = ttk.Combobox(edit_box, textvariable=self.fabric_dash_edit_vars[key],
                              values=values, state='normal' if normal else 'readonly',
                              font=('Segoe UI', 9))
            cb.grid(row=row*2+1, column=col, sticky='ew', padx=6, pady=(1,5), ipady=2)
            # V140: chọn giá trị chỉ đánh dấu thay đổi, không tự refresh toàn dashboard.
            cb.bind('<<ComboboxSelected>>', lambda ev: self._mark_fabric_dashboard_dirty())
            cb.bind('<Return>', lambda ev: self._apply_fabric_dashboard_editors())
            self.fabric_dash_edit_widgets[key] = cb
            return cb

        add_entry('Tên loại vải', 'name', 0, 0)
        add_combo('Chế độ giác ▼', 'mode', self.FABRIC_MODE_VALUES, 0, 1)
        add_combo('Kiểu tối ưu ▼', 'optimizer', self.OPTIMIZER_VALUES, 0, 2)

        # V136: PO/LOT không dùng Combobox chọn 1 giá trị nữa.
        # Bấm vào ô/mũi tên sẽ mở danh sách CHECKBOX để tích nhiều PO/LOT.
        po_cb = add_combo('PO áp dụng ▼', 'po', ['TẤT CẢ PO'], 0, 3)
        lot_cb = add_combo('LOT áp dụng ▼', 'lot', ['KHÔNG DÙNG LOT', 'TẤT CẢ LOT'], 0, 4)
        for _cb, _kind in ((po_cb, 'po'), (lot_cb, 'lot')):
            _cb.configure(state='readonly')
            _cb.bind('<Button-1>',
                     lambda ev, k=_kind, w=_cb: self._open_dashboard_multi_select(k, w),
                     add=False)
            _cb.bind('<Return>',
                     lambda ev, k=_kind, w=_cb: self._open_dashboard_multi_select(k, w),
                     add=False)
            _cb.bind('<space>',
                     lambda ev, k=_kind, w=_cb: self._open_dashboard_multi_select(k, w),
                     add=False)

        add_entry('Định mức TB (m)', 'norm', 1, 0)
        add_entry('Chiều dài tối thiểu (m)', 'min', 1, 1)
        add_entry('Chiều dài tối đa (m)', 'max', 1, 2)
        add_entry('SP tối đa / sơ đồ', 'maxsp', 1, 3)
        add_combo('Xuất PHÂN CÂY ▼', 'export_roll', ['CÓ', 'KHÔNG'], 1, 4)

        add_combo('Cho sửa PHÂN CÂY ▼', 'export_edit', ['CÓ', 'KHÔNG'], 2, 0)
        add_combo('Âm/dương tối đa (%) ▼', 'balance_pct',
                  ['0', '0.5', '1', '1.5', '2', '3', '5'], 2, 1, normal=True)
        add_entry('Nếu đầu tấm còn dưới (m)', 'reserve_m', 2, 2)
        add_entry('Số lá để lại', 'reserve_plies', 2, 3)
        tk.Label(edit_box,
                 text='Đầu tấm: mặc định nếu phần dư < 1.00 m thì bớt 1 lá • PO/LOT: bấm ▼ để tích từng mục',
                 font=('Segoe UI', 7), fg=self.UI_MUTED, bg='#f8fafc', anchor='w').grid(
                     row=6, column=0, columnspan=4, sticky='ew', padx=6, pady=(3,0))
        tk.Button(edit_box, text='✓  LƯU THÔNG TIN', command=self._apply_fabric_dashboard_editors,
                  font=('Segoe UI', 8, 'bold'), bg='#475569', fg='white', relief='flat', bd=0,
                  padx=10, pady=4, cursor='hand2').grid(row=7, column=4, sticky='e', padx=6, pady=(1,5))

        # ===== THANH THAO TÁC =====
        actions = tk.Frame(right, bg=self.UI_CARD)
        actions.pack(fill='x', padx=12, pady=(0, 6))
        self.fabric_recalc_button = tk.Button(
            actions, text='↻  TÍNH LẠI LOẠI VẢI NÀY', command=self.recalculate_fabric_dashboard,
            font=('Segoe UI', 9, 'bold'), bg=self.UI_BLUE, fg='white',
            activebackground='#115bb8', activeforeground='white', relief='flat', bd=0,
            padx=14, pady=6, cursor='hand2')
        self.fabric_recalc_button.pack(side='left')

        self.fabric_add_table_button = tk.Button(
            actions, text='＋  THÊM BÀN', command=self._add_dashboard_table,
            font=('Segoe UI', 9, 'bold'), bg='#16a34a', fg='white',
            activebackground='#15803d', activeforeground='white',
            relief='flat', bd=0, padx=14, pady=6, cursor='hand2'
        )
        self.fabric_add_table_button.pack(side='left', padx=(6, 0))

        tk.Button(actions, text='⚙  QUẢN LÝ CHI TIẾT', command=self._toggle_fabric_management,
                  font=('Segoe UI', 8, 'bold'), bg='#64748b', fg='white',
                  activebackground='#526275', activeforeground='white', relief='flat', bd=0,
                  padx=12, pady=6, cursor='hand2').pack(side='left', padx=6)
        self.fabric_dash_note_var = tk.StringVar(
            value='TÍNH TOÀN BỘ một lần • Sau đó chỉ loại vải nào thay đổi mới cần TÍNH LẠI.')
        tk.Label(actions, textvariable=self.fabric_dash_note_var, font=('Segoe UI', 8),
                 fg=self.UI_MUTED, bg=self.UI_CARD, anchor='e').pack(side='right', fill='x', expand=True)

        # ===== BẢNG KẾT QUẢ KẺ Ô NHƯ EXCEL =====
        table_wrap = tk.Frame(right, bg=self.UI_CARD)
        table_wrap.pack(fill='both', expand=True, padx=12, pady=(0, 10))
        self.fabric_result_grid = tk.Frame(table_wrap, bg='#9aa4ad')
        self.fabric_result_grid.pack(fill='both', expand=True)

        # Khu quản lý cũ: giữ đầy đủ chức năng nâng cao nhưng mặc định ẩn.
        self.fabric_management_holder = tk.Frame(outer, bg=self.UI_BG)
        self.create_fabric_tab(self.fabric_management_holder)
        self._fabric_management_visible = False

        self._refresh_fabric_dashboard_list()

    def _toggle_fabric_management(self):
        holder = getattr(self, 'fabric_management_holder', None)
        if holder is None:
            return
        if bool(getattr(self, '_fabric_management_visible', False)):
            holder.pack_forget()
            self._fabric_management_visible = False
        else:
            holder.pack(fill='x', expand=False, pady=(8, 0))
            self._fabric_management_visible = True
            try:
                holder.update_idletasks()
                if hasattr(self, 'cut_main_canvas'):
                    self.cut_main_canvas.configure(scrollregion=self.cut_main_canvas.bbox('all'))
            except Exception:
                pass

    def _selected_dashboard_fabric_index(self):
        tree = getattr(self, 'fabric_nav_tree', None)
        if tree is None or not tree.selection():
            return None
        try:
            idx = int(str(tree.selection()[0]).replace('fabric_', ''))
            return idx if 0 <= idx < len(self.fabric_list) else None
        except Exception:
            return None

    def _refresh_fabric_dashboard_list(self, select_index=None):
        tree = getattr(self, 'fabric_nav_tree', None)
        if tree is None:
            return
        old_idx = self._selected_dashboard_fabric_index()
        for item in tree.get_children():
            tree.delete(item)
        for i, fabric in enumerate(self.fabric_list):
            cached = self._dashboard_cached_result(i)
            raw_item = getattr(self, '_fabric_preview_cache', {}).get(i)
            has_old = isinstance(raw_item, dict) and raw_item.get('result') is not None
            if cached is not None:
                mark = '✓ '
            elif has_old:
                mark = '⚠ '
            else:
                mark = '  '
            tree.insert('', 'end', iid=f'fabric_{i}', text=mark + str(fabric.get('name','')))
        idx = select_index if select_index is not None else old_idx
        if idx is None and self.fabric_list:
            idx = 0
        if idx is not None and 0 <= idx < len(self.fabric_list):
            iid = f'fabric_{idx}'
            try:
                tree.selection_set(iid); tree.focus(iid); tree.see(iid)
            except Exception:
                pass
            self._show_fabric_dashboard(idx)
        elif not self.fabric_list:
            self._clear_fabric_dashboard()

    def _on_fabric_nav_selected(self, event=None):
        idx = self._selected_dashboard_fabric_index()
        if idx is None:
            return
        if hasattr(self, 'fabric_tree'):
            children = self.fabric_tree.get_children()
            if idx < len(children):
                item = children[idx]
                try:
                    self.fabric_tree.selection_set(item); self.fabric_tree.focus(item)
                except Exception:
                    pass
        self._show_fabric_dashboard(idx)
        try:
            self._refresh_lot_fabric_combo(select_index=idx)
            self.refresh_lot_table()
        except Exception:
            pass

    def _current_plan_cache_key_for_dashboard(self):
        try:
            payload = {
                'sizes': self.sizes,
                'po_list': self.po_list,
                'fabric_list': self.fabric_list,
                'global_lot_rows': self.global_lot_rows,
                'increase_enabled': bool(self.increase_enabled_var.get()),
                'increase_mode': str(self.increase_mode_var.get()),
                'max_over': int(self.MAX_OVER),
            }
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
        except Exception:
            return None

    def _single_fabric_cache_key(self, idx):
        if not (0 <= idx < len(self.fabric_list)):
            return None
        try:
            payload = {
                'idx': idx, 'sizes': self.sizes, 'po_list': self.po_list,
                'fabric': self.fabric_list[idx], 'global_lot_rows': self.global_lot_rows,
                'increase_enabled': bool(self.increase_enabled_var.get()),
                'increase_mode': str(self.increase_mode_var.get()), 'max_over': int(self.MAX_OVER),
            }
            return json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
        except Exception:
            return None

    def _dashboard_cached_result(self, idx):
        if not (0 <= idx < len(self.fabric_list)):
            return None
        key = self._single_fabric_cache_key(idx)
        item = getattr(self, '_fabric_preview_cache', {}).get(idx)
        if isinstance(item, dict) and item.get('key') == key and item.get('result') is not None:
            return item.get('result')
        global_key = self._current_plan_cache_key_for_dashboard()
        if global_key is None or global_key != getattr(self, '_cut_plan_cache_key', None):
            return None
        results = getattr(self, '_cut_plan_cache_results', None)
        if not isinstance(results, list) or idx >= len(results):
            return None
        return results[idx]

    def _snapshot_dashboard_results(self, exclude_idx=None):
        """V139: giữ nguyên kết quả đã tính của các loại vải khác.

        Khi tính lại 1 loại vải, một số bước đồng bộ LOT có thể làm thay đổi
        cache-key chung. Vì vậy cần chụp kết quả thực tế trước khi cập nhật loại
        đang chọn, rồi gắn lại key mới cho các loại còn lại sau khi tính xong.
        """
        saved = {}
        preview_cache = getattr(self, '_fabric_preview_cache', {}) or {}
        global_results = getattr(self, '_cut_plan_cache_results', None)

        for i in range(len(self.fabric_list)):
            if exclude_idx is not None and i == exclude_idx:
                continue

            result = None

            # Ưu tiên kết quả từng loại đã lưu riêng, kể cả key cũ.
            item = preview_cache.get(i)
            if isinstance(item, dict) and item.get('result') is not None:
                result = item.get('result')

            # Nếu chưa có cache riêng, lấy từ cache toàn bộ gần nhất.
            if result is None and isinstance(global_results, list) and i < len(global_results):
                result = global_results[i]

            if result is not None:
                saved[i] = result

        return saved

    def _restore_dashboard_results(self, saved, exclude_idx=None):
        """V139: ghi lại kết quả các loại khác với cache-key hiện tại."""
        if not isinstance(saved, dict):
            return
        for i, result in saved.items():
            if exclude_idx is not None and i == exclude_idx:
                continue
            if 0 <= i < len(self.fabric_list) and result is not None:
                self._cache_dashboard_result(i, result)

    def _cache_dashboard_result(self, idx, result):
        if not hasattr(self, '_fabric_preview_cache') or not isinstance(self._fabric_preview_cache, dict):
            self._fabric_preview_cache = {}
        key = self._single_fabric_cache_key(idx)
        self._fabric_preview_cache[idx] = {'key': key, 'result': result}

    def _promote_individual_cache_to_global(self):
        if not self.fabric_list:
            return
        results = []
        for i in range(len(self.fabric_list)):
            r = self._dashboard_cached_result(i)
            if r is None:
                return
            results.append(r)
        key = self._current_plan_cache_key_for_dashboard()
        if key is not None:
            self._cut_plan_cache_key = key
            self._cut_plan_cache_results = results

    def _clear_fabric_dashboard(self):
        if hasattr(self, 'fabric_dash_title_var'):
            self.fabric_dash_title_var.set('Thông tin loại vải')
        if hasattr(self, 'fabric_dash_cache_var'):
            self.fabric_dash_cache_var.set('Chưa chọn')
        for var in getattr(self, 'fabric_dash_edit_vars', {}).values():
            var.set('')
        self._render_fabric_result_grid(None)

    def _open_dashboard_multi_select(self, kind, widget=None):
        """V136: dropdown CHECKBOX nhiều lựa chọn cho PO áp dụng / LOT áp dụng.

        Bấm vào ô PO hoặc LOT trên dashboard sẽ mở một bảng nhỏ ngay dưới ô.
        Có thể tích nhiều mục rồi bấm ÁP DỤNG.
        """
        idx = self._selected_dashboard_fabric_index()
        if idx is None or not (0 <= idx < len(self.fabric_list)):
            return 'break'

        # Đóng popup cũ nếu còn.
        old = getattr(self, '_dashboard_multi_popup', None)
        if old is not None:
            try:
                if old.winfo_exists():
                    old.destroy()
            except Exception:
                pass

        fabric = self.fabric_list[idx]
        top = tk.Toplevel(self.root)
        self._dashboard_multi_popup = top
        top.overrideredirect(True)
        top.transient(self.root)
        top.configure(bg='white')
        # V138: popup luôn nổi trên cửa sổ chính, không bị giao diện che mất.
        try:
            top.attributes('-topmost', True)
        except Exception:
            pass
        try:
            top.lift()
        except Exception:
            pass

        try:
            if widget is not None:
                x = widget.winfo_rootx()
                y = widget.winfo_rooty() + widget.winfo_height()
                width = max(340, widget.winfo_width() + 70)
            else:
                x = self.root.winfo_rootx() + 320
                y = self.root.winfo_rooty() + 180
                width = 360
        except Exception:
            x, y, width = 320, 180, 360

        body = tk.Frame(top, bg='white', bd=2, relief='solid',
                        highlightthickness=2, highlightbackground='#1769d2')
        body.pack(fill='both', expand=True)

        title = 'TÍCH PO ÁP DỤNG' if kind == 'po' else 'TÍCH LOT ÁP DỤNG'
        tk.Label(body, text=title, font=('Segoe UI', 10, 'bold'),
                 bg='#eaf2ff', fg='#123b68', anchor='w',
                 padx=12, pady=8).pack(fill='x')

        # Danh sách có cuộn dọc để PO/LOT nhiều vẫn dùng được.
        list_wrap = tk.Frame(body, bg='white')
        list_wrap.pack(fill='both', expand=True)
        canvas = tk.Canvas(list_wrap, bg='white', highlightthickness=0,
                           width=width, height=280)
        scroll = ttk.Scrollbar(list_wrap, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)

        inner = tk.Frame(canvas, bg='white')
        win = canvas.create_window((0, 0), window=inner, anchor='nw')

        def _resize_inner(event=None):
            try:
                canvas.configure(scrollregion=canvas.bbox('all'))
                if event is not None:
                    canvas.itemconfigure(win, width=event.width)
            except Exception:
                pass
        inner.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', _resize_inner)

        # Cho lăn chuột trong popup.
        def _wheel(event):
            try:
                delta = int(getattr(event, 'delta', 0) or 0)
                if delta:
                    canvas.yview_scroll(-1 if delta > 0 else 1, 'units')
                elif getattr(event, 'num', None) == 4:
                    canvas.yview_scroll(-1, 'units')
                elif getattr(event, 'num', None) == 5:
                    canvas.yview_scroll(1, 'units')
                return 'break'
            except Exception:
                return
        canvas.bind('<MouseWheel>', _wheel)
        canvas.bind('<Button-4>', _wheel)
        canvas.bind('<Button-5>', _wheel)
        inner.bind('<MouseWheel>', _wheel)

        if kind == 'po':
            names = []
            for po in self.po_list:
                n = str(po.get('po', '') or '').strip()
                if n and n not in names:
                    names.append(n)

            mode = str(fabric.get('po_mode', 'all') or 'all').lower()
            selected = set(self._fabric_po_names(fabric)) if mode != 'all' else set()
            all_var = tk.BooleanVar(value=(mode == 'all'))
            vars_map = {n: tk.BooleanVar(value=(n in selected)) for n in names}

            def all_toggle():
                if all_var.get():
                    for v in vars_map.values():
                        v.set(False)

            tk.Checkbutton(
                inner, text='TẤT CẢ PO', variable=all_var, command=all_toggle,
                font=('Segoe UI', 10, 'bold'), bg='white', fg='#145da0',
                activebackground='white', anchor='w', cursor='hand2'
            ).pack(fill='x', anchor='w', padx=12, pady=(8, 4), ipady=2)

            for n in names:
                def one_toggle(name=n):
                    if vars_map[name].get():
                        all_var.set(False)
                cb = tk.Checkbutton(
                    inner, text=n, variable=vars_map[n], command=one_toggle,
                    font=('Segoe UI', 10), bg='white', activebackground='white',
                    anchor='w', cursor='hand2'
                )
                cb.pack(fill='x', anchor='w', padx=(24, 10), pady=3, ipady=2)
                cb.bind('<MouseWheel>', _wheel)

            def apply_choice():
                if all_var.get():
                    fabric['po_mode'] = 'all'
                    fabric['po_targets'] = []
                else:
                    picks = [n for n, var in vars_map.items() if var.get()]
                    if not picks:
                        messagebox.showwarning(
                            'PO áp dụng',
                            'Hãy tích ít nhất 1 PO hoặc chọn TẤT CẢ PO!',
                            parent=top
                        )
                        return
                    fabric['po_mode'] = 'selected'
                    fabric['po_targets'] = picks
                self.fabric_dash_edit_vars['po'].set(self._fabric_po_display(fabric))
                _finish_apply('PO')

        else:
            names = []
            for row in getattr(self, 'global_lot_rows', []) or []:
                n = str(row.get('lot', '') or '').strip()
                if n and n not in names:
                    names.append(n)

            mode = str(fabric.get('lot_mode', 'none') or 'none').lower()
            selected = set(self._fabric_lot_names(fabric)) if mode == 'selected' else set()
            none_var = tk.BooleanVar(value=(mode == 'none'))
            all_var = tk.BooleanVar(value=(mode == 'all'))
            vars_map = {n: tk.BooleanVar(value=(n in selected)) for n in names}

            def none_toggle():
                if none_var.get():
                    all_var.set(False)
                    for v in vars_map.values():
                        v.set(False)

            def all_toggle():
                if all_var.get():
                    none_var.set(False)
                    for v in vars_map.values():
                        v.set(False)

            tk.Checkbutton(
                inner, text='KHÔNG DÙNG LOT', variable=none_var, command=none_toggle,
                font=('Segoe UI', 10, 'bold'), bg='white', fg='#c0392b',
                activebackground='white', anchor='w', cursor='hand2'
            ).pack(fill='x', anchor='w', padx=12, pady=(8, 3), ipady=2)

            tk.Checkbutton(
                inner, text='TẤT CẢ LOT', variable=all_var, command=all_toggle,
                font=('Segoe UI', 10, 'bold'), bg='white', fg='#6d28d9',
                activebackground='white', anchor='w', cursor='hand2'
            ).pack(fill='x', anchor='w', padx=12, pady=(3, 4), ipady=2)

            for n in names:
                def one_toggle(name=n):
                    if vars_map[name].get():
                        none_var.set(False)
                        all_var.set(False)
                cb = tk.Checkbutton(
                    inner, text=n, variable=vars_map[n], command=one_toggle,
                    font=('Segoe UI', 10), bg='white', activebackground='white',
                    anchor='w', cursor='hand2'
                )
                cb.pack(fill='x', anchor='w', padx=(24, 10), pady=3, ipady=2)
                cb.bind('<MouseWheel>', _wheel)

            def apply_choice():
                if none_var.get():
                    fabric['lot_mode'] = 'none'
                    fabric['lot_targets'] = []
                elif all_var.get():
                    fabric['lot_mode'] = 'all'
                    fabric['lot_targets'] = []
                else:
                    picks = [n for n, var in vars_map.items() if var.get()]
                    if picks:
                        fabric['lot_mode'] = 'selected'
                        fabric['lot_targets'] = picks
                    else:
                        fabric['lot_mode'] = 'none'
                        fabric['lot_targets'] = []
                self.fabric_dash_edit_vars['lot'].set(self._fabric_lot_display(fabric))
                _finish_apply('LOT')

        def _close_popup():
            try:
                top.grab_release()
            except Exception:
                pass
            try:
                top.destroy()
            except Exception:
                pass

        def _finish_apply(label):
            # V140: PO/LOT đổi thì kết quả cũ của loại này trở thành "chưa tính lại",
            # nhưng vẫn giữ để hiển thị cho đến khi người dùng bấm TÍNH LẠI.
            self._cut_plan_cache_key = None
            self._cut_plan_cache_results = None
            try:
                self._sync_global_lots()
                self.update_fabric_table(select_index=idx)
                self._refresh_lot_fabric_combo(select_index=idx)
            except Exception:
                pass
            _close_popup()
            self._refresh_fabric_dashboard_list(select_index=idx)
            self.status_var.set(
                f"{fabric.get('name','')}: đã cập nhật {label} áp dụng. "
                "Bấm TÍNH LẠI loại vải này nếu cần."
            )

        btn_row = tk.Frame(body, bg='#f8fafc')
        btn_row.pack(fill='x')
        tk.Button(
            btn_row, text='✓ ÁP DỤNG', command=apply_choice,
            font=('Segoe UI', 9, 'bold'), bg='#16a34a', fg='white',
            activebackground='#15803d', activeforeground='white',
            relief='flat', bd=0, padx=18, pady=7, cursor='hand2'
        ).pack(side='right', padx=(4, 7), pady=6)
        tk.Button(
            btn_row, text='HỦY', command=_close_popup,
            font=('Segoe UI', 9, 'bold'), bg='#64748b', fg='white',
            activebackground='#475569', activeforeground='white',
            relief='flat', bd=0, padx=18, pady=7, cursor='hand2'
        ).pack(side='right', padx=4, pady=6)

        # V138: popup lớn hơn và luôn nằm trọn trong màn hình.
        item_count = len(names) + (1 if kind == 'po' else 2)
        list_h = min(360, max(120, 42 + item_count * 34))
        total_h = list_h + 94
        canvas.configure(height=list_h)

        try:
            screen_w = int(top.winfo_screenwidth())
            screen_h = int(top.winfo_screenheight())
            margin = 12
            width = min(max(340, int(width)), max(340, screen_w - margin * 2))
            total_h = min(total_h, max(220, screen_h - margin * 2))

            # Nếu bên dưới không đủ chỗ thì bung lên phía trên ô.
            if y + total_h > screen_h - margin and widget is not None:
                y = widget.winfo_rooty() - total_h
            x = max(margin, min(int(x), screen_w - width - margin))
            y = max(margin, min(int(y), screen_h - total_h - margin))
        except Exception:
            pass

        top.geometry(f'{width}x{total_h}+{x}+{y}')
        top.bind('<Escape>', lambda e: _close_popup())
        top.grab_set()
        try:
            top.lift()
            top.focus_force()
        except Exception:
            pass
        return 'break'

    def _refresh_dashboard_combo_values(self, idx):
        widgets = getattr(self, 'fabric_dash_edit_widgets', {})
        po_cb = widgets.get('po')
        lot_cb = widgets.get('lot')
        if po_cb is not None:
            vals = ['TẤT CẢ PO'] + [str(x.get('po','')).strip() for x in self.po_list if str(x.get('po','')).strip()]
            cur = self._fabric_po_display(self.fabric_list[idx]) if 0 <= idx < len(self.fabric_list) else ''
            if cur and cur not in vals: vals.append(cur)
            po_cb['values'] = vals
        if lot_cb is not None:
            names = []
            for row in getattr(self, 'global_lot_rows', []) or []:
                n = str(row.get('lot','')).strip()
                if n and n not in names: names.append(n)
            vals = ['KHÔNG DÙNG LOT', 'TẤT CẢ LOT'] + names
            cur = self._fabric_lot_display(self.fabric_list[idx]) if 0 <= idx < len(self.fabric_list) else ''
            if cur and cur not in vals: vals.append(cur)
            lot_cb['values'] = vals

    def _load_fabric_dashboard_editors(self, idx):
        if not (0 <= idx < len(self.fabric_list)):
            return
        fabric = self.fabric_list[idx]
        self._refresh_dashboard_combo_values(idx)
        v = self.fabric_dash_edit_vars
        v['name'].set(str(fabric.get('name','')))
        v['mode'].set(self.FABRIC_MODE_LABELS.get(
            self._fabric_mode_key_from_label(fabric.get('cut_mode','auto')), 'TỰ ĐỘNG'))
        v['optimizer'].set(self.OPTIMIZER_LABELS.get(
            self._optimizer_mode_key_from_label(fabric.get('optimizer_mode','global')), 'TOÀN CỤC'))
        v['po'].set(self._fabric_po_display(fabric))
        v['lot'].set(self._fabric_lot_display(fabric))
        v['norm'].set(f"{float(fabric.get('norm',0) or 0):.4f}".rstrip('0').rstrip('.'))
        v['min'].set(f"{float(fabric.get('min_length',0) or 0):.2f}".rstrip('0').rstrip('.'))
        mx = float(fabric.get('max_length',0) or 0)
        v['max'].set(f"{mx:.2f}".rstrip('0').rstrip('.') if mx else '0')
        v['maxsp'].set(str(int(fabric.get('max_products',0) or 0)))
        _bp = float(fabric.get('balance_pct', 1.0) if fabric.get('balance_pct', 1.0) is not None else 1.0)
        v['balance_pct'].set(f"{_bp:.3f}".rstrip('0').rstrip('.') if abs(_bp) > 1e-12 else '0')
        _reserve_m, _reserve_plies = self._fabric_roll_reserve_settings(fabric)
        v['reserve_m'].set(f"{_reserve_m:.3f}".rstrip('0').rstrip('.') if abs(_reserve_m) > 1e-12 else '0')
        v['reserve_plies'].set(str(int(_reserve_plies)))
        v['export_roll'].set('CÓ' if bool(fabric.get('export_roll', True)) else 'KHÔNG')
        v['export_edit'].set('CÓ' if bool(fabric.get('export_edit', True)) else 'KHÔNG')

    def _mark_fabric_dashboard_dirty(self):
        """V140: chỉ báo dữ liệu đang sửa, không xóa/refresh bàn đã tính."""
        idx = self._selected_dashboard_fabric_index()
        if idx is None:
            return
        try:
            self.fabric_dash_cache_var.set('● ĐANG SỬA - CHƯA LƯU')
            self.fabric_dash_note_var.set(
                'Thông tin đang được chỉnh sửa • Bảng phía dưới vẫn giữ kết quả cũ. '
                'Bấm LƯU THÔNG TIN hoặc TÍNH LẠI khi sửa xong.'
            )
        except Exception:
            pass

    def _apply_fabric_dashboard_editors(self, silent=False):
        idx = self._selected_dashboard_fabric_index()
        if idx is None:
            return False
        fabric = self.fabric_list[idx]
        v = self.fabric_dash_edit_vars
        try:
            name = v['name'].get().strip()
            if not name:
                raise ValueError('Tên loại vải không được để trống.')
            norm = float(v['norm'].get().strip().replace(',', '.'))
            min_len = float((v['min'].get().strip() or '0').replace(',', '.'))
            max_len = float((v['max'].get().strip() or '0').replace(',', '.'))
            maxsp = int(float((v['maxsp'].get().strip() or '0').replace(',', '.')))
            balance_pct = float((v['balance_pct'].get().strip() or '1').replace(',', '.'))
            reserve_m = float((v['reserve_m'].get().strip() or '1').replace(',', '.'))
            reserve_plies = int(float((v['reserve_plies'].get().strip() or '1').replace(',', '.')))
            if norm <= 0: raise ValueError('Định mức TB phải lớn hơn 0.')
            if min_len < 0 or max_len < 0 or maxsp < 0: raise ValueError('Các giới hạn không được âm.')
            if balance_pct < 0 or balance_pct > 100:
                raise ValueError('% âm/dương phải nằm trong khoảng 0 đến 100.')
            if reserve_m < 0:
                raise ValueError('Mét đầu tấm không được âm.')
            if reserve_plies < 1:
                raise ValueError('Số lá để lại phải từ 1 lá trở lên.')
            if max_len <= 0 and maxsp <= 0: raise ValueError('Cần nhập Chiều dài tối đa hoặc SP tối đa/sơ đồ.')
            if max_len > 0 and min_len > max_len + 1e-9: raise ValueError('Chiều dài tối thiểu không được lớn hơn tối đa.')
            po_mode, po_targets = self._parse_fabric_po_text(v['po'].get())
            lot_mode, lot_targets = self._parse_fabric_lot_text(v['lot'].get())
            fabric.update({
                'name': name,
                'cut_mode': self._fabric_mode_key_from_label(v['mode'].get()),
                'optimizer_mode': self._optimizer_mode_key_from_label(v['optimizer'].get()),
                'po_mode': po_mode, 'po_targets': list(po_targets),
                'lot_mode': lot_mode, 'lot_targets': list(lot_targets),
                'norm': norm, 'min_length': min_len, 'max_length': max_len,
                'max_products': maxsp,
                'balance_pct': balance_pct,
                'reserve_m': reserve_m,
                'reserve_plies': reserve_plies,
                'export_roll': str(v['export_roll'].get()).strip().upper() != 'KHÔNG',
                'export_edit': str(v['export_edit'].get()).strip().upper() != 'KHÔNG',
            })
        except Exception as e:
            if not silent:
                messagebox.showerror('Thông tin loại vải', str(e))
            return False

        # V140: KHÔNG xóa kết quả bàn cũ của loại đang sửa.
        # Key của loại đã thay đổi nên kết quả này tự trở thành "cũ/chưa tính lại",
        # nhưng vẫn được giữ để hiển thị cho người dùng đối chiếu.
        self._cut_plan_cache_key = None
        self._cut_plan_cache_results = None
        try:
            self.update_fabric_table(select_index=idx)
            self._refresh_lot_fabric_combo(select_index=idx)
        except Exception:
            pass
        self._refresh_fabric_dashboard_list(select_index=idx)
        if not silent:
            self.status_var.set(f"Đã cập nhật thông tin: {fabric.get('name','')}. Bấm TÍNH LẠI loại này nếu cần.")
        return True

    def _format_ratio_map_dashboard(self, ratio_map):
        """V156: định dạng tỉ lệ theo thứ tự size hiện tại, ví dụ S/1 + M/2 + L/1."""
        order = {s.get('key'): i for i, s in enumerate(self.sizes)}
        names = {s.get('key'): str(s.get('name', s.get('key', ''))) for s in self.sizes}
        rm = {
            k: int(v or 0)
            for k, v in (ratio_map or {}).items()
            if int(v or 0) > 0
        }
        parts = []
        for k in sorted(rm, key=lambda x: order.get(x, 10**9)):
            parts.append(f"{names.get(k, k)}/{rm[k]}")
        return ' + '.join(parts)

    def _parse_ratio_text_dashboard(self, text_value):
        """V156: đọc tỉ lệ người dùng gõ trên dashboard.

        Hỗ trợ:
          S/1 + M/2 + L/1
          S:1, M:2, L:1
          S*1 | M*2 | L*1
          M            -> hiểu M/1
        """
        raw = str(text_value or '').strip()
        if not raw:
            raise ValueError('Tỉ lệ sơ đồ không được để trống.')

        name_to_key = {}
        for s in self.sizes:
            name = str(s.get('name', '') or '').strip()
            key = s.get('key')
            if name and key:
                name_to_key[name.casefold()] = key

        # Cho phép nhiều kiểu dấu phân cách.
        normalized = raw.replace('＋', '+').replace('×', '*')
        parts = [
            p.strip()
            for p in re.split(r'\s*(?:\+|,|;|\|)\s*', normalized)
            if p.strip()
        ]
        if not parts:
            raise ValueError('Không đọc được tỉ lệ sơ đồ.')

        ratio_map = {}
        for part in parts:
            m = re.match(r'^(.*?)\s*(?:/|:|\*|x|X)\s*(\d+)\s*$', part)
            if m:
                size_name = m.group(1).strip()
                ratio = int(m.group(2))
            else:
                size_name = part.strip()
                ratio = 1

            key = name_to_key.get(size_name.casefold())
            if key is None:
                raise ValueError(
                    f"Không tìm thấy size '{size_name}'. "
                    "Hãy nhập đúng tên size đang có trong đơn hàng."
                )
            if ratio <= 0:
                raise ValueError(f"Tỉ lệ của size {size_name} phải lớn hơn 0.")
            ratio_map[key] = int(ratio_map.get(key, 0)) + ratio

        if not ratio_map:
            raise ValueError('Tỉ lệ sơ đồ không hợp lệ.')
        return ratio_map

    def _rebuild_tables_after_ratio_edit_dashboard(self, idx, result, edited_table_index, new_ratio_map):
        """V161: sửa TỈ LỆ chỉ làm thay đổi BÀN ĐANG SỬA.

        Quy tắc:
        - Các bàn khác GIỮ NGUYÊN số lá và sản lượng.
        - Bàn đang sửa:
            + Chiều dài = Định mức TB × tổng tỉ lệ mới.
            + Số lá = số lá cần để bù phần sản lượng còn thiếu,
              sau khi đã trừ sản lượng của TẤT CẢ các bàn khác.
        - Không chạy chia lại số lá từ B1 -> B cuối.

        Ví dụ:
        B6 đang S/3 x 10 lá = 30 SP.
        Các bàn B1-B5 đã có 327 SP S, kế hoạch S = 356.
        Đổi B6 thành S/1 -> B6 tự thành 29 lá, B1-B5 giữ nguyên.
        """
        if not (0 <= idx < len(self.fabric_list)):
            raise ValueError('Không tìm thấy loại vải đang chọn.')

        fabric = self.fabric_list[idx]
        norm = float(fabric.get('norm', 0) or 0)
        if norm <= 0:
            raise ValueError('Định mức TB phải lớn hơn 0.')

        max_len = float(fabric.get('max_length', 0) or 0)
        max_products = int(fabric.get('max_products', 0) or 0)

        required = {
            k: int(v or 0)
            for k, v in (result.get('total_by_size', {}) or {}).items()
        }
        size_keys = [s.get('key') for s in self.sizes]
        size_names = {
            s.get('key'): str(s.get('name', s.get('key', '')))
            for s in self.sizes
        }

        old_tables = list(result.get('cutting_tables', []) or [])
        if not (0 <= edited_table_index < len(old_tables)):
            raise ValueError('Không tìm thấy bàn cần sửa.')

        # Copy sâu các phần cần chỉnh.
        tables = []
        for tb in old_tables:
            nt = dict(tb)
            nt['ratio_map'] = dict(tb.get('ratio_map', {}) or {})
            nt['sizes'] = dict(tb.get('sizes', {}) or {})
            tables.append(nt)

        # Chỉ thay tỉ lệ bàn được sửa.
        tables[edited_table_index]['ratio_map'] = dict(new_ratio_map)

        # Chuẩn hóa tỉ lệ + chiều dài.
        for i, tb in enumerate(tables):
            rm = {
                k: int(v or 0)
                for k, v in (tb.get('ratio_map', {}) or {}).items()
                if int(v or 0) > 0
            }
            if not rm:
                raise ValueError(f"Bàn {i+1} không có size nào.")

            ratio_total = sum(rm.values())
            raw_len = float(norm) * float(ratio_total)

            if max_len > 0 and raw_len > max_len + 1e-9:
                raise ValueError(
                    f"Bàn {i+1}: chiều dài tự tính {raw_len:.2f}m "
                    f"vượt tối đa {max_len:.2f}m."
                )
            if max_products > 0 and ratio_total > max_products:
                raise ValueError(
                    f"Bàn {i+1}: tổng tỉ lệ {ratio_total} vượt "
                    f"SP tối đa/sơ đồ ({max_products})."
                )

            tb['ratio_map'] = rm
            tb['ratio'] = self._format_ratio_map_dashboard(rm)
            tb['raw_length'] = raw_len
            tb['length'] = raw_len
            tb['meter_rate'] = raw_len / max(1, ratio_total)
            tb['size_count'] = len(rm)

        # ==========================================================
        # V161: KHÓA TOÀN BỘ BÀN KHÁC.
        # Chúng giữ nguyên số lá; chỉ đồng bộ lại sizes = ratio × lá.
        # ==========================================================
        actual_other = {k: 0 for k in size_keys}

        for i, tb in enumerate(tables):
            if i == edited_table_index:
                continue

            plies = max(0, int(tb.get('plies', 0) or 0))
            tb['plies'] = plies

            rm = tb.get('ratio_map', {}) or {}
            sizes = {}
            for k, ratio in rm.items():
                qty = int(ratio or 0) * plies
                if qty > 0:
                    sizes[k] = qty
                    actual_other[k] = int(actual_other.get(k, 0) or 0) + qty

            tb['sizes'] = sizes
            tb['total_output'] = sum(sizes.values())

        # ==========================================================
        # TÍNH RIÊNG SỐ LÁ BÀN ĐANG SỬA.
        # Cần bao nhiêu sản lượng sau khi trừ tất cả bàn khác?
        # ==========================================================
        edited = tables[edited_table_index]
        edited_rm = edited.get('ratio_map', {}) or {}

        residual = {
            k: max(
                0,
                int(required.get(k, 0) or 0)
                - int(actual_other.get(k, 0) or 0)
            )
            for k in size_keys
        }

        # Nếu một cỡ còn thiếu nhưng tỉ lệ bàn sửa không chứa cỡ đó,
        # thì không thể sửa riêng bàn này mà vẫn đủ sản lượng.
        impossible = {
            k: qty
            for k, qty in residual.items()
            if qty > 0 and int(edited_rm.get(k, 0) or 0) <= 0
        }
        if impossible:
            detail = ', '.join(
                f"{size_names.get(k, k)} thiếu {v}"
                for k, v in impossible.items()
            )
            raise ValueError(
                "Tỉ lệ mới làm thiếu sản lượng ở cỡ không có trong bàn đang sửa: "
                + detail
                + ". Hãy thêm cỡ đó vào tỉ lệ bàn này hoặc sửa một bàn khác."
            )

        needed_plies = []
        for k, ratio in edited_rm.items():
            ratio = int(ratio or 0)
            need = int(residual.get(k, 0) or 0)
            if ratio > 0 and need > 0:
                needed_plies.append(
                    int(math.ceil(float(need) / float(ratio)))
                )

        # Nếu các bàn khác đã đủ toàn bộ cỡ của bàn này thì bàn sửa = 0 lá.
        new_plies = max(needed_plies) if needed_plies else 0
        new_plies = max(0, int(new_plies))
        edited['plies'] = new_plies

        edited_sizes = {}
        for k, ratio in edited_rm.items():
            qty = int(ratio or 0) * new_plies
            if qty > 0:
                edited_sizes[k] = qty
        edited['sizes'] = edited_sizes
        edited['total_output'] = sum(edited_sizes.values())

        # Tổng sản lượng cuối sau khi ghép lại bàn sửa + các bàn khóa.
        actual = dict(actual_other)
        for k, qty in edited_sizes.items():
            actual[k] = int(actual.get(k, 0) or 0) + int(qty or 0)

        missing = {
            k: max(
                0,
                int(required.get(k, 0) or 0)
                - int(actual.get(k, 0) or 0)
            )
            for k in size_keys
        }
        missing = {k: v for k, v in missing.items() if v > 0}

        if missing:
            detail = ', '.join(
                f"{size_names.get(k, k)} thiếu {v}"
                for k, v in missing.items()
            )
            raise ValueError(
                "Tỉ lệ mới vẫn chưa đủ sản lượng: " + detail + "."
            )

        # Cập nhật thông tin thống kê theo đúng thứ tự bàn,
        # nhưng KHÔNG thay đổi số lá của các bàn khác.
        cumulative = {k: 0 for k in size_keys}
        for i, tb in enumerate(tables, start=1):
            tb['table'] = f'B{i}'
            for k, qty in (tb.get('sizes', {}) or {}).items():
                cumulative[k] = int(cumulative.get(k, 0) or 0) + int(qty or 0)

            tb['left_total'] = sum(
                max(
                    0,
                    int(required.get(k, 0) or 0)
                    - int(cumulative.get(k, 0) or 0)
                )
                for k in size_keys
            )
            tb['over_total'] = sum(
                max(
                    0,
                    int(cumulative.get(k, 0) or 0)
                    - int(required.get(k, 0) or 0)
                )
                for k in size_keys
            )

        # LOT/phân cây chạy lại vì bàn sửa đã đổi chiều dài/số lá.
        preview_tables, lot_summary = self.allocate_lots_to_tables(
            fabric, tables
        )

        new_result = dict(result)
        new_result['cutting_tables'] = tables
        new_result['preview_tables'] = preview_tables
        new_result['lot_summary'] = lot_summary
        new_result['manual_ratio_edit'] = True
        new_result['manual_ratio_lock_other_tables'] = True

        info = dict(new_result.get('adjust_info', {}) or {})
        info['manual_ratio_edit'] = True
        info['manual_ratio_lock_other_tables'] = True
        info['optimizer_strategy'] = 'manual_ratio_locked'
        new_result['adjust_info'] = info

        return new_result


    def _apply_dashboard_ratio_edit(self, idx, table_index, value):
        """V161: áp dụng ô tỉ lệ vừa sửa rồi refresh chiều dài/số lá ngay."""
        if getattr(self, '_dashboard_ratio_edit_busy', False):
            return
        self._dashboard_ratio_edit_busy = True
        try:
            result = self._dashboard_cached_result(idx)
            if result is None:
                raise ValueError(
                    'Kết quả hiện tại đã cũ. Hãy TÍNH LẠI loại vải này trước khi sửa tỉ lệ.'
                )

            new_ratio_map = self._parse_ratio_text_dashboard(value)

            old_tables = result.get('cutting_tables', []) or []
            if 0 <= table_index < len(old_tables):
                old_ratio_map = {
                    k: int(v or 0)
                    for k, v in (old_tables[table_index].get('ratio_map', {}) or {}).items()
                    if int(v or 0) > 0
                }
                if old_ratio_map == new_ratio_map:
                    return

            new_result = self._rebuild_tables_after_ratio_edit_dashboard(
                idx, result, table_index, new_ratio_map
            )

            # Cache ngay phương án sửa tay để Xuất Excel dùng đúng bàn vừa sửa.
            self._cache_dashboard_result(idx, new_result)
            self._promote_individual_cache_to_global()

            try:
                self.fabric_dash_cache_var.set('✎ ĐÃ SỬA TỈ LỆ')
                self.fabric_dash_note_var.set(
                    'Tỉ lệ đã sửa thủ công • Các bàn khác giữ nguyên • Chiều dài và số lá bàn này tự tính lại • '
                    'Xuất Excel sẽ dùng phương án này.'
                )
            except Exception:
                pass

            self._render_fabric_result_grid(new_result)
            self.status_var.set(
                f"B{table_index+1}: đã sửa tỉ lệ; chiều dài và số lá tự cập nhật."
            )

        except Exception as e:
            messagebox.showerror('Sửa tỉ lệ sơ đồ', str(e))
            try:
                current = self._dashboard_cached_result(idx)
                if current is not None:
                    self._render_fabric_result_grid(current)
            except Exception:
                pass
        finally:
            self._dashboard_ratio_edit_busy = False

    def _add_dashboard_table(self):
        """V157: thêm bàn mới, người dùng chỉ nhập TỈ LỆ."""
        idx = self._selected_dashboard_fabric_index()
        if idx is None or not (0 <= idx < len(self.fabric_list)):
            messagebox.showwarning('Thêm bàn', 'Hãy chọn loại vải cần thêm bàn.')
            return

        result = self._dashboard_cached_result(idx)
        if result is None:
            messagebox.showwarning(
                'Thêm bàn',
                'Hãy TÍNH LẠI loại vải này trước, sau đó mới thêm bàn.'
            )
            return

        tables = list(result.get('cutting_tables', []) or [])
        new_no = len(tables) + 1

        suggestion = ''
        if tables:
            suggestion = (
                tables[-1].get('ratio', '')
                or self._format_ratio_map_dashboard(tables[-1].get('ratio_map', {}))
            )
        if not suggestion and self.sizes:
            suggestion = f"{self.sizes[0].get('name', 'SIZE')}/1"

        top = tk.Toplevel(self.root)
        top.title(f'THÊM BÀN B{new_no}')
        top.configure(bg=self.UI_BG)
        top.transient(self.root)
        try:
            top.resizable(False, False)
            top.attributes('-topmost', True)
        except Exception:
            pass

        box = tk.Frame(
            top, bg='white',
            highlightthickness=1, highlightbackground=self.UI_BORDER
        )
        box.pack(fill='both', expand=True, padx=10, pady=10)

        tk.Label(
            box, text=f'＋  THÊM BÀN B{new_no}',
            font=('Segoe UI', 12, 'bold'),
            fg=self.UI_NAVY, bg='white'
        ).pack(anchor='w', padx=12, pady=(12, 3))

        tk.Label(
            box,
            text='Chỉ nhập TỈ LỆ SƠ ĐỒ. Chiều dài và số lá sẽ tự tính.',
            font=('Segoe UI', 8),
            fg=self.UI_MUTED, bg='white'
        ).pack(anchor='w', padx=12, pady=(0, 10))

        tk.Label(
            box, text='Tỉ lệ bàn mới',
            font=('Segoe UI', 8, 'bold'),
            fg=self.UI_TEXT, bg='white'
        ).pack(anchor='w', padx=12)

        ratio_var = tk.StringVar(value=suggestion)
        entry = tk.Entry(
            box, textvariable=ratio_var,
            font=('Segoe UI', 11, 'bold'),
            bg='#e2f0d9', fg='#17365d',
            relief='solid', bd=1,
            justify='center'
        )
        entry.pack(fill='x', padx=12, pady=(4, 5), ipady=6)

        tk.Label(
            box,
            text='Ví dụ: S/1 + M/2 + L/1',
            font=('Segoe UI', 8),
            fg=self.UI_MUTED, bg='white'
        ).pack(anchor='w', padx=12, pady=(0, 10))

        btns = tk.Frame(box, bg='white')
        btns.pack(fill='x', padx=12, pady=(0, 12))

        def close():
            try:
                top.grab_release()
            except Exception:
                pass
            try:
                top.destroy()
            except Exception:
                pass

        def apply_new_table():
            try:
                ratio_map = self._parse_ratio_text_dashboard(ratio_var.get())

                temp_result = dict(result)
                temp_tables = []
                for tb in tables:
                    nt = dict(tb)
                    nt['ratio_map'] = dict(tb.get('ratio_map', {}) or {})
                    nt['sizes'] = dict(tb.get('sizes', {}) or {})
                    temp_tables.append(nt)

                temp_tables.append({
                    'table': f'B{new_no}',
                    'ratio_map': dict(ratio_map),
                    'ratio': self._format_ratio_map_dashboard(ratio_map),
                    'length': 0.0,
                    'raw_length': 0.0,
                    'plies': 0,
                    'sizes': {},
                    'total_output': 0,
                    'size_count': len(ratio_map),
                })
                temp_result['cutting_tables'] = temp_tables

                new_result = self._rebuild_tables_after_ratio_edit_dashboard(
                    idx, temp_result, len(temp_tables) - 1, ratio_map
                )

                self._cache_dashboard_result(idx, new_result)
                self._promote_individual_cache_to_global()

                new_tables = new_result.get('cutting_tables', []) or []
                new_tb = new_tables[-1] if new_tables else {}
                new_plies = int(new_tb.get('plies', 0) or 0)
                new_len = float(new_tb.get('length', 0) or 0)

                try:
                    self.fabric_dash_cache_var.set('✎ ĐÃ THÊM BÀN')
                    self.fabric_dash_note_var.set(
                        'Đã thêm bàn thủ công • Chỉ sửa tỉ lệ • '
                        'Chiều dài và số lá tự tính • Xuất Excel dùng đúng phương án này.'
                    )
                except Exception:
                    pass

                self._render_fabric_result_grid(new_result)
                self.status_var.set(
                    f"Đã thêm B{len(new_tables)} • "
                    f"Dài {new_len:.2f}m • {new_plies} lá."
                )

                close()

                if new_plies <= 0:
                    messagebox.showinfo(
                        'Thêm bàn',
                        f'Đã thêm B{len(new_tables)}, nhưng số lá hiện tại = 0.\n\n'
                        'Các bàn phía trước đã đủ sản lượng cho tỉ lệ này.\n'
                        'Bạn có thể sửa tỉ lệ bàn trước hoặc bàn mới để phần mềm tự chia lại số lá.'
                    )

            except Exception as e:
                messagebox.showerror('Thêm bàn', str(e), parent=top)

        tk.Button(
            btns, text='HỦY', command=close,
            font=('Segoe UI', 9, 'bold'),
            bg='#64748b', fg='white',
            activebackground='#475569', activeforeground='white',
            relief='flat', bd=0, padx=18, pady=7,
            cursor='hand2'
        ).pack(side='right', padx=(6, 0))

        tk.Button(
            btns, text='✓  THÊM BÀN', command=apply_new_table,
            font=('Segoe UI', 9, 'bold'),
            bg='#16a34a', fg='white',
            activebackground='#15803d', activeforeground='white',
            relief='flat', bd=0, padx=18, pady=7,
            cursor='hand2'
        ).pack(side='right')

        entry.bind('<Return>', lambda e: apply_new_table())
        top.bind('<Escape>', lambda e: close())

        try:
            top.update_idletasks()
            w, h = 470, 245
            x = self.root.winfo_rootx() + max(20, (self.root.winfo_width() - w)//2)
            y = self.root.winfo_rooty() + max(20, (self.root.winfo_height() - h)//2)
            top.geometry(f'{w}x{h}+{x}+{y}')
            top.grab_set()
            top.lift()
            entry.focus_set()
            entry.selection_range(0, 'end')
        except Exception:
            pass

    def _render_fabric_result_grid(self, result):
        grid = getattr(self, 'fabric_result_grid', None)
        if grid is None:
            return
        for w in grid.winfo_children():
            w.destroy()

        size_keys = [s['key'] for s in self.sizes]
        size_names = [s['name'] for s in self.sizes]
        cols = ['table','ratio','length','plies'] + size_keys + ['total']
        headers = ['Số bàn','TỈ LỆ SƠ ĐỒ / MARKER RATE\n(SỬA + ENTER)','Chiều dài\n(TỰ NHẢY)','Số lá\n(TỰ NHẢY)'] + size_names + ['Tổng']
        widths = [7, 38, 11, 8] + [7]*len(size_keys) + [9]
        weights = [0, 5, 0, 0] + [1]*len(size_keys) + [0]
        for c, wt in enumerate(weights):
            grid.grid_columnconfigure(c, weight=wt, uniform=None if c==1 else 'qty')

        def cell(row, col, text='', bg='white', fg='#1f2937', bold=False, anchor='center', width=None):
            lbl = tk.Label(grid, text=text, bg=bg, fg=fg,
                           font=('Segoe UI', 8, 'bold' if bold else 'normal'),
                           relief='solid', bd=1, padx=4, pady=4, anchor=anchor,
                           justify='center')
            if width: lbl.configure(width=width)
            lbl.grid(row=row, column=col, sticky='nsew')
            return lbl

        for c, h in enumerate(headers):
            cell(0, c, h, bg='#d9e2f3', fg='#102a43', bold=True, width=widths[c])

        if result is None:
            cell(1, 0, 'CHƯA TÍNH', bg='#f8fafc', fg='#64748b', bold=True)
            cell(1, 1, 'Bấm TÍNH TOÀN BỘ hoặc TÍNH LẠI LOẠI VẢI NÀY', bg='#f8fafc', fg='#64748b')
            for c in range(2, len(cols)):
                cell(1, c, '', bg='#f8fafc')
            return

        required = result.get('total_by_size', {}) or {}
        # Hàng kế hoạch màu cam nhạt như Excel xuất.
        cell(1, 0, 'KH', bg='#fce4d6', bold=True)
        cell(1, 1, 'SẢN LƯỢNG KẾ HOẠCH', bg='#fce4d6', bold=True)
        cell(1, 2, '', bg='#fce4d6'); cell(1, 3, '', bg='#fce4d6')
        for i,k in enumerate(size_keys): cell(1, 4+i, int(required.get(k,0) or 0), bg='#fce4d6', bold=True)
        cell(1, 4+len(size_keys), sum(int(required.get(k,0) or 0) for k in size_keys), bg='#fce4d6', bold=True)

        tables = result.get('cutting_tables', []) or []
        actual = {k:0 for k in size_keys}
        r = 2
        selected_idx = self._selected_dashboard_fabric_index()
        editable_ratio = bool(
            selected_idx is not None
            and getattr(self, '_fabric_dashboard_result_editable', True)
        )

        for table_index, tb in enumerate(tables):
            sizes = tb.get('sizes', {}) or {}
            for k in size_keys:
                actual[k] += int(sizes.get(k,0) or 0)

            # Cột Số bàn.
            cell(r, 0, tb.get('table',''), bg='white', bold=True, width=widths[0])

            # V157: CHỈ TỈ LỆ được phép sửa.
            ratio_text = tb.get('ratio','') or self._format_ratio_map_dashboard(tb.get('ratio_map', {}))
            if editable_ratio:
                e = tk.Entry(
                    grid,
                    font=('Segoe UI', 9, 'bold'),
                    bg='#e2f0d9', fg='#17365d',
                    relief='solid', bd=1,
                    justify='center',
                    insertbackground='#17365d'
                )
                e.insert(0, ratio_text)
                e.grid(row=r, column=1, sticky='nsew', padx=0, pady=0, ipady=4)

                # Lưu text gốc để FocusOut chỉ tính khi người dùng thực sự thay đổi.
                e._ratio_original = ratio_text

                def _commit(ev=None, entry=e, fi=selected_idx, ti=table_index):
                    try:
                        new_text = entry.get().strip()
                        old_text = getattr(entry, '_ratio_original', '')
                        if new_text != old_text:
                            self._apply_dashboard_ratio_edit(fi, ti, new_text)
                    except Exception:
                        pass
                    return 'break' if ev is not None and getattr(ev, 'keysym', '') == 'Return' else None

                e.bind('<Return>', _commit)
                e.bind('<FocusOut>', _commit)
            else:
                cell(r, 1, ratio_text, bg='#e2f0d9', bold=True, width=widths[1])

            # Chiều dài + Số lá chỉ hiển thị, tự nhảy sau khi sửa tỉ lệ.
            cell(
                r, 2,
                f"{float(tb.get('length',0) or 0):.2f}".rstrip('0').rstrip('.'),
                bg='#eaf3ff', bold=False, width=widths[2]
            )
            cell(
                r, 3,
                int(tb.get('plies',0) or 0),
                bg='#fff2cc', bold=True, width=widths[3]
            )

            c0 = 4
            for j, k in enumerate(size_keys):
                qty = int(sizes.get(k,0) or 0)
                cell(r, c0+j, qty if qty else '', bg='white', width=widths[c0+j])

            cell(
                r, c0+len(size_keys),
                sum(int(sizes.get(k,0) or 0) for k in size_keys),
                bg='white',
                width=widths[c0+len(size_keys)]
            )
            r += 1

        # Hai dòng tổng kết xanh giống mockup / Excel.
        actual_vals = ['', 'SẢN LƯỢNG THỰC CẮT / ACTUAL CUT QTY', '', ''] + [actual[k] for k in size_keys] + [sum(actual.values())]
        diff = {k: actual[k] - int(required.get(k,0) or 0) for k in size_keys}
        diff_vals = ['', 'SẢN LƯỢNG ÂM/DƯƠNG (+/-)', '', ''] + [diff[k] for k in size_keys] + [sum(diff.values())]
        for vals, bg in ((actual_vals,'#c6e0b4'), (diff_vals,'#e2f0d9')):
            for c,val in enumerate(vals):
                cell(r,c,val,bg=bg,bold=True,width=widths[c])
            r += 1

    def _show_fabric_dashboard(self, idx):
        if not (0 <= idx < len(self.fabric_list)):
            self._clear_fabric_dashboard(); return
        fabric = self.fabric_list[idx]
        self.fabric_dash_title_var.set('Thông tin loại vải: ' + str(fabric.get('name','')))
        self._load_fabric_dashboard_editors(idx)
        result = self._dashboard_cached_result(idx)
        stale_result = None
        if result is None:
            # V140: nếu dữ liệu loại vải vừa thay đổi, vẫn hiện bàn/tỉ lệ cũ
            # để người dùng không bị mất kết quả ngay khi đang sửa thông tin.
            item = getattr(self, '_fabric_preview_cache', {}).get(idx)
            if isinstance(item, dict):
                stale_result = item.get('result')

        if result is not None:
            self.fabric_dash_cache_var.set('✓ ĐÃ TÍNH SẴN')
            self.fabric_dash_note_var.set(
                'Kết quả đã có trong bộ nhớ • Nếu không đổi dữ liệu, xuất Excel không cần tối ưu lại.'
            )
            shown_result = result
        elif stale_result is not None:
            self.fabric_dash_cache_var.set('⚠ ĐÃ THAY ĐỔI - CHƯA TÍNH LẠI')
            self.fabric_dash_note_var.set(
                'Bảng phía dưới là kết quả trước khi sửa • Bấm TÍNH LẠI LOẠI VẢI NÀY để cập nhật.'
            )
            shown_result = stale_result
        else:
            self.fabric_dash_cache_var.set('CHƯA TÍNH')
            self.fabric_dash_note_var.set(
                'Loại này chưa có kết quả • Bấm TÍNH LẠI riêng loại vải này.'
            )
            shown_result = None

        # V156: kết quả cũ/stale chỉ để xem, không cho sửa tỉ lệ.
        self._fabric_dashboard_result_editable = (result is not None)
        self._render_fabric_result_grid(shown_result)

    def _calculate_single_fabric_dashboard(self, idx):
        """Tính đúng MỘT loại vải, dùng cùng thuật toán/post-process với kế hoạch chính."""
        if not (0 <= idx < len(self.fabric_list)):
            return None, 'Không tìm thấy loại vải.'
        try:
            self._sync_po_grid_from_ui()
        except Exception:
            pass
        if not self.po_list:
            return None, 'Chưa có dữ liệu PO!'
        try:
            self._sync_all_shade_lots()
            self._sync_size_percent_from_ui(silent=False)
        except ValueError as e:
            return None, str(e)
        except Exception:
            pass

        fabric = self.fabric_list[idx]
        raw_total_by_size = self._fabric_total_by_size(fabric)
        total_by_size = self._fabric_planned_total_by_size(fabric)
        if sum(total_by_size.values()) <= 0:
            return None, f"Loại vải '{fabric.get('name','')}' không có sản lượng từ PO đã chọn."
        size_factor = {s['key']: s.get('factor',1.0) for s in self.sizes}
        norm = float(fabric.get('norm',0) or 0)
        min_len = max(0.0, float(fabric.get('min_length',1.0) or 0))
        max_len = float(fabric.get('max_length',0) or 0)
        max_products = int(fabric.get('max_products',0) or 0)
        balance_pct = float(fabric.get('balance_pct', 1.0) if fabric.get('balance_pct', 1.0) is not None else 1.0)
        resolved_mode = self._resolved_fabric_mode(fabric)
        optimizer_mode = self._optimizer_mode_key_from_label(fabric.get('optimizer_mode','global'))
        try:
            cutting_tables, adjust_info = self._run_optimizer_strategy(
                optimizer_mode, dict(total_by_size), size_factor, norm,
                max_len, max_products, resolved_mode, min_len, balance_pct,
                fabric=fabric
            )
        except Exception as e:
            return None, f"{fabric.get('name','Loại vải')}: {e}"
        unresolved = adjust_info.get('unresolved', {}) if isinstance(adjust_info, dict) else {}
        if unresolved:
            names = {s['key']:s['name'] for s in self.sizes}
            detail = ', '.join(f"{names.get(k,k)} thiếu {v}" for k,v in unresolved.items())
            return None, 'Chưa đủ sản lượng: ' + detail

        # V154:
        # - LÁ CAO NHẤT: không stretch vì stretch sẽ giảm số lá.
        # - SƠ ĐỒ DÀI NHẤT: cho stretch mạnh hơn, chấp nhận bàn chính còn tối thiểu 4 lá.
        # - Các mode khác giữ logic V130.
        if cutting_tables and max_len > 0 and optimizer_mode not in ('high_plies', 'production'):
            nm = {x['key']:x['name'] for x in self.sizes}; order={x['key']:i for i,x in enumerate(self.sizes)}
            if optimizer_mode == 'long_marker':
                pref = 4
            else:
                pref=max(4,int(getattr(self,'MIN_PREFERRED_PLIES',10) or 10))
            mxp=max([int(t.get('plies',0) or 0) for t in cutting_tables] or [0])
            mnp=min([int(t.get('plies',0) or 0) for t in cutting_tables if int(t.get('plies',0) or 0)>0] or [0])
            protect=(mxp>0 and mnp>0 and (mnp<pref or mnp<=0.50*mxp))
            newtabs=[dict(t) for t in cutting_tables]
            for tb in newtabs:
                n=int(tb.get('plies',0) or 0); rm={k:int(v or 0) for k,v in (tb.get('ratio_map',{}) or {}).items() if int(v or 0)>0}
                if n<=0 or not rm or (protect and n==mnp): continue
                raw=float(tb.get('raw_length',tb.get('length',0)) or 0) or (norm*sum(rm.values()))
                rt=sum(rm.values())
                mf=min(max(1,n//pref), max(1,int((max_len+1e-9)//raw)))
                if max_products>0: mf=min(mf,max(1,int(max_products//max(1,rt))))
                kfac=1
                for f in range(mf,1,-1):
                    if n%f==0: kfac=f; break
                if kfac<=1: continue
                nn=n//kfac; nrm={k:v*kfac for k,v in rm.items()}; nraw=raw*kfac
                if nn<pref or nraw>max_len+1e-9 or (max_products>0 and sum(nrm.values())>max_products): continue
                tb['plies']=nn; tb['ratio_map']=nrm; tb['raw_length']=nraw; tb['length']=nraw
                tb['ratio']=' + '.join(f"{nm.get(k,k)}/{nrm[k]}" for k in sorted(nrm,key=lambda x:order.get(x,10**6)))
                tb['size_count']=len(nrm); tb['meter_rate']=nraw/max(1,sum(nrm.values()))
            cutting_tables=newtabs

        base=[dict(tb) for tb in cutting_tables]
        def rtot(tb):
            rm=tb.get('ratio_map',{}) or {}; return sum(int(v or 0) for v in rm.values()) if rm else int(tb.get('size_count',0) or 0)
        if len(base)>1:
            li=min(range(len(base)), key=lambda i:(int(base[i].get('plies',0) or 0), rtot(base[i]), float(base[i].get('raw_length',base[i].get('length',0)) or 0), i))
            tail=base.pop(li)
            base.sort(key=lambda tb:(-int(tb.get('plies',0) or 0),-rtot(tb),-float(tb.get('raw_length',tb.get('length',0)) or 0)))
            base.append(tail)
        for i,tb in enumerate(base,1): tb['table']=f'B{i}'
        preview_tables, lot_summary = self.allocate_lots_to_tables(fabric, base)
        result = {
            'fabric': fabric, 'raw_total_by_size': dict(raw_total_by_size),
            'total_by_size': dict(total_by_size), 'production_percent': 0.0,
            'cutting_tables': base, 'preview_tables': preview_tables,
            'lot_summary': lot_summary, 'adjust_info': adjust_info,
            'fabric_mode': resolved_mode,
            'fabric_mode_label': self.FABRIC_MODE_LABELS.get(resolved_mode,'VẢI CHÍNH')
        }
        return result, None

    def _calc_all_progress_begin(self):
        """V150: bắt đầu tính và giữ cửa sổ phản hồi với Windows."""
        self._calc_all_progress_active = True
        self._calc_all_progress_value = 0
        self._calculation_busy = True

        for attr in ('fabric_calc_all_button', 'fixed_recalc_button'):
            btn = getattr(self, attr, None)
            if btn is not None:
                try:
                    btn.config(
                        state='disabled',
                        text='⏳  ĐANG TÍNH... 0%',
                        bg='#94a3b8', fg='white',
                        activebackground='#94a3b8',
                        activeforeground='white',
                        disabledforeground='white',
                        relief='sunken'
                    )
                except Exception:
                    pass

        try:
            self.root.configure(cursor='watch')
            self.root.update()
        except Exception:
            pass

    def _calc_all_progress(self, percent, stage=''):
        """V150: cập nhật % và xử lý message queue để Windows không báo Not Responding."""
        if not getattr(self, '_calc_all_progress_active', False):
            return
        try:
            old = int(getattr(self, '_calc_all_progress_value', 0) or 0)
            pct = max(old, min(100, int(percent)))
        except Exception:
            pct = 0
        self._calc_all_progress_value = pct

        for attr in ('fabric_calc_all_button', 'fixed_recalc_button'):
            btn = getattr(self, attr, None)
            if btn is not None:
                try:
                    btn.config(text=f'⏳  ĐANG TÍNH... {pct}%')
                except Exception:
                    pass

        if stage and hasattr(self, 'status_var'):
            try:
                self.status_var.set(f'{stage} ({pct}%)')
            except Exception:
                pass

        try:
            # update() thay cho update_idletasks(): Windows vẫn nhận message
            # nên cửa sổ không bị gắn nhãn Not Responding trong các giai đoạn dài.
            self.root.update()
        except Exception:
            pass

    def _calc_all_progress_end(self, success=True):
        """V150: kết thúc tính và khôi phục cả nút trên trang lẫn nút cố định."""
        self._calc_all_progress_active = False
        self._calc_all_progress_value = 0
        self._calculation_busy = False

        try:
            self.root.configure(cursor='')
        except Exception:
            pass

        for attr in ('fabric_calc_all_button', 'fixed_recalc_button'):
            btn = getattr(self, attr, None)
            if btn is None:
                continue
            try:
                if success:
                    btn.config(
                        text='✓  HOÀN TẤT 100%',
                        bg='#94a3b8', fg='white',
                        disabledforeground='white'
                    )
                else:
                    btn.config(
                        text='✕  TÍNH LỖI',
                        bg='#94a3b8', fg='white',
                        disabledforeground='white'
                    )
            except Exception:
                pass

        try:
            self.root.update()
        except Exception:
            pass

        def _restore():
            configs = {
                'fabric_calc_all_button': {
                    'text':'↻  TÍNH TOÀN BỘ',
                    'bg':'#0f766e',
                    'activebackground':'#0b5f59'
                },
                'fixed_recalc_button': {
                    'text':'↻  TÍNH TOÁN LẠI',
                    'bg':'#2375c6',
                    'activebackground':'#1b62a8'
                }
            }
            for attr, cfg in configs.items():
                b = getattr(self, attr, None)
                if b is not None:
                    try:
                        b.config(
                            state='normal',
                            text=cfg['text'],
                            bg=cfg['bg'], fg='white',
                            activebackground=cfg['activebackground'],
                            activeforeground='white',
                            relief='flat'
                        )
                    except Exception:
                        pass

        try:
            self.root.after(700 if success else 1200, _restore)
        except Exception:
            _restore()

    def recalculate_fabric_dashboard(self):
        idx = self._selected_dashboard_fabric_index()
        if idx is None:
            messagebox.showwarning('Cảnh báo','Hãy chọn loại vải cần tính lại.')
            return

        # V139: chụp lại bàn đã tính của TẤT CẢ loại vải khác trước khi
        # LƯU THÔNG TIN / đồng bộ LOT làm thay đổi cache-key.
        preserved_results = self._snapshot_dashboard_results(exclude_idx=idx)

        if not self._apply_fabric_dashboard_editors(silent=False):
            return

        try:
            self.fabric_recalc_button.config(
                state='disabled',
                text='⏳  ĐANG TÍNH LOẠI NÀY...',
                bg='#94a3b8',
                fg='white'
            )
            self.root.update_idletasks()
        except Exception:
            pass

        result, error = self._calculate_single_fabric_dashboard(idx)

        try:
            self.fabric_recalc_button.config(
                state='normal',
                text='↻  TÍNH LẠI LOẠI VẢI NÀY',
                bg='#2563eb',
                fg='white'
            )
        except Exception:
            pass

        if error:
            # Nếu loại đang tính lỗi thì vẫn khôi phục kết quả các loại khác.
            self._restore_dashboard_results(preserved_results, exclude_idx=idx)
            self._promote_individual_cache_to_global()
            self.fabric_dash_cache_var.set('LỖI')
            self.fabric_dash_note_var.set(error)
            self._refresh_fabric_dashboard_list(select_index=idx)
            messagebox.showerror('Lỗi tính toán', error)
            return

        # Ghi kết quả mới của đúng loại đang chọn.
        self._cache_dashboard_result(idx, result)

        # Sau khi _calculate_single_fabric_dashboard() đồng bộ lại LOT,
        # cache-key của các loại khác có thể đã đổi. Gắn lại các kết quả cũ
        # với key mới để bàn của chúng không biến mất.
        self._restore_dashboard_results(preserved_results, exclude_idx=idx)

        # Nếu tất cả loại vải đều đã có kết quả thì tạo lại cache toàn bộ.
        # Xuất Excel sẽ dùng lại cache này, không cần tính lại.
        self._promote_individual_cache_to_global()

        self._refresh_fabric_dashboard_list(select_index=idx)
        self.status_var.set(
            f"Đã tính lại riêng {self.fabric_list[idx].get('name','')}. "
            "Bàn của các loại vải khác được giữ nguyên."
        )

    def recalculate_all_fabrics_dashboard(self):
        """V137: TÍNH TOÀN BỘ luôn tính lại từ đầu, không dùng kết quả/cache cũ."""
        idx = self._selected_dashboard_fabric_index()
        if idx is not None:
            if not self._apply_fabric_dashboard_editors(silent=False):
                return

        if not self.fabric_list:
            messagebox.showwarning('Cảnh báo', 'Chưa có loại vải để tính.')
            return

        # XÓA TOÀN BỘ CACHE trước khi tính.
        # Đây là điểm khác với xuất Excel: nút TÍNH TOÀN BỘ bắt buộc tối ưu lại từ đầu.
        self._cut_plan_cache_key = None
        self._cut_plan_cache_results = None
        self._fabric_preview_cache = {}

        self._calc_all_progress_begin()
        self._calc_all_progress(2, 'Đang chuẩn bị dữ liệu')

        try:
            results, error = self.calculate_cutting_plan(force_recalculate=True)
        except Exception as e:
            self._calc_all_progress_end(success=False)
            messagebox.showerror('Lỗi tính toán', str(e))
            return

        if error:
            self._calc_all_progress_end(success=False)
            messagebox.showerror('Lỗi tính toán', error)
            return

        self._calc_all_progress(94, 'Đang cập nhật kết quả từng loại vải')

        self._fabric_preview_cache = {}
        for i, result in enumerate(results or []):
            self._cache_dashboard_result(i, result)

        # Sau khi tính toàn bộ xong mới tạo cache mới để Xuất Excel dùng lại.
        self._promote_individual_cache_to_global()

        self._calc_all_progress(100, 'Hoàn tất tính toàn bộ')
        self._refresh_fabric_dashboard_list(select_index=idx if idx is not None else 0)
        self.status_var.set(
            'Đã TÍNH LẠI TOÀN BỘ từ đầu. Xuất Excel sẽ dùng kết quả này để xuất nhanh.'
        )
        self._calc_all_progress_end(success=True)

    def _apply_modern_theme_recursive(self, widget=None):
        """V131: làm giao diện đồng nhất/compact mà không đổi logic widget."""
        if widget is None:
            widget = self.root
        card = getattr(self, 'UI_CARD', '#ffffff')
        bg = getattr(self, 'UI_BG', '#eef2f6')
        text = getattr(self, 'UI_TEXT', '#243447')
        muted = getattr(self, 'UI_MUTED', '#6b7c8f')
        border = getattr(self, 'UI_BORDER', '#d7dee7')
        old_light = {'#f0f0f0', '#eef4fb', '#f7fbff', '#fffaf0', '#f4f6f7', 'SystemButtonFace'}
        try:
            cls = widget.winfo_class()
            current_bg = ''
            try:
                current_bg = str(widget.cget('bg'))
            except Exception:
                pass

            if isinstance(widget, tk.LabelFrame):
                widget.configure(bg=card, fg=text, font=('Segoe UI', 9, 'bold'),
                                 bd=1, relief='solid', padx=10, pady=7,
                                 highlightthickness=0)
            elif isinstance(widget, tk.Frame):
                # Không đụng header hoặc các frame có màu chức năng riêng.
                if current_bg in old_light or current_bg.lower() in {x.lower() for x in old_light}:
                    widget.configure(bg=card if widget is not getattr(self, 'cut_main_body', None) else bg)
            elif isinstance(widget, tk.Label):
                # Giữ label tiêu đề/header có nền màu riêng; các label nội dung chuyển sang Segoe UI.
                f = str(widget.cget('font'))
                size = 9
                if '18' in f or '15' in f: size = 15
                elif '13' in f: size = 11
                elif '11' in f: size = 9
                elif '10' in f: size = 9
                elif '8' in f: size = 8
                bold = 'bold' in f.lower()
                widget.configure(font=('Segoe UI', size, 'bold' if bold else 'normal'))
                if current_bg in old_light or current_bg.lower() in {x.lower() for x in old_light}:
                    widget.configure(bg=card)
                    try:
                        fg = str(widget.cget('fg'))
                        if fg in ('#555555', '#566573', '#7f8c8d', 'gray', 'grey'):
                            widget.configure(fg=muted)
                        elif fg in ('black', '#000000'):
                            widget.configure(fg=text)
                    except Exception:
                        pass
            elif isinstance(widget, tk.Entry):
                widget.configure(font=('Segoe UI', 9), relief='solid', bd=1,
                                 highlightthickness=1, highlightbackground=border,
                                 highlightcolor=getattr(self, 'UI_BLUE', '#246bce'))
            elif isinstance(widget, tk.Spinbox):
                widget.configure(font=('Segoe UI', 9), relief='solid', bd=1,
                                 highlightthickness=1, highlightbackground=border,
                                 highlightcolor=getattr(self, 'UI_BLUE', '#246bce'))
            elif isinstance(widget, tk.Button):
                # Giữ màu chức năng sẵn có nhưng chuyển nút sang dạng phẳng/gọn.
                widget.configure(font=('Segoe UI', 9, 'bold'), relief='flat', bd=0,
                                 cursor='hand2', padx=max(6, int(widget.cget('padx') or 0)),
                                 pady=min(6, max(3, int(widget.cget('pady') or 0))))
            elif isinstance(widget, (tk.Checkbutton, tk.Radiobutton)):
                widget.configure(font=('Segoe UI', 9), activebackground=card,
                                 selectcolor='white')
                if current_bg in old_light or current_bg.lower() in {x.lower() for x in old_light}:
                    widget.configure(bg=card)
            elif isinstance(widget, tk.Canvas):
                # Chỉ đổi canvas nền giao diện, không đổi canvas dùng để vẽ nội dung đặc biệt.
                if current_bg in old_light or current_bg.lower() in {x.lower() for x in old_light}:
                    widget.configure(bg=card, highlightthickness=0)
        except Exception:
            pass

        try:
            for child in widget.winfo_children():
                self._apply_modern_theme_recursive(child)
        except Exception:
            pass

    def _widget_is_inside(self, widget, ancestor):
        """Kiểm tra widget có nằm bên trong ancestor hay không."""
        try:
            cur = widget
            while cur is not None:
                if cur == ancestor:
                    return True
                parent_name = cur.winfo_parent()
                if not parent_name:
                    break
                cur = cur._nametowidget(parent_name)
        except Exception:
            pass
        return False

    def _nearest_scrollable_widget(self, widget):
        """V109: tìm vùng cuộn gần nhất dưới con trỏ (Canvas/Treeview/Listbox/Text)."""
        cur = widget
        while cur is not None:
            if cur is getattr(self, 'cut_main_canvas', None):
                return None
            if isinstance(cur, (tk.Canvas, tk.Listbox, tk.Text, ttk.Treeview)):
                return cur
            try:
                parent_name = cur.winfo_parent()
                if not parent_name:
                    break
                cur = cur._nametowidget(parent_name)
            except Exception:
                break
        return None

    def _apply_responsive_heights(self):
        """V110: co/giãn vùng nhiều dòng theo dữ liệu + chiều cao cửa sổ, tránh vùng trống lớn."""
        try:
            h = max(480, int(self.root.winfo_height() or 800))
            compact = h < 700

            if hasattr(self, 'po_grid_canvas'):
                # V158: ưu tiên chiều cao lớn cho danh sách PO để thấy nhiều dòng.
                # Bảng đã có dòng trống dự phòng nên không co theo số PO hiện có nữa.
                if h < 620:
                    rows = 9
                elif compact:
                    rows = 13
                elif h < 850:
                    rows = 17
                else:
                    rows = 20
                self.po_grid_canvas.configure(height=rows * 27)

            if hasattr(self, 'lot_inventory_canvas'):
                count = len(getattr(self, 'lot_inventory_entries', []) or [])
                rows = max(5, min(8 if compact else 10, count + 1))
                self.lot_inventory_canvas.configure(height=28 + rows * 23)

            if hasattr(self, 'global_lot_detail_canvas'):
                lots = getattr(self, 'global_lot_rows', []) or []
                if not lots:
                    dh = 54
                else:
                    roll_count = sum(max(1, len(x.get('rolls_detail') or [])) for x in lots if isinstance(x, dict))
                    estimated = 36 + roll_count * 24 + len(lots) * 58
                    dh = max(90, min(220 if compact else 320, estimated))
                self.global_lot_detail_canvas.configure(height=dh)

            if hasattr(self, 'info_tree'):
                n = len(getattr(self, 'custom_info_list', []) or [])
                self.info_tree.configure(height=max(3, min(6 if compact else 9, n + 2)))

            if hasattr(self, 'fabric_tree'):
                n = len(getattr(self, 'fabric_list', []) or [])
                self.fabric_tree.configure(height=max(3, min(6 if compact else 9, n + 2)))
        except Exception:
            pass

    def _on_root_responsive_configure(self, event):
        """V110: debounce khi kéo cửa sổ để giao diện mượt và không nhảy chiều cao liên tục."""
        try:
            if getattr(event, 'widget', None) is not self.root:
                return
            old = getattr(self, '_responsive_after_id', None)
            if old:
                try:
                    self.root.after_cancel(old)
                except Exception:
                    pass
            self._responsive_after_id = self.root.after(80, self._apply_responsive_heights)
        except Exception:
            pass

    def _on_global_mousewheel(self, event):
        """V109: con lăn ưu tiên vùng nhiều dòng dưới chuột; ngoài ra cuộn trang chính."""
        try:
            if getattr(event, 'num', None) == 4:
                steps = -3
            elif getattr(event, 'num', None) == 5:
                steps = 3
            else:
                delta = int(getattr(event, 'delta', 0) or 0)
                if delta == 0:
                    return
                steps = -3 if delta > 0 else 3

            pointer = None
            try:
                pointer = self.root.winfo_containing(event.x_root, event.y_root)
            except Exception:
                pass

            shift = bool(int(getattr(event, 'state', 0) or 0) & 0x0001)
            target = self._nearest_scrollable_widget(pointer)
            if target is not None:
                try:
                    if shift and hasattr(target, 'xview_scroll'):
                        first, last = target.xview()
                        if first > 1e-6 or last < 0.999999:
                            target.xview_scroll(steps, 'units')
                            return 'break'
                    if hasattr(target, 'yview_scroll'):
                        first, last = target.yview()
                        if first > 1e-6 or last < 0.999999:
                            target.yview_scroll(steps, 'units')
                            return 'break'
                except Exception:
                    pass

            # V149: menu PHÂN SỐ CẮT & BIỂU 10 không có canvas chính.
            canvas = getattr(self, 'cut_main_canvas', None)
            if canvas is None:
                return
            canvas.yview_scroll(steps, 'units')
            return 'break'
        except Exception:
            return

    def create_aux_tool_menu(self, parent, mode="cut"):
        """V42: Menu mở công cụ PHÂN SỐ CẮT / BIỂU 10 đã ghép vào cùng chương trình."""
        is_form10 = (mode == "form10")
        title = "BIỂU 10" if is_form10 else "PHÂN SỐ CẮT"
        color = "#7b4ab5" if is_form10 else "#1f77b4"

        box = tk.Frame(parent, bg="#f7fbff", bd=1, relief="solid")
        box.pack(fill="both", expand=True, padx=30, pady=30)
        tk.Label(
            box, text=title, font=("Arial", 20, "bold"),
            bg="#f7fbff", fg="#17365d"
        ).pack(pady=(45, 12))

        desc = (
            "Dùng chung dữ liệu với menu PHÂN SỐ CẮT. Mở menu này để xuất FORM 10."
            if is_form10 else
            "Công cụ phân số bàn cắt đã được ghép vào phần mềm. Dữ liệu nhập ở đây được giữ lại khi chuyển sang menu BIỂU 10."
        )
        tk.Label(
            box, text=desc, font=("Arial", 11), bg="#f7fbff", fg="#555555",
            wraplength=760, justify="center"
        ).pack(pady=(0, 22))

        tk.Button(
            box, text=f"MỞ {title}",
            command=lambda m=mode: self.open_aux_cut_tool(m),
            bg=color, fg="white", activebackground=color,
            font=("Arial", 13, "bold"), padx=28, pady=12, relief="flat"
        ).pack(pady=8)

        tk.Button(
            box, text="NẠP LẠI THÔNG TIN ĐƠN HÀNG TỪ MENU CHÍNH",
            command=lambda m=mode: self.open_aux_cut_tool(m, refresh_info=True),
            bg="#5cb85c", fg="white", activebackground="#449d44",
            font=("Arial", 10, "bold"), padx=18, pady=8, relief="flat"
        ).pack(pady=(10, 6))

        tk.Button(
            box, text="🔗 ĐỒNG BỘ SỐ LƯỢNG + LOT (ÁNH)",
            command=lambda m=mode: self.open_aux_cut_tool(m, sync_cut_data=True),
            bg="#d68910", fg="white", activebackground="#b9770e",
            font=("Arial", 10, "bold"), padx=18, pady=8, relief="flat"
        ).pack(pady=(0, 30))

    def _collect_aux_initial_info(self):
        """Lấy thông tin chung hiện tại để điền sẵn cho công cụ ghép V42."""
        def _entry(name):
            w = getattr(self, f"entry_{name}", None)
            try:
                return w.get().strip() if w is not None else ""
            except Exception:
                return ""

        po_names = [str(x.get("po", "") or "").strip() for x in self.po_list]
        po_names = [x for x in po_names if x]
        return {
            "customer": _entry("customer"),
            "style_code": _entry("style"),
            "color": _entry("color"),
            "batch": _entry("batch"),
            "season": _entry("season"),
            "date": _entry("date"),
            "po": " + ".join(po_names),
            "logo": self.logo_path or "",
        }

    def open_aux_cut_tool(self, mode="cut", refresh_info=False, sync_cut_data=False):
        """Mở một cửa sổ dùng chung cho hai menu; chuyển menu không làm mất dữ liệu đã nhập."""
        win = getattr(self, "aux_cut_window", None)
        if win is None or not win.winfo_exists():
            self.aux_cut_window = AuxCutTableWindow(
                self.root, mode=mode, initial=self._collect_aux_initial_info(), owner=self
            )
            win = self.aux_cut_window
        else:
            if refresh_info:
                win.apply_initial_info(self._collect_aux_initial_info(), overwrite=True)
            win.set_mode(mode)
            win.deiconify()
            win.lift()
            try:
                win.focus_force()
            except Exception:
                pass
        if sync_cut_data:
            try:
                win.sync_from_main()
            except Exception as e:
                messagebox.showerror("Lỗi đồng bộ", str(e), parent=win)
        self.status_var.set(
            "Đã mở BIỂU 10" if mode == "form10" else "Đã mở PHÂN SỐ CẮT"
        )

    def create_info_tab(self, parent):
        """V131: thông tin đơn hàng dạng card compact; phần nâng cao có thể thu gọn."""
        card = getattr(self, 'UI_CARD', '#ffffff')
        text = getattr(self, 'UI_TEXT', '#243447')
        muted = getattr(self, 'UI_MUTED', '#6b7c8f')
        border = getattr(self, 'UI_BORDER', '#d7dee7')

        info_frame = tk.LabelFrame(parent, text="THÔNG TIN ĐƠN HÀNG",
                                   font=('Segoe UI', 9, 'bold'), padx=10, pady=8,
                                   bg=card, fg=text, bd=1, relief='solid')
        info_frame.pack(fill='x', padx=14, pady=(10, 6))

        fields = [
            ('KHÁCH HÀNG / CUSTOMER', 'customer'),
            ('MÃ HÀNG / STYLE', 'style'),
            ('ĐỢT / BATCH', 'batch'),
            ('MÙA / SEASON', 'season'),
            ('MÀU / COLOR', 'color'),
            ('CODE', 'code'),
            ('DATE', 'date')
        ]
        default_values = {'code': 'F-TECH-17', 'date': '15/12/2023'}
        for c in range(4):
            info_frame.grid_columnconfigure(c, weight=1, uniform='order_info')

        for i, (label, key) in enumerate(fields):
            block_row = (i // 4) * 2
            col = i % 4
            tk.Label(info_frame, text=label, font=('Segoe UI', 8, 'bold'),
                     anchor='w', bg=card, fg=muted).grid(
                         row=block_row, column=col, padx=5, pady=(2, 1), sticky='ew')
            entry = tk.Entry(info_frame, font=('Segoe UI', 9), relief='solid', bd=1,
                             highlightthickness=1, highlightbackground=border,
                             highlightcolor=getattr(self, 'UI_BLUE', '#246bce'))
            if key in default_values:
                entry.insert(0, default_values[key])
            entry.grid(row=block_row + 1, column=col, padx=5, pady=(0, 5), sticky='ew')
            setattr(self, f'entry_{key}', entry)

        # Logo nằm ở ô thứ 4 của hàng dưới để không chiếm thêm một dòng lớn.
        logo_cell = tk.Frame(info_frame, bg=card)
        logo_cell.grid(row=2, column=3, rowspan=2, sticky='nsew', padx=5, pady=(2, 5))
        tk.Label(logo_cell, text='LOGO', font=('Segoe UI', 8, 'bold'),
                 bg=card, fg=muted).pack(anchor='w')
        logo_actions = tk.Frame(logo_cell, bg=card)
        logo_actions.pack(fill='x', pady=(2, 2))
        tk.Button(logo_actions, text='Chọn', command=self.select_logo,
                  font=('Segoe UI', 8, 'bold'), bg=getattr(self, 'UI_BLUE', '#246bce'), fg='white',
                  padx=9, pady=3, relief='flat', bd=0).pack(side='left')
        tk.Button(logo_actions, text='Bỏ', command=self.clear_logo,
                  font=('Segoe UI', 8, 'bold'), bg='#7f8c8d', fg='white',
                  padx=8, pady=3, relief='flat', bd=0).pack(side='left', padx=(5, 0))
        self.logo_name_var = tk.StringVar(value='Chưa chọn logo')
        tk.Label(logo_actions, textvariable=self.logo_name_var, font=('Segoe UI', 8),
                 bg=card, fg=muted, anchor='w').pack(side='left', fill='x', expand=True, padx=(7, 0))
        self.logo_preview_label = tk.Label(
            logo_cell, text='Chưa có logo', font=('Segoe UI', 7),
            bg='#f8fafc', fg=muted, relief='solid', bd=1,
            width=14, height=2, anchor='center'
        )
        self.logo_preview_label.pack(anchor='w', fill='x')

        # ===== THÔNG TIN BỔ SUNG: mặc định thu gọn để giao diện chính gọn =====
        extra_shell = tk.Frame(parent, bg=card, bd=1, relief='solid')
        extra_shell.pack(fill='x', padx=14, pady=(0, 6))
        extra_header = tk.Frame(extra_shell, bg=card)
        extra_header.pack(fill='x')
        self._extra_info_open = False
        self.extra_info_toggle_btn = tk.Button(
            extra_header, text='▸  THÔNG TIN BỔ SUNG / VỊ TRÍ EXCEL',
            font=('Segoe UI', 9, 'bold'), anchor='w',
            bg=card, fg=text, activebackground='#f2f6fa', activeforeground=text,
            relief='flat', bd=0, padx=10, pady=6
        )
        self.extra_info_toggle_btn.pack(fill='x')

        extra_body = tk.Frame(extra_shell, bg=card)
        self.extra_info_body = extra_body

        input_row = tk.Frame(extra_body, bg=card)
        input_row.pack(fill='x', padx=10, pady=(7, 6))
        for c, weight in enumerate((1, 2, 0, 0, 0)):
            input_row.grid_columnconfigure(c, weight=weight)

        self.entry_extra_info_name = tk.Entry(input_row, font=('Segoe UI', 9))
        self.entry_extra_info_value = tk.Entry(input_row, font=('Segoe UI', 9))
        self.entry_extra_info_col = tk.Entry(input_row, width=6, font=('Segoe UI', 9))
        self.entry_extra_info_row = tk.Entry(input_row, width=6, font=('Segoe UI', 9))
        for w in (self.entry_extra_info_name, self.entry_extra_info_value,
                  self.entry_extra_info_col, self.entry_extra_info_row):
            w.configure(relief='solid', bd=1, highlightthickness=1,
                        highlightbackground=border, highlightcolor=getattr(self, 'UI_BLUE', '#246bce'))

        tk.Label(input_row, text='Tên', font=('Segoe UI', 8, 'bold'), bg=card, fg=muted).grid(row=0, column=0, sticky='w')
        tk.Label(input_row, text='Nội dung', font=('Segoe UI', 8, 'bold'), bg=card, fg=muted).grid(row=0, column=1, sticky='w', padx=(8, 0))
        tk.Label(input_row, text='Cột', font=('Segoe UI', 8, 'bold'), bg=card, fg=muted).grid(row=0, column=2, sticky='w', padx=(8, 0))
        tk.Label(input_row, text='Dòng', font=('Segoe UI', 8, 'bold'), bg=card, fg=muted).grid(row=0, column=3, sticky='w', padx=(8, 0))
        self.entry_extra_info_name.grid(row=1, column=0, sticky='ew', pady=(1, 0))
        self.entry_extra_info_value.grid(row=1, column=1, sticky='ew', padx=(8, 0), pady=(1, 0))
        self.entry_extra_info_col.grid(row=1, column=2, padx=(8, 0), pady=(1, 0))
        self.entry_extra_info_row.grid(row=1, column=3, padx=(8, 0), pady=(1, 0))
        tk.Button(input_row, text='＋ THÊM', command=self.add_custom_order_info,
                  font=('Segoe UI', 8, 'bold'), bg=getattr(self, 'UI_BLUE', '#246bce'), fg='white',
                  relief='flat', bd=0, padx=12, pady=4).grid(row=1, column=4, padx=(10, 0), sticky='ew')

        table_wrap = tk.Frame(extra_body, bg=card)
        table_wrap.pack(fill='both', expand=True, padx=10, pady=(0, 6))
        columns = ('name', 'value', 'col', 'row')
        self.info_tree = ttk.Treeview(table_wrap, columns=columns, show='headings', height=4)
        headers = {'name': 'Tên thông tin', 'value': 'Nội dung', 'col': 'Cột Excel', 'row': 'Dòng Excel'}
        widths = {'name': 170, 'value': 420, 'col': 80, 'row': 80}
        for col in columns:
            self.info_tree.heading(col, text=headers[col])
            self.info_tree.column(col, width=widths[col], anchor='center' if col in ('col', 'row') else 'w')
        info_hscroll = ttk.Scrollbar(table_wrap, orient='horizontal', command=self.info_tree.xview)
        info_hscroll.pack(side='bottom', fill='x')
        self.info_tree.pack(side='left', fill='both', expand=True)
        info_scroll = ttk.Scrollbar(table_wrap, orient='vertical', command=self.info_tree.yview)
        info_scroll.pack(side='right', fill='y')
        self.info_tree.configure(yscrollcommand=info_scroll.set, xscrollcommand=info_hscroll.set)

        btn_row = tk.Frame(extra_body, bg=card)
        btn_row.pack(fill='x', padx=10, pady=(0, 8))
        tk.Button(btn_row, text='Xóa dòng chọn', command=self.delete_custom_order_info,
                  font=('Segoe UI', 8, 'bold'), bg='#d84a4a', fg='white', relief='flat', bd=0,
                  padx=10, pady=3).pack(side='left')
        tk.Button(btn_row, text='Xóa tất cả', command=self.clear_custom_order_info,
                  font=('Segoe UI', 8, 'bold'), bg='#e39a20', fg='white', relief='flat', bd=0,
                  padx=10, pady=3).pack(side='left', padx=6)
        tk.Label(btn_row, text='Ô trống ghi đúng vị trí; chỉ dời bố cục khi vị trí chạm vùng dữ liệu.',
                 font=('Segoe UI', 8), bg=card, fg=muted).pack(side='left', padx=8)

        def _toggle_extra_info():
            self._extra_info_open = not bool(getattr(self, '_extra_info_open', False))
            if self._extra_info_open:
                extra_body.pack(fill='both', expand=True)
                self.extra_info_toggle_btn.config(text='▾  THÔNG TIN BỔ SUNG / VỊ TRÍ EXCEL')
            else:
                extra_body.pack_forget()
                self.extra_info_toggle_btn.config(text='▸  THÔNG TIN BỔ SUNG / VỊ TRÍ EXCEL')
            try:
                self.cut_main_canvas.configure(scrollregion=self.cut_main_canvas.bbox('all'))
            except Exception:
                pass

        self.extra_info_toggle_btn.configure(command=_toggle_extra_info)

    def _app_base_dir(self):
        """Thư mục chứa file .py hoặc .exe để có thể đặt logo.png cạnh chương trình."""
        if getattr(sys, 'frozen', False):
            return os.path.dirname(os.path.abspath(sys.executable))
        return os.path.dirname(os.path.abspath(__file__))

    def _logo_config_dir(self):
        """Thư mục lưu cấu hình/logo mặc định, dùng được cả khi đóng gói EXE."""
        base = os.environ.get('APPDATA') or os.path.expanduser('~')
        folder = os.path.join(base, 'CuttingPlan')
        try:
            os.makedirs(folder, exist_ok=True)
        except Exception:
            # Nếu không tạo được AppData thì dùng thư mục chương trình.
            folder = self._app_base_dir()
        return folder

    def _logo_config_file(self):
        return os.path.join(self._logo_config_dir(), 'config.json')

    def _load_default_logo_path(self):
        """Ưu tiên logo đã lưu. Nếu chưa có cấu hình thì tìm logo cạnh chương trình."""
        config_file = self._logo_config_file()
        try:
            if os.path.isfile(config_file):
                with open(config_file, 'r', encoding='utf-8') as f:
                    cfg = json.load(f)
                # Có khóa logo_path rỗng nghĩa là người dùng đã chủ động Bỏ logo.
                if 'logo_path' in cfg:
                    saved = str(cfg.get('logo_path') or '').strip()
                    if not saved:
                        return None
                    if os.path.isfile(saved):
                        return saved
        except Exception:
            pass

        # Lần đầu chạy: chỉ cần đặt một file tên logo.png cạnh chương trình.
        base = self._app_base_dir()
        for name in ('logo.png', 'logo.jpg', 'logo.jpeg', 'logo.bmp', 'logo.webp'):
            candidate = os.path.join(base, name)
            if os.path.isfile(candidate):
                return candidate
        return None

    def _save_logo_preference(self, logo_path):
        """Lưu đường dẫn logo để lần sau tự chọn."""
        try:
            cfg = {'logo_path': logo_path or ''}
            with open(self._logo_config_file(), 'w', encoding='utf-8') as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
        except Exception:
            # Không làm gián đoạn chương trình nếu máy không cho ghi cấu hình.
            pass

    def _store_logo_as_default(self, source_path):
        """Chép/chuyển logo người dùng chọn thành PNG mặc định bền vững trong AppData."""
        if PILImage is None:
            self._save_logo_preference(source_path)
            return source_path
        try:
            dest = os.path.join(self._logo_config_dir(), 'default_logo.png')
            with PILImage.open(source_path) as img:
                img.load()
                # Giữ nền trong suốt nếu có.
                if img.mode not in ('RGB', 'RGBA'):
                    img = img.convert('RGBA')
                img.save(dest, format='PNG')
            self._save_logo_preference(dest)
            return dest
        except Exception:
            self._save_logo_preference(source_path)
            return source_path

    def _apply_loaded_logo_to_ui(self):
        """Sau khi giao diện đã tạo, hiển thị logo mặc định lên preview."""
        if not getattr(self, 'logo_path', None):
            return
        if hasattr(self, 'logo_name_var'):
            self.logo_name_var.set(os.path.basename(self.logo_path))
        if self._update_logo_preview() and hasattr(self, 'status_var'):
            self.status_var.set(f"Đã nạp logo mặc định: {os.path.basename(self.logo_path)}")

    def _update_logo_preview(self):
        """Hiển thị logo đã chọn trên giao diện và kiểm tra ảnh có đọc được hay không."""
        if not getattr(self, 'logo_path', None):
            self.logo_preview_photo = None
            if hasattr(self, 'logo_preview_label'):
                self.logo_preview_label.config(image='', text='Chưa có logo')
            return True

        if PILImage is None or ImageTk is None:
            messagebox.showerror(
                "Thiếu thư viện Pillow",
                "Không thể hiển thị/chèn logo vì máy chưa có Pillow.\n\n"
                "Mở Command Prompt và chạy:\npip install pillow"
            )
            return False

        try:
            with PILImage.open(self.logo_path) as img:
                # Đọc ảnh ngay để phát hiện file lỗi trước khi xuất Excel.
                img.load()
                preview = img.convert('RGBA')
                preview.thumbnail((110, 42), PILImage.Resampling.LANCZOS)
                self.logo_preview_photo = ImageTk.PhotoImage(preview)

            if hasattr(self, 'logo_preview_label'):
                self.logo_preview_label.config(
                    image=self.logo_preview_photo,
                    text='',
                    width=110,
                    height=42
                )
            return True
        except Exception as e:
            self.logo_preview_photo = None
            if hasattr(self, 'logo_preview_label'):
                self.logo_preview_label.config(image='', text='Logo không đọc được')
            messagebox.showerror("Lỗi logo", f"Không thể mở file logo:\n{e}")
            return False

    def select_logo(self):
        filename = filedialog.askopenfilename(
            title="Chọn logo",
            filetypes=[
                ("Image files", "*.png *.jpg *.jpeg *.bmp *.webp"),
                ("PNG", "*.png"),
                ("JPEG", "*.jpg *.jpeg"),
                ("BMP", "*.bmp"),
                ("WEBP", "*.webp"),
                ("All files", "*.*"),
            ]
        )
        if not filename:
            return

        # Chỉ nhận logo sau khi đã xác nhận ảnh đọc được.
        old_logo = getattr(self, 'logo_path', None)
        self.logo_path = filename
        if not self._update_logo_preview():
            self.logo_path = old_logo
            self._update_logo_preview()
            return

        # Lưu thành logo mặc định để lần mở chương trình sau tự nạp lại.
        saved_logo = self._store_logo_as_default(filename)
        self.logo_path = saved_logo
        self._update_logo_preview()

        if hasattr(self, 'logo_name_var'):
            self.logo_name_var.set(os.path.basename(filename))
        if hasattr(self, 'status_var'):
            self.status_var.set(f"Đã chọn và lưu logo mặc định: {os.path.basename(filename)}")

    def clear_logo(self):
        self.logo_path = None
        self._save_logo_preference(None)
        self.logo_preview_photo = None
        if hasattr(self, 'logo_name_var'):
            self.logo_name_var.set("Chưa chọn logo")
        if hasattr(self, 'logo_preview_label'):
            self.logo_preview_label.config(image='', text='Chưa có logo', width=14, height=2)
        if hasattr(self, 'status_var'):
            self.status_var.set("Đã bỏ logo")

    def add_custom_order_info(self):
        name = self.entry_extra_info_name.get().strip()
        value = self.entry_extra_info_value.get().strip()
        col = self.entry_extra_info_col.get().strip().upper()
        row_text = self.entry_extra_info_row.get().strip()

        if not name and not value:
            messagebox.showwarning("Cảnh báo", "Vui lòng nhập tên thông tin hoặc nội dung!")
            return
        if not re.fullmatch(r'[A-Z]{1,2}', col or ''):
            messagebox.showwarning("Cảnh báo", "Cột Excel phải là chữ, ví dụ C, H, O, AA...")
            return
        try:
            row = int(row_text)
        except ValueError:
            messagebox.showwarning("Cảnh báo", "Dòng Excel phải là số nguyên dương!")
            return
        if row < 1:
            messagebox.showwarning("Cảnh báo", "Dòng Excel phải từ 1 trở lên!")
            return

        self.custom_info_list.append({'name': name, 'value': value, 'col': col, 'row': row})
        self.update_custom_info_table()
        self.entry_extra_info_name.delete(0, tk.END)
        self.entry_extra_info_value.delete(0, tk.END)
        self.entry_extra_info_col.delete(0, tk.END)
        self.entry_extra_info_row.delete(0, tk.END)
        self.status_var.set(f"Đã thêm thông tin đơn hàng tại {col}{row}")

    def update_custom_info_table(self):
        if not hasattr(self, 'info_tree'):
            return
        for item in self.info_tree.get_children():
            self.info_tree.delete(item)
        for item in self.custom_info_list:
            self.info_tree.insert('', 'end', values=(
                item.get('name', ''), item.get('value', ''),
                item.get('col', ''), item.get('row', '')
            ))

    def delete_custom_order_info(self):
        if not hasattr(self, 'info_tree'):
            return
        selected = self.info_tree.selection()
        if not selected:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn thông tin cần xóa!")
            return
        indices = sorted({self.info_tree.index(i) for i in selected}, reverse=True)
        for idx in indices:
            if 0 <= idx < len(self.custom_info_list):
                del self.custom_info_list[idx]
        self.update_custom_info_table()

    def clear_custom_order_info(self):
        if self.custom_info_list and messagebox.askyesno("Xác nhận", "Xóa tất cả thông tin đơn hàng đã thêm?"):
            self.custom_info_list.clear()
            self.update_custom_info_table()

    def create_po_tab(self, parent):
        input_frame = tk.LabelFrame(parent, text="Thêm PO mới",
                                   font=('Arial', 11, 'bold'), padx=15, pady=15)
        input_frame.pack(fill='x', padx=20, pady=(6, 4))

        # Khu vực chỉnh tên size / thêm size
        size_name_frame = tk.LabelFrame(input_frame, text="Tên size (có thể sửa)",
                                        font=('Arial', 10, 'bold'), padx=8, pady=8)
        size_name_frame.grid(row=0, column=0, columnspan=8, sticky='w', padx=5, pady=5)
        self.size_name_frame = size_name_frame
        self.size_name_entries = {}

        # V62: % tăng sản lượng nhập ngay trong phần mềm, riêng cho từng cỡ.
        percent_frame = tk.LabelFrame(input_frame, text="% DƯƠNG / TĂNG SẢN LƯỢNG TỪNG CỠ",
                                      font=('Arial', 10, 'bold'), padx=8, pady=6)
        percent_frame.grid(row=1, column=0, columnspan=9, sticky='ew', padx=5, pady=(4, 2))
        self.size_percent_frame = percent_frame
        self.size_percent_entries = {}

        # Khu vực nhập số lượng PO.
        qty_frame = tk.Frame(input_frame)
        qty_frame.grid(row=2, column=0, columnspan=8, sticky='w', padx=5, pady=5)
        self.qty_frame = qty_frame

        tk.Label(qty_frame, text="Số PO:", font=('Arial', 10, 'bold')).grid(
            row=0, column=0, padx=5, pady=5, sticky='e')
        self.entry_po = tk.Entry(qty_frame, width=10, font=('Arial', 10))
        self.entry_po.grid(row=0, column=1, padx=5, pady=5, sticky='w')

        self.size_entries = {}
        self.size_labels = {}
        self.refresh_size_ui()

        self.add_po_button = tk.Button(input_frame, text="➕ Thêm PO", command=self.add_po,
                 font=('Arial', 10, 'bold'), bg='#27ae60', fg='white',
                 padx=15, pady=5)
        self.add_po_button.grid(row=2, column=8, padx=20, pady=5, sticky='w')

        # ===== V26: DANH SÁCH PO DẠNG Ô GIỐNG EXCEL =====
        table_frame = tk.LabelFrame(parent, text="Danh sách PO - bảng nhập liệu kiểu Excel",
                                   font=('Arial', 11, 'bold'), padx=8, pady=8)
        table_frame.pack(fill='both', expand=True, padx=20, pady=(4, 6))

        grid_wrap = tk.Frame(table_frame, bd=1, relief='solid', bg='#9aa4ad')
        grid_wrap.pack(fill='both', expand=True)
        # V112: bảng PO luôn tự co các cột theo chiều rộng đang có.
        # Không dùng thanh cuộn ngang nữa; khi thu nhỏ cửa sổ thì cột SIZE tự hẹp lại.
        self.po_grid_canvas = tk.Canvas(grid_wrap, highlightthickness=0, bg='white', height=470)
        self.po_grid_vscroll = ttk.Scrollbar(grid_wrap, orient='vertical', command=self.po_grid_canvas.yview)
        self.po_grid_canvas.configure(yscrollcommand=self.po_grid_vscroll.set)
        self.po_grid_vscroll.pack(side='right', fill='y')
        self.po_grid_canvas.pack(side='left', fill='both', expand=True)

        self.po_grid_inner = tk.Frame(self.po_grid_canvas, bg='white')
        self.po_grid_window = self.po_grid_canvas.create_window((0, 0), window=self.po_grid_inner, anchor='nw')
        self.po_grid_inner.bind('<Configure>', lambda e: self.po_grid_canvas.configure(
            scrollregion=self.po_grid_canvas.bbox('all')))
        self.po_grid_canvas.bind('<Configure>', self._on_po_grid_canvas_configure)

        self.po_grid_selected = (0, 0)
        self.po_grid_selection_anchor = (0, 0)
        self.po_grid_selection_end = (0, 0)
        self.po_grid_selected_widget = None
        self.po_grid_cell_widgets = {}
        self.po_grid_widget_coords = {}
        self.po_grid_base_bg = {}
        self.po_grid_total_vars = {}
        self.po_grid_min_rows = 30
        self.refresh_po_grid()

        btn_frame = tk.Frame(parent)
        btn_frame.pack(fill='x', padx=20, pady=5)

        tk.Button(btn_frame, text="🗑️ Xóa PO đang chọn", command=self.delete_po,
                 font=('Arial', 10, 'bold'), bg='#e74c3c', fg='white',
                 padx=15, pady=5).pack(side='left')
        tk.Button(btn_frame, text="🧹 Xóa tất cả", command=self.clear_all_pos,
                 font=('Arial', 10, 'bold'), bg='#f39c12', fg='white',
                 padx=15, pady=5).pack(side='left', padx=10)
        self.po_paste_info_var = tk.StringVar(value='Ô dán: Số PO - dòng 1')
        tk.Label(btn_frame, textvariable=self.po_paste_info_var,
                 font=('Arial', 9, 'bold'), fg='#1f4e78').pack(side='left', padx=8)
        tk.Label(btn_frame, text="Chọn DƯƠNG TỪNG PO → tích cột DƯƠNG % ở PO cần tăng • Ctrl+C/Ctrl+V • Delete xóa SL",
                 font=('Arial', 9), fg='#566573').pack(side='left', padx=8)

        self.summary_frame = tk.LabelFrame(parent, text="Tổng kết",
                                           font=('Arial', 11, 'bold'), padx=15, pady=10)
        self.summary_frame.pack(fill='x', padx=20, pady=(4, 6))

        self.summary_label = tk.Label(self.summary_frame, text="Tổng số lượng: 0",
                                     font=('Arial', 11, 'bold'), fg='#2c3e50')
        self.summary_label.pack(side='left', anchor='w', fill='x', expand=True)

    def refresh_size_ui(self):
        """Ve lai o ten size va o nhap so luong theo danh sach size hien tai."""
        # Luu lai du lieu dang nhap truoc khi ve lai giao dien.
        old_po = ''
        old_color = ''
        if hasattr(self, 'entry_po'):
            try:
                old_po = self.entry_po.get()
            except tk.TclError:
                old_po = ''
        if hasattr(self, 'entry_po_color'):
            try:
                old_color = self.entry_po_color.get()
            except tk.TclError:
                old_color = ''
        old_qty = {}
        if hasattr(self, 'size_entries'):
            for key, entry in self.size_entries.items():
                try:
                    old_qty[key] = entry.get()
                except tk.TclError:
                    old_qty[key] = '0'

        # Commit % đang nhập trước khi vẽ lại giao diện size.
        try:
            self._sync_size_percent_from_ui(silent=True)
        except Exception:
            pass

        if hasattr(self, 'size_name_frame'):
            for widget in self.size_name_frame.winfo_children():
                widget.destroy()
        if hasattr(self, 'size_percent_frame'):
            for widget in self.size_percent_frame.winfo_children():
                widget.destroy()
        if hasattr(self, 'qty_frame'):
            for widget in self.qty_frame.winfo_children():
                widget.destroy()

        self.size_name_entries = {}
        self.size_percent_entries = {}
        self.size_entries = {}
        self.size_labels = {}

        # Ten size: moi size co 1 o Entry. Sua xong roi khoi o se cap nhat ngay.
        for i, size in enumerate(self.sizes):
            key = size['key']
            col = (i % 6) * 2
            row = i // 6
            tk.Label(self.size_name_frame, text=f"Size {i+1}:",
                     font=('Arial', 9, 'bold')).grid(row=row, column=col, padx=3, pady=3, sticky='e')
            entry = tk.Entry(self.size_name_frame, width=9, font=('Arial', 9))
            entry.insert(0, size['name'])
            entry.grid(row=row, column=col + 1, padx=3, pady=3, sticky='w')
            tk.Button(self.size_name_frame, text='Xóa', command=lambda k=key: self.delete_size(k),
                      font=('Arial', 8, 'bold'), bg='#e74c3c', fg='white',
                      padx=5, pady=1).grid(row=row, column=col + 2, padx=2, pady=3, sticky='w')
            entry.bind('<FocusOut>', lambda e, k=key: self.rename_size(k))
            entry.bind('<Return>', lambda e, k=key: self.rename_size(k))
            self.size_name_entries[key] = entry

        add_row = max(0, (len(self.sizes) - 1) // 6) + 1

        # V158: cho phép chèn cỡ ở ĐẦU hoặc thêm ở CUỐI.
        size_add_bar = tk.Frame(self.size_name_frame, bg=self.size_name_frame.cget('bg'))
        size_add_bar.grid(
            row=add_row, column=0, columnspan=12,
            sticky='w', padx=3, pady=(6, 3)
        )

        tk.Button(
            size_add_bar, text="＋ CỠ ĐẦU",
            command=self.add_size_first,
            font=('Arial', 9, 'bold'),
            bg='#8e44ad', fg='white',
            activebackground='#7d3c98', activeforeground='white',
            padx=12, pady=4
        ).pack(side='left', padx=(0, 6))

        tk.Button(
            size_add_bar, text="＋ CỠ CUỐI",
            command=self.add_size,
            font=('Arial', 9, 'bold'),
            bg='#3498db', fg='white',
            activebackground='#2e86c1', activeforeground='white',
            padx=12, pady=4
        ).pack(side='left')

        # V83: bật/tắt % dương + chọn áp dụng TẤT CẢ PO hay TỪNG PO.
        if hasattr(self, 'size_percent_frame'):
            mode_row = tk.Frame(self.size_percent_frame, bg='#fffaf0')
            mode_row.grid(row=0, column=0, columnspan=12, sticky='ew', padx=3, pady=(1, 6))

            tk.Checkbutton(
                mode_row, text='ÁP DỤNG % DƯƠNG', variable=self.increase_enabled_var,
                command=self._on_increase_mode_changed, font=('Arial', 9, 'bold'),
                bg='#fffaf0', activebackground='#fffaf0'
            ).pack(side='left', padx=(2, 14))
            tk.Radiobutton(
                mode_row, text='DƯƠNG TẤT CẢ PO', variable=self.increase_mode_var, value='all',
                command=self._on_increase_mode_changed, font=('Arial', 9, 'bold'),
                bg='#fffaf0', activebackground='#fffaf0'
            ).pack(side='left', padx=(0, 12))
            tk.Radiobutton(
                mode_row, text='DƯƠNG TỪNG PO', variable=self.increase_mode_var, value='selected',
                command=self._on_increase_mode_changed, font=('Arial', 9, 'bold'),
                bg='#fffaf0', activebackground='#fffaf0'
            ).pack(side='left', padx=(0, 12))
            tk.Label(
                mode_row, text='(DƯƠNG TỪNG PO: tích PO cần dương ở bảng bên dưới)',
                font=('Arial', 8), fg='#7a5b00', bg='#fffaf0'
            ).pack(side='left')

            for i, size in enumerate(self.sizes):
                key = size['key']
                col = (i % 6) * 2
                row = 1 + (i // 6)
                tk.Label(self.size_percent_frame, text=f"{size['name']} (%):",
                         font=('Arial', 9, 'bold')).grid(row=row, column=col, padx=(5, 2), pady=3, sticky='e')
                ent_pct = tk.Entry(self.size_percent_frame, width=7, font=('Arial', 9), justify='center')
                pct = float(size.get('increase_pct', 0.0) or 0.0)
                ent_pct.insert(0, (f"{pct:.4f}").rstrip('0').rstrip('.') if abs(pct) > 1e-12 else '0')
                ent_pct.grid(row=row, column=col + 1, padx=(0, 8), pady=3, sticky='w')
                ent_pct.bind('<FocusOut>', lambda e, k=key: self.update_size_percent(k))
                ent_pct.bind('<Return>', lambda e, k=key: self.update_size_percent(k))
                self.size_percent_entries[key] = ent_pct

        # Ô nhập PO + MÀU + số lượng: tất cả trên CÙNG 1 hàng.
        self.entry_po = tk.Entry(self.qty_frame, width=10, font=('Arial', 10))
        self.entry_po.insert(0, old_po)
        tk.Label(self.qty_frame, text="Số PO:", font=('Arial', 10, 'bold')).grid(
            row=0, column=0, padx=5, pady=5, sticky='e')
        self.entry_po.grid(row=0, column=1, padx=5, pady=5, sticky='w')

        tk.Label(self.qty_frame, text="Màu/Color:", font=('Arial', 10, 'bold')).grid(
            row=0, column=2, padx=5, pady=5, sticky='e')
        # V93: ô MÀU của PO dùng tên riêng để không ghi đè self.entry_color của THÔNG TIN CHUNG.
        self.entry_po_color = tk.Entry(self.qty_frame, width=18, font=('Arial', 10))
        self.entry_po_color.insert(0, old_color)
        self.entry_po_color.grid(row=0, column=3, padx=5, pady=5, sticky='w')

        for i, size in enumerate(self.sizes):
            key = size['key']
            row = 0
            pair_col = i * 2 + 4
            tk.Label(self.qty_frame, text=f"{size['name']}:", font=('Arial', 10, 'bold')).grid(
                row=row, column=pair_col, padx=5, pady=5, sticky='e')
            entry = tk.Entry(self.qty_frame, width=8, font=('Arial', 10))
            entry.insert(0, old_qty.get(key, '0') or '0')
            entry.grid(row=row, column=pair_col + 1, padx=5, pady=5, sticky='w')
            self.size_entries[key] = entry
            self.size_labels[key] = self.qty_frame.grid_slaves(row=row, column=pair_col)[0]

        if hasattr(self, 'po_tree') or hasattr(self, 'po_grid_inner'):
            self.refresh_po_tree_columns()
            self.update_po_table()
        if hasattr(self, 'summary_label'):
            self.update_summary()

    def rename_size(self, key):
        """Cập nhật tên size nhưng không thay đổi dữ liệu PO bên trong."""
        if key not in self.size_name_entries:
            return
        new_name = self.size_name_entries[key].get().strip()
        if not new_name:
            # Không cho tên rỗng, trả lại tên cũ.
            old_name = next((s['name'] for s in self.sizes if s['key'] == key), '')
            self.size_name_entries[key].delete(0, tk.END)
            self.size_name_entries[key].insert(0, old_name)
            return

        # Không cho trùng tên size (không phân biệt hoa thường).
        for size in self.sizes:
            if size['key'] != key and size['name'].strip().lower() == new_name.lower():
                messagebox.showwarning("Cảnh báo", f"Tên size '{new_name}' đã tồn tại!")
                old_name = next((s['name'] for s in self.sizes if s['key'] == key), '')
                self.size_name_entries[key].delete(0, tk.END)
                self.size_name_entries[key].insert(0, old_name)
                return

        for size in self.sizes:
            if size['key'] == key:
                size['name'] = new_name
                break

        # Đồng bộ label nhập số lượng và tiêu đề bảng.
        if key in self.size_labels:
            self.size_labels[key].config(text=f"{new_name}:")
        self.refresh_po_tree_columns()
        self.status_var.set(f"Đã đổi tên size: {new_name}")

    def delete_size(self, key):
        """Xoa mot size va cot du lieu tu tat ca PO. Khong cho xoa size cuoi cung."""
        if len(self.sizes) <= 1:
            messagebox.showwarning("Cảnh báo", "Phải giữ lại ít nhất 1 size!")
            return

        size = next((item for item in self.sizes if item['key'] == key), None)
        if not size:
            return

        # Neu size da co du lieu, hoi xac nhan truoc khi xoa.
        has_qty = any(po.get(key, 0) not in (0, '', None) for po in self.po_list)
        if has_qty:
            ok = messagebox.askyesno(
                "Xác nhận xóa size",
                f"Size {size['name']} đang có số lượng trong PO.\n\n"
                f"Xóa size này sẽ xóa luôn số lượng {size['name']} trong tất cả PO.\n\n"
                "Bạn có chắc muốn xóa?"
            )
            if not ok:
                return

        self.sizes = [item for item in self.sizes if item['key'] != key]
        for po in self.po_list:
            po.pop(key, None)
            po['total'] = sum(po.get(item['key'], 0) for item in self.sizes)

        self.refresh_size_ui()
        self.status_var.set(f"Đã xóa size: {size['name']}")

    def add_size_first(self):
        """V158: thêm một cỡ mới vào ĐẦU danh sách size."""
        key = f"size{self.next_size_number}"
        self.next_size_number += 1

        # Tên mặc định rõ vị trí, người dùng có thể đổi ngay sau khi thêm.
        new_name = "SIZE ĐẦU"
        used = {str(s.get('name', '')).strip().lower() for s in self.sizes}
        if new_name.lower() in used:
            no = 1
            while f"SIZE ĐẦU {no}".lower() in used:
                no += 1
            new_name = f"SIZE ĐẦU {no}"

        new_size = {
            'key': key,
            'name': new_name,
            'factor': 1.00,
            'increase_pct': 0.0
        }
        self.sizes.insert(0, new_size)

        # PO cũ được bổ sung cỡ mới với số lượng 0.
        for po in self.po_list:
            po[key] = 0
            po['total'] = sum(po.get(s['key'], 0) for s in self.sizes)

        self.refresh_size_ui()
        self.status_var.set(f"Đã thêm cỡ đầu: {new_name}")

        # Đưa con trỏ vào ô tên cỡ vừa thêm để đổi tên ngay.
        if key in self.size_name_entries:
            try:
                self.size_name_entries[key].focus_set()
                self.size_name_entries[key].selection_range(0, tk.END)
            except Exception:
                pass

    def add_size(self):
        """V158: thêm một cỡ mới vào CUỐI danh sách size."""
        key = f"size{self.next_size_number}"
        self.next_size_number += 1
        new_name = f"SIZE {len(self.sizes) + 1}"
        self.sizes.append({
            'key': key, 'name': new_name,
            'factor': 1.00, 'increase_pct': 0.0
        })

        # Bổ sung cột dữ liệu mới cho các PO đã nhập.
        for po in self.po_list:
            po[key] = 0
            po['total'] = sum(po.get(s['key'], 0) for s in self.sizes)

        self.refresh_size_ui()
        self.status_var.set(f"Đã thêm size: {new_name}")
        # Đưa con trỏ vào ô tên size mới.
        if key in self.size_name_entries:
            self.size_name_entries[key].focus_set()
            self.size_name_entries[key].selection_range(0, tk.END)

    def refresh_po_tree_columns(self):
        """V26: cập nhật cột PO. Nếu đang dùng bảng ô Excel thì vẽ lại bảng."""
        # Đồng bộ lại CÂY và LOT tự động từ ÁNH trước mỗi lần tính/xuất.
        self._sync_all_shade_lots()
        if hasattr(self, 'po_grid_inner'):
            self.refresh_po_grid()
            return
        if not hasattr(self, 'po_tree'):
            return
        size_keys = [s['key'] for s in self.sizes]
        columns = ['po', 'color'] + size_keys + ['total']
        self.po_tree['columns'] = columns
        self.po_tree.heading('po', text='Số PO')
        self.po_tree.column('po', width=100, anchor='center')
        self.po_tree.heading('color', text='MÀU/COLOR')
        self.po_tree.column('color', width=160, anchor='center')
        for size in self.sizes:
            self.po_tree.heading(size['key'], text=size['name'])
            self.po_tree.column(size['key'], width=90, anchor='center')
        self.po_tree.heading('total', text='TỔNG')
        self.po_tree.column('total', width=100, anchor='center')

    def add_po(self):
        try:
            po = self.entry_po.get().strip()
            if not po:
                messagebox.showwarning("Cảnh báo", "Vui lòng nhập số PO!")
                return
            color = self.entry_po_color.get().strip() if hasattr(self, 'entry_po_color') else ''

            sizes = {}
            for size in self.sizes:
                key = size['key']
                entry = self.size_entries[key]
                val = entry.get().strip()
                sizes[key] = int(val) if val else 0

            total = sum(sizes.values())
            po_data = {'po': po, 'color': color, 'apply_increase': False, **sizes, 'total': total}
            self.po_list.append(po_data)

            self.update_po_table()
            self.update_summary()

            self.entry_po.delete(0, tk.END)
            if hasattr(self, 'entry_po_color'):
                self.entry_po_color.delete(0, tk.END)
            for entry in self.size_entries.values():
                entry.delete(0, tk.END)
                entry.insert(0, '0')

            self.status_var.set(f"Đã thêm PO: {po}")

        except ValueError:
            messagebox.showerror("Lỗi", "Số lượng phải là số nguyên!")

    def delete_po(self):
        # V26: bảng PO dạng ô dùng dòng đang chọn thay cho selection của Treeview.
        if hasattr(self, 'po_grid_inner'):
            if not self.po_list:
                messagebox.showwarning("Cảnh báo", "Chưa có PO để xóa!")
                return
            row = int(getattr(self, 'po_grid_selected', (0, 0))[0])
            if row < 0 or row >= len(self.po_list):
                messagebox.showwarning("Cảnh báo", "Hãy chọn một ô trong dòng PO cần xóa!")
                return
            name = str(self.po_list[row].get('po', '') or '')
            if not messagebox.askyesno('Xác nhận', f'Xóa PO {name}?'):
                return
            del self.po_list[row]
            self.po_grid_selected = (max(0, min(row, len(self.po_list)-1)), 0)
            self.update_po_table()
            self.update_summary()
            self.status_var.set("Đã xóa PO được chọn")
            return

        selected = self.po_tree.selection()
        if not selected:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn PO cần xóa!")
            return
        for item in selected:
            idx = self.po_tree.index(item)
            if 0 <= idx < len(self.po_list):
                del self.po_list[idx]
        self.update_po_table()
        self.update_summary()
        self.status_var.set("Đã xóa PO được chọn")

    def clear_all_pos(self):
        if messagebox.askyesno("Xác nhận", "Bạn có chắc muốn xóa tất cả PO?"):
            self.po_list.clear()
            self.update_po_table()
            self.update_summary()
            self.status_var.set("Đã xóa tất cả PO")

    def update_po_table(self):
        # V26: bảng PO dạng ô giống Excel.
        if hasattr(self, 'po_grid_inner'):
            self.refresh_po_grid()
            self._refresh_fabric_po_selector()
            return
        if not hasattr(self, 'po_tree'):
            return
        for item in self.po_tree.get_children():
            self.po_tree.delete(item)
        self.refresh_po_tree_columns()
        size_keys = [s['key'] for s in self.sizes]
        for po in self.po_list:
            values = [po.get('po', ''), po.get('color', '')] + [po.get(k, 0) for k in size_keys]
            values.append(sum(po.get(k, 0) for k in size_keys))
            self.po_tree.insert('', 'end', values=tuple(values))
        self._refresh_fabric_po_selector()

    # ==================== V62: % DƯƠNG RIÊNG TỪNG CỠ TRONG PHẦN MỀM ====================
    def _parse_size_percent(self, value, silent=False):
        raw = str(value if value is not None else '').strip().replace('%', '').replace(',', '.')
        if raw == '':
            return 0.0
        try:
            pct = float(raw)
        except Exception:
            if silent:
                return 0.0
            raise ValueError('% dương từng cỡ phải là số, ví dụ 1 hoặc 1.5.')
        if pct < 0:
            if silent:
                return 0.0
            raise ValueError('% dương từng cỡ không được âm.')
        return pct

    def update_size_percent(self, key):
        entry = getattr(self, 'size_percent_entries', {}).get(key)
        size = next((x for x in self.sizes if x.get('key') == key), None)
        if entry is None or size is None:
            return
        try:
            pct = self._parse_size_percent(entry.get(), silent=False)
        except ValueError as e:
            messagebox.showerror('Lỗi', str(e))
            pct = float(size.get('increase_pct', 0.0) or 0.0)
        size['increase_pct'] = pct
        try:
            entry.delete(0, tk.END)
            entry.insert(0, (f"{pct:.4f}").rstrip('0').rstrip('.') if abs(pct) > 1e-12 else '0')
        except Exception:
            pass
        self.update_summary()
        if hasattr(self, 'status_var'):
            self.status_var.set(f"% dương {size.get('name','')}: {pct:g}%")

    def _sync_size_percent_from_ui(self, silent=False):
        entries = getattr(self, 'size_percent_entries', {}) or {}
        for size in self.sizes:
            key = size.get('key')
            entry = entries.get(key)
            if entry is None:
                size.setdefault('increase_pct', 0.0)
                continue
            try:
                pct = self._parse_size_percent(entry.get(), silent=silent)
            except ValueError:
                if silent:
                    pct = float(size.get('increase_pct', 0.0) or 0.0)
                else:
                    raise
            size['increase_pct'] = pct
        return {s['key']: float(s.get('increase_pct', 0.0) or 0.0) for s in self.sizes}

    def _size_percent_map(self):
        return {s['key']: max(0.0, float(s.get('increase_pct', 0.0) or 0.0)) for s in self.sizes}

    def _increase_enabled(self):
        try:
            return bool(self.increase_enabled_var.get())
        except Exception:
            return True

    def _increase_mode(self):
        try:
            mode = str(self.increase_mode_var.get() or 'all').strip().lower()
        except Exception:
            mode = 'all'
        return mode if mode in ('all', 'selected') else 'all'

    def _po_increase_active(self, po):
        """V83: PO này có thực sự được áp dụng % dương hay không."""
        if not self._increase_enabled():
            return False
        if self._increase_mode() == 'all':
            return True
        return bool((po or {}).get('apply_increase', False))

    def _on_increase_mode_changed(self):
        """Cập nhật ngay kế hoạch và cột tích PO khi đổi chế độ % dương."""
        try:
            self.update_summary()
        except Exception:
            pass
        try:
            self.refresh_po_grid()
        except Exception:
            pass
        if self.fabric_list:
            try:
                self._sync_global_lots()
                self.update_fabric_table()
            except Exception:
                pass
        if hasattr(self, 'status_var'):
            if not self._increase_enabled():
                msg = 'Đã tắt % dương cho tất cả PO'
            elif self._increase_mode() == 'all':
                msg = 'Áp dụng % dương cho TẤT CẢ PO'
            else:
                msg = 'Áp dụng % dương theo TỪNG PO được tích chọn'
            self.status_var.set(msg)

    def _planned_po_qty(self, po, key):
        raw = max(0, int(po.get(key, 0) or 0))
        # V83: có 3 trạng thái: tắt % dương / dương tất cả PO / dương từng PO.
        if not self._po_increase_active(po):
            return raw
        pct = self._size_percent_map().get(key, 0.0)
        if raw <= 0:
            return 0
        return int(math.ceil(raw * (1.0 + pct / 100.0) - 1e-12))

    def get_production_percent(self, silent=False):
        """Lấy % tăng sản lượng. Người dùng nhập 2 nghĩa là tăng 2%."""
        if not hasattr(self, 'production_percent_var'):
            return 0.0
        raw = str(self.production_percent_var.get()).strip().replace(',', '.')
        if raw == '':
            return 0.0
        try:
            value = float(raw)
        except ValueError:
            if silent:
                return 0.0
            raise ValueError("% tăng sản lượng phải là số. Ví dụ nhập 2 để tăng 2%.")
        if value < 0:
            if silent:
                return 0.0
            raise ValueError("% tăng sản lượng không được âm.")
        return value

    def on_production_percent_changed(self, event=None):
        try:
            pct = self.get_production_percent()
        except ValueError as e:
            messagebox.showerror("Lỗi", str(e))
            self.production_percent_var.set('0')
            pct = 0.0
        # Chuẩn hóa cách hiển thị, nhưng không ép số lẻ không cần thiết.
        if abs(pct - round(pct)) < 1e-9:
            self.production_percent_var.set(str(int(round(pct))))
        else:
            self.production_percent_var.set((f"{pct:.4f}").rstrip('0').rstrip('.'))
        self.update_summary()
        if hasattr(self, 'status_var'):
            self.status_var.set(f"Tăng sản lượng: {pct:g}%")

    def update_summary(self):
        """V62: hiển thị cả số lượng gốc và kế hoạch sau % riêng từng cỡ."""
        raw_by_size = {
            size['key']: sum(int(po.get(size['key'], 0) or 0) for po in self.po_list)
            for size in self.sizes
        }
        planned_by_size = {
            size['key']: sum(self._planned_po_qty(po, size['key']) for po in self.po_list)
            for size in self.sizes
        }
        total_raw = sum(raw_by_size.values())
        total_plan = sum(planned_by_size.values())
        if not self._increase_enabled():
            mode_text = 'DƯƠNG: TẮT'
        elif self._increase_mode() == 'all':
            mode_text = 'DƯƠNG: TẤT CẢ PO'
        else:
            selected_count = sum(1 for po in self.po_list if bool(po.get('apply_increase', False)))
            mode_text = f'DƯƠNG: {selected_count}/{len(self.po_list)} PO'
        parts = [f"Tổng gốc: {total_raw} SP", f"Kế hoạch: {total_plan} SP", mode_text]
        for size in self.sizes:
            key = size['key']
            pct = float(size.get('increase_pct', 0.0) or 0.0)
            parts.append(f"{size['name']}: {raw_by_size[key]}→{planned_by_size[key]} (+{pct:g}%)")
        self.summary_label.config(text=" | ".join(parts))

    # ==================== V26: BẢNG PO DẠNG Ô + DÁN THEO Ô ====================
    def _po_grid_columns(self):
        return ['po', 'color', 'apply_increase'] + [s['key'] for s in self.sizes] + ['total']

    def _po_grid_headers(self):
        return ['SỐ PO', 'MÀU/COLOR', 'DƯƠNG %'] + [s['name'] for s in self.sizes] + ['TỔNG']

    def _on_po_grid_canvas_configure(self, event=None):
        """V112: ép bảng PO vừa đúng chiều rộng canvas, không sinh cuộn ngang."""
        try:
            if event is not None and getattr(event, 'widget', None) == self.po_grid_canvas:
                width = max(1, int(event.width or 1))
                self.po_grid_canvas.itemconfigure(self.po_grid_window, width=width)
            self.po_grid_canvas.configure(scrollregion=self.po_grid_canvas.bbox('all'))
        except Exception:
            pass

    def _po_grid_selection_bounds(self):
        a = getattr(self, 'po_grid_selection_anchor', getattr(self, 'po_grid_selected', (0, 0)))
        b = getattr(self, 'po_grid_selection_end', getattr(self, 'po_grid_selected', (0, 0)))
        r1, r2 = sorted((max(0, int(a[0])), max(0, int(b[0]))))
        c1, c2 = sorted((max(0, int(a[1])), max(0, int(b[1]))))
        return r1, c1, r2, c2

    def _po_grid_highlight_selection(self):
        r1, c1, r2, c2 = self._po_grid_selection_bounds()
        for (r, c), w in getattr(self, 'po_grid_cell_widgets', {}).items():
            try:
                selected = r1 <= r <= r2 and c1 <= c <= c2
                base = getattr(self, 'po_grid_base_bg', {}).get((r, c), 'white')
                w.configure(bg=('#cfe8ff' if selected else base))
                if (r, c) == getattr(self, 'po_grid_selected', (-1, -1)):
                    w.configure(highlightthickness=2, highlightbackground='#1f6aa5', highlightcolor='#1f6aa5')
                else:
                    w.configure(highlightthickness=0)
            except Exception:
                pass

    def _po_grid_select_cell(self, row_index, col_index, widget=None, extend=False):
        row_index = max(0, int(row_index)); col_index = max(0, int(col_index))
        if not extend:
            self.po_grid_selection_anchor = (row_index, col_index)
        self.po_grid_selection_end = (row_index, col_index)
        self.po_grid_selected = (row_index, col_index)
        self.po_grid_selected_widget = widget
        self._po_grid_highlight_selection()
        headers = self._po_grid_headers()
        title = headers[col_index] if 0 <= col_index < len(headers) else ''
        if hasattr(self, 'po_paste_info_var'):
            r1, c1, r2, c2 = self._po_grid_selection_bounds()
            if (r1, c1) == (r2, c2):
                self.po_paste_info_var.set(f'Ô chọn: {title} - dòng {row_index + 1}')
            else:
                self.po_paste_info_var.set(f'Vùng chọn: dòng {r1+1}:{r2+1}, cột {c1+1}:{c2+1}')

    def _po_grid_mouse_down(self, event, row_index, col_index, widget):
        extend = bool(int(getattr(event, 'state', 0) or 0) & 0x0001)
        self._po_grid_select_cell(row_index, col_index, widget, extend=extend)

    def _po_grid_drag_select(self, event):
        try:
            target = self.root.winfo_containing(event.x_root, event.y_root)
            while target is not None and target not in self.po_grid_widget_coords:
                parent_name = target.winfo_parent()
                if not parent_name:
                    target = None
                    break
                target = target._nametowidget(parent_name)
            if target in self.po_grid_widget_coords:
                r, c = self.po_grid_widget_coords[target]
                self._po_grid_select_cell(r, c, target, extend=True)
        except Exception:
            pass

    def _po_grid_select_row(self, row_index):
        cols = self._po_grid_columns()
        if not cols:
            return
        self.po_grid_selection_anchor = (row_index, 0)
        self.po_grid_selection_end = (row_index, len(cols)-1)
        self.po_grid_selected = (row_index, 0)
        self._po_grid_highlight_selection()
        if hasattr(self, 'po_paste_info_var'):
            self.po_paste_info_var.set(f'Đã chọn dòng {row_index + 1}')

    def _po_grid_select_all(self, event=None):
        cols = self._po_grid_columns()
        if not cols:
            return 'break'
        last_row = max(0, len(self.po_list)-1)
        self.po_grid_selection_anchor = (0, 0)
        self.po_grid_selection_end = (last_row, len(cols)-1)
        self.po_grid_selected = (0, 0)
        self._po_grid_highlight_selection()
        return 'break'

    def _po_grid_get_value(self, row_index, col_index):
        cols = self._po_grid_columns()
        if not (0 <= col_index < len(cols)) or not (0 <= row_index < len(self.po_list)):
            return ''
        key = cols[col_index]
        po = self.po_list[row_index]
        if key == 'po':
            return str(po.get('po', '') or '')
        if key == 'color':
            return str(po.get('color', '') or '')
        if key == 'apply_increase':
            return '1' if bool(po.get('apply_increase', True)) else '0'
        if key == 'total':
            return str(sum(int(po.get(sz['key'], 0) or 0) for sz in self.sizes))
        return str(po.get(key, 0) or 0)

    def _copy_po_grid_selection(self, event=None):
        r1, c1, r2, c2 = self._po_grid_selection_bounds()
        lines = []
        for r in range(r1, r2 + 1):
            lines.append('\t'.join(self._po_grid_get_value(r, c) for c in range(c1, c2 + 1)))
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append('\n'.join(lines))
            self.status_var.set(f'Đã copy vùng PO dòng {r1+1}:{r2+1}')
        except Exception:
            pass
        return 'break'

    def _clear_po_grid_selection(self, event=None):
        r1, c1, r2, c2 = self._po_grid_selection_bounds()
        cols = self._po_grid_columns()
        changed = 0
        for r in range(r1, min(r2, len(self.po_list)-1) + 1):
            for c in range(c1, min(c2, len(cols)-1) + 1):
                key = cols[c]
                if key in ('po', 'total'):
                    continue
                clear_value = '' if key == 'color' else '0'
                if self._po_cell_set_value(r, key, clear_value, show_error=False):
                    changed += 1
        if changed:
            self.update_po_table(); self.update_summary(); self._refresh_fabric_po_selector()
            if self.fabric_list:
                self._sync_global_lots(); self.update_fabric_table()
            self.status_var.set(f'Đã xóa số lượng trong {changed} ô')
        return 'break'

    def _po_grid_commit_size_header(self, key, var):
        new_name = str(var.get() or '').strip()
        size = next((x for x in self.sizes if x['key'] == key), None)
        if size is None:
            return
        old_name = str(size.get('name', '') or '')
        if not new_name:
            var.set(old_name); return
        if any(x['key'] != key and str(x.get('name','')).strip().lower() == new_name.lower() for x in self.sizes):
            messagebox.showwarning('Cảnh báo', f"Tên size '{new_name}' đã tồn tại!")
            var.set(old_name); return
        if new_name == old_name:
            return
        size['name'] = new_name
        if key in getattr(self, 'size_name_entries', {}):
            e = self.size_name_entries[key]
            e.delete(0, tk.END); e.insert(0, new_name)
        if key in getattr(self, 'size_labels', {}):
            self.size_labels[key].configure(text=f'{new_name}:')
        self.update_summary()
        self.status_var.set(f'Đã đổi tên size: {new_name}')
        self.root.after_idle(self.refresh_po_grid)

    def _po_cell_set_value(self, row_index, col_key, value, show_error=True):
        if not (0 <= row_index < len(self.po_list)):
            return False
        if col_key == 'total':
            return False
        po = self.po_list[row_index]
        raw = str(value or '').strip()
        try:
            if col_key == 'apply_increase':
                po['apply_increase'] = str(raw).strip().lower() not in ('', '0', 'false', 'no', 'không', 'khong', 'off', '☐')
            elif col_key == 'po':
                if not raw:
                    raise ValueError('Số PO không được để trống!')
                old_name = str(po.get('po', '') or '').strip()
                if any(i != row_index and str(x.get('po','')).strip() == raw
                       for i, x in enumerate(self.po_list)):
                    raise ValueError(f'PO {raw} đã tồn tại!')
                po['po'] = raw
                if old_name != raw:
                    for fabric in self.fabric_list:
                        if str(fabric.get('po_mode','all')).lower() != 'all':
                            fabric['po_targets'] = [raw if str(x) == old_name else x
                                                    for x in (fabric.get('po_targets', []) or [])]
                            fabric['roll_po_targets'] = [raw if str(x) == old_name else x
                                                         for x in (fabric.get('roll_po_targets', []) or [])]
            elif col_key == 'color':
                po['color'] = raw
            else:
                qty = int(float(raw.replace(',', '.'))) if raw else 0
                if qty < 0:
                    raise ValueError('Số lượng PO không được âm!')
                po[col_key] = qty
        except Exception as e:
            if show_error:
                messagebox.showerror('Lỗi', str(e))
            return False
        po['total'] = sum(int(po.get(sz['key'], 0) or 0) for sz in self.sizes)
        return True

    def _po_grid_commit_entry(self, row_index, col_key, var, old_value='', total_var=None):
        value = str(var.get() or '').strip()
        created = False
        # Dòng trống kiểu Excel: nhập SỐ PO trước để tạo dòng dữ liệu mới.
        if row_index >= len(self.po_list):
            if not value:
                return
            if col_key != 'po':
                messagebox.showwarning('Danh sách PO', 'Dòng mới hãy nhập SỐ PO trước, sau đó nhập số lượng từng cỡ.')
                var.set('')
                return
            if any(str(x.get('po','')).strip() == value for x in self.po_list):
                messagebox.showerror('Lỗi', f'PO {value} đã tồn tại!')
                var.set('')
                return
            new = {'po': value, 'color': '', 'apply_increase': False}
            for sz in self.sizes:
                new[sz['key']] = 0
            new['total'] = 0
            self.po_list.append(new)
            created = True
        else:
            current = self.po_list[row_index].get('po', '') if col_key == 'po' else self.po_list[row_index].get(col_key, '' if col_key == 'color' else 0)
            if value == str(current).strip():
                return
            if not self._po_cell_set_value(row_index, col_key, value, show_error=True):
                current = self.po_list[row_index].get('po', '') if col_key == 'po' else self.po_list[row_index].get(col_key, '' if col_key == 'color' else 0)
                var.set(str(current))
                return

        if total_var is not None and 0 <= row_index < len(self.po_list):
            total_var.set(str(self.po_list[row_index].get('total', 0)))
        self.update_summary()
        self._refresh_fabric_po_selector()
        if self.fabric_list:
            self._sync_global_lots(); self.update_fabric_table()
        self.status_var.set('Đã thêm PO mới' if created else 'Đã sửa trực tiếp ô PO')
        if created:
            self.root.after_idle(self.refresh_po_grid)

    def _po_grid_focus_cell(self, row_index, col_index):
        w = getattr(self, 'po_grid_cell_widgets', {}).get((row_index, col_index))
        if w is not None:
            try:
                w.focus_set()
                if isinstance(w, tk.Entry):
                    w.selection_range(0, tk.END)
            except Exception:
                pass
            self._po_grid_select_cell(row_index, col_index, w)

    def _po_grid_commit_and_move(self, row_index, col_index, col_key, var, total_var, dr=0, dc=0):
        self._po_grid_commit_entry(row_index, col_key, var, '', total_var)
        nr = max(0, row_index + dr); nc = max(0, min(col_index + dc, len(self._po_grid_columns()) - 1))
        self.root.after_idle(lambda: self._po_grid_focus_cell(nr, nc))
        return 'break'

    def _bind_po_grid_keys(self, widget):
        widget.bind('<Control-c>', self._copy_po_grid_selection)
        widget.bind('<Control-C>', self._copy_po_grid_selection)
        widget.bind('<Control-v>', lambda e: (self._paste_po_grid_from_clipboard(), 'break')[1])
        widget.bind('<Control-V>', lambda e: (self._paste_po_grid_from_clipboard(), 'break')[1])
        widget.bind('<Control-a>', self._po_grid_select_all)
        widget.bind('<Control-A>', self._po_grid_select_all)
        widget.bind('<Delete>', self._clear_po_grid_selection)

    def _sync_po_grid_from_ui(self):
        """V93: đồng bộ dữ liệu đang nhìn thấy trong bảng PO trước khi tính/xuất.

        Tkinter Button không phải lúc nào cũng làm ô Entry mất focus ngay, nên giá trị vừa gõ
        (đặc biệt MÀU/COLOR) có thể còn nằm trong ô giao diện nhưng chưa vào self.po_list.
        Hàm này đọc trực tiếp các Entry của những PO đã tồn tại để Excel luôn nhận đúng dữ liệu.
        """
        if not hasattr(self, 'po_grid_cell_widgets') or not self.po_list:
            return
        cols = self._po_grid_columns()
        for r in range(len(self.po_list)):
            for c, key in enumerate(cols):
                if key in ('apply_increase', 'total'):
                    continue
                w = self.po_grid_cell_widgets.get((r, c))
                if w is None or not isinstance(w, tk.Entry):
                    continue
                try:
                    value = w.get()
                except Exception:
                    continue
                # Không hiện popup trong lúc xuất; nếu giá trị không hợp lệ thì giữ dữ liệu cũ.
                self._po_cell_set_value(r, key, value, show_error=False)
        for po in self.po_list:
            po['total'] = sum(int(po.get(sz['key'], 0) or 0) for sz in self.sizes)

    def refresh_po_grid(self):
        if not hasattr(self, 'po_grid_inner'):
            return
        for child in self.po_grid_inner.winfo_children():
            child.destroy()
        self.po_grid_cell_widgets = {}
        self.po_grid_widget_coords = {}
        self.po_grid_base_bg = {}
        self.po_grid_total_vars = {}
        cols = self._po_grid_columns()
        headers = self._po_grid_headers()
        # V112: width widget để rất nhỏ, còn chiều rộng thực tế do GRID tự chia.
        # Nhờ vậy dù có nhiều SIZE, bảng vẫn nằm gọn trong cửa sổ và không cần cuộn ngang.
        widths = [1, 1, 1] + [1] * len(self.sizes) + [1]

        # Góc trái giống Excel.
        corner = tk.Label(self.po_grid_inner, text='#', font=('Arial', 9, 'bold'),
                          bg='#c7d5e0', bd=1, relief='solid', width=2, height=2)
        corner.grid(row=0, column=0, sticky='nsew')
        self.po_grid_inner.grid_columnconfigure(0, weight=0, minsize=24)

        # Hàng tiêu đề: tên SIZE sửa trực tiếp tại đây.
        size_key_by_col = {i+3: sz['key'] for i, sz in enumerate(self.sizes)}
        for c, (title, width) in enumerate(zip(headers, widths)):
            visual_col = c + 1
            if c in size_key_by_col:
                key = size_key_by_col[c]
                var = tk.StringVar(value=title)
                hdr = tk.Entry(self.po_grid_inner, textvariable=var, justify='center',
                               font=('Arial', 9, 'bold'), bg='#d9eaf7', fg='#1f2937',
                               bd=1, relief='solid', width=width)
                hdr.bind('<FocusOut>', lambda e, k=key, v=var: self._po_grid_commit_size_header(k, v))
                hdr.bind('<Return>', lambda e, k=key, v=var: (self._po_grid_commit_size_header(k, v), 'break')[1])
            else:
                hdr = tk.Label(self.po_grid_inner, text=title, font=('Arial', 9, 'bold'),
                               bg='#d9eaf7', fg='#1f2937', bd=1, relief='solid',
                               width=width, height=2)
            hdr.grid(row=0, column=visual_col, sticky='nsew')
            # Cột PO/MÀU rộng hơn; DƯƠNG và TỔNG hẹp; các SIZE chia đều phần còn lại.
            if c == 0:          # SỐ PO
                col_weight = 14
            elif c == 1:        # MÀU/COLOR
                col_weight = 13
            elif c == 2:        # DƯƠNG %
                col_weight = 6
            elif c == len(cols) - 1:  # TỔNG
                col_weight = 7
            else:               # SIZE
                col_weight = 9
            self.po_grid_inner.grid_columnconfigure(
                visual_col, weight=col_weight, minsize=0, uniform='po_autofit'
            )

        display_rows = max(int(getattr(self, 'po_grid_min_rows', 30)), len(self.po_list) + 5)
        for r in range(display_rows):
            exists = r < len(self.po_list)
            po = self.po_list[r] if exists else None
            row_hdr = tk.Label(self.po_grid_inner, text=str(r+1), font=('Arial', 9),
                               bg='#eef2f5', fg='#455a64', bd=1, relief='solid', width=5)
            row_hdr.grid(row=r+1, column=0, sticky='nsew')
            row_hdr.bind('<Button-1>', lambda e, rr=r: self._po_grid_select_row(rr))

            total_var = tk.StringVar(value=(str(sum(int(po.get(sz['key'], 0) or 0) for sz in self.sizes)) if exists else ''))
            self.po_grid_total_vars[r] = total_var
            values = ([str(po.get('po', '') or ''), str(po.get('color', '') or ''), ''] + [str(po.get(sz['key'], 0) or 0) for sz in self.sizes]) if exists else ([''] * (3 + len(self.sizes)))

            for c, col_key in enumerate(cols):
                visual_col = c + 1
                if col_key == 'total':
                    base_bg = '#f3f4f6'
                    w = tk.Label(self.po_grid_inner, textvariable=total_var, justify='center',
                                 font=('Arial', 10, 'bold'), bg=base_bg, bd=1, relief='solid')
                elif col_key == 'apply_increase':
                    selectable = self._increase_enabled() and self._increase_mode() == 'selected'
                    base_bg = ('#fff2a8' if selectable else '#eeeeee') if exists else '#f7f7f7'
                    if exists:
                        flag = tk.BooleanVar(value=bool(po.get('apply_increase', False)))
                        def _toggle_po_pct(rr=r, vv=flag):
                            if 0 <= rr < len(self.po_list):
                                self.po_list[rr]['apply_increase'] = bool(vv.get())
                                self.update_summary()
                                if self.fabric_list:
                                    try:
                                        self._sync_global_lots(); self.update_fabric_table()
                                    except Exception:
                                        pass
                                self.status_var.set(
                                    f"PO {self.po_list[rr].get('po','')}: "
                                    f"{'CÓ DƯƠNG %' if vv.get() else 'KHÔNG DƯƠNG %'}"
                                )
                        w = tk.Checkbutton(self.po_grid_inner, variable=flag, command=_toggle_po_pct,
                                           bg=base_bg, activebackground=base_bg, bd=1, relief='solid',
                                           state=('normal' if selectable else 'disabled'))
                    else:
                        w = tk.Label(self.po_grid_inner, text='', bg=base_bg, bd=1, relief='solid')
                else:
                    base_bg = 'white'
                    var = tk.StringVar(value=values[c])
                    w = tk.Entry(self.po_grid_inner, textvariable=var, justify='center',
                                 font=('Arial', 10), bd=1, relief='solid', bg=base_bg, width=1)
                    w.bind('<FocusOut>', lambda e, rr=r, ck=col_key, vv=var, tv=total_var:
                           self._po_grid_commit_entry(rr, ck, vv, '', tv))
                    w.bind('<Return>', lambda e, rr=r, cc=c, ck=col_key, vv=var, tv=total_var:
                           self._po_grid_commit_and_move(rr, cc, ck, vv, tv, dr=1, dc=0))
                    w.bind('<Tab>', lambda e, rr=r, cc=c, ck=col_key, vv=var, tv=total_var:
                           self._po_grid_commit_and_move(rr, cc, ck, vv, tv, dr=0, dc=1))
                    w.bind('<ISO_Left_Tab>', lambda e, rr=r, cc=c, ck=col_key, vv=var, tv=total_var:
                           self._po_grid_commit_and_move(rr, cc, ck, vv, tv, dr=0, dc=-1))
                    self._bind_po_grid_keys(w)
                w.grid(row=r+1, column=visual_col, sticky='nsew', ipadx=1, ipady=4)
                w.bind('<Button-1>', lambda e, rr=r, cc=c, ww=w: self._po_grid_mouse_down(e, rr, cc, ww), add='+')
                w.bind('<B1-Motion>', self._po_grid_drag_select, add='+')
                self.po_grid_cell_widgets[(r, c)] = w
                self.po_grid_widget_coords[w] = (r, c)
                self.po_grid_base_bg[(r, c)] = base_bg

        self._bind_po_grid_keys(self.po_grid_canvas)
        self.po_grid_canvas.update_idletasks()
        try:
            cw = max(1, int(self.po_grid_canvas.winfo_width() or 1))
            self.po_grid_canvas.itemconfigure(self.po_grid_window, width=cw)
        except Exception:
            pass
        self.po_grid_canvas.configure(scrollregion=self.po_grid_canvas.bbox('all'))
        r, c = getattr(self, 'po_grid_selected', (0, 0))
        r = min(max(0, r), display_rows-1); c = min(max(0, c), max(0, len(cols)-1))
        self.po_grid_selected = (r, c)
        if not hasattr(self, 'po_grid_selection_anchor'):
            self.po_grid_selection_anchor = (r, c)
            self.po_grid_selection_end = (r, c)
        self._po_grid_highlight_selection()

    def _paste_po_grid_from_clipboard(self):
        try:
            clip = self.root.clipboard_get()
        except Exception:
            messagebox.showwarning('Cảnh báo', 'Clipboard không có dữ liệu để dán!')
            return
        rows = [r.split('\t') for r in str(clip).replace('\r', '').split('\n') if r != '']
        if not rows:
            return
        r1, c1, r2, c2 = self._po_grid_selection_bounds()
        start_row, start_col = r1, c1
        cols = self._po_grid_columns()

        # Excel-like: một ô clipboard + vùng đang bôi đen => điền cùng giá trị cho cả vùng.
        if len(rows) == 1 and len(rows[0]) == 1 and (r1 != r2 or c1 != c2):
            raw = rows[0][0]
            changed = bad = 0
            for tr in range(r1, r2 + 1):
                for tc in range(c1, c2 + 1):
                    if tc >= len(cols) or cols[tc] == 'total':
                        continue
                    if tr >= len(self.po_list):
                        # Chỉ có thể tạo dòng mới khi đang điền cột SỐ PO.
                        if tc != 0 or not str(raw).strip():
                            bad += 1; continue
                        name = str(raw).strip()
                        if any(str(x.get('po','')).strip() == name for x in self.po_list):
                            bad += 1; continue
                        row = {'po': name, 'color': '', 'apply_increase': False}
                        for sz in self.sizes:
                            row[sz['key']] = 0
                        row['total'] = 0
                        self.po_list.append(row); changed += 1
                    elif self._po_cell_set_value(tr, cols[tc], raw, show_error=False):
                        changed += 1
                    else:
                        bad += 1
            self.update_po_table(); self.update_summary(); self._refresh_fabric_po_selector()
            if self.fabric_list:
                self._sync_global_lots(); self.update_fabric_table()
            self.status_var.set(f'Dán vào vùng chọn: cập nhật {changed} ô, lỗi/bỏ qua {bad}')
            return
        # Nếu dán cả tiêu đề bắt đầu từ cột PO thì bỏ dòng tiêu đề.
        if start_col == 0 and rows and str(rows[0][0]).strip().upper() in ('PO','SỐ PO','SO PO','SỐ PO:'):
            rows = rows[1:]
        if not rows:
            return

        changed = 0
        bad = 0
        for dr, vals in enumerate(rows):
            tr = start_row + dr
            # Nếu vượt số dòng hiện tại thì chỉ tạo dòng mới khi vùng dán có cột SỐ PO.
            if tr >= len(self.po_list):
                po_value = ''
                if start_col == 0 and vals:
                    po_value = str(vals[0]).strip()
                if not po_value:
                    bad += 1
                    continue
                new = {'po': po_value, 'color': '', 'apply_increase': False}
                for s in self.sizes:
                    new[s['key']] = 0
                new['total'] = 0
                # Không thêm PO trùng.
                if any(str(x.get('po','')).strip() == po_value for x in self.po_list):
                    bad += 1
                    continue
                self.po_list.append(new)
            for dc, raw in enumerate(vals):
                tc = start_col + dc
                if tc >= len(cols):
                    break
                key = cols[tc]
                if key == 'total':
                    continue
                if self._po_cell_set_value(tr, key, raw, show_error=False):
                    changed += 1
                else:
                    bad += 1

        self.update_po_table()
        self.update_summary()
        self._refresh_fabric_po_selector()
        if self.fabric_list:
            self._sync_global_lots()
            self.update_fabric_table()
        self.status_var.set(f'Dán từ ô đã chọn: cập nhật {changed} ô, lỗi/bỏ qua {bad}')
        if bad:
            messagebox.showwarning('Dán PO', f'Có {bad} ô/dòng không hợp lệ hoặc bị bỏ qua.')

    # ==================== V56: SỬA / DÁN TRỰC TIẾP PO + LOẠI VẢI ====================
    def _begin_tree_cell_edit(self, tree, item, column_key, on_commit):
        """Đặt một Entry đúng lên ô Treeview để sửa trực tiếp."""
        try:
            bbox = tree.bbox(item, column_key)
        except Exception:
            bbox = ()
        if not bbox:
            return
        x, y, w, h = bbox
        old_value = tree.set(item, column_key)
        editor = tk.Entry(tree, font=('Arial', 10), justify='center')
        editor.insert(0, old_value)
        editor.select_range(0, tk.END)
        editor.place(x=x, y=y, width=max(40, w), height=max(22, h))
        editor.focus_set()
        finished = {'done': False}

        def commit(event=None):
            if finished['done']:
                return
            finished['done'] = True
            value = editor.get().strip()
            editor.destroy()
            on_commit(value)

        def cancel(event=None):
            if finished['done']:
                return
            finished['done'] = True
            editor.destroy()

        editor.bind('<Return>', commit)
        editor.bind('<FocusOut>', commit)
        editor.bind('<Escape>', cancel)

    def _on_po_tree_double_click(self, event):
        if not hasattr(self, 'po_tree'):
            return
        item = self.po_tree.identify_row(event.y)
        col_id = self.po_tree.identify_column(event.x)
        if not item or not col_id or not col_id.startswith('#'):
            return
        try:
            col_index = int(col_id[1:]) - 1
            columns = list(self.po_tree['columns'])
            col_key = columns[col_index]
            row_index = self.po_tree.index(item)
        except Exception:
            return
        if col_key == 'total' or not (0 <= row_index < len(self.po_list)):
            return

        def save(value):
            po = self.po_list[row_index]
            if col_key == 'po':
                new_name = value.strip()
                if not new_name:
                    messagebox.showwarning('Cảnh báo', 'Số PO không được để trống!')
                    return
                old_name = str(po.get('po', '') or '').strip()
                if any(i != row_index and str(x.get('po','')).strip() == new_name
                       for i, x in enumerate(self.po_list)):
                    messagebox.showwarning('Cảnh báo', f'PO {new_name} đã tồn tại!')
                    return
                po['po'] = new_name
                # Đổi tên PO ở mọi loại vải đang chọn PO riêng.
                for fabric in self.fabric_list:
                    if str(fabric.get('po_mode','all')).lower() != 'all':
                        fabric['po_targets'] = [new_name if str(x) == old_name else x
                                                for x in (fabric.get('po_targets', []) or [])]
                        fabric['roll_po_targets'] = [new_name if str(x) == old_name else x
                                                     for x in (fabric.get('roll_po_targets', []) or [])]
            elif col_key == 'color':
                po['color'] = value.strip()
            else:
                try:
                    qty = int(float(value.replace(',', '.'))) if value else 0
                except Exception:
                    messagebox.showerror('Lỗi', 'Số lượng PO phải là số nguyên!')
                    return
                if qty < 0:
                    messagebox.showerror('Lỗi', 'Số lượng PO không được âm!')
                    return
                po[col_key] = qty
            po['total'] = sum(int(po.get(sz['key'], 0) or 0) for sz in self.sizes)
            self.update_po_table()
            self.update_summary()
            self._refresh_fabric_po_selector()
            if self.fabric_list:
                self._sync_global_lots()
                self.update_fabric_table()
            self.status_var.set('Đã sửa trực tiếp danh sách PO')

        self._begin_tree_cell_edit(self.po_tree, item, col_key, save)

    def paste_po_from_clipboard(self):
        """V26: dán từ clipboard bắt đầu đúng ô PO đang chọn."""
        if hasattr(self, 'po_grid_inner'):
            return self._paste_po_grid_from_clipboard()
        # Fallback cho giao diện Treeview cũ.
        try:
            clip = self.root.clipboard_get()
        except Exception:
            messagebox.showwarning('Cảnh báo', 'Clipboard không có dữ liệu để dán!')
            return
        rows = [r for r in str(clip).replace('\r','').split('\n') if r.strip()]
        if not rows:
            return
        parsed = [r.split('\t') for r in rows]
        if parsed and str(parsed[0][0]).strip().upper() in ('PO', 'SỐ PO', 'SO PO', 'SỐ PO:'):
            parsed = parsed[1:]
        size_keys = [s['key'] for s in self.sizes]
        added = updated = bad = 0
        for vals in parsed:
            if not vals:
                continue
            po_name = str(vals[0]).strip()
            if not po_name:
                continue
            color = str(vals[1]).strip() if len(vals) > 1 else ''
            qtys = {}
            ok = True
            for i, key in enumerate(size_keys):
                raw = str(vals[i+2]).strip() if i+2 < len(vals) else '0'
                try:
                    q = int(float(raw.replace(',', '.'))) if raw else 0
                except Exception:
                    ok = False; break
                if q < 0:
                    ok = False; break
                qtys[key] = q
            if not ok:
                bad += 1
                continue
            existing = next((x for x in self.po_list if str(x.get('po','')).strip() == po_name), None)
            if existing is None:
                existing = {'po': po_name, 'color': color, 'apply_increase': False}
                self.po_list.append(existing)
                added += 1
            else:
                updated += 1
            existing['color'] = color
            for key, q in qtys.items():
                existing[key] = q
            existing['total'] = sum(qtys.values())
        self.update_po_table(); self.update_summary(); self._refresh_fabric_po_selector()
        if self.fabric_list:
            self._sync_global_lots(); self.update_fabric_table()
        self.status_var.set(f'Dán PO: thêm {added}, cập nhật {updated}, lỗi {bad}')
        if bad:
            messagebox.showwarning('Dán PO', f'Có {bad} dòng không hợp lệ và đã được bỏ qua.')

    @staticmethod
    def _split_selection_text(value):
        return [x.strip() for x in re.split(r'[,+;|]+', str(value or '')) if x.strip()]

    def _parse_fabric_po_text(self, value):
        txt = str(value or '').strip()
        up = txt.upper()
        if not txt or up in ('TẤT CẢ PO', 'TAT CA PO', 'ALL', 'ALL PO', '*'):
            return 'all', []
        names = self._split_selection_text(txt)
        known = {str(x.get('po','')).strip() for x in self.po_list}
        unknown = [x for x in names if x not in known]
        if unknown:
            raise ValueError('PO không tồn tại: ' + ', '.join(unknown))
        return 'selected', names

    def _parse_fabric_lot_text(self, value):
        txt = str(value or '').strip()
        up = txt.upper()
        if not txt or up in ('KHÔNG DÙNG LOT', 'KHONG DUNG LOT', 'NONE', 'NO LOT', '-'):
            return 'none', []
        if up in ('TẤT CẢ LOT', 'TAT CA LOT', 'ALL', 'ALL LOT', '*'):
            return 'all', []
        names = self._split_selection_text(txt)
        known = {str(x.get('lot','')).strip() for x in getattr(self, 'global_lot_rows', []) or []}
        unknown = [x for x in names if x not in known]
        if unknown:
            raise ValueError('LOT không tồn tại trong kho: ' + ', '.join(unknown))
        return 'selected', names

    @staticmethod
    def _parse_yes_no(value, default=True):
        txt = str(value or '').strip().upper()
        if not txt:
            return bool(default)
        if txt in ('CÓ','CO','YES','Y','1','TRUE','X'):
            return True
        if txt in ('KHÔNG','KHONG','NO','N','0','FALSE'):
            return False
        raise ValueError('Giá trị CÓ/KHÔNG không hợp lệ: ' + str(value))

    # ==================== V26: DROPDOWN PO / LOT TRONG DANH SÁCH LOẠI VẢI ====================
    def _on_fabric_tree_single_click(self, event):
        if not hasattr(self, 'fabric_tree'):
            return
        item = self.fabric_tree.identify_row(event.y)
        col_id = self.fabric_tree.identify_column(event.x)
        if not item or not col_id or not col_id.startswith('#'):
            return
        try:
            col_index = int(col_id[1:]) - 1
            columns = list(self.fabric_tree['columns'])
            col_key = columns[col_index]
            row_index = self.fabric_tree.index(item)
        except Exception:
            return
        if not (0 <= row_index < len(self.fabric_list)):
            return
        if col_key == 'cut_mode':
            self.root.after(80, lambda: self._open_fabric_mode_popup(row_index, item))
        elif col_key == 'optimizer_mode':
            self.root.after(80, lambda: self._open_optimizer_mode_popup(row_index, item))
        elif col_key in ('po_apply', 'lot_apply'):
            self.root.after(80, lambda: self._open_fabric_select_popup(row_index, col_key, item))
        elif col_key == 'export_roll':
            # V98: Xuất PHÂN CÂY có thêm lựa chọn PO CHỈ ĐỂ HIỂN THỊ TÊN.
            # Số lượng cắt vẫn luôn tính theo PO áp dụng của loại vải, không phụ thuộc lựa chọn này.
            self.root.after(80, lambda: self._open_roll_export_po_popup(row_index, item))
        elif col_key == 'export_edit':
            # SỬA PHÂN CÂY vẫn bật/tắt nhanh như trước.
            now = int(getattr(event, 'time', 0) or 0)
            last = getattr(self, '_fabric_last_check_click', None)
            if last and last[0] == row_index and last[1] == col_key and now - last[2] < 350:
                return
            self._fabric_last_check_click = (row_index, col_key, now)
            fabric = self.fabric_list[row_index]
            fabric[col_key] = not bool(fabric.get(col_key, True))
            self.update_fabric_table(select_index=row_index)
            self.status_var.set(f"{fabric.get('name','')}: SỬA PHÂN CÂY = {'CÓ' if fabric[col_key] else 'KHÔNG'}")

    def _fabric_roll_po_names(self, fabric):
        """V98: PO chỉ dùng để HIỂN THỊ tên trên sheet PHÂN CÂY.

        Không dùng danh sách này để tính số lượng. Số lượng vẫn theo po_mode/po_targets.
        """
        applicable = self._fabric_po_names(fabric)
        saved = [str(x).strip() for x in (fabric.get('roll_po_targets', []) or []) if str(x).strip()]
        # Dự án cũ/chưa từng chọn: mặc định hiện tất cả PO đang áp dụng.
        if not bool(fabric.get('roll_po_selection_set', False)):
            return list(applicable)
        allowed = set(applicable)
        return [x for x in saved if x in allowed]

    def _open_roll_export_po_popup(self, row_index, item=None):
        """V98: chọn CÓ/KHÔNG xuất PHÂN CÂY + PO nào chỉ xuất TÊN."""
        if not (0 <= row_index < len(self.fabric_list)):
            return
        old = getattr(self, '_fabric_select_popup', None)
        if old is not None:
            try:
                if old.winfo_exists(): old.destroy()
            except Exception:
                pass

        fabric = self.fabric_list[row_index]
        applicable = self._fabric_po_names(fabric)
        current_names = self._fabric_roll_po_names(fabric)

        top = tk.Toplevel(self.root)
        self._fabric_select_popup = top
        top.title('Xuất PHÂN CÂY / chọn tên PO')
        top.transient(self.root)
        top.resizable(False, False)
        body = tk.Frame(top, padx=12, pady=10, bg='white')
        body.pack(fill='both', expand=True)

        tk.Label(body, text=f"{fabric.get('name','')}", font=('Arial', 11, 'bold'),
                 bg='white', fg='#1f4e78').pack(anchor='w', pady=(0,6))
        tk.Label(body, text='Chọn CÓ để xuất PHÂN CÂY. Các PO dưới đây chỉ quyết định TÊN PO hiển thị; số lượng vẫn lấy toàn bộ PO áp dụng.',
                 font=('Arial', 9), bg='white', fg='#555555', wraplength=460,
                 justify='left').pack(anchor='w', pady=(0,8))

        export_var = tk.StringVar(value='CÓ' if bool(fabric.get('export_roll', True)) else 'KHÔNG')
        opt = tk.Frame(body, bg='white')
        opt.pack(fill='x', pady=(0,8))
        tk.Radiobutton(opt, text='☑ CÓ - XUẤT PHÂN CÂY', variable=export_var, value='CÓ',
                       bg='white', font=('Arial', 9, 'bold')).pack(side='left', padx=(0,15))
        tk.Radiobutton(opt, text='☐ KHÔNG XUẤT', variable=export_var, value='KHÔNG',
                       bg='white', font=('Arial', 9, 'bold')).pack(side='left')

        po_box = tk.LabelFrame(body, text='PO CẦN XUẤT TÊN (cách nhau bằng dấu +)',
                               font=('Arial', 9, 'bold'), bg='white', padx=8, pady=6)
        po_box.pack(fill='both', expand=True)
        vars_by_po = {}
        for i, name in enumerate(applicable):
            v = tk.BooleanVar(value=(name in current_names))
            vars_by_po[name] = v
            tk.Checkbutton(po_box, text=name, variable=v, bg='white', anchor='w',
                           font=('Arial', 9)).grid(row=i//3, column=i%3, sticky='w', padx=6, pady=3)
        if not applicable:
            tk.Label(po_box, text='Loại vải này chưa có PO áp dụng.', bg='white', fg='#c0392b').pack(anchor='w')

        quick = tk.Frame(body, bg='white')
        quick.pack(fill='x', pady=(7,2))
        def _set_all(val):
            for v in vars_by_po.values(): v.set(val)
        tk.Button(quick, text='TÍCH TẤT CẢ', command=lambda: _set_all(True),
                  font=('Arial',8,'bold')).pack(side='left')
        tk.Button(quick, text='BỎ TẤT CẢ', command=lambda: _set_all(False),
                  font=('Arial',8,'bold')).pack(side='left', padx=6)

        btns = tk.Frame(body, bg='white')
        btns.pack(fill='x', pady=(8,0))
        def apply():
            enabled = (export_var.get() == 'CÓ')
            picks = [name for name in applicable if bool(vars_by_po[name].get())]
            if enabled and applicable and not picks:
                messagebox.showwarning('Chưa chọn PO', 'Hãy tích ít nhất 1 PO cần xuất TÊN, hoặc chọn KHÔNG XUẤT.', parent=top)
                return
            fabric['export_roll'] = enabled
            fabric['roll_po_targets'] = picks
            fabric['roll_po_selection_set'] = True
            try: top.destroy()
            except Exception: pass
            self.update_fabric_table(select_index=row_index)
            if enabled:
                shown = ' + '.join(picks) if picks else '(không có PO)'
                self.status_var.set(f"{fabric.get('name','')}: PHÂN CÂY = CÓ | Tên PO: {shown}")
            else:
                self.status_var.set(f"{fabric.get('name','')}: PHÂN CÂY = KHÔNG")
        tk.Button(btns, text='ÁP DỤNG', command=apply, bg='#27ae60', fg='white',
                  font=('Arial',9,'bold'), padx=14).pack(side='right')
        tk.Button(btns, text='HỦY', command=top.destroy,
                  font=('Arial',9,'bold'), padx=14).pack(side='right', padx=6)

        try:
            top.update_idletasks()
            x = self.root.winfo_rootx() + max(20, (self.root.winfo_width()-top.winfo_width())//2)
            y = self.root.winfo_rooty() + max(20, (self.root.winfo_height()-top.winfo_height())//2)
            top.geometry(f'+{x}+{y}')
        except Exception:
            pass
        top.grab_set()

    def _open_fabric_mode_popup(self, row_index, item=None):
        """V80: chọn/đổi lại chế độ giác ngay trong danh sách loại vải bằng 1 click."""
        if not (0 <= row_index < len(self.fabric_list)):
            return
        old = getattr(self, '_fabric_select_popup', None)
        if old is not None:
            try:
                if old.winfo_exists():
                    old.destroy()
            except Exception:
                pass

        fabric = self.fabric_list[row_index]
        tree = self.fabric_tree
        try:
            bbox = tree.bbox(item or tree.get_children()[row_index], 'cut_mode')
        except Exception:
            bbox = ()
        if bbox:
            bx, by, bw, bh = bbox
            x = tree.winfo_rootx() + bx
            y = tree.winfo_rooty() + by + bh
            width = max(190, bw)
        else:
            x = self.root.winfo_rootx() + 260
            y = self.root.winfo_rooty() + 250
            width = 210

        top = tk.Toplevel(self.root)
        self._fabric_select_popup = top
        top.overrideredirect(True)
        top.transient(self.root)
        top.geometry(f'{width}x62+{x}+{y}')
        body = tk.Frame(top, bd=1, relief='solid', bg='white', padx=5, pady=5)
        body.pack(fill='both', expand=True)

        saved_key = self._fabric_mode_key_from_label(fabric.get('cut_mode', 'auto'))
        var = tk.StringVar(value=self.FABRIC_MODE_LABELS.get(saved_key, 'TỰ ĐỘNG'))
        combo = ttk.Combobox(body, textvariable=var, values=self.FABRIC_MODE_VALUES,
                             state='readonly', width=24, font=('Arial', 10))
        combo.pack(fill='x', expand=True)

        def apply(event=None):
            fabric['cut_mode'] = self._fabric_mode_key_from_label(var.get())
            try:
                top.destroy()
            except Exception:
                pass
            self.update_fabric_table(select_index=row_index)
            self.status_var.set(
                f"{fabric.get('name','')}: chế độ giác = {self._fabric_mode_display(fabric)}"
            )

        combo.bind('<<ComboboxSelected>>', apply)
        combo.bind('<Return>', apply)
        top.bind('<Escape>', lambda e: top.destroy())
        combo.focus_set()
        # V80: bấm 1 lần vào ô Chế độ giác là xổ danh sách ngay.
        # Dùng after để Treeview hoàn tất sự kiện chọn dòng trước khi mở combobox.
        def _drop_mode_list():
            try:
                combo.event_generate('<Button-1>')
            except Exception:
                pass
        self.root.after(60, _drop_mode_list)

    def _optimizer_plan_metrics(self, tables, adjust_info, total_by_size, fabric=None):
        """V154: quy đổi một phương án thành bộ chỉ số để 10 chiến lược mới so sánh."""
        tables = list(tables or [])
        info = adjust_info if isinstance(adjust_info, dict) else {}
        keys = [s.get('key') for s in self.sizes if s.get('key') in total_by_size]
        size_order = {k: i for i, k in enumerate(keys)}

        actual = {k: 0 for k in total_by_size}
        for tb in tables:
            for k, v in (tb.get('sizes', {}) or {}).items():
                actual[k] = actual.get(k, 0) + int(v or 0)

        raw_diff = {
            k: int(actual.get(k, 0)) - int(total_by_size.get(k, 0) or 0)
            for k in total_by_size
        }

        residual = info.get('residual_under')
        if isinstance(residual, dict):
            under = sum(max(0, int(residual.get(k, 0) or 0)) for k in total_by_size)
        else:
            under = sum(max(0, -v) for v in raw_diff.values())

        if 'final_positive_surplus' in info:
            over = max(0, int(info.get('final_positive_surplus', 0) or 0))
        else:
            over = sum(max(0, v) for v in raw_diff.values())

        abs_diff = under + over
        plies = [max(0, int(tb.get('plies', 0) or 0)) for tb in tables]
        lengths = [
            max(0.0, float(tb.get('raw_length', tb.get('length', 0)) or 0))
            for tb in tables
        ]
        ratio_totals = []
        size_counts = []
        spans = []
        total_meters = 0.0

        for tb, L, n in zip(tables, lengths, plies):
            rm = {
                k: int(v or 0)
                for k, v in (tb.get('ratio_map', {}) or {}).items()
                if int(v or 0) > 0
            }
            rt = sum(rm.values())
            ratio_totals.append(rt)
            size_counts.append(len(rm))
            idxs = [size_order[k] for k in rm if k in size_order]
            spans.append((max(idxs) - min(idxs)) if len(idxs) >= 2 else 0)
            total_meters += L * n

        if tables:
            tail_i = min(
                range(len(tables)),
                key=lambda i: (plies[i], ratio_totals[i], lengths[i], i)
            )
            tail_plies = plies[tail_i]
            tail_ratio = ratio_totals[tail_i]
            tail_length = lengths[tail_i]
            tail_sizes = size_counts[tail_i]
        else:
            tail_plies = tail_ratio = tail_sizes = 0
            tail_length = 0.0

        positive_plies = [x for x in plies if x > 0]
        min_plies = min(positive_plies) if positive_plies else 0
        avg_plies = (sum(positive_plies) / len(positive_plies)) if positive_plies else 0.0

        # V155: chỉ số phục vụ sản xuất thực tế.
        preferred_plies = max(4, int(getattr(self, 'MIN_PREFERRED_PLIES', 10) or 10))
        low_ply_count = sum(1 for x in positive_plies if x < preferred_plies)
        ply_shortfall = sum(max(0, preferred_plies - x) for x in positive_plies)

        avg_len = (sum(lengths) / len(lengths)) if lengths else 0.0
        avg_span = (sum(spans) / len(spans)) if spans else 0.0
        avg_sizes = (sum(size_counts) / len(size_counts)) if size_counts else 0.0

        # Điểm phù hợp LOT: ưu tiên tổng mét phương án nằm sát ranh giới tích lũy
        # của các LOT được phép dùng, để hạn chế mở dở nhiều LOT.
        lot_penalty = 0.0
        lot_shortage = 0.0
        if fabric is not None:
            try:
                mode = str(fabric.get('lot_mode', 'none') or 'none').lower()
                allowed = []
                if mode == 'selected':
                    allowed = list(self._fabric_lot_names(fabric))
                elif mode == 'all':
                    allowed = [
                        str(r.get('lot', '') or '').strip()
                        for r in (getattr(self, 'global_lot_rows', []) or [])
                        if str(r.get('lot', '') or '').strip()
                    ]

                if allowed:
                    caps = []
                    for r in (getattr(self, 'global_lot_rows', []) or []):
                        name = str(r.get('lot', '') or '').strip()
                        if name in allowed:
                            try:
                                meters = max(0.0, float(r.get('meters', 0) or 0))
                            except Exception:
                                meters = 0.0
                            if meters > 0:
                                caps.append(meters)

                    if caps:
                        cum = 0.0
                        boundaries = []
                        for c in caps:
                            cum += c
                            boundaries.append(cum)
                        lot_shortage = max(0.0, total_meters - cum)
                        if lot_shortage > 0:
                            lot_penalty = lot_shortage * 1000.0
                        else:
                            lot_penalty = min(abs(b - total_meters) for b in boundaries)
            except Exception:
                pass

        return {
            'tables': len(tables),
            'under': under,
            'over': over,
            'abs_diff': abs_diff,
            'min_plies': min_plies,
            'avg_plies': avg_plies,
            'sum_plies': sum(plies),
            'low_ply_count': low_ply_count,
            'ply_shortfall': ply_shortfall,
            'avg_len': avg_len,
            'max_len': max(lengths) if lengths else 0.0,
            'sum_len': sum(lengths),
            'avg_span': avg_span,
            'avg_sizes': avg_sizes,
            'tail_plies': tail_plies,
            'tail_ratio': tail_ratio,
            'tail_length': tail_length,
            'tail_sizes': tail_sizes,
            'total_meters': total_meters,
            'lot_penalty': lot_penalty,
            'lot_shortage': lot_shortage,
        }

    def _optimizer_candidate_score(self, mode, metrics, resolved_mode='main'):
        """V154: mỗi kiểu tối ưu có thứ tự ưu tiên riêng."""
        m = metrics
        # Mọi chiến lược đều đặt thiếu sản lượng lên đầu; không vì tối ưu hình thức mà cắt thiếu.
        common = (m['under'],)

        if mode == 'few_tables':
            return common + (
                m['tables'], m['over'], m['abs_diff'],
                m['tail_ratio'], m['tail_length'],
                -m['avg_plies'], -m['avg_len']
            )

        if mode == 'high_plies':
            return common + (
                m['over'],
                -m['min_plies'], -m['avg_plies'], -m['sum_plies'],
                m['tables'], m['tail_length']
            )

        if mode == 'long_marker':
            return common + (
                m['over'],
                -m['avg_len'], -m['max_len'], -m['sum_len'],
                m['tables'], -m['avg_sizes']
            )

        if mode == 'size_mix':
            return common + (
                m['over'],
                -m['avg_span'], -m['avg_sizes'],
                m['tables'], m['tail_ratio'], m['tail_length']
            )

        if mode == 'balance':
            return common + (
                m['over'], m['abs_diff'],
                m['tables'], m['tail_ratio'], m['tail_length']
            )

        if mode == 'tail_opt':
            return common + (
                m['over'],
                m['tail_ratio'], m['tail_length'], m['tail_sizes'],
                m['tables'], -m['avg_plies']
            )

        if mode == 'lot_opt':
            return common + (
                m['lot_shortage'], m['lot_penalty'],
                m['over'], m['tables'], m['tail_length']
            )

        if mode == 'accurate':
            return common + (
                m['over'], m['abs_diff'],
                m['tables'], m['tail_ratio'], m['tail_length'],
                -m['avg_plies'], -m['avg_span'], -m['avg_len']
            )

        if mode == 'production':
            # TỐI ƯU SẢN XUẤT:
            # không thiếu -> ít bàn -> hạn chế bàn ít lá -> dương thấp
            # -> ghép cỡ hợp lý -> lá cao -> bàn cuối gọn -> sơ đồ chính dài.
            return common + (
                m['tables'],
                m['low_ply_count'], m['ply_shortfall'],
                m['over'], m['abs_diff'],
                -m['avg_span'], -m['avg_sizes'],
                -m['avg_plies'],
                m['tail_ratio'], m['tail_length'], m['tail_sizes'],
                -m['avg_len']
            )

        # AUTO SMART: thay thứ tự ưu tiên theo loại vật tư.
        if mode == 'smart':
            if resolved_mode in ('interlining', 'padding'):
                return common + (
                    m['over'], m['abs_diff'],
                    m['tables'], m['tail_ratio'], m['tail_length'],
                    -m['avg_sizes']
                )
            if resolved_mode == 'interlayer':
                return common + (
                    m['tables'], m['over'],
                    -m['avg_plies'], -m['avg_len'],
                    m['tail_length']
                )
            if resolved_mode == 'lining':
                return common + (
                    m['tables'], m['over'],
                    -m['avg_len'], -m['avg_span'],
                    m['tail_length']
                )
            return common + (
                m['tables'], m['over'],
                -m['avg_span'], -m['avg_plies'],
                m['tail_ratio'], m['tail_length']
            )

        # fallback "chính xác" an toàn.
        return common + (
            m['over'], m['tables'],
            m['tail_ratio'], m['tail_length'],
            -m['avg_plies']
        )

    def _run_optimizer_strategy(
        self, optimizer_mode, total_by_size, size_factor, norm,
        max_len, max_products, resolved_mode, min_len, balance_pct,
        fabric=None
    ):
        """V154: bộ điều phối 13 kiểu tối ưu.

        Hai thuật toán nền TOÀN CỤC/TUẦN TỰ được giữ nguyên.
        11 kiểu mới thay đổi cách chọn phương án và cách ưu tiên sản xuất.
        """
        mode = self._optimizer_mode_key_from_label(optimizer_mode)

        def run_global():
            return self.optimize_cutting_global(
                dict(total_by_size), size_factor, norm, max_len,
                max_products, resolved_mode, min_len, balance_pct
            )

        def run_sequential():
            return self.optimize_cutting(
                dict(total_by_size), size_factor, norm, max_len,
                max_products, resolved_mode, min_len, balance_pct
            )

        if mode == 'global':
            tables, info = run_global()
            if isinstance(info, dict):
                info = dict(info); info['optimizer_strategy'] = mode
            return tables, info

        if mode in ('sequential', 'fast'):
            tables, info = run_sequential()
            if isinstance(info, dict):
                info = dict(info); info['optimizer_strategy'] = mode
            return tables, info

        # Các mode còn lại thử nhiều phương án rồi chấm điểm theo mục tiêu.
        candidates = []
        errors = []
        runners = [('global', run_global), ('sequential', run_sequential)]

        # V155: TỐI ƯU SẢN XUẤT sinh thêm cấu trúc bàn khác thực sự.
        if mode == 'production':
            if max_len and float(max_len) > 0:
                for factor in (0.90, 0.80):
                    alt_max = float(max_len) * factor
                    if alt_max + 1e-9 < float(min_len or 0):
                        continue

                    def _g(alt=alt_max):
                        return self.optimize_cutting_global(
                            dict(total_by_size), size_factor, norm, alt,
                            max_products, resolved_mode, min_len, balance_pct
                        )

                    def _s(alt=alt_max):
                        return self.optimize_cutting(
                            dict(total_by_size), size_factor, norm, alt,
                            max_products, resolved_mode, min_len, balance_pct
                        )

                    runners.append((f'global_{factor:.0%}', _g))
                    runners.append((f'sequential_{factor:.0%}', _s))

            elif max_products and int(max_products) > 2:
                alt_products = max(2, int(round(int(max_products) * 0.85)))
                if alt_products < int(max_products):
                    def _gp(mp=alt_products):
                        return self.optimize_cutting_global(
                            dict(total_by_size), size_factor, norm, max_len,
                            mp, resolved_mode, min_len, balance_pct
                        )

                    def _sp(mp=alt_products):
                        return self.optimize_cutting(
                            dict(total_by_size), size_factor, norm, max_len,
                            mp, resolved_mode, min_len, balance_pct
                        )

                    runners.append((f'global_{alt_products}sp', _gp))
                    runners.append((f'sequential_{alt_products}sp', _sp))

        for engine_name, runner in runners:
            try:
                tables, info = runner()
                if tables is not None:
                    metrics = self._optimizer_plan_metrics(
                        tables, info, total_by_size, fabric=fabric
                    )
                    score = self._optimizer_candidate_score(
                        mode, metrics, resolved_mode=resolved_mode
                    )
                    candidates.append((score, engine_name, tables, info, metrics))
            except Exception as e:
                errors.append((engine_name, e))

            try:
                self.root.update_idletasks()
            except Exception:
                pass

        if not candidates:
            if errors:
                raise errors[0][1]
            raise ValueError('Không tìm được phương án tối ưu phù hợp.')

        candidates.sort(key=lambda x: x[0])
        score, engine_name, tables, info, metrics = candidates[0]

        info = dict(info or {})
        info['optimizer_strategy'] = mode
        info['optimizer_engine'] = engine_name
        info['optimizer_metrics'] = metrics
        return tables, info

    def _optimizer_mode_key_from_label(self, value):
        txt = str(value or '').strip().upper()
        for key, label in self.OPTIMIZER_LABELS.items():
            if txt == label.upper():
                return key
        # Tương thích dự án cũ trước V116.
        old_aliases = {
            'TOÀN CỤC GHÉP CỠ 1-6 BÀN V106': 'global',
            'TOÀN CỤC GHÉP CỠ 1-6 BÀN': 'global',
            'TOÀN CỤC TỰ ĐỘNG 1-6 BÀN': 'global',
            'TUẦN TỰ V100': 'sequential',
            'ÍT BÀN': 'few_tables',
            'LÁ CAO': 'high_plies',
            'SƠ ĐỒ DÀI': 'long_marker',
            'GHÉP CỠ': 'size_mix',
            'CÂN DƯƠNG': 'balance',
            'BÀN CUỐI': 'tail_opt',
            'THEO LOT': 'lot_opt',
            'SẢN XUẤT': 'production',
            'TOI UU SAN XUAT': 'production',
            'AUTO': 'smart',
        }
        if txt in old_aliases:
            return old_aliases[txt]
        raw = str(value or '').strip().lower()
        return raw if raw in self.OPTIMIZER_LABELS else 'global'

    def _open_optimizer_mode_popup(self, row_index, item=None):
        """V101: chọn thuật toán riêng cho từng loại vải."""
        if not (0 <= row_index < len(self.fabric_list)):
            return
        old = getattr(self, '_fabric_select_popup', None)
        if old is not None:
            try:
                if old.winfo_exists(): old.destroy()
            except Exception:
                pass
        fabric = self.fabric_list[row_index]
        tree = self.fabric_tree
        try:
            bbox = tree.bbox(item or tree.get_children()[row_index], 'optimizer_mode')
        except Exception:
            bbox = ()
        if bbox:
            bx, by, bw, bh = bbox
            x = tree.winfo_rootx() + bx; y = tree.winfo_rooty() + by + bh; width = max(180, bw)
        else:
            x = self.root.winfo_rootx() + 300; y = self.root.winfo_rooty() + 250; width = 200
        top = tk.Toplevel(self.root); self._fabric_select_popup = top
        top.overrideredirect(True); top.transient(self.root); top.geometry(f'{width}x62+{x}+{y}')
        body = tk.Frame(top, bd=1, relief='solid', bg='white', padx=5, pady=5); body.pack(fill='both', expand=True)
        key = self._optimizer_mode_key_from_label(fabric.get('optimizer_mode', 'global'))
        var = tk.StringVar(value=self.OPTIMIZER_LABELS.get(key, 'TOÀN CỤC'))
        combo = ttk.Combobox(body, textvariable=var, values=self.OPTIMIZER_VALUES, state='readonly', width=30, font=('Arial',10))
        combo.pack(fill='x', expand=True)
        def apply(event=None):
            fabric['optimizer_mode'] = self._optimizer_mode_key_from_label(var.get())
            try: top.destroy()
            except Exception: pass
            self.update_fabric_table(select_index=row_index)
            self.status_var.set(f"{fabric.get('name','')}: kiểu tối ưu = {self.OPTIMIZER_LABELS[fabric['optimizer_mode']]}")
        combo.bind('<<ComboboxSelected>>', apply); combo.bind('<Return>', apply); top.bind('<Escape>', lambda e: top.destroy())
        combo.focus_set(); self.root.after(60, lambda: combo.event_generate('<Button-1>'))

    def _open_fabric_yes_no_popup(self, row_index, col_key, item=None):
        """V44: dropdown CÓ/KHÔNG ngay trong cột xuất PHÂN CÂY / SỬA PHÂN CÂY."""
        if not (0 <= row_index < len(self.fabric_list)):
            return
        old = getattr(self, '_fabric_select_popup', None)
        if old is not None:
            try:
                if old.winfo_exists():
                    old.destroy()
            except Exception:
                pass

        fabric = self.fabric_list[row_index]
        tree = self.fabric_tree
        try:
            bbox = tree.bbox(item or tree.get_children()[row_index], col_key)
        except Exception:
            bbox = ()
        if bbox:
            bx, by, bw, bh = bbox
            x = tree.winfo_rootx() + bx
            y = tree.winfo_rooty() + by + bh
            width = max(105, bw)
        else:
            x = self.root.winfo_rootx() + 300
            y = self.root.winfo_rooty() + 250
            width = 130

        top = tk.Toplevel(self.root)
        self._fabric_select_popup = top
        top.overrideredirect(True)
        top.transient(self.root)
        top.geometry(f'{width}x58+{x}+{y}')
        body = tk.Frame(top, bd=1, relief='solid', bg='white', padx=4, pady=4)
        body.pack(fill='both', expand=True)

        current = bool(fabric.get(col_key, True))
        var = tk.StringVar(value='CÓ' if current else 'KHÔNG')
        combo = ttk.Combobox(body, textvariable=var, values=['CÓ', 'KHÔNG'],
                             state='readonly', width=12, font=('Arial', 10))
        combo.pack(fill='x', expand=True)

        def apply(event=None):
            fabric[col_key] = (var.get().strip().upper() == 'CÓ')
            try:
                top.destroy()
            except Exception:
                pass
            self.update_fabric_table(select_index=row_index)
            label = 'PHÂN CÂY' if col_key == 'export_roll' else 'SỬA PHÂN CÂY'
            self.status_var.set(f"{fabric.get('name','')}: {label} = {'CÓ' if fabric[col_key] else 'KHÔNG'}")

        combo.bind('<<ComboboxSelected>>', apply)
        combo.bind('<Return>', apply)
        top.bind('<Escape>', lambda e: top.destroy())
        combo.focus_set()
        try:
            combo.event_generate('<Button-1>')
        except Exception:
            pass

    def _open_fabric_select_popup(self, row_index, col_key, item=None):
        if not (0 <= row_index < len(self.fabric_list)):
            return
        # Đóng popup cũ nếu còn mở.
        old = getattr(self, '_fabric_select_popup', None)
        if old is not None:
            try:
                if old.winfo_exists(): old.destroy()
            except Exception:
                pass
        fabric = self.fabric_list[row_index]
        tree = self.fabric_tree
        try:
            bbox = tree.bbox(item or tree.get_children()[row_index], col_key)
        except Exception:
            bbox = ()
        if bbox:
            bx, by, bw, bh = bbox
            x = tree.winfo_rootx() + bx
            y = tree.winfo_rooty() + by + bh
        else:
            x = self.root.winfo_rootx() + 200
            y = self.root.winfo_rooty() + 200

        top = tk.Toplevel(self.root)
        self._fabric_select_popup = top
        top.title('Chọn PO áp dụng' if col_key == 'po_apply' else 'Chọn LOT áp dụng')
        top.transient(self.root)
        top.resizable(False, False)
        top.geometry(f'+{x}+{y}')
        body = tk.Frame(top, bd=1, relief='solid', bg='white', padx=8, pady=8)
        body.pack(fill='both', expand=True)

        if col_key == 'po_apply':
            names = [str(po.get('po','')).strip() for po in self.po_list if str(po.get('po','')).strip()]
            mode = str(fabric.get('po_mode','all') or 'all').lower()
            selected = set(self._fabric_po_names(fabric)) if mode != 'all' else set()
            all_var = tk.BooleanVar(value=(mode == 'all'))
            vars_map = {n: tk.BooleanVar(value=(n in selected)) for n in names}

            def all_toggle():
                if all_var.get():
                    for v in vars_map.values(): v.set(False)
            tk.Checkbutton(body, text='TẤT CẢ PO', variable=all_var, command=all_toggle,
                           font=('Arial', 9, 'bold'), fg='#1f6aa5', bg='white').pack(anchor='w')
            for n in names:
                def cmd(name=n):
                    if vars_map[name].get(): all_var.set(False)
                tk.Checkbutton(body, text=n, variable=vars_map[n], command=cmd,
                               font=('Arial', 9), bg='white').pack(anchor='w', padx=(12,0))

            def apply():
                if all_var.get():
                    fabric['po_mode'], fabric['po_targets'] = 'all', []
                else:
                    picks = [n for n,v in vars_map.items() if v.get()]
                    if not picks:
                        messagebox.showwarning('Cảnh báo', 'Hãy chọn ít nhất 1 PO hoặc TẤT CẢ PO!', parent=top)
                        return
                    fabric['po_mode'], fabric['po_targets'] = 'selected', picks
                top.destroy()
                self._sync_global_lots(); self.update_fabric_table(select_index=row_index)
                self.status_var.set('Đã chọn PO áp dụng bằng danh sách xổ xuống')
        else:
            names = [str(r.get('lot','')).strip() for r in getattr(self,'global_lot_rows',[]) or [] if str(r.get('lot','')).strip()]
            mode = str(fabric.get('lot_mode','none') or 'none').lower()
            selected = set(self._fabric_lot_names(fabric)) if mode == 'selected' else set()
            none_var = tk.BooleanVar(value=(mode == 'none'))
            all_var = tk.BooleanVar(value=(mode == 'all'))
            vars_map = {n: tk.BooleanVar(value=(n in selected)) for n in names}

            def none_toggle():
                if none_var.get():
                    all_var.set(False)
                    for v in vars_map.values(): v.set(False)
            def all_toggle():
                if all_var.get():
                    none_var.set(False)
                    for v in vars_map.values(): v.set(False)
            tk.Checkbutton(body, text='KHÔNG DÙNG LOT', variable=none_var, command=none_toggle,
                           font=('Arial', 9, 'bold'), fg='#c0392b', bg='white').pack(anchor='w')
            tk.Checkbutton(body, text='TẤT CẢ LOT', variable=all_var, command=all_toggle,
                           font=('Arial', 9, 'bold'), fg='#7d3c98', bg='white').pack(anchor='w')
            for n in names:
                def cmd(name=n):
                    if vars_map[name].get():
                        none_var.set(False); all_var.set(False)
                tk.Checkbutton(body, text=n, variable=vars_map[n], command=cmd,
                               font=('Arial', 9), bg='white').pack(anchor='w', padx=(12,0))

            def apply():
                if none_var.get():
                    fabric['lot_mode'], fabric['lot_targets'] = 'none', []
                elif all_var.get():
                    fabric['lot_mode'], fabric['lot_targets'] = 'all', []
                else:
                    picks = [n for n,v in vars_map.items() if v.get()]
                    fabric['lot_mode'], fabric['lot_targets'] = ('selected', picks) if picks else ('none', [])
                top.destroy()
                self._sync_global_lots(); self.update_fabric_table(select_index=row_index)
                self.status_var.set('Đã chọn LOT áp dụng bằng danh sách xổ xuống')

        btns = tk.Frame(body, bg='white')
        btns.pack(fill='x', pady=(8,0))
        tk.Button(btns, text='ÁP DỤNG', command=apply, bg='#27ae60', fg='white',
                  font=('Arial', 9, 'bold'), padx=10).pack(side='left')
        tk.Button(btns, text='HỦY', command=top.destroy, bg='#7f8c8d', fg='white',
                  font=('Arial', 9, 'bold'), padx=10).pack(side='left', padx=6)
        top.bind('<Escape>', lambda e: top.destroy())
        top.grab_set()

    def _on_fabric_tree_double_click(self, event):
        if not hasattr(self, 'fabric_tree'):
            return
        item = self.fabric_tree.identify_row(event.y)
        col_id = self.fabric_tree.identify_column(event.x)
        if not item or not col_id or not col_id.startswith('#'):
            return
        try:
            col_index = int(col_id[1:]) - 1
            columns = list(self.fabric_tree['columns'])
            col_key = columns[col_index]
            row_index = self.fabric_tree.index(item)
        except Exception:
            return
        readonly = {'lot_count','lot_meters','roll_count'}
        if col_key in readonly or not (0 <= row_index < len(self.fabric_list)):
            return
        if col_key == 'cut_mode':
            self._open_fabric_mode_popup(row_index, item)
            return
        if col_key == 'optimizer_mode':
            self._open_optimizer_mode_popup(row_index, item)
            return
        if col_key in ('po_apply', 'lot_apply'):
            self._open_fabric_select_popup(row_index, col_key, item)
            return
        if col_key in ('export_roll', 'export_edit'):
            # Đã xử lý bằng click tích/bỏ tích ở _on_fabric_tree_single_click.
            return

        def save(value):
            fabric = self.fabric_list[row_index]
            try:
                if col_key == 'name':
                    if not value.strip():
                        raise ValueError('Tên loại vải không được để trống.')
                    fabric['name'] = value.strip()
                elif col_key == 'cut_mode':
                    fabric['cut_mode'] = self._fabric_mode_key_from_label(value)
                elif col_key == 'po_apply':
                    mode, targets = self._parse_fabric_po_text(value)
                    fabric['po_mode'], fabric['po_targets'] = mode, list(targets)
                elif col_key == 'lot_apply':
                    mode, targets = self._parse_fabric_lot_text(value)
                    fabric['lot_mode'], fabric['lot_targets'] = mode, list(targets)
                elif col_key == 'norm':
                    num = float(str(value).replace(',', '.'))
                    if num <= 0:
                        raise ValueError('Định mức phải lớn hơn 0.')
                    fabric[col_key] = num
                elif col_key == 'min_length':
                    txt = str(value).strip().replace(',', '.')
                    num = float(txt) if txt else 1.0
                    if num < 0:
                        raise ValueError('Chiều dài tối thiểu không được âm.')
                    max_now = float(fabric.get('max_length', 0) or 0)
                    if max_now > 0 and num > max_now + 1e-9:
                        raise ValueError('Chiều dài tối thiểu không được lớn hơn chiều dài tối đa.')
                    fabric[col_key] = num
                elif col_key == 'max_length':
                    txt = str(value).strip().replace(',', '.')
                    num = float(txt) if txt else 0.0
                    if num < 0:
                        raise ValueError('Chiều dài tối đa không được âm.')
                    if num <= 0 and int(fabric.get('max_products', 0) or 0) <= 0:
                        raise ValueError('Phải có Chiều dài tối đa hoặc SP tối đa / sơ đồ.')
                    min_now = float(fabric.get('min_length', 1.0) or 0)
                    if num > 0 and min_now > num + 1e-9:
                        raise ValueError('Chiều dài tối đa không được nhỏ hơn chiều dài tối thiểu.')
                    fabric[col_key] = num
                elif col_key == 'max_products':
                    txt = str(value).strip().replace(',', '.')
                    num = int(float(txt)) if txt else 0
                    if num < 0:
                        raise ValueError('SP tối đa không được âm.')
                    if num <= 0 and float(fabric.get('max_length', 0) or 0) <= 0:
                        raise ValueError('Phải có SP tối đa / sơ đồ hoặc Chiều dài tối đa.')
                    fabric[col_key] = num
                elif col_key == 'export_roll':
                    fabric['export_roll'] = self._parse_yes_no(value, fabric.get('export_roll', True))
                elif col_key == 'export_edit':
                    fabric['export_edit'] = self._parse_yes_no(value, fabric.get('export_edit', True))
            except ValueError as e:
                messagebox.showerror('Lỗi', str(e))
                return
            self._sync_global_lots()
            self.update_fabric_table(select_index=row_index)
            self.status_var.set('Đã sửa trực tiếp danh sách loại vải')

        self._begin_tree_cell_edit(self.fabric_tree, item, col_key, save)

    def paste_fabrics_from_clipboard(self):
        """Dán loại vải (hàm tương thích cũ; giao diện hiện không dùng nút dán)."""
        try:
            text = self.root.clipboard_get()
        except Exception:
            messagebox.showwarning('Cảnh báo', 'Clipboard không có dữ liệu để dán!')
            return
        rows = [r for r in str(text).replace('\r','').split('\n') if r.strip()]
        if not rows:
            return
        parsed = [r.split('\t') for r in rows]
        if parsed and ('LOẠI VẢI' in str(parsed[0][0]).strip().upper() or 'TEN LOAI VAI' in str(parsed[0][0]).strip().upper()):
            parsed = parsed[1:]
        added = bad = 0
        errors = []
        for rn, vals in enumerate(parsed, start=1):
            vals = list(vals) + [''] * (7-len(vals))
            name = str(vals[0]).strip()
            if not name:
                continue
            try:
                po_mode, po_targets = self._parse_fabric_po_text(vals[1])
                lot_mode, lot_targets = self._parse_fabric_lot_text(vals[2])
                norm = float(str(vals[3]).strip().replace(',', '.'))
                max_len = float(str(vals[4]).strip().replace(',', '.'))
                if norm <= 0 or max_len <= 0:
                    raise ValueError('Định mức/chiều dài tối đa phải > 0')
                export_roll = self._parse_yes_no(vals[5], True)
                export_edit = self._parse_yes_no(vals[6], True)
            except Exception as e:
                bad += 1; errors.append(f'Dòng {rn}: {e}')
                continue
            self.fabric_list.append({
                'name': name, 'cut_mode': 'auto', 'norm': norm, 'min_length': 1.0, 'max_length': max_len,
                'balance_pct': 1.0,
                'reserve_m': 1.0, 'reserve_plies': 1,
                'po_mode': po_mode, 'po_targets': list(po_targets),
                'lot_mode': lot_mode, 'lot_targets': list(lot_targets),
                'export_roll': export_roll, 'export_edit': export_edit,
                'lots': [], 'rolls': [], 'shades': []
            })
            added += 1
        self._sync_global_lots(); self.update_fabric_table()
        self.status_var.set(f'Dán loại vải: thêm {added}, lỗi {bad}')
        if bad:
            msg = '\n'.join(errors[:8])
            if len(errors) > 8: msg += f'\n... và {len(errors)-8} lỗi khác'
            messagebox.showwarning('Dán loại vải', msg)

    def _ensure_lot_roll_details(self, row, force_rebuild=False):
        """Đảm bảo mỗi LOT có danh sách từng cây riêng: tên cây + mét.

        Khi dữ liệu chỉ có SỐ CÂY/TỔNG MÉT, chương trình chia đều để tạo các cây 1..N.
        Sau khi người dùng sửa từng cây, tổng SỐ CÂY/SỐ MÉT được tính ngược từ chi tiết.
        """
        try:
            cnt = max(0, int(float(row.get('roll_count', 0) or 0)))
        except Exception:
            cnt = 0
        try:
            total = max(0.0, float(row.get('meters', 0) or 0))
        except Exception:
            total = 0.0
        details = row.get('rolls_detail') if isinstance(row.get('rolls_detail'), list) else []
        valid = (len(details) == cnt and all(isinstance(x, dict) for x in details))
        if force_rebuild or not valid:
            old = details if isinstance(details, list) else []
            details = []
            each = total / cnt if cnt else 0.0
            made = 0.0
            for i in range(cnt):
                old_item = old[i] if i < len(old) and isinstance(old[i], dict) else {}
                if force_rebuild or not old_item:
                    met = (total - made) if i == cnt - 1 else round(each, 4)
                else:
                    try: met = max(0.0, float(old_item.get('meters', each) or 0))
                    except Exception: met = each
                made += met
                try:
                    _yd = max(0.0, float(old_item.get('yards', 0) or 0))
                except Exception:
                    _yd = 0.0
                if _yd <= 0 and float(met or 0) > 0:
                    _yd = float(met or 0) / self.YARD_TO_METER
                details.append({
                    'roll': str(old_item.get('roll', '') or (i + 1)),
                    'lot_mark': str(old_item.get('lot_mark', row.get('lot_mark', '')) or ''),
                    'yards': max(0.0, float(_yd or 0)),
                    'meters': max(0.0, float(met or 0)),
                })
            # Nếu giữ dữ liệu cũ làm tổng bị lệch đáng kể, scale lại theo tổng mới.
            cur = sum(float(x.get('meters', 0) or 0) for x in details)
            if cnt and total >= 0 and abs(cur - total) > 0.005:
                if cur > 0:
                    scale = total / cur
                    made = 0.0
                    for i, d in enumerate(details):
                        met = (total - made) if i == len(details)-1 else round(float(d.get('meters',0))*scale, 4)
                        d['meters'] = max(0.0, met); made += met
                else:
                    each = total / cnt if cnt else 0.0
                    made = 0.0
                    for i, d in enumerate(details):
                        met = (total-made) if i == cnt-1 else round(each,4)
                        d['meters'] = max(0.0, met); made += met
            for d in details:
                try:
                    d['yards'] = max(0.0, float(d.get('meters', 0) or 0)) / self.YARD_TO_METER
                except Exception:
                    d['yards'] = 0.0
            row['rolls_detail'] = details
        else:
            # Dự án cũ chưa có SỐ Y: tự suy ra từ số mét để hiển thị trên phần mềm.
            for d in details:
                if not isinstance(d, dict):
                    continue
                try:
                    yd = max(0.0, float(d.get('yards', 0) or 0))
                except Exception:
                    yd = 0.0
                if yd <= 0:
                    try:
                        yd = max(0.0, float(d.get('meters', 0) or 0)) / self.YARD_TO_METER
                    except Exception:
                        yd = 0.0
                d['yards'] = yd
        return row.get('rolls_detail', [])

    def _recalc_lot_from_roll_details(self, row):
        details = [x for x in (row.get('rolls_detail') or []) if isinstance(x, dict)]
        cleaned = []
        for i, d in enumerate(details, start=1):
            name = str(d.get('roll', '') or '').strip()
            try: met = max(0.0, float(d.get('meters', 0) or 0))
            except Exception: met = 0.0
            # Cây không tên nhưng có mét vẫn tự đặt số để không làm mất dữ liệu.
            if not name and met <= 0:
                continue
            if not name:
                name = str(i)
            try:
                yd = max(0.0, float(d.get('yards', 0) or 0))
            except Exception:
                yd = 0.0
            if yd <= 0 and met > 0:
                yd = met / self.YARD_TO_METER
            cleaned.append({'roll': name,
                            'lot_mark': str(d.get('lot_mark', row.get('lot_mark','')) or ''),
                            'yards': yd,
                            'meters': met})
        row['rolls_detail'] = cleaned
        row['roll_count'] = len(cleaned)
        row['meters'] = round(sum(float(x.get('meters',0) or 0) for x in cleaned), 4)
        # LOT ghi trên cây cấp LOT dùng làm mặc định; cây riêng có thể khác.
        marks = [str(x.get('lot_mark','') or '').strip() for x in cleaned if str(x.get('lot_mark','') or '').strip()]
        if marks and len(set(marks)) == 1:
            row['lot_mark'] = marks[0]
        return row

    def create_lot_inventory_tab(self, parent):
        """V110 - Kho CÂY/LOT: mỗi dòng nhập là MỘT CÂY thật, không phải số lượng cây.

        Thứ tự cột: LOT - SỐ CÂY - SỐ Y - LOT GHI TRÊN CÂY - SỐ MÉT.
        Cột SỐ CÂY là tên/mã cây (ví dụ 01, 02, A15...). Tổng số cây của LOT
        được tự đếm từ số dòng cây đang có trong LOT đó.
        """
        top = tk.LabelFrame(parent, text="KHO CÂY / LOT - MỖI DÒNG = 1 CÂY",
                            font=('Arial', 11, 'bold'), padx=10, pady=10)
        top.pack(fill='x', padx=15, pady=(15, 6))
        tk.Label(top, text=(
            "Thứ tự nhập: LOT | SỐ CÂY | SỐ Y | LOT GHI TRÊN CÂY | SỐ MÉT. "
            "Nhập SỐ Y thì SỐ MÉT tự tính theo 1Y = 0,9144m. "
            "SỐ CÂY là TÊN/MÃ CÂY, không phải số lượng cây."
        ), font=('Arial', 9), fg='#455a64', justify='left').pack(anchor='w', pady=(0, 8))

        # V109: khung nhập LOT/CÂY động. Mặc định 12 dòng nhưng khi dán Excel
        # sẽ tự sinh thêm bao nhiêu dòng tùy dữ liệu, không còn giới hạn 12 cây.
        lot_grid_wrap = tk.Frame(top, bg='#f4f6f7')
        lot_grid_wrap.pack(fill='x', expand=True)
        lot_grid_canvas = tk.Canvas(lot_grid_wrap, height=245, highlightthickness=0, bg='#f4f6f7')
        lot_grid_vbar = ttk.Scrollbar(lot_grid_wrap, orient='vertical', command=lot_grid_canvas.yview)
        lot_grid_canvas.configure(yscrollcommand=lot_grid_vbar.set)
        lot_grid_canvas.grid(row=0, column=0, sticky='nsew')
        lot_grid_vbar.grid(row=0, column=1, sticky='ns')
        lot_grid_wrap.grid_rowconfigure(0, weight=1)
        lot_grid_wrap.grid_columnconfigure(0, weight=1)

        grid = tk.Frame(lot_grid_canvas, bg='#7f8c8d', bd=1, relief='solid')
        lot_grid_window = lot_grid_canvas.create_window((0, 0), window=grid, anchor='nw')
        # V112: các cột LOT/CÂY tự co giãn theo chiều rộng cửa sổ, không cuộn ngang.
        headers = [('LOT', 18), ('SỐ CÂY', 14), ('SỐ Y', 10), ('LOT GHI TRÊN CÂY', 22), ('SỐ MÉT', 11)]
        for c, (title, width) in enumerate(headers):
            grid.grid_columnconfigure(c, weight=width, minsize=0, uniform='lot_autofit')
            tk.Label(grid, text=title, width=1, font=('Arial', 9, 'bold'),
                     bg='#d9eaf7', bd=1, relief='solid').grid(row=0, column=c, sticky='nsew')

        def _lot_grid_resize(event=None):
            try:
                grid.update_idletasks()
                # Luôn ép lưới bằng đúng chiều rộng canvas để mọi cột tự thu/dãn.
                if event is not None and getattr(event, 'widget', None) == lot_grid_canvas:
                    lot_grid_canvas.itemconfigure(lot_grid_window, width=max(1, int(event.width or 1)))
                else:
                    lot_grid_canvas.itemconfigure(
                        lot_grid_window, width=max(1, int(lot_grid_canvas.winfo_width() or 1))
                    )
                lot_grid_canvas.configure(scrollregion=lot_grid_canvas.bbox('all'))
            except Exception:
                pass

        grid.bind('<Configure>', _lot_grid_resize)
        lot_grid_canvas.bind('<Configure>', _lot_grid_resize)
        self.lot_inventory_entries = []
        self.lot_inventory_canvas = lot_grid_canvas

        def _clipboard_rows(txt):
            lines = [x for x in str(txt).replace('\r\n','\n').replace('\r','\n').split('\n') if x.strip()]
            rows = []
            for line in lines:
                parts = [p.strip() for p in line.split('\t')]
                # V94 thứ tự mới: LOT | SỐ CÂY | SỐ Y | LOT GHI TRÊN CÂY | SỐ MÉT.
                # Vẫn nhận dữ liệu cũ 4 cột và 3 cột để không làm hỏng file/clipboard cũ.
                if len(parts) == 4:  # cũ: LOT | SỐ CÂY | LOT GHI TRÊN CÂY | SỐ MÉT
                    parts = [parts[0], parts[1], '', parts[2], parts[3]]
                elif len(parts) == 3:  # cũ: LOT | SỐ CÂY | SỐ MÉT
                    parts = [parts[0], parts[1], '', '', parts[2]]
                rows.append((parts + [''] * 5)[:5])
            return rows

        def _sync_meter_from_y_entries(entries):
            if len(entries) < 5:
                return
            raw = entries[2].get().strip().replace(',', '.')
            if not raw:
                return
            try:
                yards = max(0.0, float(raw))
            except Exception:
                return
            meters = yards * self.YARD_TO_METER
            entries[4].delete(0, tk.END)
            entries[4].insert(0, f"{meters:.2f}")

        def _create_lot_input_row():
            r = len(self.lot_inventory_entries) + 1
            row_entries = []
            for c, (_, width) in enumerate(headers):
                e = tk.Entry(grid, width=1, font=('Arial', 9), bd=1, relief='solid',
                             justify='left' if c in (0, 1, 3) else 'center')
                e.grid(row=r, column=c, sticky='nsew')
                row_entries.append(e)
            self.lot_inventory_entries.append(row_entries)
            # paste_into_grid được tra cứu khi sự kiện chạy nên có thể bind tại đây.
            for ent in row_entries:
                ent.bind('<Control-v>', paste_into_grid)
                ent.bind('<Control-V>', paste_into_grid)
            row_entries[2].bind('<KeyRelease>',
                                lambda ev, entries=row_entries: _sync_meter_from_y_entries(entries), add='+')
            row_entries[2].bind('<FocusOut>',
                                lambda ev, entries=row_entries: _sync_meter_from_y_entries(entries), add='+')
            return row_entries

        def _ensure_lot_input_rows(count):
            count = max(1, int(count or 1))
            while len(self.lot_inventory_entries) < count:
                _create_lot_input_row()
            _lot_grid_resize()

        def _trim_lot_input_rows(keep=12):
            keep = max(1, int(keep or 1))
            while len(self.lot_inventory_entries) > keep:
                row = self.lot_inventory_entries.pop()
                for ent in row:
                    try:
                        ent.destroy()
                    except Exception:
                        pass
            _ensure_lot_input_rows(keep)
            try:
                lot_grid_canvas.yview_moveto(0)
            except Exception:
                pass

        def paste_into_grid(event=None):
            try:
                txt = self.root.clipboard_get()
            except Exception:
                return 'break'
            rows_to_paste = _clipboard_rows(txt)
            if not rows_to_paste:
                return 'break'
            start_r = start_c = 0
            widget = self.root.focus_get()
            for rr, row in enumerate(self.lot_inventory_entries):
                for cc, ent in enumerate(row):
                    if ent == widget:
                        start_r, start_c = rr, cc
                        break
            # V109: tự thêm dòng theo clipboard, thực tế không giới hạn số cây.
            _ensure_lot_input_rows(start_r + len(rows_to_paste))
            for dr, parts in enumerate(rows_to_paste):
                for dc, val in enumerate(parts[:5-start_c]):
                    ent = self.lot_inventory_entries[start_r+dr][start_c+dc]
                    ent.delete(0, tk.END)
                    ent.insert(0, val)
                _sync_meter_from_y_entries(self.lot_inventory_entries[start_r+dr])
            _lot_grid_resize()
            try:
                target_row = min(len(self.lot_inventory_entries)-1, start_r + len(rows_to_paste)-1)
                lot_grid_canvas.update_idletasks()
                bbox = lot_grid_canvas.bbox('all')
                if bbox and bbox[3] > 0:
                    y = self.lot_inventory_entries[target_row][0].winfo_y()
                    lot_grid_canvas.yview_moveto(max(0.0, min(1.0, y / bbox[3])))
            except Exception:
                pass
            self.status_var.set(f'Đã dán {len(rows_to_paste)} dòng CÂY/LOT')
            return 'break'

        _ensure_lot_input_rows(12)

        def _norm_excel_header(value):
            """Chuẩn hóa tiêu đề Excel để nhận cả tiếng Việt có/không dấu."""
            s = str(value or '').strip().upper()
            s = unicodedata.normalize('NFKD', s)
            s = ''.join(ch for ch in s if not unicodedata.combining(ch))
            s = s.replace('Đ', 'D')
            s = re.sub(r'[^A-Z0-9#]+', ' ', s)
            return ' '.join(s.split())

        def _excel_number(value):
            if value in (None, ''):
                return 0.0
            if isinstance(value, (int, float)):
                return max(0.0, float(value))
            s = str(value).strip().replace(' ', '').replace('m', '').replace('M', '')
            if not s:
                return 0.0
            # Hỗ trợ cả 1.234,5 và 1,234.5; trường hợp chỉ có dấu phẩy coi là dấu thập phân.
            if ',' in s and '.' in s:
                if s.rfind(',') > s.rfind('.'):
                    s = s.replace('.', '').replace(',', '.')
                else:
                    s = s.replace(',', '')
            else:
                s = s.replace(',', '.')
            return max(0.0, float(s))

        def import_lot_excel():
            filename = filedialog.askopenfilename(
                title='Chọn file Excel chứa LOT / SỐ CÂY / SỐ MÉT',
                filetypes=[
                    ('Excel Workbook', '*.xlsx *.xlsm'),
                    ('Excel .xlsx', '*.xlsx'),
                    ('Excel Macro .xlsm', '*.xlsm'),
                    ('All files', '*.*'),
                ]
            )
            if not filename:
                return
            try:
                wb_in = load_workbook(filename, read_only=True, data_only=True)
            except Exception as e:
                messagebox.showerror('Không đọc được file Excel',
                                     f'Chỉ hỗ trợ .xlsx/.xlsm.\n\n{e}', parent=parent)
                return

            def detect_sheet(ws):
                max_r = min(int(ws.max_row or 0), 30)
                max_c = min(int(ws.max_column or 0), 30)
                for rr in range(1, max_r + 1):
                    found = {}
                    for cc in range(1, max_c + 1):
                        h = _norm_excel_header(ws.cell(rr, cc).value)
                        if not h:
                            continue
                        if h in ('LOT', 'TEN LOT', 'MA LOT'):
                            found.setdefault('lot', cc)
                        elif h in ('SO CAY', 'TEN CAY', 'MA CAY', 'CAY', 'ROLL', 'ROLL#', 'ROLL #'):
                            found.setdefault('roll', cc)
                        elif h in ('SO Y', 'Y', 'YARD', 'YARDS', 'SO YARD', 'CHIEU DAI Y', 'CHIEU DAI YARD'):
                            found.setdefault('yards', cc)
                        elif h in ('SO MET', 'SO M', 'SO MET VAI', 'MET', 'METER', 'METERS',
                                   'CHIEU DAI M', 'CHIEU DAI MET'):
                            found.setdefault('meters', cc)
                        elif ('LOT' in h and 'GHI' in h and 'CAY' in h) or h in ('LOT TREN CAY', 'LOT GHI TREN CAY'):
                            found.setdefault('mark', cc)
                    if all(k in found for k in ('lot', 'roll')) and ('meters' in found or 'yards' in found):
                        return rr, found
                return None

            chosen = None
            for ws_in in wb_in.worksheets:
                detected = detect_sheet(ws_in)
                if detected:
                    chosen = (ws_in, detected[0], detected[1])
                    break

            if chosen is None:
                ws_in = wb_in.active
                use_first3 = messagebox.askyesno(
                    'Không tìm thấy tiêu đề',
                    'Không tìm thấy đủ tiêu đề LOT, SỐ CÂY và SỐ Y/SỐ MÉT.\n\n'
                    'Bạn có muốn dùng sheet hiện tại theo thứ tự mới:\n'
                    'A = LOT | B = SỐ CÂY | C = SỐ Y | D = LOT GHI TRÊN CÂY | E = SỐ MÉT?',
                    parent=parent
                )
                if not use_first3:
                    wb_in.close()
                    return
                chosen = (ws_in, 0, {'lot': 1, 'roll': 2, 'yards': 3, 'mark': 4, 'meters': 5})

            ws_in, header_row, cols = chosen
            added = updated = bad = skipped = 0
            first_data_row = header_row + 1 if header_row else 1
            for rr in range(first_data_row, int(ws_in.max_row or 0) + 1):
                lot = str(ws_in.cell(rr, cols['lot']).value or '').strip()
                roll_name = str(ws_in.cell(rr, cols['roll']).value or '').strip()
                mark = ''
                if cols.get('mark'):
                    mark = str(ws_in.cell(rr, cols['mark']).value or '').strip()
                raw_yards = ws_in.cell(rr, cols['yards']).value if cols.get('yards') else None
                raw_meters = ws_in.cell(rr, cols['meters']).value if cols.get('meters') else None

                if not lot and not roll_name and raw_yards in (None, '') and raw_meters in (None, ''):
                    skipped += 1
                    continue
                # Bỏ dòng tiêu đề lặp lại giữa dữ liệu.
                if _norm_excel_header(lot) in ('LOT', 'TEN LOT', 'MA LOT'):
                    skipped += 1
                    continue
                if not lot or not roll_name:
                    bad += 1
                    continue
                try:
                    yd = _excel_number(raw_yards) if raw_yards not in (None, '') else 0.0
                    if yd > 0:
                        met = yd * self.YARD_TO_METER
                    else:
                        met = _excel_number(raw_meters)
                        yd = (met / self.YARD_TO_METER) if met > 0 else 0.0
                except Exception:
                    bad += 1
                    continue

                found = next((x for x in self.global_lot_rows
                              if str(x.get('lot','')).strip().lower() == lot.lower()), None)
                if found is None:
                    found = {'lot': lot, 'lot_mark': mark, 'roll_count': 0,
                             'meters': 0.0, 'rolls_detail': []}
                    self.global_lot_rows.append(found)

                details = self._ensure_lot_roll_details(found)
                # V93: một cây được nhận diện bằng LOT + LOT GHI TRÊN CÂY + SỐ CÂY.
                # Vì vậy cùng SỐ CÂY nhưng LOT ghi trên cây khác nhau là 2 cây độc lập.
                _mark_key = str(mark or '').strip().lower()
                existing = next((d for d in details
                                 if str(d.get('roll','')).strip().lower() == roll_name.lower()
                                 and str(d.get('lot_mark','') or '').strip().lower() == _mark_key), None)
                if existing:
                    existing['roll'] = roll_name
                    existing['lot_mark'] = mark
                    existing['yards'] = yd
                    existing['meters'] = met
                    updated += 1
                else:
                    details.append({'roll': roll_name, 'lot_mark': mark, 'yards': yd, 'meters': met})
                    added += 1
                found['rolls_detail'] = details
                self._recalc_lot_from_roll_details(found)

            wb_in.close()
            refresh()
            if hasattr(self, '_refresh_fabric_lot_selector'):
                self._refresh_fabric_lot_selector()
            self.status_var.set(
                f'Nhập Excel: thêm {added} cây, cập nhật {updated} cây, lỗi {bad}'
            )
            messagebox.showinfo(
                'Nhập file Excel hoàn tất',
                f'Sheet: {ws_in.title}\n'
                f'Thêm mới: {added} cây\n'
                f'Cập nhật: {updated} cây\n'
                f'Dòng lỗi/bỏ qua: {bad + skipped}',
                parent=parent
            )

        btns = tk.Frame(top)
        btns.pack(fill='x', pady=(8, 0))
        for _c in range(4):
            btns.grid_columnconfigure(_c, weight=1, uniform='lot_actions')
        tk.Button(btns, text='📋 DÁN TỪ EXCEL', command=paste_into_grid,
                  font=('Arial', 9, 'bold'), bg='#16a085', fg='white',
                  padx=8, pady=4, wraplength=180).grid(row=0, column=0, sticky='ew', padx=(0, 3))
        tk.Button(btns, text='📥 NHẬP FILE EXCEL', command=import_lot_excel,
                  font=('Arial', 9, 'bold'), bg='#2471a3', fg='white',
                  padx=8, pady=4, wraplength=180).grid(row=0, column=1, sticky='ew', padx=3)

        detail_box = tk.LabelFrame(parent, text='CHI TIẾT TỪNG LOT - MỖI CÂY 1 DÒNG',
                                   font=('Arial', 11, 'bold'), padx=6, pady=6)
        detail_box.pack(fill='x', expand=False, padx=15, pady=(5, 8))
        canvas = tk.Canvas(detail_box, height=54, highlightthickness=0, bg='#f4f6f7')
        vbar = ttk.Scrollbar(detail_box, orient='vertical', command=canvas.yview)
        inner = tk.Frame(canvas, bg='#f4f6f7')
        inner_id = canvas.create_window((0, 0), window=inner, anchor='nw')
        canvas.configure(yscrollcommand=vbar.set)
        canvas.pack(side='left', fill='both', expand=True)
        vbar.pack(side='right', fill='y')
        self.global_lot_detail_canvas = canvas
        inner.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfigure(inner_id, width=e.width))
        self.global_lot_detail_inner = inner
        self.global_lot_summary_var = tk.StringVar(value='')
        tk.Label(parent, textvariable=self.global_lot_summary_var, font=('Arial', 10, 'bold'),
                 fg='#1f4e78', anchor='w').pack(fill='x', padx=18, pady=(0, 8))

        def refresh():
            if self.fabric_list:
                self._sync_global_lots()
            for w in inner.winfo_children():
                w.destroy()
            total_c = 0
            total_m = 0.0
            if not self.global_lot_rows:
                tk.Label(inner, text='Chưa có LOT. Hãy nhập từng cây ở khung phía trên.',
                         font=('Arial', 10), bg='#f4f6f7', fg='#7f8c8d').pack(anchor='w', padx=8, pady=8)

            for idx, row in enumerate(self.global_lot_rows):
                details = self._ensure_lot_roll_details(row)
                lot_name = str(row.get('lot', '') or f'LOT {idx+1}')
                frame = tk.LabelFrame(inner, text=f"LOT: {lot_name}", font=('Arial', 10, 'bold'),
                                      padx=6, pady=6, bg='#ffffff', fg='#1f4e78')
                frame.pack(fill='x', padx=5, pady=5)

                head = tk.Frame(frame, bg='#ffffff')
                head.pack(fill='x')
                hdr = [('SỐ CÂY', 16), ('SỐ Y', 12), ('LOT GHI TRÊN CÂY', 22), ('SỐ MÉT', 14)]
                for c, (t, wid) in enumerate(hdr):
                    tk.Label(head, text=t, width=wid, font=('Arial', 9, 'bold'), bg='#d9eaf7',
                             bd=1, relief='solid').grid(row=0, column=c, sticky='nsew')

                row_entries = []
                for ri, d in enumerate(details, start=1):
                    _met = float(d.get('meters',0) or 0)
                    try:
                        _yd = float(d.get('yards',0) or 0)
                    except Exception:
                        _yd = 0.0
                    if _yd <= 0 and _met > 0:
                        _yd = _met / self.YARD_TO_METER
                    vals = [str(d.get('roll', '') or ''),
                            f"{_yd:.2f}" if _yd > 0 else '',
                            str(d.get('lot_mark', row.get('lot_mark', '')) or ''),
                            f"{_met:.2f}"]
                    ents = []
                    for c, val in enumerate(vals):
                        e = tk.Entry(head, width=hdr[c][1], font=('Arial', 9), bd=1, relief='solid',
                                     justify='left' if c in (0, 2) else 'center')
                        e.insert(0, val)
                        e.grid(row=ri, column=c, sticky='nsew')
                        ents.append(e)
                    row_entries.append(ents)

                foot = tk.Frame(frame, bg='#ffffff')
                foot.pack(fill='x', pady=(5, 0))
                summary = tk.StringVar()

                def recalc_local(row=row, entries=row_entries, summary=summary):
                    new = []
                    for ents in entries:
                        name = ents[0].get().strip()
                        yt = ents[1].get().strip().replace(',', '.')
                        mark = ents[2].get().strip()
                        mt = ents[3].get().strip().replace(',', '.')
                        try:
                            yd = max(0.0, float(yt)) if yt else 0.0
                        except Exception:
                            yd = 0.0
                        try:
                            met = max(0.0, float(mt)) if mt else 0.0
                        except Exception:
                            met = 0.0
                        if yd > 0:
                            met = yd * self.YARD_TO_METER
                            ents[3].delete(0, tk.END)
                            ents[3].insert(0, f"{met:.2f}")
                        elif met > 0:
                            yd = met / self.YARD_TO_METER
                        if not name and met <= 0:
                            continue
                        if not name:
                            name = str(len(new) + 1)
                        new.append({'roll': name, 'lot_mark': mark, 'yards': yd, 'meters': met})
                    row['rolls_detail'] = new
                    self._recalc_lot_from_roll_details(row)
                    cnt = int(row.get('roll_count', 0) or 0)
                    met = float(row.get('meters', 0) or 0)
                    summary.set(f'TỔNG LOT: {cnt} CÂY | {met:.2f} m')
                    self.global_lot_summary_var.set(
                        f"TỔNG KHO: {len(self.global_lot_rows)} LOT | "
                        f"{sum(int(x.get('roll_count',0) or 0) for x in self.global_lot_rows)} CÂY | "
                        f"{sum(float(x.get('meters',0) or 0) for x in self.global_lot_rows):.2f} m"
                    )
                    if self.fabric_list:
                        self._sync_global_lots()
                        self.update_fabric_table()

                recalc_local()
                for ents in row_entries:
                    def _sync_detail_y(ev=None, entries=ents):
                        raw = entries[1].get().strip().replace(',', '.')
                        if raw:
                            try:
                                yd = max(0.0, float(raw))
                                entries[3].delete(0, tk.END)
                                entries[3].insert(0, f"{yd * self.YARD_TO_METER:.2f}")
                            except Exception:
                                pass
                    ents[1].bind('<KeyRelease>', _sync_detail_y, add='+')
                    for e in ents:
                        e.bind('<Return>', lambda ev, fn=recalc_local: fn())
                        e.bind('<FocusOut>', lambda ev, fn=recalc_local: fn())

                tk.Label(foot, textvariable=summary, font=('Arial', 9, 'bold'),
                         bg='#ffffff', fg='#1f4e78').pack(side='left')

                def add_one(row=row):
                    self._ensure_lot_roll_details(row)
                    existing = {str(x.get('roll','')).strip() for x in row['rolls_detail']}
                    n = 1
                    while str(n) in existing:
                        n += 1
                    row['rolls_detail'].append({'roll': str(n),
                                                'yards': 0.0,
                                                'lot_mark': str(row.get('lot_mark','') or ''),
                                                'meters': 0.0})
                    self._recalc_lot_from_roll_details(row)
                    refresh()

                def del_lot(i=idx):
                    if messagebox.askyesno('Xóa LOT',
                                           f'Xóa toàn bộ LOT {self.global_lot_rows[i].get("lot","")}?',
                                           parent=parent):
                        del self.global_lot_rows[i]
                        refresh()

                tk.Button(foot, text='➕ THÊM CÂY', command=add_one, font=('Arial', 8, 'bold'),
                          bg='#2980b9', fg='white').pack(side='right', padx=3)
                tk.Button(foot, text='🗑 XÓA LOT', command=del_lot, font=('Arial', 8, 'bold'),
                          bg='#c0392b', fg='white').pack(side='right', padx=3)
                total_c += int(row.get('roll_count', 0) or 0)
                total_m += float(row.get('meters', 0) or 0)

            self.global_lot_summary_var.set(
                f'TỔNG KHO: {len(self.global_lot_rows)} LOT | {total_c} CÂY | {total_m:.2f} m'
            )
            self._apply_responsive_heights()
            if hasattr(self, '_refresh_fabric_lot_selector'):
                self._refresh_fabric_lot_selector()
            if self.fabric_list:
                self.update_fabric_table()

        self.refresh_global_lot_inventory = refresh

        def save_grid():
            """Lưu từng dòng cây; nếu LOT + SỐ CÂY đã có thì cập nhật cây đó."""
            added = updated = bad = 0
            for entries in self.lot_inventory_entries:
                vals = [e.get().strip() for e in entries]
                if not any(vals):
                    continue
                lot, roll_name, yards_text, mark, meters_text = vals[0], vals[1], vals[2], vals[3], vals[4]
                if lot.upper() == 'LOT' and roll_name.upper() in ('SỐ CÂY', 'SO CAY'):
                    continue
                try:
                    yd = max(0.0, float(yards_text.replace(',', '.'))) if yards_text else 0.0
                    if yd > 0:
                        met = yd * self.YARD_TO_METER
                    else:
                        met = max(0.0, float(meters_text.replace(',', '.'))) if meters_text else 0.0
                        yd = (met / self.YARD_TO_METER) if met > 0 else 0.0
                except Exception:
                    bad += 1
                    continue
                if not lot or not roll_name:
                    bad += 1
                    continue

                found = next((x for x in self.global_lot_rows
                              if str(x.get('lot','')).strip().lower() == lot.lower()), None)
                if found is None:
                    found = {'lot': lot, 'lot_mark': mark, 'roll_count': 0,
                             'meters': 0.0, 'rolls_detail': []}
                    self.global_lot_rows.append(found)

                details = self._ensure_lot_roll_details(found)
                # V93: cho phép trùng SỐ CÂY nếu LOT GHI TRÊN CÂY khác nhau.
                _mark_key = str(mark or '').strip().lower()
                existing = next((d for d in details
                                 if str(d.get('roll','')).strip().lower() == roll_name.lower()
                                 and str(d.get('lot_mark','') or '').strip().lower() == _mark_key), None)
                if existing:
                    existing['roll'] = roll_name
                    existing['lot_mark'] = mark
                    existing['yards'] = yd
                    existing['meters'] = met
                    updated += 1
                else:
                    details.append({'roll': roll_name, 'lot_mark': mark, 'yards': yd, 'meters': met})
                    added += 1
                found['rolls_detail'] = details
                self._recalc_lot_from_roll_details(found)

            for row in self.lot_inventory_entries:
                for e in row:
                    e.delete(0, tk.END)
            _trim_lot_input_rows(12)
            refresh()
            self.status_var.set(f'Kho cây/LOT: thêm {added} cây, cập nhật {updated} cây, lỗi {bad}')

        def clear_grid():
            for row in self.lot_inventory_entries:
                for e in row:
                    e.delete(0, tk.END)
            _trim_lot_input_rows(12)

        def add_input_row():
            _ensure_lot_input_rows(len(self.lot_inventory_entries) + 1)
            try:
                self.lot_inventory_entries[-1][0].focus_set()
                lot_grid_canvas.yview_moveto(1.0)
            except Exception:
                pass

        tk.Button(btns, text='✅ LƯU / CẬP NHẬT CÂY', command=save_grid,
                  font=('Arial', 9, 'bold'), bg='#27ae60', fg='white',
                  padx=8, pady=4, wraplength=180).grid(row=0, column=2, sticky='ew', padx=3)
        tk.Button(btns, text='🧹 XÓA KHUNG NHẬP', command=clear_grid,
                  font=('Arial', 9, 'bold'), bg='#7f8c8d', fg='white',
                  padx=8, pady=4, wraplength=180).grid(row=0, column=3, sticky='ew', padx=(3, 0))
        tk.Button(btns, text='➕ THÊM DÒNG NHẬP', command=add_input_row,
                  font=('Arial', 8, 'bold'), bg='#5d6d7e', fg='white',
                  padx=8, pady=3).grid(row=1, column=0, columnspan=4, sticky='ew', pady=(5, 0))
        refresh()

    # ==================== V72: CHẾ ĐỘ GIÁC THEO LOẠI VẢI ====================
    @staticmethod
    def _fabric_text_key(value):
        """Chuẩn hóa tên vật tư để nhận diện tự động, bỏ dấu và ký tự thừa."""
        txt = str(value or '').strip().upper()
        txt = ''.join(
            ch for ch in unicodedata.normalize('NFD', txt)
            if unicodedata.category(ch) != 'Mn'
        )
        txt = re.sub(r'[^A-Z0-9]+', ' ', txt)
        return re.sub(r'\s+', ' ', txt).strip()

    def _infer_fabric_mode_key(self, name):
        """Nhận diện nhóm giác theo tên vật tư; tên không rõ mặc định VẢI CHÍNH."""
        txt = self._fabric_text_key(name)
        # Ưu tiên nhóm đặc thù trước để tránh tên ghép bị nhận nhầm.
        if any(k in txt for k in ('KEP TANG', 'INTERLAYER', 'SANDWICH LAYER', 'INNER LAYER')):
            return 'interlayer'
        if any(k in txt for k in ('DUNG', 'MEX', 'FUSING', 'FUSE', 'INTERLINING', 'KEO DUNG', 'KEO MEX')):
            return 'interlining'
        if any(k in txt for k in ('BONG', 'PADDING', 'WADDING', 'FILLING', 'QUILTING')):
            return 'padding'
        if any(k in txt for k in ('VAI LOT', 'LOT', 'LINING', 'POCKETING')):
            return 'lining'
        if any(k in txt for k in ('VAI CHINH', 'MAIN FABRIC', 'SHELL', 'OUTER', 'BODY FABRIC')):
            return 'main'
        return 'main'

    def _fabric_mode_key_from_label(self, value):
        txt = self._fabric_text_key(value)
        for key, label in self.FABRIC_MODE_LABELS.items():
            if self._fabric_text_key(label) == txt:
                return key
        # Cho phép dữ liệu cũ hoặc dữ liệu nhập thẳng bằng key.
        raw = str(value or '').strip().lower()
        return raw if raw in self.FABRIC_MODE_LABELS else 'auto'

    def _resolved_fabric_mode(self, fabric):
        mode = self._fabric_mode_key_from_label(fabric.get('cut_mode', 'auto'))
        if mode == 'auto':
            return self._infer_fabric_mode_key(fabric.get('name', ''))
        return mode

    def _fabric_mode_display(self, fabric):
        saved = self._fabric_mode_key_from_label(fabric.get('cut_mode', 'auto'))
        resolved = self._resolved_fabric_mode(fabric)
        if saved == 'auto':
            return f"TỰ ĐỘNG → {self.FABRIC_MODE_LABELS.get(resolved, 'VẢI CHÍNH')}"
        return self.FABRIC_MODE_LABELS.get(resolved, 'VẢI CHÍNH')

    def _fabric_cut_profile(self, mode_key, total_by_size, norm, max_len, balance_pct=1.0):
        """Thông số tối ưu V72 theo từng nhóm vật tư.

        - Vải chính: chính xác nhất, dương thấp.
        - Vải lót: ghép nhiều cỡ, marker đủ dài, dương vừa.
        - Kẹp tầng: định mức thường lớn nhưng ít quan trọng -> ưu tiên ít bàn,
          tỷ lệ đơn giản và cho phép dương rộng hơn.
        - Dựng/Mex: định mức có thể rất nhỏ -> marker chính phải đủ dài,
          nhiều cỡ/tỷ lệ để tránh sơ đồ vài cm và không kín khổ.
        - Bông: ưu tiên ít bàn/tận dụng khổ, cho phép dương rộng nhất.
        """
        mode_key = mode_key if mode_key in self.FABRIC_MODE_LABELS else 'main'
        max_len = max(0.0, float(max_len or 0))
        norm = max(0.000001, float(norm or 0.000001))

        base = {
            'mode': mode_key,
            'label': self.FABRIC_MODE_LABELS.get(mode_key, 'VẢI CHÍNH'),
            'merge_style': 'balanced',
            'score_style': 'exact',
            'base_over': int(getattr(self, 'MAX_OVER', 3) or 3),
            'over_pct': 0.0,
            'over_cap': int(getattr(self, 'MAX_OVER', 3) or 3),
            'target_min_marker': 0.8,
            'prefer_size_spread': True,
            # V115: mặc định các nhóm vải vẫn không cho âm. Riêng DỰNG/MEX và BÔNG
            # được phép âm/dương theo từng cỡ và phần dương của cỡ lớn có thể hạ
            # xuống bù cho cỡ nhỏ.
            'allow_under': False,
            'under_pct': 0.0,
            'under_cap': 0,
            'downgrade_large_to_small': False,
            # V117: giới hạn TỔNG dương còn lại sau khi đã hạ cỡ lớn -> cỡ bé.
            # -1 = không áp dụng giới hạn tổng.
            'total_surplus_pct': 0.0,
            'total_surplus_cap': -1,
        }
        if mode_key == 'lining':
            base.update({
                'merge_style': 'strong', 'score_style': 'lining',
                'base_over': 5, 'over_pct': 0.01, 'over_cap': 10,
                'target_min_marker': 1.20, 'prefer_size_spread': True,
            })
        elif mode_key == 'interlayer':
            base.update({
                'merge_style': 'simple', 'score_style': 'few_tables',
                'base_over': 8, 'over_pct': 0.03, 'over_cap': 20,
                'target_min_marker': 0.60, 'prefer_size_spread': False,
            })
        elif mode_key == 'interlining':
            base.update({
                'merge_style': 'strong', 'score_style': 'high_ratio',
                'base_over': 8, 'over_pct': 0.04, 'over_cap': 25,
                'target_min_marker': 1.50, 'prefer_size_spread': True,
                'allow_under': True, 'under_pct': 0.04, 'under_cap': 25,
                'downgrade_large_to_small': True,
                'total_surplus_pct': 0.01,
            })
        elif mode_key == 'padding':
            base.update({
                'merge_style': 'strong', 'score_style': 'few_tables',
                'base_over': 10, 'over_pct': 0.05, 'over_cap': 30,
                'target_min_marker': 1.20, 'prefer_size_spread': True,
                'allow_under': True, 'under_pct': 0.05, 'under_cap': 30,
                'downgrade_large_to_small': True,
                'total_surplus_pct': 0.01,
            })

        # V141: DỰNG/MEX và BÔNG dùng % âm/dương do người dùng chọn RIÊNG
        # cho từng loại vải. Giá trị trên giao diện nhập theo %, ví dụ 1 = 1%.
        # Các loại vải khác giữ logic cũ và không dùng giới hạn tổng này.
        if mode_key in ('interlining', 'padding'):
            try:
                _user_balance_pct = max(0.0, min(100.0, float(balance_pct if balance_pct is not None else 1.0)))
            except Exception:
                _user_balance_pct = 1.0
            base['total_surplus_pct'] = _user_balance_pct / 100.0

        # Không đặt mục tiêu dài hơn giới hạn marker. Kẹp tầng định mức lớn thường
        # tự đạt chiều dài này chỉ với 1-2 nhịp tỷ lệ.
        if max_len > 0:
            base['target_min_marker'] = min(float(base['target_min_marker']), max_len)

        over_limits = {}
        for key, qty in (total_by_size or {}).items():
            q = max(0, int(qty or 0))
            by_pct = int(math.ceil(q * float(base['over_pct']) - 1e-12)) if q > 0 else 0
            limit = max(int(base['base_over']), by_pct)
            limit = min(limit, int(base['over_cap']))
            over_limits[key] = max(0, limit)
        base['over_limits'] = over_limits
        base['max_over_any'] = max(over_limits.values(), default=int(base['base_over']))

        # V115: giới hạn âm dùng đối xứng với cách tính dương nhưng chỉ bật cho
        # DỰNG/MEX và BÔNG. Ví dụ BÔNG 5% (min 10, max 30); DỰNG 4% (min 8, max 25).
        under_limits = {}
        allow_under = bool(base.get('allow_under', False))
        for key, qty in (total_by_size or {}).items():
            q = max(0, int(qty or 0))
            if allow_under:
                by_pct = int(math.ceil(q * float(base.get('under_pct', 0.0)) - 1e-12)) if q > 0 else 0
                limit = max(int(base.get('base_over', 0) or 0), by_pct)
                cap = int(base.get('under_cap', 0) or 0)
                if cap > 0:
                    limit = min(limit, cap)
                under_limits[key] = max(0, min(q, limit))
            else:
                under_limits[key] = 0
        base['under_limits'] = under_limits
        base['max_under_any'] = max(under_limits.values(), default=0)

        # V117: DỰNG/MEX và BÔNG chỉ được phép dương tổng tối đa 1% sau khi
        # đã dùng phần dương cỡ lớn để bù phần âm của cỡ bé.
        _surplus_pct = max(0.0, float(base.get('total_surplus_pct', 0.0) or 0.0))
        if bool(base.get('allow_under', False)) and mode_key in ('interlining', 'padding'):
            _total_target = sum(max(0, int(v or 0)) for v in (total_by_size or {}).values())
            # 0% = yêu cầu sau cân size không còn dương; không phải "tắt giới hạn".
            base['total_surplus_cap'] = max(0, int(math.floor(_total_target * _surplus_pct + 1e-12)))
        else:
            base['total_surplus_cap'] = -1
        return base

    def create_fabric_tab(self, parent):
        input_frame = tk.LabelFrame(parent, text="Thêm loại vải mới",
                                   font=('Arial', 11, 'bold'), padx=15, pady=15)
        input_frame.pack(fill='x', padx=20, pady=10)

        # V110: chia phần nhập loại vải thành 2 hàng để nút không bị ẩn khi cửa sổ thu nhỏ.
        for c in range(8):
            input_frame.grid_columnconfigure(c, weight=1 if c in (1, 3, 5, 7) else 0)

        tk.Label(input_frame, text="Tên loại vải:", font=('Arial', 10, 'bold')).grid(row=0, column=0, padx=5, pady=5, sticky='e')
        self.entry_fabric_name = tk.Entry(input_frame, width=20, font=('Arial', 10))
        self.entry_fabric_name.insert(0, 'VẢI CHÍNH')
        self.entry_fabric_name.grid(row=0, column=1, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="Định mức TB (m):", font=('Arial', 10, 'bold')).grid(row=0, column=2, padx=5, pady=5, sticky='e')
        self.entry_fabric_norm = tk.Entry(input_frame, width=10, font=('Arial', 10))
        self.entry_fabric_norm.grid(row=0, column=3, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="Dài tối đa (m):", font=('Arial', 10, 'bold')).grid(row=0, column=4, padx=5, pady=5, sticky='e')
        self.entry_fabric_maxlen = tk.Entry(input_frame, width=9, font=('Arial', 10))
        self.entry_fabric_maxlen.grid(row=0, column=5, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="Dài tối thiểu (m):", font=('Arial', 10, 'bold')).grid(row=0, column=6, padx=5, pady=5, sticky='e')
        self.entry_fabric_minlen = tk.Entry(input_frame, width=9, font=('Arial', 10))
        self.entry_fabric_minlen.insert(0, '1')
        self.entry_fabric_minlen.grid(row=0, column=7, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="SP tối đa / sơ đồ:", font=('Arial', 10, 'bold')).grid(row=1, column=0, padx=5, pady=5, sticky='e')
        self.entry_fabric_max_products = tk.Entry(input_frame, width=9, font=('Arial', 10))
        self.entry_fabric_max_products.grid(row=1, column=1, padx=5, pady=5, sticky='ew')

        tk.Label(input_frame, text="Chế độ giác:", font=('Arial', 10, 'bold')).grid(row=1, column=2, padx=5, pady=5, sticky='e')
        self.fabric_mode_var = tk.StringVar(value='TỰ ĐỘNG')
        self.fabric_mode_combo = ttk.Combobox(
            input_frame, textvariable=self.fabric_mode_var, values=self.FABRIC_MODE_VALUES,
            state='readonly', width=15, font=('Arial', 10)
        )
        self.fabric_mode_combo.grid(row=1, column=3, columnspan=2, padx=5, pady=5, sticky='ew')

        tk.Button(input_frame, text="➕ Thêm vải", command=self.add_fabric,
                 font=('Arial', 10, 'bold'), bg='#27ae60', fg='white',
                 padx=15, pady=5).grid(row=1, column=5, columnspan=3, padx=5, pady=5, sticky='ew')

        # V40: PO vẫn nhập như cũ. Khi thêm LOẠI VẢI, chọn PO mà loại vải này áp dụng.
        self.fabric_po_frame = tk.LabelFrame(
            input_frame, text="PO áp dụng cho loại vải",
            font=('Arial', 10, 'bold'), padx=8, pady=6
        )
        self.fabric_po_frame.grid(row=2, column=0, columnspan=8, sticky='ew', padx=5, pady=(8, 2))
        self.fabric_all_po_var = tk.BooleanVar(value=True)
        self.fabric_po_vars = {}
        self.fabric_all_po_check = tk.Checkbutton(
            self.fabric_po_frame, text="TẤT CẢ PO", variable=self.fabric_all_po_var,
            command=self._on_fabric_all_po_toggled, font=('Arial', 9, 'bold'),
            fg='#1f4e78'
        )
        self.fabric_all_po_check.pack(side='left', padx=(2, 12))
        self.fabric_po_checks_frame = tk.Frame(self.fabric_po_frame)
        self.fabric_po_checks_frame.pack(side='left', fill='x', expand=True)
        self._refresh_fabric_po_selector()

        # V45: chọn LOT từ kho áp dụng cho loại vải đang thêm.
        self.fabric_lot_frame = tk.LabelFrame(
            input_frame, text="LOT trong kho áp dụng cho loại vải này",
            font=('Arial', 10, 'bold'), padx=8, pady=6
        )
        self.fabric_lot_frame.grid(row=3, column=0, columnspan=8, sticky='ew', padx=5, pady=(6, 2))
        self.fabric_no_lot_var = tk.BooleanVar(value=True)
        self.fabric_all_lot_var = tk.BooleanVar(value=False)
        self.fabric_lot_vars = {}
        self.fabric_no_lot_check = tk.Checkbutton(
            self.fabric_lot_frame, text="KHÔNG DÙNG LOT", variable=self.fabric_no_lot_var,
            command=self._on_fabric_no_lot_toggled, font=('Arial', 9, 'bold'), fg='#c0392b'
        )
        self.fabric_no_lot_check.pack(side='left', padx=(2, 12))
        self.fabric_all_lot_check = tk.Checkbutton(
            self.fabric_lot_frame, text="TẤT CẢ LOT", variable=self.fabric_all_lot_var,
            command=self._on_fabric_all_lot_toggled, font=('Arial', 9, 'bold'), fg='#7d3c98'
        )
        self.fabric_all_lot_check.pack(side='left', padx=(2, 12))
        self.fabric_lot_checks_frame = tk.Frame(self.fabric_lot_frame)
        self.fabric_lot_checks_frame.pack(side='left', fill='x', expand=True)
        self._refresh_fabric_lot_selector()

        # V44: bỏ checkbox bật/tắt ở khu thêm vải.
        # Mặc định khi thêm mới là CÓ; sau đó chọn CÓ/KHÔNG trực tiếp bằng mũi tên trong danh sách loại vải.
        self.fabric_export_roll_var = tk.BooleanVar(value=True)
        self.fabric_export_edit_var = tk.BooleanVar(value=True)

        table_frame = tk.LabelFrame(parent, text="Danh sách loại vải",
                                   font=('Arial', 11, 'bold'), padx=10, pady=10)
        table_frame.pack(fill='x', padx=20, pady=8)

        columns = ('name', 'cut_mode', 'optimizer_mode', 'po_apply', 'lot_apply', 'norm', 'min_length', 'max_length', 'max_products', 'lot_count', 'lot_meters', 'roll_count', 'export_roll', 'export_edit')
        self.fabric_tree = ttk.Treeview(table_frame, columns=columns, show='headings', height=4)

        headers = {
            'name': 'Tên loại vải',
            'cut_mode': 'Chế độ giác ▼',
            'optimizer_mode': 'Kiểu tối ưu ▼',
            'po_apply': 'PO áp dụng',
            'lot_apply': 'LOT áp dụng',
            'norm': 'Định mức TB (m)',
            'min_length': 'Chiều dài tối thiểu (m)',
            'max_length': 'Chiều dài tối đa (m)',
            'max_products': 'SP tối đa / sơ đồ',
            'lot_count': 'Số LOT',
            'lot_meters': 'Tổng mét LOT',
            'roll_count': 'Số cây',
            'export_roll': 'Xuất PHÂN CÂY',
            'export_edit': 'Xuất SỬA PHÂN CÂY'
        }
        widths = {'name': 125, 'cut_mode': 165, 'optimizer_mode': 145, 'po_apply': 190, 'lot_apply': 145, 'norm': 90, 'min_length': 110, 'max_length': 110, 'max_products': 100, 'lot_count': 60, 'lot_meters': 85, 'roll_count': 60, 'export_roll': 190, 'export_edit': 115}
        for col, header in headers.items():
            self.fabric_tree.heading(col, text=header)
            self.fabric_tree.column(col, width=widths[col], anchor='center')

        fabric_hscroll = ttk.Scrollbar(table_frame, orient='horizontal', command=self.fabric_tree.xview)
        fabric_hscroll.pack(side='bottom', fill='x')
        self.fabric_tree.pack(fill='both', expand=True, side='left')
        scrollbar = ttk.Scrollbar(table_frame, orient='vertical', command=self.fabric_tree.yview)
        scrollbar.pack(side='right', fill='y')
        self.fabric_tree.configure(yscrollcommand=scrollbar.set, xscrollcommand=fabric_hscroll.set)

        # V57: danh sách loại vải tự tăng chiều cao đến 10 dòng; nhiều hơn thì
        # cuộn ngay trong danh sách bằng con lăn/thanh cuộn.
        def _fabric_tree_wheel(event):
            if len(self.fabric_tree.get_children()) <= 10:
                return
            if getattr(event, 'num', None) == 4:
                step = -2
            elif getattr(event, 'num', None) == 5:
                step = 2
            else:
                delta = int(getattr(event, 'delta', 0) or 0)
                if delta == 0:
                    return
                step = -2 if delta > 0 else 2
            self.fabric_tree.yview_scroll(step, 'units')
            return 'break'
        self.fabric_tree.bind('<MouseWheel>', _fabric_tree_wheel)
        self.fabric_tree.bind('<Button-4>', _fabric_tree_wheel)
        self.fabric_tree.bind('<Button-5>', _fabric_tree_wheel)
        self.fabric_tree.bind('<<TreeviewSelect>>', self.on_fabric_selected)
        # V26: PO/LOT có mũi tên xổ xuống; các cột khác vẫn double-click để sửa.
        self.fabric_tree.bind('<Button-1>', self._on_fabric_tree_single_click, add='+')
        self.fabric_tree.bind('<Double-1>', self._on_fabric_tree_double_click)

        btn_frame = tk.Frame(parent)
        btn_frame.pack(fill='x', padx=20, pady=3)
        tk.Button(btn_frame, text="🗑️ Xóa vải được chọn", command=self.delete_fabric,
                 font=('Arial', 10, 'bold'), bg='#e74c3c', fg='white',
                 padx=15, pady=5).pack(side='left')
        tk.Button(btn_frame, text="🧹 Xóa tất cả", command=self.clear_all_fabrics,
                 font=('Arial', 10, 'bold'), bg='#f39c12', fg='white',
                 padx=15, pady=5).pack(side='left', padx=10)
        tk.Label(btn_frame,
                 text='CHẾ ĐỘ GIÁC / PO / LOT: bấm 1 lần vào ô ▼ để chọn lại  •  Xuất PHÂN CÂY: click để chọn CÓ/KHÔNG + PO hiện tên  •  SỬA PHÂN CÂY: click để ☑ / ☐',
                 font=('Arial', 9), fg='#566573').pack(side='left', padx=12)

        # ==================== KHU VỰC LOT VẢI ====================
        lot_frame = tk.LabelFrame(parent, text="LOT vải - nhập số mét cho từng LOT của loại vải đang chọn",
                                  font=('Arial', 11, 'bold'), padx=10, pady=8)
        # V45: khu LOT cũ được giữ cho tương thích nội bộ nhưng ẩn khỏi giao diện.
        # lot_frame không pack; quản lý LOT nằm ở menu riêng.

        lot_input = tk.Frame(lot_frame)
        lot_input.pack(fill='x', pady=(0, 6))

        # LOT duoc luu RIENG cho tung loai vai. Nguoi dung chon ro loai vai
        # ma LOT se ap dung, khong co LOT dung chung cho tat ca cac loai vai.
        tk.Label(lot_input, text="Loại vải áp dụng LOT:", font=('Arial', 10, 'bold')).pack(side='left', padx=(0, 4))
        self.lot_fabric_var = tk.StringVar(value='')
        self.lot_fabric_combo = ttk.Combobox(lot_input, textvariable=self.lot_fabric_var,
                                              state='readonly', width=20, font=('Arial', 10))
        self.lot_fabric_combo.pack(side='left', padx=(0, 10))
        self.lot_fabric_combo.bind('<<ComboboxSelected>>', self.on_lot_fabric_selected)

        self.selected_fabric_var = tk.StringVar(value="Chưa chọn loại vải")

        tk.Label(lot_input, text="Tên LOT:", font=('Arial', 10, 'bold')).pack(side='left', padx=4)
        self.entry_lot_name = tk.Entry(lot_input, width=16, font=('Arial', 10))
        self.entry_lot_name.pack(side='left', padx=4)

        tk.Label(lot_input, text="SL mét vải (có thể để trống):", font=('Arial', 10, 'bold')).pack(side='left', padx=(12, 4))
        self.entry_lot_meters = tk.Entry(lot_input, width=12, font=('Arial', 10))
        self.entry_lot_meters.pack(side='left', padx=4)

        tk.Button(lot_input, text="➕ Thêm LOT", command=self.add_lot,
                  font=('Arial', 10, 'bold'), bg='#2980b9', fg='white', padx=12, pady=4).pack(side='left', padx=10)
        tk.Button(lot_input, text="🗑️ Xóa LOT", command=self.delete_lot,
                  font=('Arial', 10, 'bold'), bg='#c0392b', fg='white', padx=12, pady=4).pack(side='left', padx=4)
        tk.Button(lot_input, text="🧹 Xóa tất cả LOT", command=self.clear_lots,
                  font=('Arial', 10, 'bold'), bg='#d68910', fg='white', padx=12, pady=4).pack(side='left', padx=4)

        lot_table_frame = tk.Frame(lot_frame)
        lot_table_frame.pack(fill='both', expand=True)
        self.lot_tree = ttk.Treeview(lot_table_frame, columns=('lot', 'meters'), show='headings', height=5)
        self.lot_tree.heading('lot', text='Tên LOT')
        self.lot_tree.heading('meters', text='Số mét vải')
        self.lot_tree.column('lot', width=220, anchor='center')
        self.lot_tree.column('meters', width=160, anchor='center')
        self.lot_tree.pack(fill='both', expand=True, side='left')
        lot_scroll = ttk.Scrollbar(lot_table_frame, orient='vertical', command=self.lot_tree.yview)
        lot_scroll.pack(side='right', fill='y')
        self.lot_tree.configure(yscrollcommand=lot_scroll.set)

        guide_frame = tk.LabelFrame(parent, text="💡 Quy tắc LOT",
                                   font=('Arial', 11, 'bold'), padx=12, pady=7)
        # guide_frame cũ cũng ẩn khỏi giao diện V45.
        guide_text = (
            "1️⃣ LOT là RIÊNG cho từng loại vải. Chọn đúng loại vải ở ô 'Loại vải áp dụng LOT' rồi mới thêm LOT.\n"
            "2️⃣ Ví dụ LOT thêm cho VẢI CHÍNH chỉ áp dụng cho VẢI CHÍNH; VẢI LÓT thêm sau không có LOT thì để trống LOT và vẫn tính bình thường.\n"
            "3️⃣ Chương trình ưu tiên LOT theo thứ tự đã nhập. Nếu LOT hiện tại chỉ còn đủ 1–2 lá và việc dùng phần đó sẽ làm tách một bàn, chương trình để phần vải đó DƯ và chuyển sang LOT tiếp theo.\n"
            "4️⃣ Có thể thêm LOT mà chưa nhập số mét. Sau khi xuất Excel, nhập/chỉnh tổng mét LOT ở cột ngoài vùng in; LOT chỉ hiện trong GHI CHÚ khi tổng mét > 0."
        )
        tk.Label(guide_frame, text=guide_text, font=('Arial', 9), justify='left', fg='#555').pack(anchor='w')

        # V44: XUẤT BIỂU CẮT đặt ngay dưới cùng phần LOẠI VẢI, không còn tab Xuất riêng và không có khung xem trước.
        export_frame = tk.LabelFrame(parent, text="Xuất BIỂU CẮT",
                                     font=('Arial', 11, 'bold'), padx=15, pady=12)
        export_frame.pack(fill='x', padx=20, pady=(14, 24))

        # V86: người dùng tự chọn số dòng công thức dư cần chừa cho MỖI LOT.
        # Gợi ý mặc định = 3; có thể đổi 0..20 trước khi xuất để giảm công thức thừa.
        tk.Label(export_frame, text="Dòng dư / LOT (gợi ý 3):", font=('Arial', 10, 'bold')).pack(side='left', padx=(0, 5))
        self.extra_surplus_rows_var = tk.StringVar(value=str(int(getattr(self, 'EXTRA_SURPLUS_ROWS', 0) or 0)))
        self.extra_surplus_rows_spin = tk.Spinbox(
            export_frame, from_=0, to=20, width=4, justify='center',
            textvariable=self.extra_surplus_rows_var, font=('Arial', 10)
        )
        self.extra_surplus_rows_spin.pack(side='left', padx=(0, 10))
        tk.Label(export_frame, text="(thêm dòng có công thức trước khi xuất)",
                 font=('Arial', 8), fg='#566573').pack(side='left', padx=(0, 12))

        # V100: số dòng trống chừa thêm trong mỗi khung bàn của sheet PHÂN CÂY.
        # Khung sẽ lấy số cây thực tế dự kiến của nhóm bàn + số dòng trống này,
        # thay vì luôn chừa rất nhiều dòng theo tổng số cây của cả loại vải.
        tk.Label(export_frame, text="Dòng trống / bàn PHÂN CÂY:",
                 font=('Arial', 10, 'bold')).pack(side='left', padx=(0, 5))
        self.roll_extra_blank_rows_var = tk.StringVar(
            value=str(int(getattr(self, 'ROLL_EXTRA_BLANK_ROWS', 3) or 0))
        )
        self.roll_extra_blank_rows_spin = tk.Spinbox(
            export_frame, from_=0, to=20, width=4, justify='center',
            textvariable=self.roll_extra_blank_rows_var, font=('Arial', 10)
        )
        self.roll_extra_blank_rows_spin.pack(side='left', padx=(0, 12))

        # V111: 3 nút XUẤT / LƯU / MỞ được chuyển xuống thanh cố định ở đáy cửa sổ.
        # Không đặt các nút trong vùng cuộn nữa để khi co/giãn cửa sổ chúng luôn nhìn thấy.
        tk.Label(
            export_frame,
            text="Các nút XUẤT FILE EXCEL / LƯU DỰ ÁN MỚI / MỞ DỰ ÁN được cố định ở thanh dưới cửa sổ.",
            font=('Arial', 9, 'bold'), fg='#566573'
        ).pack(side='left', padx=(8, 0))
        tk.Label(parent,
                 text="Khi xuất Excel, phần mềm tự lưu thêm file .cutplan cùng tên để mở lại và chỉnh sửa sau.",
                 font=('Arial', 9), fg='#566573').pack(anchor='w', padx=22, pady=(0, 8))

    def _get_extra_surplus_rows(self, silent=False):
        """V85: số dòng dư có công thức chừa thêm cho MỖI LOT khi xuất Excel."""
        raw = None
        try:
            raw = self.extra_surplus_rows_var.get() if hasattr(self, 'extra_surplus_rows_var') else self.EXTRA_SURPLUS_ROWS
            value = int(float(str(raw).strip().replace(',', '.')))
        except Exception:
            if silent:
                return max(0, int(getattr(self, 'EXTRA_SURPLUS_ROWS', 0) or 0))
            raise ValueError('Số dòng dư / LOT phải là số nguyên từ 0 đến 20.')
        if value < 0 or value > 20:
            if silent:
                value = min(20, max(0, value))
            else:
                raise ValueError('Số dòng dư / LOT phải từ 0 đến 20.')
        self.EXTRA_SURPLUS_ROWS = int(value)
        try:
            if hasattr(self, 'extra_surplus_rows_var'):
                self.extra_surplus_rows_var.set(str(int(value)))
        except Exception:
            pass
        return int(value)

    def _get_roll_extra_blank_rows(self, silent=False):
        """V100: số dòng trống chừa thêm cho mỗi khung bàn trong sheet PHÂN CÂY."""
        try:
            raw = (self.roll_extra_blank_rows_var.get()
                   if hasattr(self, 'roll_extra_blank_rows_var')
                   else self.ROLL_EXTRA_BLANK_ROWS)
            value = int(float(str(raw).strip().replace(',', '.')))
        except Exception:
            if silent:
                return max(0, int(getattr(self, 'ROLL_EXTRA_BLANK_ROWS', 3) or 0))
            raise ValueError('Số dòng trống / bàn PHÂN CÂY phải là số nguyên từ 0 đến 20.')
        if value < 0 or value > 20:
            if silent:
                value = min(20, max(0, value))
            else:
                raise ValueError('Số dòng trống / bàn PHÂN CÂY phải từ 0 đến 20.')
        self.ROLL_EXTRA_BLANK_ROWS = int(value)
        try:
            if hasattr(self, 'roll_extra_blank_rows_var'):
                self.roll_extra_blank_rows_var.set(str(int(value)))
        except Exception:
            pass
        return int(value)

    def _on_fabric_all_po_toggled(self):
        """Bật TẤT CẢ PO thì khóa các ô chọn PO riêng; tắt thì cho chọn nhiều PO."""
        state = 'disabled' if bool(self.fabric_all_po_var.get()) else 'normal'
        for cb in getattr(self, 'fabric_po_checkbuttons', []):
            try:
                cb.config(state=state)
            except tk.TclError:
                pass

    def _refresh_fabric_po_selector(self):
        """Vẽ lại danh sách PO trong phần chọn PO của LOẠI VẢI."""
        if not hasattr(self, 'fabric_po_checks_frame'):
            return

        old_selected = {
            str(po): bool(var.get())
            for po, var in getattr(self, 'fabric_po_vars', {}).items()
        }
        for widget in self.fabric_po_checks_frame.winfo_children():
            widget.destroy()

        self.fabric_po_vars = {}
        self.fabric_po_checkbuttons = []
        po_names = []
        for po in self.po_list:
            name = str(po.get('po', '')).strip()
            if name and name not in po_names:
                po_names.append(name)

        if not po_names:
            tk.Label(self.fabric_po_checks_frame, text="Chưa có PO - hãy thêm PO trước",
                     font=('Arial', 9), fg='#7f8c8d').pack(side='left', padx=4)
            return

        for name in po_names:
            var = tk.BooleanVar(value=old_selected.get(name, False))
            po_obj = next((x for x in self.po_list if str(x.get('po','')).strip() == name), None)
            color = str((po_obj or {}).get('color', '') or '').strip()
            label = f'{name} - {color}' if color else name
            cb = tk.Checkbutton(self.fabric_po_checks_frame, text=label, variable=var,
                                font=('Arial', 9))
            cb.pack(side='left', padx=4)
            self.fabric_po_vars[name] = var
            self.fabric_po_checkbuttons.append(cb)

        self._on_fabric_all_po_toggled()

    def _on_fabric_no_lot_toggled(self):
        no_lot = bool(getattr(self, 'fabric_no_lot_var', tk.BooleanVar(value=False)).get())
        if no_lot:
            self.fabric_all_lot_var.set(False)
        state = 'disabled' if no_lot else 'normal'
        if hasattr(self, 'fabric_all_lot_check'):
            self.fabric_all_lot_check.config(state=state)
        for cb in getattr(self, 'fabric_lot_checkbuttons', []):
            try: cb.config(state=state)
            except tk.TclError: pass

    def _on_fabric_all_lot_toggled(self):
        if bool(getattr(self, 'fabric_all_lot_var', tk.BooleanVar(value=False)).get()):
            if hasattr(self, 'fabric_no_lot_var'):
                self.fabric_no_lot_var.set(False)
        no_lot = bool(getattr(self, 'fabric_no_lot_var', tk.BooleanVar(value=False)).get())
        state = 'disabled' if no_lot or bool(getattr(self, 'fabric_all_lot_var', tk.BooleanVar(value=False)).get()) else 'normal'
        for cb in getattr(self, 'fabric_lot_checkbuttons', []):
            try: cb.config(state=state)
            except tk.TclError: pass

    def _refresh_fabric_lot_selector(self):
        if not hasattr(self, 'fabric_lot_checks_frame'):
            return
        old = {name: bool(var.get()) for name,var in getattr(self,'fabric_lot_vars',{}).items()}
        for w in self.fabric_lot_checks_frame.winfo_children(): w.destroy()
        self.fabric_lot_vars = {}; self.fabric_lot_checkbuttons = []
        names=[]
        for row in getattr(self,'global_lot_rows',[]) or []:
            name=str(row.get('lot','') or '').strip()
            if name and name not in names: names.append(name)
        if not names:
            tk.Label(self.fabric_lot_checks_frame, text='Chưa có LOT - có thể thêm loại vải chỉ theo PO',
                     font=('Arial',9), fg='#7f8c8d').pack(side='left', padx=4)
            self._on_fabric_no_lot_toggled()
            return
        for name in names:
            var=tk.BooleanVar(value=old.get(name, False))
            cb=tk.Checkbutton(self.fabric_lot_checks_frame, text=name, variable=var, font=('Arial',9),
                              command=lambda: getattr(self, 'fabric_no_lot_var', tk.BooleanVar(value=False)).set(False))
            cb.pack(side='left', padx=4)
            self.fabric_lot_vars[name]=var; self.fabric_lot_checkbuttons.append(cb)
        self._on_fabric_no_lot_toggled()
        self._on_fabric_all_lot_toggled()

    def _get_fabric_lot_selection(self):
        if bool(getattr(self,'fabric_no_lot_var',tk.BooleanVar(value=False)).get()):
            return 'none', []
        if bool(getattr(self,'fabric_all_lot_var',tk.BooleanVar(value=False)).get()):
            return 'all', []
        selected=[name for name,var in getattr(self,'fabric_lot_vars',{}).items() if bool(var.get())]
        # Không chọn LOT cũng hợp lệ: loại vải chỉ lấy sản lượng PO.
        return ('selected', selected) if selected else ('none', [])

    def _fabric_lot_names(self, fabric):
        mode=str(fabric.get('lot_mode','none') or 'none').lower()
        if mode == 'none':
            return []
        if mode == 'all':
            return [str(r.get('lot','')).strip() for r in getattr(self,'global_lot_rows',[]) or [] if str(r.get('lot','')).strip()]
        return [str(x).strip() for x in (fabric.get('lot_targets',[]) or []) if str(x).strip()]

    def _fabric_lot_display(self, fabric):
        mode=str(fabric.get('lot_mode','none') or 'none').lower()
        if mode == 'none':
            return 'KHÔNG DÙNG LOT'
        if mode == 'all':
            return 'TẤT CẢ LOT'
        names=self._fabric_lot_names(fabric)
        return ', '.join(names) if names else 'KHÔNG DÙNG LOT'

    def _get_fabric_po_selection(self):
        """Trả về ('all', []) hoặc ('selected', [PO...]) từ giao diện thêm vải."""
        if bool(getattr(self, 'fabric_all_po_var', tk.BooleanVar(value=True)).get()):
            return 'all', []
        selected = [name for name, var in getattr(self, 'fabric_po_vars', {}).items() if bool(var.get())]
        return 'selected', selected

    def _fabric_po_names(self, fabric):
        """Danh sách tên PO thực tế áp dụng cho một loại vải."""
        mode = str(fabric.get('po_mode', 'all') or 'all').lower()
        if mode == 'all':
            return [str(po.get('po', '')).strip() for po in self.po_list if str(po.get('po', '')).strip()]
        selected = [str(x).strip() for x in (fabric.get('po_targets', []) or []) if str(x).strip()]
        return selected

    def _fabric_po_display(self, fabric):
        if str(fabric.get('po_mode', 'all') or 'all').lower() == 'all':
            return 'TẤT CẢ PO'
        names = self._fabric_po_names(fabric)
        return ', '.join(names) if names else '(CHƯA CHỌN PO)'

    def _po_color_text(self, po_name):
        """Trả về màu của một PO; PO cũ chưa có màu thì trả chuỗi rỗng."""
        name = str(po_name or '').strip()
        po = next((x for x in self.po_list if str(x.get('po','')).strip() == name), None)
        return str((po or {}).get('color', '') or '').strip()

    def _fabric_po_color_lines(self, fabric):
        """Mỗi PO - MÀU một dòng để ghi trong ô LOẠI VẢI khi xuất Excel."""
        lines = []
        for po_name in self._fabric_po_names(fabric):
            color = self._po_color_text(po_name)
            lines.append(f'PO: {po_name} - MÀU: {color}' if color else f'PO: {po_name}')
        return lines

    def _fabric_po_color_display(self, fabric):
        lines = self._fabric_po_color_lines(fabric)
        return ' | '.join(lines) if lines else self._fabric_po_display(fabric)

    def _fabric_total_by_size(self, fabric):
        """Tổng sản lượng theo cỡ chỉ từ các PO mà loại vải được phép áp dụng."""
        size_keys = [item['key'] for item in self.sizes]
        totals = {key: 0 for key in size_keys}
        mode = str(fabric.get('po_mode', 'all') or 'all').lower()
        selected = set(self._fabric_po_names(fabric)) if mode != 'all' else None
        for po in self.po_list:
            po_name = str(po.get('po', '')).strip()
            if selected is not None and po_name not in selected:
                continue
            for key in size_keys:
                totals[key] += int(po.get(key, 0) or 0)
        return totals

    def _fabric_planned_total_by_size(self, fabric):
        """V62: kế hoạch theo từng PO, làm tròn tăng riêng từng cỡ rồi mới cộng."""
        size_keys = [item['key'] for item in self.sizes]
        totals = {key: 0 for key in size_keys}
        mode = str(fabric.get('po_mode', 'all') or 'all').lower()
        selected = set(self._fabric_po_names(fabric)) if mode != 'all' else None
        for po in self.po_list:
            po_name = str(po.get('po', '')).strip()
            if selected is not None and po_name not in selected:
                continue
            for key in size_keys:
                totals[key] += self._planned_po_qty(po, key)
        return totals

    def create_export_tab(self, parent):
        preview_frame = tk.Frame(parent, padx=20, pady=20)
        preview_frame.pack(fill='x')

        tk.Button(preview_frame, text="👁️ Xem trước tính toán", command=self.preview_calculation,
                 font=('Arial', 11, 'bold'), bg='#3498db', fg='white',
                 padx=20, pady=8).pack(side='left')

        self.preview_text = tk.Text(parent, height=20, font=('Courier New', 10),
                                   bg='white', relief='sunken', bd=2)
        self.preview_text.pack(fill='both', expand=True, padx=20, pady=10)

        export_frame = tk.Frame(parent, padx=20, pady=20)
        export_frame.pack(fill='x')

        tk.Button(export_frame, text="📤 XUẤT FILE EXCEL", command=self.export_excel,
                 font=('Arial', 14, 'bold'), bg='#27ae60', fg='white',
                 padx=30, pady=12).pack(side='left')

        tk.Button(export_frame, text="💾 LƯU DỰ ÁN", command=self.save_project_manual,
                 font=('Arial', 11, 'bold'), bg='#8e44ad', fg='white',
                 padx=18, pady=10).pack(side='left', padx=(12, 4))
        tk.Button(export_frame, text="📂 MỞ DỰ ÁN", command=self.load_project,
                 font=('Arial', 11, 'bold'), bg='#2471a3', fg='white',
                 padx=18, pady=10).pack(side='left', padx=4)

        self.export_status = tk.Label(export_frame, text="", font=('Arial', 10), fg='#27ae60')
        self.export_status.pack(side='left', padx=20)

        tk.Label(parent,
                 text="V36: mỗi lần xuất Excel sẽ tự tạo thêm file .cutplan cùng tên. "
                      "Lần sau mở .cutplan để nạp lại PO, cỡ, loại vải, LOT/cây và toàn bộ thông tin đơn hàng.",
                 font=('Arial', 9), fg='#566573').pack(anchor='w', padx=22, pady=(0, 8))

    # ==================== HÀM XỬ LÝ LOẠI VẢI + LOT ====================
    def _selected_fabric_index(self):
        """Index loại vải đang chọn trong bảng danh sách loại vải."""
        selected = self.fabric_tree.selection() if hasattr(self, 'fabric_tree') else ()
        if not selected:
            return None
        idx = self.fabric_tree.index(selected[0])
        return idx if 0 <= idx < len(self.fabric_list) else None

    def _lot_target_fabric_index(self):
        """Index loại vải mà khu vực LOT đang áp dụng.

        Dùng combobox riêng để LOT không thể vô tình dùng chung cho nhiều loại vải.
        """
        if hasattr(self, 'lot_fabric_combo'):
            idx = self.lot_fabric_combo.current()
            if 0 <= idx < len(self.fabric_list):
                return idx
        return None

    def _refresh_lot_fabric_combo(self, select_index=None):
        if not hasattr(self, 'lot_fabric_combo'):
            return
        values = [f"{i+1}. {fabric['name']}" for i, fabric in enumerate(self.fabric_list)]
        self.lot_fabric_combo['values'] = values

        if not values:
            self.lot_fabric_var.set('')
            self.lot_fabric_combo.set('')
            self.selected_fabric_var.set("Chưa chọn loại vải")
            return

        if select_index is not None and 0 <= select_index < len(values):
            self.lot_fabric_combo.current(select_index)
            self.selected_fabric_var.set(f"Loại vải: {self.fabric_list[select_index]['name']}")
        else:
            cur = self.lot_fabric_combo.current()
            if cur < 0 or cur >= len(values):
                self.lot_fabric_combo.set('')
                self.selected_fabric_var.set("Chưa chọn loại vải")

    def on_lot_fabric_selected(self, event=None):
        """Chọn loại vải đích cho LOT; đồng bộ lựa chọn ở bảng loại vải."""
        idx = self._lot_target_fabric_index()
        if idx is None:
            self.selected_fabric_var.set("Chưa chọn loại vải")
            self.refresh_lot_table()
            return

        self.selected_fabric_var.set(f"Loại vải: {self.fabric_list[idx]['name']}")
        if hasattr(self, 'fabric_tree'):
            children = self.fabric_tree.get_children()
            if idx < len(children):
                item = children[idx]
                self.fabric_tree.selection_set(item)
                self.fabric_tree.focus(item)
                self.fabric_tree.see(item)
        self.refresh_lot_table()

    def on_fabric_selected(self, event=None):
        idx = self._selected_fabric_index()
        if idx is None:
            self.selected_fabric_var.set("Chưa chọn loại vải")
            if hasattr(self, 'lot_fabric_combo'):
                self.lot_fabric_combo.set('')
        else:
            # Khi chọn loại vải ở bảng, khu vực LOT chuyển đúng sang loại vải đó.
            self._refresh_lot_fabric_combo(select_index=idx)
            self.selected_fabric_var.set(f"Loại vải: {self.fabric_list[idx]['name']}")
            try:
                self._show_fabric_dashboard(idx)
            except Exception:
                pass
        self.refresh_lot_table()

    def add_fabric(self):
        try:
            name = self.entry_fabric_name.get().strip()
            if not name:
                messagebox.showwarning("Cảnh báo", "Vui lòng nhập tên loại vải!")
                return

            norm_text = self.entry_fabric_norm.get().strip().replace(',', '.')
            min_text = self.entry_fabric_minlen.get().strip().replace(',', '.') if hasattr(self, 'entry_fabric_minlen') else '1'
            max_text = self.entry_fabric_maxlen.get().strip().replace(',', '.')
            max_sp_text = self.entry_fabric_max_products.get().strip().replace(',', '.') if hasattr(self, 'entry_fabric_max_products') else ''
            if not norm_text:
                messagebox.showwarning("Cảnh báo", "Vui lòng nhập định mức trung bình!")
                return
            norm = float(norm_text)
            min_length = float(min_text) if min_text else 1.0
            max_length = float(max_text) if max_text else 0.0
            max_products = int(float(max_sp_text)) if max_sp_text else 0
            if norm <= 0:
                messagebox.showwarning("Cảnh báo", "Định mức phải lớn hơn 0!")
                return
            if max_length <= 0 and max_products <= 0:
                messagebox.showwarning("Cảnh báo", "Chỉ cần nhập CHIỀU DÀI TỐI ĐA hoặc SP TỐI ĐA / 1 SƠ ĐỒ (ít nhất một mục phải > 0).")
                return
            if min_length < 0 or max_length < 0 or max_products < 0:
                messagebox.showwarning("Cảnh báo", "Giới hạn không được nhỏ hơn 0!")
                return
            if max_length > 0 and min_length > max_length + 1e-9:
                messagebox.showwarning("Cảnh báo", "CHIỀU DÀI TỐI THIỂU không được lớn hơn CHIỀU DÀI TỐI ĐA!")
                return

            # V40: mỗi loại vải chọn PO áp dụng riêng; PO vẫn nhập ở tab PO như cũ.
            po_mode, po_targets = self._get_fabric_po_selection()
            if po_mode == 'selected' and not po_targets:
                messagebox.showwarning("Cảnh báo", "Hãy chọn ít nhất 1 PO cho loại vải hoặc chọn TẤT CẢ PO!")
                return

            lot_mode, lot_targets = self._get_fabric_lot_selection()
            # V47: LOT là tùy chọn. Loại vải có thể chỉ lấy số lượng PO mà không dùng LOT.

            cut_mode = self._fabric_mode_key_from_label(
                self.fabric_mode_var.get() if hasattr(self, 'fabric_mode_var') else 'TỰ ĐỘNG'
            )

            self.fabric_list.append({
                'name': name,
                'cut_mode': cut_mode,
                'optimizer_mode': 'global',
                'norm': norm,
                'min_length': min_length,
                'max_length': max_length,
                'max_products': max_products,
                'balance_pct': 1.0,
                # V163: đầu tấm mặc định 1 m / chừa 1 lá.
                'reserve_m': 1.0,
                'reserve_plies': 1,
                'po_mode': po_mode,
                'po_targets': list(po_targets),
                'lot_mode': lot_mode,
                'lot_targets': list(lot_targets),
                'export_roll': bool(getattr(self, 'fabric_export_roll_var', tk.BooleanVar(value=True)).get()),
                # V98: mặc định chưa chốt lựa chọn PO hiển thị -> khi mở popup sẽ tích toàn bộ PO áp dụng.
                'roll_po_targets': [], 'roll_po_selection_set': False,
                'export_edit': bool(getattr(self, 'fabric_export_edit_var', tk.BooleanVar(value=True)).get()),
                'lots': [],
                'rolls': [],
                'shades': []
            })

            new_idx = len(self.fabric_list) - 1
            self.update_fabric_table(select_index=new_idx)
            self.entry_fabric_name.delete(0, tk.END)
            self.entry_fabric_name.insert(0, 'VẢI LÓT')
            self.entry_fabric_norm.delete(0, tk.END)
            if hasattr(self, 'entry_fabric_minlen'):
                self.entry_fabric_minlen.delete(0, tk.END)
                self.entry_fabric_minlen.insert(0, '1')
            self.entry_fabric_maxlen.delete(0, tk.END)
            if hasattr(self, 'entry_fabric_max_products'):
                self.entry_fabric_max_products.delete(0, tk.END)
            if hasattr(self, 'fabric_mode_var'):
                self.fabric_mode_var.set('TỰ ĐỘNG')
            if hasattr(self, 'fabric_export_roll_var'):
                self.fabric_export_roll_var.set(True)
            if hasattr(self, 'fabric_export_edit_var'):
                self.fabric_export_edit_var.set(True)
            self._sync_global_lots()
            po_text = self._fabric_po_display(self.fabric_list[new_idx])
            lot_text = self._fabric_lot_display(self.fabric_list[new_idx])
            self.status_var.set(f"Đã thêm loại vải: {name} | PO: {po_text} | {lot_text}")

        except ValueError:
            messagebox.showerror("Lỗi", "Định mức, chiều dài tối thiểu/tối đa và SP tối đa phải là số!")

    def delete_fabric(self):
        selected = self.fabric_tree.selection()
        if not selected:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn loại vải cần xóa!")
            return

        indices = sorted({self.fabric_tree.index(item) for item in selected}, reverse=True)
        for idx in indices:
            if 0 <= idx < len(self.fabric_list):
                del self.fabric_list[idx]

        self._sync_global_lots()
        self.update_fabric_table()
        self.selected_fabric_var.set("Chưa chọn loại vải")
        self.refresh_lot_table()
        self.status_var.set("Đã xóa loại vải được chọn")

    def clear_all_fabrics(self):
        if messagebox.askyesno("Xác nhận", "Bạn có chắc muốn xóa tất cả loại vải?"):
            self.fabric_list.clear()
            self.update_fabric_table()
            self.selected_fabric_var.set("Chưa chọn loại vải")
            self.refresh_lot_table()
            self.status_var.set("Đã xóa tất cả loại vải")

    def update_fabric_table(self, select_index=None):
        if not hasattr(self, 'fabric_tree'):
            return
        for item in self.fabric_tree.get_children():
            self.fabric_tree.delete(item)

        for fabric in self.fabric_list:
            # V57: cùng một LOT có thể cấp các cây khác nhau cho nhiều loại vải;
            # tổng mét hiển thị ở đây chỉ là phần mét thực sự đã phân cho loại vải này.
            lots = fabric.get('lots', []) or []
            total_meters = sum(float(lot.get('meters', 0)) for lot in lots)
            min_len = max(0.0, float(fabric.get('min_length', 1.0) or 0))
            max_len = float(fabric.get('max_length', 0) or 0)
            max_sp = int(fabric.get('max_products', 0) or 0)
            self.fabric_tree.insert('', 'end', values=(
                fabric['name'], '▼  ' + self._fabric_mode_display(fabric),
                '▼  ' + self.OPTIMIZER_LABELS.get(self._optimizer_mode_key_from_label(fabric.get('optimizer_mode','global')), 'TOÀN CỤC'),
                self._fabric_po_display(fabric) + '  ▼', self._fabric_lot_display(fabric) + '  ▼',
                f"{float(fabric.get('norm',0) or 0):.2f}", f"{min_len:.2f}", (f"{max_len:.2f}" if max_len > 0 else ''),
                (str(max_sp) if max_sp > 0 else ''),
                len(lots), f"{total_meters:.2f}", len(fabric.get('rolls', []) or []),
                (('☑ CÓ: ' + ' + '.join(self._fabric_roll_po_names(fabric))) if bool(fabric.get('export_roll', True)) else '☐ KHÔNG'),
                ('☑ CÓ' if bool(fabric.get('export_edit', True)) else '☐ KHÔNG')
            ))

        # Tự mở rộng 4 -> 10 dòng. Từ dòng 11 trở đi giữ chiều cao 10 và dùng scrollbar.
        try:
            self.fabric_tree.configure(height=min(10, max(4, len(self.fabric_list))))
        except Exception:
            pass

        self._refresh_lot_fabric_combo(select_index=select_index)
        try:
            self._refresh_fabric_dashboard_list(select_index=select_index)
        except Exception:
            pass

        if select_index is not None and 0 <= select_index < len(self.fabric_list):
            children = self.fabric_tree.get_children()
            if select_index < len(children):
                item = children[select_index]
                self.fabric_tree.selection_set(item)
                self.fabric_tree.focus(item)
                self.fabric_tree.see(item)
                self.on_fabric_selected()
        else:
            self.refresh_lot_table()

    def toggle_selected_fabric_roll_export(self):
        """Bật/tắt việc xuất loại vải đang chọn sang sheet PHÂN CÂY."""
        idx = self._selected_fabric_index()
        if idx is None:
            messagebox.showwarning('Cảnh báo', 'Hãy chọn loại vải cần bật/tắt PHÂN CÂY!')
            return
        fabric = self.fabric_list[idx]
        fabric['export_roll'] = not bool(fabric.get('export_roll', True))
        self.update_fabric_table(select_index=idx)
        self.status_var.set(
            f"{fabric.get('name','')}: " + ('SẼ xuất PHÂN CÂY' if fabric['export_roll'] else 'KHÔNG xuất PHÂN CÂY')
        )

    def toggle_selected_fabric_edit_export(self):
        """Bật/tắt việc xuất loại vải đang chọn sang sheet SỬA PHÂN CÂY."""
        idx = self._selected_fabric_index()
        if idx is None:
            messagebox.showwarning('Cảnh báo', 'Hãy chọn loại vải cần bật/tắt SỬA PHÂN CÂY!')
            return
        fabric = self.fabric_list[idx]
        fabric['export_edit'] = not bool(fabric.get('export_edit', True))
        self.update_fabric_table(select_index=idx)
        self.status_var.set(
            f"{fabric.get('name','')}: " + ('SẼ xuất SỬA PHÂN CÂY' if fabric['export_edit'] else 'KHÔNG xuất SỬA PHÂN CÂY')
        )

    def refresh_lot_table(self):
        if not hasattr(self, 'lot_tree'):
            return
        for item in self.lot_tree.get_children():
            self.lot_tree.delete(item)
        idx = self._lot_target_fabric_index()
        if idx is None:
            return
        for lot in self.fabric_list[idx].get('lots', []) or []:
            try:
                meters = float(lot.get('meters', 0) or 0)
            except (TypeError, ValueError):
                meters = 0.0
            meters_text = f"{meters:.2f}" if meters > 0 else ''
            self.lot_tree.insert('', 'end', values=(lot.get('name', ''), meters_text))

    def add_lot(self):
        # LOT chỉ được thêm vào đúng loại vải đang chọn trong combobox LOT.
        idx = self._lot_target_fabric_index()
        if idx is None:
            messagebox.showwarning("Cảnh báo", "Hãy chọn 'Loại vải áp dụng LOT' trước khi thêm LOT!")
            return
        name = self.entry_lot_name.get().strip()
        if not name:
            messagebox.showwarning("Cảnh báo", "Vui lòng nhập tên LOT!")
            return
        meters_text = self.entry_lot_meters.get().strip().replace(',', '.')
        if meters_text:
            try:
                meters = float(meters_text)
            except ValueError:
                messagebox.showerror("Lỗi", "Số mét vải phải là số hoặc để trống!")
                return
            if meters < 0:
                messagebox.showwarning("Cảnh báo", "Số mét vải không được âm!")
                return
        else:
            meters = 0.0

        fabric = self.fabric_list[idx]
        # setdefault ở chính fabric, tuyệt đối không copy sang fabric khác.
        fabric.setdefault('lots', []).append({'name': name, 'meters': meters})
        self.entry_lot_name.delete(0, tk.END)
        self.entry_lot_meters.delete(0, tk.END)
        self.update_fabric_table(select_index=idx)
        if meters > 0:
            self.status_var.set(f"Đã thêm LOT {name}: {meters:.2f} m CHỈ cho {fabric['name']}")
        else:
            self.status_var.set(f"Đã thêm LOT {name} cho {fabric['name']} | chưa nhập số mét")

    def delete_lot(self):
        fidx = self._lot_target_fabric_index()
        if fidx is None:
            messagebox.showwarning("Cảnh báo", "Hãy chọn loại vải áp dụng LOT!")
            return
        selected = self.lot_tree.selection()
        if not selected:
            messagebox.showwarning("Cảnh báo", "Hãy chọn LOT cần xóa!")
            return
        indices = sorted({self.lot_tree.index(item) for item in selected}, reverse=True)
        lots = self.fabric_list[fidx].setdefault('lots', [])
        for idx in indices:
            if 0 <= idx < len(lots):
                del lots[idx]
        self.update_fabric_table(select_index=fidx)
        self.status_var.set(f"Đã xóa LOT của {self.fabric_list[fidx]['name']}")

    def clear_lots(self):
        fidx = self._lot_target_fabric_index()
        if fidx is None:
            messagebox.showwarning("Cảnh báo", "Hãy chọn loại vải áp dụng LOT!")
            return
        fabric = self.fabric_list[fidx]
        if messagebox.askyesno("Xác nhận", f"Xóa tất cả LOT CHỈ của {fabric['name']}?"):
            fabric['lots'] = []
            self.update_fabric_table(select_index=fidx)
            self.status_var.set(f"Đã xóa tất cả LOT của {fabric['name']}")

    # ==================== CÂY / LOT VẢI - V43 ====================
    def _po_qty_for_fabric(self, fabric):
        """Trả về [(PO, số lượng)] đúng các PO mà loại vải đang áp dụng."""
        mode = str(fabric.get('po_mode', 'all') or 'all').lower()
        allowed = set(self._fabric_po_names(fabric)) if mode != 'all' else None
        result = []
        for po in self.po_list:
            po_name = str(po.get('po', '') or '').strip()
            if not po_name:
                continue
            if allowed is not None and po_name not in allowed:
                continue
            qty = sum(int(po.get(size['key'], 0) or 0) for size in self.sizes)
            if qty > 0:
                result.append((po_name, qty))
        return result

    def _global_lot_row_scope_text(self, row):
        fabrics = row.get('fabric_names', []) or []
        pos = row.get('po_names', []) or []
        ftxt = 'TẤT CẢ' if row.get('fabric_mode', 'all') == 'all' else ', '.join(fabrics)
        ptxt = 'TẤT CẢ' if row.get('po_mode', 'all') == 'all' else ', '.join(pos)
        return ftxt, ptxt

    def _global_lot_targets(self, row):
        """Danh sách loại vải được phép dùng LOT này.

        V57: một LOT có thể cấp cho NHIỀU loại vải. Phạm vi trong QUẢN LÝ
        CÂY/LOT và lựa chọn LOT ở từng loại vải được giao nhau để xác định
        các loại vải hợp lệ.
        """
        lot_name = str(row.get('lot','') or '').strip()
        row_mode = str(row.get('fabric_mode','all') or 'all').lower()
        row_names = {str(x).strip().lower() for x in (row.get('fabric_names',[]) or []) if str(x).strip()}
        targets=[]
        for fidx, fabric in enumerate(self.fabric_list):
            fname = str(fabric.get('name','') or '').strip()
            if row_mode == 'selected' and fname.lower() not in row_names:
                continue
            mode=str(fabric.get('lot_mode','none') or 'none').lower()
            if mode == 'none':
                continue
            allowed={str(x).strip().lower() for x in (fabric.get('lot_targets',[]) or []) if str(x).strip()}
            if mode != 'all' and lot_name.lower() not in allowed:
                continue
            po_items=self._po_qty_for_fabric(fabric)
            total_qty=sum(q for _,q in po_items)
            if total_qty <= 0:
                continue
            demand=float(fabric.get('norm',1.0) or 1.0) * total_qty
            targets.append((fidx, po_items, demand))
        return targets

    def _choose_one_fabric_for_lot(self, row, targets, remaining_need, assigned_count=None):
        """Chọn đúng 1 loại vải cho toàn bộ LOT.

        V65:
        - LOT không bao giờ bị xé cho nhiều loại vải.
        - Trước tiên cố gắng cho mỗi loại vải còn nhu cầu nhận ít nhất 1 LOT.
        - Sau đó chọn LOT gần với số mét còn thiếu nhất.
        - Khi tất cả loại vải phù hợp đã đủ mét thì LOT còn lại để CHƯA GÁN.
        """
        if not targets:
            return None
        assigned_count = assigned_count or {}
        manual=row.get('manual_fabric_index', None)
        if manual is not None:
            try: manual=int(manual)
            except Exception: manual=None
            if manual is not None and any(fidx==manual for fidx,_,_ in targets):
                return manual
        try: lot_m=max(0.0,float(row.get('meters',0) or 0))
        except Exception: lot_m=0.0

        candidates=[]
        for fidx, po_items, demand in targets:
            need=max(0.0,float(remaining_need.get(fidx,demand)))
            if need <= 1e-9:
                continue
            # Ưu tiên loại vải chưa có LOT trước, sau đó ưu tiên LOT không vượt nhu cầu
            # và khoảng cách mét gần nhất.
            first_penalty = 0 if int(assigned_count.get(fidx,0) or 0) == 0 else 1
            overshoot_penalty = 0 if lot_m <= need + 1e-9 else 1
            score=(first_penalty, overshoot_penalty, abs(need-lot_m), -need, fidx)
            candidates.append((score,fidx))
        if not candidates:
            return None
        candidates.sort(key=lambda x:x[0])
        return candidates[0][1]

    @staticmethod
    def _split_integer_by_weights(total, weighted_keys):
        total=max(0,int(total or 0))
        if total <= 0 or not weighted_keys:
            return {k:0 for k,_ in weighted_keys}
        sw=sum(max(0.0,float(w)) for _,w in weighted_keys)
        if sw <= 0:
            result={k:0 for k,_ in weighted_keys}
            for i in range(total): result[weighted_keys[i % len(weighted_keys)][0]] += 1
            return result
        raw=[(k,total*max(0.0,float(w))/sw) for k,w in weighted_keys]
        result={k:int(v) for k,v in raw}
        left=total-sum(result.values())
        order=sorted(raw,key=lambda kv:(kv[1]-int(kv[1])),reverse=True)
        for i in range(left): result[order[i % len(order)][0]] += 1
        return result

    def _sync_global_lots(self):
        """V58: đồng bộ LOT dùng chung theo CÂY.

        - Một LOT có thể cấp cho nhiều loại vải.
        - Mỗi CÂY tự động chỉ thuộc đúng 1 loại vải tại một thời điểm; không tự xé
          cùng một cây cho nhiều loại vải.
        - Chương trình chỉ lấy các cây cần thiết theo số mét còn thiếu. Khi tất cả
          loại vải đã đủ, LOT/cây còn lại giữ CHƯA GÁN để người dùng điều chỉnh sau.
        - Sau khi xuất Excel, nếu muốn CHUYỂN ĐẦU TẤM thủ công sang loại vải khác,
          người dùng có thể nhập lại cùng LOT + SỐ CÂY ở một dòng khác với số mét
          đầu tấm. Dòng gốc sẽ tự trừ số mét đã chuyển, tránh nhân đôi tồn vải.
        """
        for fabric in self.fabric_list:
            fabric['lots']=[lot for lot in (fabric.get('lots',[]) or [])
                            if not lot.get('auto_global_lot') and not lot.get('auto_roll_lot') and not lot.get('auto_shade_lot')]
            fabric['rolls']=[r for r in (fabric.get('rolls',[]) or []) if not r.get('auto_global_roll')]

        remaining_need={}
        for fidx,fabric in enumerate(self.fabric_list):
            po_items=self._po_qty_for_fabric(fabric)
            qty=sum(q for _,q in po_items)
            remaining_need[fidx]=max(0.0,float(fabric.get('norm',1.0) or 1.0)*qty)

        for row_index,row in enumerate(getattr(self,'global_lot_rows',[]) or []):
            self._ensure_lot_roll_details(row)
            self._recalc_lot_from_roll_details(row)
            lot_name=str(row.get('lot','') or '').strip()
            lot_mark=str(row.get('lot_mark','') or '').strip()
            if not lot_name:
                continue

            row['assigned_fabric_name']=''
            row['assigned_fabric_index']=None
            row['display_fabric_name']=''
            row['display_fabric_index']=None
            row['assigned_rolls_by_fabric']={}

            targets=self._global_lot_targets(row)
            if not targets:
                continue
            target_ids=[fidx for fidx,_,_ in targets]

            # Nếu người dùng từng gán thủ công 1 loại vải thì giữ ưu tiên đó.
            manual=row.get('manual_fabric_index', None)
            try:
                manual=int(manual) if manual is not None else None
            except Exception:
                manual=None
            if manual not in target_ids:
                manual=None

            details = self._ensure_lot_roll_details(row)
            per_fabric_rolls={fidx:[] for fidx in target_ids}
            per_fabric_meters={fidx:0.0 for fidx in target_ids}
            per_lot_count={fidx:0 for fidx in target_ids}

            # V57: chia theo từng cây. Ưu tiên loại vải chưa nhận cây nào từ LOT này,
            # sau đó chọn loại còn thiếu sao cho cây hiện tại khớp nhu cầu nhất.
            for j,d in enumerate(details):
                try:
                    length=max(0.0,float(d.get('meters',0) or 0))
                except Exception:
                    length=0.0
                if length <= 0:
                    continue
                roll_name=str(d.get('roll','') or (j+1))
                mark=str(d.get('lot_mark',lot_mark) or '')

                if manual is not None and remaining_need.get(manual,0.0) > 1e-9:
                    chosen=manual
                else:
                    cand=[]
                    for fidx in target_ids:
                        need=max(0.0,float(remaining_need.get(fidx,0.0)))
                        if need <= 1e-9:
                            continue
                        first_penalty = 0 if per_lot_count.get(fidx,0) == 0 else 1
                        overshoot_penalty = 0 if length <= need + 1e-9 else 1
                        cand.append(((first_penalty, overshoot_penalty, abs(need-length), -need, fidx), fidx))
                    if not cand:
                        # Tất cả loại vải đã đủ: cây còn lại giữ CHƯA DÙNG / chưa gán.
                        continue
                    cand.sort(key=lambda x:x[0])
                    chosen=cand[0][1]

                per_fabric_rolls[chosen].append({
                    'roll':roll_name, 'lot':lot_name, 'lot_mark':mark, 'shade':mark,
                    'length':length, 'auto_global_roll':True, 'global_row':row_index,
                    'source_roll_no':j+1, 'source_total_length':length
                })
                per_fabric_meters[chosen]+=length
                per_lot_count[chosen]+=1
                remaining_need[chosen]=max(0.0,float(remaining_need.get(chosen,0.0))-length)

            used_names=[]
            for fidx in target_ids:
                meters=per_fabric_meters.get(fidx,0.0)
                rolls=per_fabric_rolls.get(fidx,[])
                if meters <= 0 and not rolls:
                    continue
                fabric=self.fabric_list[fidx]
                fname=str(fabric.get('name','') or '')
                used_names.append(fname)
                fabric.setdefault('lots',[]).append({
                    'name':lot_name, 'meters':meters, 'auto_global_lot':True,
                    'source_lot':lot_name, 'global_row':row_index, 'lot_mark':lot_mark,
                    'roll_count_source':len(rolls), 'shared_lot':len(target_ids)>1
                })
                fabric.setdefault('rolls',[]).extend(rolls)
                # V93: lưu khóa cây theo SỐ CÂY + LOT GHI TRÊN CÂY để không gộp
                # hai cây trùng số nhưng khác nhãn/lot ghi trên cây.
                row['assigned_rolls_by_fabric'][fname]=[
                    f"{str(r.get('roll','') or '').strip()}||{str(r.get('lot_mark','') or '').strip()}"
                    for r in rolls
                ]

            if used_names:
                row['assigned_fabric_name']=' + '.join(used_names)
                row['display_fabric_name']=row['assigned_fabric_name']
                if len(used_names)==1:
                    only=used_names[0]
                    try:
                        idx=next(i for i,f in enumerate(self.fabric_list) if str(f.get('name','') or '')==only)
                    except StopIteration:
                        idx=None
                    row['assigned_fabric_index']=idx
                    row['display_fabric_index']=idx

    def _sync_roll_lots(self, fabric):
        """Tên hàm cũ được giữ để các phần khác của chương trình vẫn tương thích."""
        if getattr(self, 'global_lot_rows', None):
            self._sync_global_lots()
            return [lot for lot in (fabric.get('lots', []) or []) if lot.get('auto_global_lot')]

        # Tương thích dữ liệu cây cũ nếu chưa dùng kho LOT V43.
        manual_lots = [
            lot for lot in (fabric.get('lots', []) or [])
            if not lot.get('auto_roll_lot') and not lot.get('auto_shade_lot')
        ]
        grouped = {}
        order = []
        for r in fabric.get('rolls', []) or []:
            lot_name = str(r.get('lot', r.get('shade', '')) or '').strip()
            try:
                length = float(r.get('length', 0) or 0)
            except (TypeError, ValueError):
                length = 0.0
            if lot_name and length > 0:
                if lot_name not in grouped:
                    grouped[lot_name] = 0.0
                    order.append(lot_name)
                grouped[lot_name] += length
        po_items = self._po_qty_for_fabric(fabric)
        total_qty = sum(q for _, q in po_items)
        auto_lots = []
        for lot_name in order:
            total_m = grouped[lot_name]
            allocated = 0.0
            for i, (po_name, qty) in enumerate(po_items):
                meters = round(total_m - allocated, 2) if i == len(po_items)-1 else round(total_m*qty/total_qty, 2)
                if i != len(po_items)-1:
                    allocated += meters
                auto_lots.append({'name': f'{lot_name} - {po_name}', 'meters': meters,
                                  'auto_roll_lot': True, 'source_lot': lot_name, 'po': po_name})
        fabric['lots'] = manual_lots + auto_lots
        return auto_lots

    def _sync_shade_lots(self, fabric):
        return self._sync_roll_lots(fabric)

    def _sync_all_shade_lots(self):
        if getattr(self, 'global_lot_rows', None):
            self._sync_global_lots()
            return
        for fabric in self.fabric_list:
            if fabric.get('rolls'):
                self._sync_roll_lots(fabric)
            else:
                fabric['lots'] = [
                    lot for lot in (fabric.get('lots', []) or [])
                    if not lot.get('auto_roll_lot') and not lot.get('auto_shade_lot')
                ]

    def open_roll_manager(self):
        """Bảng kiểu Excel: LOT | SỐ CÂY | SỐ MÉT + phạm vi LOẠI VẢI / PO."""
        if not self.fabric_list:
            messagebox.showwarning('Cảnh báo', 'Hãy thêm LOẠI VẢI trước!')
            return
        if not self.po_list:
            messagebox.showwarning('Cảnh báo', 'Hãy thêm PO trước!')
            return

        win = tk.Toplevel(self.root)
        win.title('QUẢN LÝ LOT / CÂY - DÁN NHƯ EXCEL')
        win.geometry('1250x860')
        win.transient(self.root)

        # ===== PHẠM VI ÁP DỤNG =====
        scope = tk.LabelFrame(win, text='LOT ÁP DỤNG CHO LOẠI VẢI / PO NÀO',
                              font=('Arial', 10, 'bold'), padx=10, pady=8)
        scope.pack(fill='x', padx=12, pady=(10, 6))

        fabric_all_var = tk.BooleanVar(value=True)
        fabric_vars = {}
        unique_fabrics = []
        for f in self.fabric_list:
            n = str(f.get('name', '') or '').strip()
            if n and n not in unique_fabrics:
                unique_fabrics.append(n)
        tk.Label(scope, text='LOẠI VẢI:', font=('Arial', 9, 'bold')).grid(row=0, column=0, sticky='w')
        f_all = tk.Checkbutton(scope, text='TẤT CẢ', variable=fabric_all_var, font=('Arial', 9, 'bold'))
        f_all.grid(row=0, column=1, sticky='w', padx=5)
        for i, name in enumerate(unique_fabrics):
            var = tk.BooleanVar(value=False)
            fabric_vars[name] = var
            tk.Checkbutton(scope, text=name, variable=var, font=('Arial', 9)).grid(
                row=0, column=i+2, sticky='w', padx=5)

        po_all_var = tk.BooleanVar(value=True)
        po_vars = {}
        po_names = []
        for p in self.po_list:
            n = str(p.get('po', '') or '').strip()
            if n and n not in po_names:
                po_names.append(n)
        tk.Label(scope, text='PO:', font=('Arial', 9, 'bold')).grid(row=1, column=0, sticky='w', pady=(6,0))
        tk.Checkbutton(scope, text='TẤT CẢ', variable=po_all_var, font=('Arial', 9, 'bold')).grid(
            row=1, column=1, sticky='w', padx=5, pady=(6,0))
        for i, name in enumerate(po_names):
            var = tk.BooleanVar(value=False)
            po_vars[name] = var
            tk.Checkbutton(scope, text=name, variable=var, font=('Arial', 9)).grid(
                row=1, column=i+2, sticky='w', padx=5, pady=(6,0))

        def selected_scope():
            if fabric_all_var.get():
                fmode, fnames = 'all', []
            else:
                fnames = [n for n, v in fabric_vars.items() if v.get()]
                fmode = 'selected'
            if po_all_var.get():
                pmode, pnames = 'all', []
            else:
                pnames = [n for n, v in po_vars.items() if v.get()]
                pmode = 'selected'
            return fmode, fnames, pmode, pnames

        # ===== KHUNG DÁN EXCEL 3 CỘT =====
        # V44: thay ô Text tự do bằng lưới Entry có tiêu đề và khung từng ô,
        # nhìn/nhập gần giống Excel. Có thể Ctrl+V trực tiếp dữ liệu nhiều hàng/cột.
        paste_frame = tk.LabelFrame(
            win, text='NHẬP / DÁN TỪ EXCEL',
            font=('Arial', 10, 'bold'), padx=8, pady=7
        )
        paste_frame.pack(fill='x', padx=12, pady=6)

        paste_grid_wrap = tk.Frame(paste_frame, bg='#7f8c8d', bd=1, relief='solid')
        paste_grid_wrap.pack(anchor='w', pady=(1, 5))

        paste_headers = [('LOT', 28), ('SỐ CÂY', 12), ('SỐ MÉT', 16)]
        paste_entries = []
        for c, (header, width) in enumerate(paste_headers):
            lbl = tk.Label(
                paste_grid_wrap, text=header, font=('Arial', 9, 'bold'),
                bg='#d9eaf7', fg='#1f1f1f', width=width,
                bd=1, relief='solid', padx=2, pady=4
            )
            lbl.grid(row=0, column=c, sticky='nsew')

        PASTE_ROWS = 8
        for r in range(PASTE_ROWS):
            row_entries = []
            for c, (_, width) in enumerate(paste_headers):
                ent = tk.Entry(
                    paste_grid_wrap, font=('Arial', 10), width=width,
                    bd=1, relief='solid', justify='left' if c == 0 else 'center',
                    highlightthickness=0
                )
                ent.grid(row=r + 1, column=c, sticky='nsew', ipady=3)
                row_entries.append(ent)
            paste_entries.append(row_entries)

        # Dòng số thứ tự ở ngoài lưới để dễ nhìn số hàng nhưng không làm thay đổi 3 cột dữ liệu.
        row_no_frame = tk.Frame(paste_frame, bg='white')
        row_no_frame.place(x=2, y=27) if False else None

        def _split_clipboard_rows(raw):
            rows = []
            for line in str(raw or '').replace('\r\n', '\n').replace('\r', '\n').split('\n'):
                if not line.strip():
                    continue
                if '\t' in line:
                    parts = line.split('\t')
                elif ';' in line:
                    parts = line.split(';')
                elif '|' in line:
                    parts = line.split('|')
                else:
                    parts = re.split(r'\s{2,}', line.strip())
                rows.append([str(x).strip() for x in parts[:3]])
            return rows

        def clear_paste_grid():
            for row in paste_entries:
                for ent in row:
                    ent.delete(0, tk.END)

        def fill_paste_grid(rows, start_row=0, start_col=0):
            for rr, vals in enumerate(rows):
                gr = start_row + rr
                if gr >= len(paste_entries):
                    break
                for cc, val in enumerate(vals):
                    gc = start_col + cc
                    if gc >= 3:
                        break
                    ent = paste_entries[gr][gc]
                    ent.delete(0, tk.END)
                    ent.insert(0, val)

        def paste_clipboard_to_grid(event=None, start_entry=None):
            try:
                raw = win.clipboard_get()
            except tk.TclError:
                return 'break' if event is not None else None
            rows = _split_clipboard_rows(raw)
            if not rows:
                return 'break' if event is not None else None

            start_r = 0
            start_c = 0
            if start_entry is not None:
                found = False
                for rr, row in enumerate(paste_entries):
                    for cc, ent in enumerate(row):
                        if ent is start_entry:
                            start_r, start_c = rr, cc
                            found = True
                            break
                    if found:
                        break
            fill_paste_grid(rows, start_r, start_c)
            return 'break' if event is not None else None

        # Ctrl+V tại bất kỳ ô nào: nếu clipboard có nhiều cột/hàng thì trải đúng như Excel.
        for row in paste_entries:
            for ent in row:
                ent.bind('<Control-v>', lambda e, w=ent: paste_clipboard_to_grid(e, w))
                ent.bind('<Control-V>', lambda e, w=ent: paste_clipboard_to_grid(e, w))

        paste_btns = tk.Frame(paste_frame)
        paste_btns.pack(fill='x', pady=(2, 0))
        tk.Button(
            paste_btns, text='📋 DÁN TỪ CLIPBOARD',
            command=paste_clipboard_to_grid,
            font=('Arial', 9, 'bold'), bg='#16a085', fg='white', padx=11, pady=4
        ).pack(side='left')
        tk.Button(
            paste_btns, text='🧹 XÓA KHUNG NHẬP',
            command=clear_paste_grid,
            font=('Arial', 9, 'bold'), bg='#7f8c8d', fg='white', padx=11, pady=4
        ).pack(side='left', padx=6)
        tk.Label(
            paste_btns,
            text='Copy 3 cột LOT | SỐ CÂY | SỐ MÉT từ Excel rồi Ctrl+V vào ô đầu tiên. Có thể sửa từng ô trước khi đưa vào danh sách.',
            font=('Arial', 9), fg='#555'
        ).pack(side='left', padx=10)

        # ===== BẢNG KIỂU EXCEL =====
        table_frame = tk.LabelFrame(win, text='BẢNG LOT - double click LOT / SỐ CÂY / SỐ MÉT để sửa trực tiếp',
                                    font=('Arial', 10, 'bold'), padx=6, pady=6)
        table_frame.pack(fill='both', expand=True, padx=12, pady=6)
        cols = ('lot','roll_count','meters','fabrics','pos')
        tree = ttk.Treeview(table_frame, columns=cols, show='headings', height=16, selectmode='extended')
        heads = {'lot':'LOT','roll_count':'SỐ CÂY','meters':'SỐ MÉT','fabrics':'LOẠI VẢI ÁP DỤNG','pos':'PO ÁP DỤNG'}
        widths = {'lot':230,'roll_count':110,'meters':130,'fabrics':300,'pos':300}
        for c in cols:
            tree.heading(c, text=heads[c])
            tree.column(c, width=widths[c], anchor='center')
        tree.pack(side='left', fill='both', expand=True)
        scr = ttk.Scrollbar(table_frame, orient='vertical', command=tree.yview)
        scr.pack(side='right', fill='y')
        tree.configure(yscrollcommand=scr.set)

        summary_var = tk.StringVar(value='')
        tk.Label(win, textvariable=summary_var, font=('Arial', 9, 'bold'), fg='#1f4e78',
                 anchor='w').pack(fill='x', padx=14, pady=(0,4))

        def refresh():
            for it in tree.get_children():
                tree.delete(it)
            total_c = 0
            total_m = 0.0
            for i, row in enumerate(self.global_lot_rows):
                ftxt, ptxt = self._global_lot_row_scope_text(row)
                try: rc = int(row.get('roll_count',0) or 0)
                except Exception: rc = 0
                try: mm = float(row.get('meters',0) or 0)
                except Exception: mm = 0.0
                total_c += rc; total_m += mm
                tree.insert('', 'end', iid=str(i), values=(row.get('lot',''), rc, f'{mm:.2f}', ftxt, ptxt))
            summary_var.set(f'TỔNG: {len(self.global_lot_rows)} LOT | {total_c} CÂY | {total_m:.2f} m')
            self._sync_global_lots()
            self.update_fabric_table()
            self.refresh_lot_table()

        def paste_rows():
            # Đọc trực tiếp từ lưới 3 cột, không còn đọc từ Text.
            fmode, fnames, pmode, pnames = selected_scope()
            if fmode == 'selected' and not fnames:
                messagebox.showwarning('Cảnh báo','Chọn ít nhất 1 LOẠI VẢI hoặc chọn TẤT CẢ.', parent=win); return
            if pmode == 'selected' and not pnames:
                messagebox.showwarning('Cảnh báo','Chọn ít nhất 1 PO hoặc chọn TẤT CẢ.', parent=win); return

            added = updated = bad = 0
            has_data = False
            for row_entries in paste_entries:
                parts = [ent.get().strip() for ent in row_entries]
                if not any(parts):
                    continue
                has_data = True
                lot = parts[0]
                try:
                    cnt = int(float(str(parts[1]).replace(',','.')))
                    meters = float(str(parts[2]).replace(',','.'))
                except (ValueError, IndexError):
                    # Nếu người dùng dán cả dòng tiêu đề thì bỏ qua.
                    if 'LOT' in lot.upper() and ('CÂY' in parts[1].upper() or 'MET' in parts[2].upper() or 'MÉT' in parts[2].upper()):
                        continue
                    bad += 1
                    continue
                if not lot or cnt < 0 or meters < 0:
                    bad += 1
                    continue

                existing = None
                for row in self.global_lot_rows:
                    if (str(row.get('lot','')).strip().lower() == lot.lower()
                        and row.get('fabric_mode','all') == fmode
                        and set(row.get('fabric_names',[]) or []) == set(fnames)
                        and row.get('po_mode','all') == pmode
                        and set(row.get('po_names',[]) or []) == set(pnames)):
                        existing = row
                        break

                data = {
                    'lot': lot, 'roll_count': cnt, 'meters': meters,
                    'fabric_mode': fmode, 'fabric_names': list(fnames),
                    'po_mode': pmode, 'po_names': list(pnames)
                }
                if existing:
                    existing.update(data)
                    updated += 1
                else:
                    self.global_lot_rows.append(data)
                    added += 1

            if not has_data:
                messagebox.showwarning('Cảnh báo', 'Khung nhập chưa có dữ liệu.', parent=win)
                return

            refresh()
            clear_paste_grid()
            paste_entries[0][0].focus_set()
            self.status_var.set(f'LOT: thêm {added}, cập nhật {updated}, bỏ qua {bad}')

        def add_blank():
            fmode, fnames, pmode, pnames = selected_scope()
            self.global_lot_rows.append({'lot':'LOT MỚI','roll_count':0,'meters':0.0,
                                         'fabric_mode':fmode,'fabric_names':list(fnames),
                                         'po_mode':pmode,'po_names':list(pnames)})
            refresh()
            iid=str(len(self.global_lot_rows)-1); tree.selection_set(iid); tree.focus(iid); tree.see(iid)

        def delete_selected():
            ids=tree.selection()
            if not ids: return
            for i in sorted([int(x) for x in ids], reverse=True):
                if 0<=i<len(self.global_lot_rows): del self.global_lot_rows[i]
            refresh()

        def apply_scope_selected():
            ids=tree.selection()
            if not ids:
                messagebox.showwarning('Cảnh báo','Chọn LOT cần đổi phạm vi.', parent=win); return
            fmode, fnames, pmode, pnames = selected_scope()
            if fmode=='selected' and not fnames:
                messagebox.showwarning('Cảnh báo','Chọn loại vải.', parent=win); return
            if pmode=='selected' and not pnames:
                messagebox.showwarning('Cảnh báo','Chọn PO.', parent=win); return
            for iid in ids:
                row=self.global_lot_rows[int(iid)]
                row.update({'fabric_mode':fmode,'fabric_names':list(fnames),
                            'po_mode':pmode,'po_names':list(pnames)})
            refresh()

        # Sửa trực tiếp 3 cột đầu bằng Entry chồng lên ô Treeview.
        editor={'widget':None}
        def start_edit(event):
            region=tree.identify('region', event.x, event.y)
            if region!='cell': return
            iid=tree.identify_row(event.y); col=tree.identify_column(event.x)
            if not iid or col not in ('#1','#2','#3'): return
            bbox=tree.bbox(iid,col)
            if not bbox: return
            x,y,w,h=bbox
            old=tree.set(iid, cols[int(col[1:])-1])
            ent=tk.Entry(tree, font=('Arial',9)); ent.place(x=x,y=y,width=w,height=h); ent.insert(0,old); ent.select_range(0,tk.END); ent.focus_set()
            editor['widget']=ent
            def commit(ev=None):
                if not ent.winfo_exists(): return
                val=ent.get().strip(); idx=int(iid); row=self.global_lot_rows[idx]
                try:
                    if col=='#1':
                        if val: row['lot']=val
                    elif col=='#2': row['roll_count']=max(0,int(float(val.replace(',','.'))))
                    elif col=='#3': row['meters']=max(0.0,float(val.replace(',','.')))
                except ValueError:
                    messagebox.showwarning('Sai dữ liệu','SỐ CÂY phải là số nguyên; SỐ MÉT phải là số.', parent=win)
                ent.destroy(); refresh()
            ent.bind('<Return>',commit); ent.bind('<FocusOut>',commit); ent.bind('<Escape>',lambda e: ent.destroy())
        tree.bind('<Double-1>', start_edit)

        buttons=tk.Frame(win); buttons.pack(fill='x', padx=12, pady=(2,10))
        tk.Button(buttons,text='✅ ĐƯA KHUNG NHẬP VÀO DANH SÁCH',command=paste_rows,font=('Arial',10,'bold'),bg='#27ae60',fg='white',padx=14,pady=5).pack(side='left')
        tk.Button(buttons,text='➕ Thêm dòng',command=add_blank,font=('Arial',9,'bold'),bg='#2980b9',fg='white',padx=10,pady=5).pack(side='left',padx=6)
        tk.Button(buttons,text='✅ Áp dụng LOẠI VẢI/PO cho dòng chọn',command=apply_scope_selected,font=('Arial',9,'bold'),bg='#8e44ad',fg='white',padx=10,pady=5).pack(side='left',padx=6)
        tk.Button(buttons,text='🗑️ Xóa dòng',command=delete_selected,font=('Arial',9,'bold'),bg='#c0392b',fg='white',padx=10,pady=5).pack(side='left',padx=6)
        tk.Label(buttons,text='1 LOT có thể dùng cho nhiều LOẠI VẢI; mỗi CÂY chỉ tự cấp cho 1 loại vải. LOT/cây dư giữ CHƯA GÁN để điều chỉnh sau.',font=('Arial',9),fg='#555').pack(side='left',padx=10)
        refresh()

    def _fabric_roll_reserve_settings(self, fabric):
        """V163: đọc quy tắc chừa đầu tấm của từng loại vải.

        reserve_m: nếu sau khi trải tối đa phần dư nhỏ hơn ngưỡng này thì bớt lá.
        reserve_plies: số lá bớt lại để làm đầu tấm. Mặc định 1.00 m / 1 lá.
        """
        fabric = fabric or {}
        try:
            reserve_m = max(0.0, float(fabric.get('reserve_m', 1.0)
                                       if fabric.get('reserve_m', 1.0) is not None else 1.0))
        except Exception:
            reserve_m = 1.0
        try:
            reserve_plies = max(1, int(float(fabric.get('reserve_plies', 1) or 1)))
        except Exception:
            reserve_plies = 1
        return reserve_m, reserve_plies

    def allocate_rolls_to_tables(self, fabric, tables):
        """Phân từng cây vải cho các bàn cắt, cho phép một cây đi qua nhiều bàn.

        Quy tắc V163:
        - Ngưỡng đầu tấm và số lá chừa được chỉnh riêng theo từng loại vải.
          Mặc định: nếu trải tối đa mà đầu tấm còn dưới 1.00 m thì bớt 1 lá.
        - Một cây đang dùng được phép tiếp tục sang bàn kế tiếp nếu phần mét còn lại
          của cây đó có thể trải TỪ 3 LÁ TRỞ LÊN cho marker của bàn kế tiếp.
        - Nếu phần còn lại chỉ đủ 1-2 lá cho bàn đang xét thì KHÔNG đưa cây đó vào
          bàn này; giữ phần dư để xét cho một bàn ngắn hơn phía sau.
        - Bàn có chiều dài sơ đồ ngắn nhất vẫn được xử lý cuối để ưu tiên tận dụng
          các đầu tấm/cây đang dùng còn đủ >= 3 lá.
        - Cây mới vẫn được mở khi cần để hoàn thành số lá của bàn.

        Mỗi lá dùng = chiều dài sơ đồ * 1.01, đồng bộ với logic LOT hiện tại.
        """
        MIN_CONTINUE_PLIES = 3
        reserve_m, reserve_plies = self._fabric_roll_reserve_settings(fabric)
        src_rolls = []
        for i, r in enumerate(fabric.get('rolls', []) or []):
            try:
                length = float(r.get('length', 0) or 0)
            except (TypeError, ValueError):
                length = 0.0
            if length <= 0:
                continue
            src_rolls.append({
                'source_index': i,
                'lot': str(r.get('lot', '') or '').strip(),
                'lot_mark': str(r.get('lot_mark', r.get('shade', '')) or '').strip(),
                'shade': str(r.get('lot_mark', r.get('shade', '')) or '').strip(),
                'roll': str(r.get('roll', '') or '').strip() or str(i+1),
                'length': length,
                'remaining': length,
                'used': 0.0,
                'started': False,
                'parked': False,
                'assigned_table_idx': None,
            })

        if not src_rolls or not tables:
            return [], src_rolls, None

        valid = [(i, t) for i, t in enumerate(tables)
                 if int(t.get('plies', 0) or 0) > 0 and float(t.get('length', 0) or 0) > 0]
        if not valid:
            return [], src_rolls, None

        # Giữ logic bàn ngắn nhất xử lý cuối để tận dụng đầu tấm tốt hơn.
        min_len = min(float(t.get('length', 0)) for _, t in valid)
        target_idx = max(i for i, t in valid if abs(float(t.get('length', 0)) - min_len) < 1e-9)
        allocations = []
        eps = 1e-9

        def raw_capacity(state, mpp):
            """Sức chứa tối đa nhưng luôn chừa đầu tấm.

            Quy tắc V163:
            - Trước hết tính số lá tối đa có thể trải.
            - Nếu phần dư sau khi trải tối đa nhỏ hơn reserve_m thì bớt
              reserve_plies lá. Mặc định reserve_m=1.00 m và reserve_plies=1.
            """
            if mpp <= 0:
                return 0
            raw = max(0, int((state['remaining'] + eps) // mpp))
            if raw <= 0:
                return 0
            rem_after_raw = max(0.0, state['remaining'] - raw * mpp)
            if rem_after_raw < reserve_m - eps:
                raw = max(0, raw - reserve_plies)
            return raw

        def add_alloc(table_idx, state, use_plies, mpp, source_note):
            if use_plies <= 0:
                return
            meters = use_plies * mpp
            state['remaining'] = max(0.0, state['remaining'] - meters)
            state['used'] += meters
            state['started'] = True
            state['parked'] = False
            if state.get('assigned_table_idx') is None:
                state['assigned_table_idx'] = table_idx
            table = tables[table_idx]
            allocations.append({
                'fabric': fabric.get('name', ''),
                'lot': state.get('lot',''),
                'lot_mark': state.get('lot_mark',''),
                'shade': state.get('lot_mark',''),
                'table': table.get('table', f'B{table_idx+1}'),
                'table_index': table_idx,
                'roll': state['roll'],
                'roll_length': state['length'],
                'marker_length': float(table.get('length', 0)),
                'meters_per_ply': mpp,
                'plies': int(use_plies),
                'meters_used': meters,
                'remaining_after': state['remaining'],
                'source': source_note,
                'is_short_final': table_idx == target_idx,
            })

        def use_existing_rolls(table_idx, table, need, final_table=False):
            """Dùng tiếp cây đã mở nếu cây đóng góp được ít nhất 3 lá cho bàn này."""
            if need < MIN_CONTINUE_PLIES:
                return need
            mpp = float(table.get('length', 0) or 0) * 1.01
            if mpp <= 0:
                return need

            candidates = [r for r in src_rolls
                          if r['started'] and raw_capacity(r, mpp) >= MIN_CONTINUE_PLIES]
            # Bàn cuối ưu tiên đầu tấm ngắn trước; bàn thường giữ đúng thứ tự cây nhập.
            if final_table:
                candidates.sort(key=lambda r: (r['remaining'], r['source_index']))
            else:
                candidates.sort(key=lambda r: r['source_index'])

            for state in candidates:
                if need < MIN_CONTINUE_PLIES:
                    break
                cap = raw_capacity(state, mpp)
                if cap < MIN_CONTINUE_PLIES:
                    state['parked'] = True
                    continue
                use = min(need, cap)
                # Không chuyển một cây sang bàn mới chỉ để trải 1-2 lá.
                if use < MIN_CONTINUE_PLIES:
                    continue
                note = ('ĐẦU TẤM/CÂY ĐANG DÙNG → BÀN NGẮN CUỐI'
                        if final_table else 'CÂY ĐANG DÙNG → BÀN TIẾP')
                add_alloc(table_idx, state, use, mpp, note)
                need -= use
            return need

        def use_new_rolls(table_idx, table, need, final_table=False):
            """Mở cây mới để hoàn thành số lá còn thiếu của bàn."""
            mpp = float(table.get('length', 0) or 0) * 1.01
            if mpp <= 0:
                return need
            for state in src_rolls:
                if need <= 0:
                    break
                if state['started'] or state['remaining'] + eps < mpp:
                    continue
                cap = raw_capacity(state, mpp)
                if cap <= 0:
                    continue
                use = min(need, cap)
                note = 'CÂY MỚI → BÀN NGẮN CUỐI' if final_table else 'CÂY MỚI'
                add_alloc(table_idx, state, use, mpp, note)
                need -= use
            return need

        # 1) Các bàn thường: ưu tiên tiếp tục cây đang dùng nếu còn đủ >=3 lá,
        # sau đó mới mở cây mới. Cây còn 1-2 lá cho bàn hiện tại được giữ lại.
        for table_idx, table in valid:
            if table_idx == target_idx:
                continue
            need = int(table.get('plies', 0) or 0)
            mpp = float(table.get('length', 0) or 0) * 1.01
            need = use_existing_rolls(table_idx, table, need, final_table=False)
            need = use_new_rolls(table_idx, table, need, final_table=False)

            # Đánh dấu những cây đã mở nhưng hiện chỉ còn đủ 1-2 lá cho marker này.
            for state in src_rolls:
                if state['started'] and state['remaining'] > eps:
                    cap = raw_capacity(state, mpp)
                    if 0 < cap < MIN_CONTINUE_PLIES:
                        state['parked'] = True

            if need > 0:
                allocations.append({
                    'fabric': fabric.get('name', ''), 'lot': '', 'lot_mark': '', 'shade': '',
                    'table': table.get('table', f'B{table_idx+1}'), 'table_index': table_idx,
                    'roll': 'THIẾU VẢI', 'roll_length': 0.0,
                    'marker_length': float(table.get('length', 0)), 'meters_per_ply': mpp,
                    'plies': need, 'meters_used': need * mpp, 'remaining_after': 0.0,
                    'source': 'THIẾU VẢI', 'is_short_final': False,
                })

        # 2) Bàn ngắn nhất xử lý cuối: tận dụng cây đã dùng nếu phần còn lại
        # trải được >=3 lá; sau đó mới mở cây mới.
        target = tables[target_idx]
        need = int(target.get('plies', 0) or 0)
        mpp = float(target.get('length', 0) or 0) * 1.01
        need = use_existing_rolls(target_idx, target, need, final_table=True)
        need = use_new_rolls(target_idx, target, need, final_table=True)

        if need > 0:
            allocations.append({
                'fabric': fabric.get('name', ''), 'lot': '', 'lot_mark': '', 'shade': '',
                'table': target.get('table', f'B{target_idx+1}'), 'table_index': target_idx,
                'roll': 'THIẾU VẢI', 'roll_length': 0.0,
                'marker_length': float(target.get('length', 0)), 'meters_per_ply': mpp,
                'plies': need, 'meters_used': need * mpp, 'remaining_after': 0.0,
                'source': 'THIẾU VẢI', 'is_short_final': True,
            })

        return allocations, src_rolls, target_idx

    def allocate_lots_to_tables(self, fabric, tables):
        """
        Phân mét LOT vào các bàn sau khi thuật toán cắt đã hoàn tất.

        Quy tắc V28 (phần xem trước):
        - LOT là riêng cho từng loại vải, giữ nguyên logic marker / sản lượng V13.
        - ƯU TIÊN DÙNG HẾT LOT THEO THỨ TỰ ĐÃ NHẬP: dùng LOT đầu tiên tối đa
          có thể rồi mới chuyển sang LOT tiếp theo.
        - Với mỗi LOT, chương trình chọn phần bàn/số lá giúp sử dụng được nhiều mét
          nhất có thể. Chỉ chuyển LOT khi phần mét còn lại không đủ cho 1 lá của
          bất kỳ marker nào còn chưa phân.
        - Một marker có thể bị tách số lá sang nhiều LOT; tổng số lá và sản lượng
          của marker không thay đổi.
        - Mét mỗi phần = chiều dài marker * số lá * 1.01, đúng công thức Excel.
        - Nếu tất cả LOT không đủ, phần còn lại được gắn LOT = 'THIẾU VẢI'.
        """
        lots_src = fabric.get('lots', []) or []
        if not lots_src:
            plain = []
            for i, table in enumerate(tables, start=1):
                t = dict(table)
                t['table'] = f'B{i}'
                t['lot'] = ''
                t['meters_needed'] = float(t['length']) * int(t['plies']) * 1.01
                plain.append(t)
            return plain, []

        lots = [
            {
                'name': str(lot.get('name', '')).strip() or f'LOT {i+1}',
                'meters': float(lot.get('meters', 0)),
                'remaining': float(lot.get('meters', 0)),
                'used': 0.0
            }
            for i, lot in enumerate(lots_src)
            if float(lot.get('meters', 0)) > 0
        ]
        if not lots:
            return self.allocate_lots_to_tables({'lots': []}, tables)

        # Chuẩn bị dữ liệu marker, giữ nguyên thứ tự ban đầu.
        works = []
        for idx, table in enumerate(tables):
            plies = int(table.get('plies', 0))
            if plies <= 0:
                continue
            length = float(table.get('length', 0))
            mpp = length * 1.01  # mét vải cho 1 lá của marker
            ratios = {}
            for key, qty in table.get('sizes', {}).items():
                q = int(qty)
                if q > 0:
                    ratios[key] = int(round(q / plies))
            works.append({
                'index': idx,
                'table': table,
                'plies': plies,
                'left': plies,
                'mpp': mpp,
                'ratios': ratios,
                'segments': []
            })

        eps = 1e-9

        # V28: phân LOT theo đúng thứ tự bàn trong Excel để phần XEM TRƯỚC
        # và file xuất ra cho cùng một kết quả.
        # Với từng LOT: đi lần lượt B1, B2, B3...; phần LOT còn đủ 1-2 lá nhưng
        # chỉ tạo ra một đoạn tách nhỏ của bàn thì để DƯ và chuyển sang LOT sau.
        for li, lot in enumerate(lots):
            for work in works:
                if lot['remaining'] <= eps:
                    break
                if work['left'] <= 0 or work['mpp'] <= 0:
                    continue

                cap = int((lot['remaining'] + eps) // work['mpp'])
                if cap <= 0:
                    continue

                use_plies = min(work['left'], cap)

                # Không tạo đoạn LOT 1-2 lá nếu bàn vẫn còn nhiều lá phải chuyển
                # sang LOT kế tiếp. Nếu 1-2 lá này hoàn tất toàn bộ bàn thì vẫn dùng.
                if use_plies < 3 and use_plies < work['left']:
                    continue

                meters = work['mpp'] * use_plies
                work['segments'].append((li, use_plies, meters))
                work['left'] -= use_plies
                lot['remaining'] -= meters
                if abs(lot['remaining']) < 1e-8:
                    lot['remaining'] = 0.0
                lot['used'] += meters

            if all(w['left'] <= 0 for w in works):
                break

        # Sau khi đã dùng hết khả năng của tất cả LOT, phần số lá còn lại là thiếu vải.
        for work in works:
            if work['left'] > 0:
                meters = work['mpp'] * work['left']
                work['segments'].append((None, work['left'], meters))
                work['left'] = 0

        # Trả về theo thứ tự marker gốc; mỗi segment là 1 bàn thực tế.
        expanded = []
        for work in sorted(works, key=lambda x: x['index']):
            src = work['table']
            for li, plies, meters in work['segments']:
                sizes = {
                    k: ratio * plies
                    for k, ratio in work['ratios'].items()
                    if ratio * plies > 0
                }
                t = dict(src)
                t['plies'] = plies
                t['sizes'] = sizes
                t['lot'] = lots[li]['name'] if li is not None else 'THIẾU VẢI'
                t['meters_needed'] = meters
                expanded.append(t)

        for i, table in enumerate(expanded, start=1):
            table['table'] = f'B{i}'

        summary = [
            {
                'name': lot['name'],
                'meters': lot['meters'],
                'used': max(0.0, lot['used']),
                'remaining': max(0.0, lot['remaining'])
            }
            for lot in lots
        ]
        return expanded, summary

    # ==================== THUẬT TOÁN TỐI ƯU MỚI ====================
    def optimize_cutting_global(self, total_by_size, size_factor, norm, max_len, max_products=0, fabric_mode='main', min_marker_length=1.0, balance_pct=1.0):
        """V106: tối ưu toàn cục 1..6 bàn, giữ NHIỀU cách phân bổ tỷ lệ cho mỗi cỡ.

        Điểm sửa quan trọng so với V104: cùng một sản lượng của một cỡ có thể được
        tạo bởi nhiều cách phân bổ tỷ lệ khác nhau giữa các bàn. V104 chỉ giữ 1
        vector cho mỗi tổng sản lượng nên thường vô tình dồn nhiều cỡ vào cùng một
        bàn, làm vượt chiều dài và khiến bộ toàn cục thất bại rồi rơi về V100.
        V106 giữ nhiều vector phân bổ khác nhau và chấm cả bộ bàn đồng thời.

        V106 sửa thêm lỗi V105: nếu giới hạn chiều dài khiến KHÔNG THỂ ghép
        bất kỳ 2 cỡ nào trên cùng sơ đồ, phương án bàn đơn cỡ là bắt buộc và
        phải được trả về thay vì báo thiếu toàn bộ sản lượng.
        """
        from itertools import combinations as _comb

        name_map = {x['key']: x['name'] for x in self.sizes}
        profile = self._fabric_cut_profile(fabric_mode, total_by_size, norm, max_len, balance_pct)
        over_limits = dict(profile.get('over_limits', {}))
        under_limits = dict(profile.get('under_limits', {}))
        allow_under = bool(profile.get('allow_under', False))
        downgrade_large_to_small = bool(profile.get('downgrade_large_to_small', False))
        total_surplus_cap = int(profile.get('total_surplus_cap', -1))
        total_surplus_pct = float(profile.get('total_surplus_pct', 0.0) or 0.0)

        def over_limit(k):
            return max(0, int(over_limits.get(k, self.MAX_OVER) or 0))

        def under_limit(k):
            return max(0, int(under_limits.get(k, 0) or 0)) if allow_under else 0

        keys = [x['key'] for x in self.sizes if int(total_by_size.get(x['key'], 0) or 0) > 0]
        if not keys:
            return [], {'unresolved': {}}

        # V127: Chiều dài sơ đồ dùng đúng DMTB × TỔNG TỈ LỆ.
        # Không nhân hệ số size; người dùng nhập DMTB là định mức trung bình cho 1 SP.
        slen = {k: float(norm) for k in keys}
        min_len = max(0.0, float(min_marker_length or 0.0))
        max_len = max(0.0, float(max_len or 0.0))
        try:
            max_products = max(0, int(float(max_products or 0)))
        except Exception:
            max_products = 0

        if max_len > 0 and min_len > max_len + 1e-9:
            raise ValueError(f"Chiều dài sơ đồ tối đa {max_len:.2f} m nhỏ hơn chiều dài tối thiểu {min_len:.2f} m.")

        min_unit = min(max(1e-9, slen[k]) for k in keys)
        ratio_cap = int(max_len / min_unit) if max_len > 0 else 24
        ratio_cap = max(1, min(36, ratio_cap))
        if max_products > 0:
            ratio_cap = min(ratio_cap, max_products)

        max_q = max(int(total_by_size[k]) + over_limit(k) for k in keys)
        max_lays = max(12, min(max_q, 500))
        min_lays = 4

        def fmt(r):
            return ' + '.join(
                f"{name_map.get(k, k)}/{int(r.get(k, 0))}"
                for k in keys if int(r.get(k, 0)) > 0
            )

        # V106: xác định xem về mặt chiều dài có thể đặt >=2 cỡ trên
        # cùng một sơ đồ hay không. Nếu ngay cả cặp ngắn nhất cũng vượt MAX,
        # thì việc tách từng cỡ thành một bàn không phải lỗi thuật toán mà là
        # nghiệm duy nhất theo mô hình chiều dài hiện tại.
        def can_merge_two_sizes():
            if len(keys) < 2:
                return False
            if max_products > 0 and max_products < 2:
                return False
            vals = sorted(float(slen[k]) for k in keys)
            if max_len > 0:
                return vals[0] + vals[1] <= max_len + 1e-9
            return True

        merge_physically_possible = can_merge_two_sizes()

        # V128: số lá càng ít so với bàn chính thì marker càng phải ngắn.
        # Quy tắc áp dụng cho mọi loại vải trong bộ TOÀN CỤC:
        #   <=10% số lá lớn nhất: tối đa 40% chiều dài MAX
        #   <=25%: tối đa 60% MAX
        #   <=50%: tối đa 80% MAX
        #   >50%: được dùng toàn bộ MAX
        # Không bao giờ ép thấp hơn chiều dài tối thiểu người dùng đã nhập.
        def dynamic_marker_cap(plies, max_plies):
            if max_len <= 0 or max_plies <= 0:
                return max_len
            share = float(plies) / float(max_plies)
            if share <= 0.10 + 1e-12:
                frac = 0.40
            elif share <= 0.25 + 1e-12:
                frac = 0.60
            elif share <= 0.50 + 1e-12:
                frac = 0.80
            else:
                frac = 1.00
            return min(max_len, max(min_len, max_len * frac))

        def build_forced_singletons():
            """Tạo phương án 1 bàn/cỡ khi chiều dài không cho phép ghép cỡ.

            Ưu tiên tỷ lệ nhỏ nhất thỏa MIN để giữ sơ đồ ngắn và số lá cao.
            Chỉ dùng khi KHÔNG có bất kỳ cặp cỡ nào có thể ghép theo MAX.
            """
            if len(keys) > 6:
                return None
            out = []
            for idx, k in enumerate(keys, start=1):
                q = int(total_by_size[k])
                # Tìm ratio nhỏ nhất thỏa chiều dài min/max và SP tối đa.
                best = None
                for r in range(1, ratio_cap + 1):
                    L = slen[k] * r
                    if L + 1e-9 < min_len:
                        continue
                    if max_len > 0 and L > max_len + 1e-9:
                        break
                    if max_products > 0 and r > max_products:
                        break
                    n = int(math.ceil(q / float(r)))
                    if n < min_lays:
                        continue
                    made = r * n
                    over = made - q
                    if over < 0 or over > over_limit(k):
                        continue
                    cand = (r, n, L, over)
                    if best is None or (over, r, -n) < (best[3], best[0], -best[1]):
                        best = cand
                if best is None:
                    return None
                r, n, L, over = best
                ratios = {k: r}
                sizes = {k: r * n}
                out.append({
                    'table': f'B{idx}', 'sizes': sizes, 'ratio': fmt(ratios),
                    'length': L, 'raw_length': L, 'plies': n,
                    'ratio_map': ratios, 'total_output': sum(sizes.values()),
                    'size_count': 1, 'left_total': 0, 'small_left_count': 0,
                    'small_left_sum': 0, 'zeroed': 0, 'over_total': over,
                    'size_span': 0, 'meter_rate': L / max(1, r)
                })
            return out

        def build_feasible_emergency():
            """V120: bộ cứu hộ khả thi, không báo thiếu toàn bộ chỉ vì beam bỏ sót nghiệm.

            Mỗi cỡ được giải độc lập bằng 1 hoặc 2 bàn đơn cỡ trong đúng giới hạn
            chiều dài / SP tối đa / dương cho phép. Sau đó các bàn có cùng số lá
            được ghép lại nếu marker sau ghép vẫn không vượt giới hạn.

            Điểm khác build_forced_singletons: một cỡ không bắt buộc phải biểu diễn
            bằng đúng 1 phép r*n. Ví dụ nếu q không có bội phù hợp trong khoảng
            q..q+MAX_OVER thì có thể tách thành 2 bàn để đạt đúng q hoặc dương thấp.
            """
            from bisect import bisect_left, bisect_right

            segments = []
            total_emergency_over = 0

            for k in keys:
                q = int(total_by_size[k])
                hi = q + over_limit(k)
                unit = float(slen[k])
                if unit <= 0:
                    return None

                r_lo = 1
                if min_len > 0:
                    r_lo = max(r_lo, int(math.ceil((min_len - 1e-9) / unit)))
                r_hi = ratio_cap
                if max_len > 0:
                    r_hi = min(r_hi, int(math.floor((max_len + 1e-9) / unit)))
                if max_products > 0:
                    r_hi = min(r_hi, int(max_products))
                if r_lo > r_hi:
                    return None

                # output -> lựa chọn (ratio, plies, length) tốt nhất cho output đó.
                # Ưu tiên ratio ít/marker ngắn, sau đó nhiều lá.
                by_output = {}
                for r in range(r_lo, r_hi + 1):
                    L = unit * r
                    if L + 1e-9 < min_len:
                        continue
                    if max_len > 0 and L > max_len + 1e-9:
                        continue
                    n_hi = min(max_lays, hi // r)
                    if n_hi < min_lays:
                        continue
                    for n in range(min_lays, n_hi + 1):
                        made = r * n
                        if made <= 0 or made > hi:
                            continue
                        old = by_output.get(made)
                        cand = (r, n, L)
                        if old is None or (r, L, -n) < (old[0], old[2], -old[1]):
                            by_output[made] = cand

                if not by_output:
                    return None

                values = sorted(by_output)
                best = None

                # 1 bàn.
                for made in values:
                    if made < q:
                        continue
                    r, n, L = by_output[made]
                    score = (made - q, 1, r, L, -n)
                    cand = (score, [(k, r, n, L, made)])
                    if best is None or score < best[0]:
                        best = cand

                # 2 bàn. Cho phép hai bàn cùng số lá / cùng ratio.
                # Chỉ cần xem các tổng q..hi; dùng bisect để tránh O(N^2) đầy đủ.
                for p1 in values:
                    lo2 = max(values[0], q - p1)
                    hi2 = hi - p1
                    if hi2 < values[0]:
                        continue
                    a = bisect_left(values, lo2)
                    b = bisect_right(values, hi2)
                    if a >= b:
                        continue
                    # Với mỗi p1, chỉ cần vài p2 gần mục tiêu thấp nhất và biên trên.
                    idxs = {a, min(b - 1, a + 1), b - 1}
                    for ii in idxs:
                        if not (a <= ii < b):
                            continue
                        p2 = values[ii]
                        made = p1 + p2
                        if made < q or made > hi:
                            continue
                        r1, n1, L1 = by_output[p1]
                        r2, n2, L2 = by_output[p2]
                        score = (made - q, 2, r1 + r2, max(L1, L2), -(n1 + n2))
                        cand = (score, [(k, r1, n1, L1, p1),
                                        (k, r2, n2, L2, p2)])
                        if best is None or score < best[0]:
                            best = cand

                if best is None:
                    return None

                total_emergency_over += int(best[0][0])
                segments.extend(best[1])

            # DỰNG/BÔNG: cứu hộ cũng phải giữ giới hạn dương tổng sau cùng.
            # Bộ cứu hộ này không tạo âm nên dương sau hạ cỡ chính là tổng dương.
            if allow_under and total_surplus_cap >= 0 and total_emergency_over > total_surplus_cap:
                return None

            # Ghép các segment có CÙNG số lá. Đây là phép ghép an toàn vì sản lượng
            # từng cỡ không đổi; chỉ gom marker nếu tổng chiều dài vẫn hợp lệ.
            packed = []
            for k, r, n, L, made in sorted(segments, key=lambda x: (-x[2], x[3], x[1])):
                placed = False
                for tb in packed:
                    if int(tb['plies']) != int(n):
                        continue
                    new_ratio_total = int(tb['_ratio_total']) + int(r)
                    new_len = float(tb['length']) + float(L)
                    if max_products > 0 and new_ratio_total > max_products:
                        continue
                    if max_len > 0 and new_len > max_len + 1e-9:
                        continue
                    tb['ratio_map'][k] = int(tb['ratio_map'].get(k, 0)) + int(r)
                    tb['sizes'][k] = int(tb['sizes'].get(k, 0)) + int(made)
                    tb['_ratio_total'] = new_ratio_total
                    tb['length'] = new_len
                    tb['raw_length'] = new_len
                    tb['total_output'] = sum(tb['sizes'].values())
                    tb['size_count'] = len(tb['ratio_map'])
                    placed = True
                    break
                if not placed:
                    packed.append({
                        'table': '', 'sizes': {k: int(made)}, 'ratio': '',
                        'length': float(L), 'raw_length': float(L), 'plies': int(n),
                        'ratio_map': {k: int(r)}, '_ratio_total': int(r),
                        'total_output': int(made), 'size_count': 1,
                        'left_total': 0, 'small_left_count': 0, 'small_left_sum': 0,
                        'zeroed': 0, 'over_total': 0, 'size_span': 0,
                        'meter_rate': float(L) / max(1, int(r)),
                    })

            # Sắp nhiều lá trước; bàn ít lá/tỷ lệ ít/ngắn để cuối đúng logic V118+.
            packed.sort(key=lambda tb: (-int(tb.get('plies', 0)),
                                        -int(tb.get('_ratio_total', 0)),
                                        -float(tb.get('length', 0))))
            if len(packed) > 1:
                tail_i = min(range(len(packed)), key=lambda i: (
                    int(packed[i].get('plies', 0)),
                    int(packed[i].get('_ratio_total', 0)),
                    float(packed[i].get('length', 0)),
                ))
                tail = packed.pop(tail_i)
                packed.append(tail)

            for i, tb in enumerate(packed, start=1):
                tb['table'] = f'B{i}'
                tb['ratio'] = fmt(tb['ratio_map'])
                tb.pop('_ratio_total', None)

            # Kiểm tra lần cuối: phải đủ từng cỡ và không vượt dương từng cỡ.
            actual = {k: 0 for k in keys}
            for tb in packed:
                for k, v in (tb.get('sizes', {}) or {}).items():
                    actual[k] = actual.get(k, 0) + int(v or 0)
            for k in keys:
                d = int(actual.get(k, 0)) - int(total_by_size[k])
                if d < 0 or d > over_limit(k):
                    return None
            return packed

        def build_fast_flexible_single_table():
            """V121: đường tìm nhanh cho DỰNG/BÔNG định mức nhỏ.

            Với các vật tư cho phép âm/dương + hạ cỡ lớn xuống cỡ bé, marker có
            định mức rất nhỏ (ví dụ DỰNG 14G) thường cần tổng tỷ lệ lớn. Beam tổng
            quát có thể phải duyệt cực nhiều trạng thái rồi bỏ sót nghiệm, dù một
            marker duy nhất đã có nghiệm rất đẹp.

            Hàm này quét số lá, mỗi cỡ chỉ giữ vài tỷ lệ gần sản lượng mục tiêu,
            sau đó kiểm tra hạ cỡ lớn -> cỡ bé y hệt tiêu chí cuối của solver.
            Chỉ dùng cho norm <= 0.15 để không thay đổi cách chia vải chính/lót/
            kẹp tầng và DỰNG định mức lớn.
            """
            if not (allow_under and downgrade_large_to_small):
                return None
            if float(norm or 0.0) > 0.15:
                return None

            from itertools import product as _product

            def _transfer_eval(raw_diff):
                sources = []
                transfers = []
                residual = {k: 0 for k in keys}
                used = 0
                for k in reversed(keys):
                    d = int(raw_diff.get(k, 0))
                    if d > 0:
                        sources.append([k, d])
                        continue
                    if d >= 0:
                        continue
                    need = -d
                    # nguồn gần nhất trước: khi duyệt từ lớn -> bé, nguồn được
                    # thêm theo thứ tự lớn dần về gần; reversed = gần nhất trước.
                    for src in reversed(sources):
                        if need <= 0:
                            break
                        if src[1] <= 0:
                            continue
                        take = min(need, src[1])
                        if take > 0:
                            src[1] -= take
                            need -= take
                            used += take
                            transfers.append((src[0], k, take))
                    residual[k] = need
                positive = sum(max(0, int(src[1])) for src in sources)
                return residual, positive, transfers, used

            best = None
            # Quét rộng số lá nhưng mỗi n chỉ có rất ít tỷ lệ cần thử.
            for n in range(min_lays, max_lays + 1):
                ratio_choices = []
                impossible = False
                for idx, k in enumerate(keys):
                    q = int(total_by_size[k])
                    transfer_cap = (sum(over_limit(x) for x in keys[idx + 1:])
                                    if downgrade_large_to_small else 0)
                    lo = max(0, q - under_limit(k) - transfer_cap)
                    hi = q + over_limit(k)

                    choices = []
                    for r in range(0, ratio_cap + 1):
                        made = int(r) * int(n)
                        if lo <= made <= hi:
                            choices.append(int(r))
                    if not choices:
                        impossible = True
                        break
                    # Giữ tối đa 5 tỷ lệ gần mục tiêu để tổ hợp vẫn rất nhẹ.
                    choices.sort(key=lambda r: (
                        abs(int(r) * int(n) - q),
                        0 if int(r) * int(n) >= q else 1,
                        int(r)
                    ))
                    ratio_choices.append(choices[:5])

                if impossible:
                    continue

                for rr in _product(*ratio_choices):
                    if not any(int(r) > 0 for r in rr):
                        continue
                    ratio_total = sum(int(r) for r in rr)
                    if max_products > 0 and ratio_total > max_products:
                        continue

                    L = sum(float(slen[k]) * int(r) for k, r in zip(keys, rr))
                    if L + 1e-9 < min_len:
                        continue
                    if max_len > 0 and L > max_len + 1e-9:
                        continue

                    actual = {k: int(n) * int(r) for k, r in zip(keys, rr)}
                    raw_diff = {k: int(actual[k]) - int(total_by_size[k]) for k in keys}
                    if any(raw_diff[k] > over_limit(k) for k in keys):
                        continue

                    residual, positive, transfers, used = _transfer_eval(raw_diff)
                    if any(int(residual[k]) > under_limit(k) for k in keys):
                        continue
                    if total_surplus_cap >= 0 and int(positive) > int(total_surplus_cap):
                        continue

                    residual_short = sum(int(v) for v in residual.values())
                    total_abs = sum(abs(int(v)) for v in raw_diff.values())
                    # DỰNG/BÔNG: âm còn lại -> dương còn lại -> nhiều lá ->
                    # tỷ lệ gọn -> marker ngắn. Một bàn nên không cần tiêu chí số bàn.
                    score = (
                        residual_short,
                        int(positive),
                        total_abs,
                        -int(n),
                        ratio_total,
                        float(L),
                    )
                    if best is None or score < best[0]:
                        ratios = {k: int(r) for k, r in zip(keys, rr) if int(r) > 0}
                        best = (score, n, L, ratios, actual, raw_diff,
                                residual, positive, transfers, used)

            if best is None:
                return None

            _, n, L, ratios, actual, raw_diff, residual, positive, transfers, used = best
            table = {
                'table': 'B1',
                'sizes': {k: int(v) for k, v in actual.items() if int(v) > 0},
                'ratio': fmt(ratios),
                'length': float(L),
                'raw_length': float(L),
                'plies': int(n),
                'ratio_map': dict(ratios),
                'total_output': sum(int(v) for v in actual.values()),
                'size_count': len(ratios),
                'left_total': 0,
                'small_left_count': 0,
                'small_left_sum': 0,
                'zeroed': 0,
                'over_total': sum(max(0, int(v)) for v in raw_diff.values()),
                'size_span': 0,
                'meter_rate': float(L) / max(1, sum(int(v) for v in ratios.values())),
            }
            info = {
                'unresolved': {},
                'optimizer': 'global_v121_fast_flexible_1_table',
                'fabric_mode': fabric_mode,
                'fabric_mode_label': profile.get('label', ''),
                'over_limits': dict(over_limits),
                'under_limits': dict(under_limits),
                'allow_under': allow_under,
                'downgrade_large_to_small': downgrade_large_to_small,
                'raw_diff': dict(raw_diff),
                'residual_under': dict(residual),
                'size_transfers': list(transfers),
                'transfer_used': int(used),
                'final_positive_surplus': int(positive),
                'total_surplus_cap': int(total_surplus_cap),
                'total_surplus_pct': float(total_surplus_pct),
                'note': 'V121: dùng bộ tìm nhanh 1 bàn cho DỰNG/BÔNG định mức nhỏ.'
            }
            return [table], info

        # V126: DỰNG/BÔNG dùng CÙNG một nguyên tắc cho phương án 1 bàn.
        # Sau khi cho cỡ lớn hạ xuống bù cỡ bé, nếu KHÔNG còn thiếu và tổng dương
        # cuối cùng vẫn nằm trong giới hạn thì chốt 1 bàn ngay. Không còn giới hạn
        # số lượng phải hạ cỡ (transfer_used), vì giới hạn này làm BÔNG bị ép sang
        # 2 bàn dù một marker đã cân đủ sản lượng sau quy đổi.
        fast_flexible = build_fast_flexible_single_table()
        _fast_low_norm_mode = fast_flexible is not None
        if fast_flexible is not None:
            _fi = fast_flexible[1] if isinstance(fast_flexible, tuple) and len(fast_flexible) > 1 else {}
            _fr = _fi.get('residual_under', {}) if isinstance(_fi, dict) else {}
            _f_residual = sum(max(0, int(v or 0)) for v in _fr.values())
            _f_positive = int((_fi or {}).get('final_positive_surplus', 0) or 0)
            _pos_cap = max(0, int(total_surplus_cap)) if total_surplus_cap >= 0 else 10**9
            if _f_residual == 0 and _f_positive <= _pos_cap:
                return fast_flexible

        # Nếu không thể ghép 2 cỡ ngay từ điều kiện chiều dài, trả phương án
        # bắt buộc này ngay. V105 trước đây cấm mọi nghiệm toàn bàn đơn cỡ nên
        # cuối cùng báo "thiếu" toàn bộ sản lượng dù thực tế vẫn cắt được.
        if not merge_physically_possible:
            singles = build_forced_singletons()
            if singles is not None:
                return singles, {
                    'unresolved': {},
                    'optimizer': 'global_v106_forced_singletons',
                    'note': 'Không thể ghép 2 cỡ trong giới hạn chiều dài; dùng bàn đơn cỡ bắt buộc.'
                }

        def _vec_rank(vec):
            active = sum(1 for x in vec if x > 0)
            mx = max(vec) if vec else 0
            ss = sum(vec)
            spread = (mx - min((x for x in vec if x > 0), default=0)) if active else 0
            # Giữ cả vector trải đều và vector tập trung để beam phía sau còn lựa chọn.
            return (-active, mx, ss, spread, vec)

        def options_for_size(k, lays, keep=9, per_output=5):
            """Tìm nhiều vector tỷ lệ cho một cỡ.

            V115: DỰNG/MEX và BÔNG được phép âm/dương. Vì vậy output của một
            cỡ có thể nằm trong [yêu cầu-under, yêu cầu+over]. Cỡ lớn dương sẽ
            được phép hạ xuống bù cỡ bé ở bước chấm toàn bộ phương án.
            """
            q = int(total_by_size[k])
            if allow_under:
                _idx = keys.index(k)
                _transfer_cap = (sum(over_limit(x) for x in keys[_idx + 1:])
                                 if downgrade_large_to_small else 0)
                # Có thể thiếu sâu hơn giới hạn âm riêng nếu phần thiếu đó có khả năng
                # được cỡ lớn dương hạ xuống bù. Phần âm CÒN LẠI sau hạ cỡ mới bị
                # giới hạn bởi under_limit(k).
                lo = max(0, q - under_limit(k) - _transfer_cap)
            else:
                lo = q
            hi = q + over_limit(k)

            # got -> danh sách vector. Không chỉ giữ 1 vector như V104.
            states = {0: [tuple()]}
            for j, n in enumerate(lays):
                nxt = {}
                for got, vecs in states.items():
                    max_r = min(ratio_cap, (hi - got) // n)
                    for vec in vecs:
                        for r in range(max_r + 1):
                            ng = got + r * n
                            nv = vec + (r,)
                            bucket = nxt.setdefault(ng, [])
                            bucket.append(nv)
                # Cắt gọn nhưng giữ nhiều kiểu phân bổ khác nhau cho cùng output.
                pruned = {}
                for got, vecs in nxt.items():
                    uniq = list(dict.fromkeys(vecs))
                    a = sorted(uniq, key=_vec_rank)[:max(2, per_output // 2)]
                    b = sorted(uniq, key=lambda v: (sum(v), max(v) if v else 0,
                                                   -sum(1 for x in v if x > 0), v))[:max(2, per_output // 2)]
                    merged = list(dict.fromkeys(a + b))[:per_output]
                    pruned[got] = merged
                states = pruned
                if not states:
                    return []

            out = []
            for got in range(lo, hi + 1):
                for vec in states.get(got, []):
                    if not any(vec):
                        continue
                    rs = sum(vec)
                    active = sum(1 for v in vec if v > 0)
                    diff = got - q
                    # Với BÔNG/DỰNG: phạt theo độ lệch tuyệt đối, không coi âm là lỗi.
                    penalty = abs(diff) if allow_under else max(0, diff)
                    out.append((penalty, rs, vec, active, diff))

            # Ưu tiên lệch ít, ghép nhiều bàn, tỷ lệ gọn. Nếu độ lệch bằng nhau
            # thì hơi ưu tiên dương vì dương cỡ lớn còn có thể hạ xuống cỡ bé.
            out.sort(key=lambda z: (z[0], -z[3], z[1], 0 if z[4] >= 0 else 1,
                                    max(z[2]), z[2]))
            return [(a, b, c) for a, b, c, _, _ in out[:keep]]

        def solve_lays(lays, beam_width=320):
            # V128: cap chiều dài riêng cho từng bàn dựa trên tương quan số lá.
            # VD max=4m, bàn chính 109 lá, bàn vét 4 lá -> bàn 4 lá chỉ được <=1.6m.
            _max_lay_in_set = max(int(n) for n in lays) if lays else 0
            _dynamic_caps = tuple(dynamic_marker_cap(int(n), _max_lay_in_set) for n in lays)

            opts_all = []
            for k in keys:
                oo = options_for_size(k, lays)
                if not oo:
                    return None
                opts_all.append((k, oo))

            m = len(lays)
            # over, ratio_total, lengths, ratios_per_table, dicts
            beam = [(0, 0, tuple(0.0 for _ in range(m)),
                     tuple(0 for _ in range(m)), tuple({} for _ in range(m)))]

            for k, opts in opts_all:
                nxt = []
                for ov, rt, lens, rps, dicts in beam:
                    for addov, addr, rr in opts:
                        nl = list(lens)
                        np = list(rps)
                        nd = [dict(d) for d in dicts]
                        bad = False
                        for j, r in enumerate(rr):
                            if not r:
                                continue
                            np[j] += r
                            if max_products > 0 and np[j] > max_products:
                                bad = True
                                break
                            nl[j] += slen[k] * r
                            _cap_j = _dynamic_caps[j] if j < len(_dynamic_caps) else max_len
                            if _cap_j > 0 and nl[j] > _cap_j + 1e-9:
                                bad = True
                                break
                            nd[j][k] = r
                        if not bad:
                            nxt.append((ov + addov, rt + addr, tuple(nl),
                                        tuple(np), tuple(nd)))
                if not nxt:
                    return None

                # Beam ưu tiên trước hết khả năng ghép: nhiều bàn đã có >=2 cỡ,
                # sau đó dương thấp và chiều dài cân đối.
                def partial_score(x):
                    ov, rt, lens, rps, dicts = x
                    counts = [len(d) for d in dicts]
                    multi = sum(1 for c in counts if c >= 2)
                    used = sum(1 for c in counts if c >= 1)
                    single = sum(1 for c in counts if c == 1)

                    # V119: beam chỉ giữ tiêu chí khả thi/chất lượng chính.
                    # Không đưa quy tắc bàn cuối vào đây vì có thể loại sớm một
                    # trạng thái đang cần thiết để ghép đủ sản lượng ở bước sau.
                    return (ov, -multi, -used, single, rt,
                            max(lens) if lens else 0,
                            (max(lens) - min(lens)) if lens else 0)

                nxt.sort(key=partial_score)
                beam = nxt[:beam_width]

            best = None
            for st in beam:
                ov, rt, lens, rps, dicts = st
                if any(not d for d in dicts):
                    continue
                if any(L + 1e-9 < min_len for L in lens):
                    continue
                # V128: kiểm tra lại cap động ở nghiệm hoàn chỉnh.
                if any((_dynamic_caps[j] > 0 and float(lens[j]) > float(_dynamic_caps[j]) + 1e-9)
                       for j in range(m)):
                    continue

                size_counts = [len(d) for d in dicts]
                singleton_count = sum(1 for c in size_counts if c <= 1)
                multi_count = sum(1 for c in size_counts if c >= 2)

                # Nếu thực sự có thể ghép cỡ thì không nhận phương án tất cả bàn
                # đều đơn cỡ. Một bàn đuôi đơn cỡ vẫn được phép.
                if m > 1 and singleton_count == m and merge_physically_possible:
                    continue

                # Tính sản lượng thực của từng cỡ từ toàn bộ bàn.
                actual = {k: 0 for k in keys}
                for j, d in enumerate(dicts):
                    for k, r in d.items():
                        actual[k] += int(r) * int(lays[j])

                raw_diff = {k: int(actual.get(k, 0)) - int(total_by_size[k]) for k in keys}
                # Dương thô của từng cỡ vẫn không vượt profile.
                if any(raw_diff[k] > over_limit(k) for k in keys):
                    continue

                transfers = []
                residual_under = {k: max(0, -raw_diff[k]) for k in keys}
                transfer_used = 0
                final_positive_surplus = sum(max(0, raw_diff[k]) for k in keys)

                if allow_under and downgrade_large_to_small:
                    # Hạ cỡ một chiều: cỡ LỚN -> cỡ BÉ. Đi từ cỡ lớn về bé,
                    # giữ lượng dương chưa dùng của cỡ lớn làm nguồn bù.
                    sources = []  # [size_key, qty_available]
                    residual_under = {k: 0 for k in keys}
                    for k in reversed(keys):
                        d = raw_diff[k]
                        if d > 0:
                            sources.append([k, int(d)])
                            continue
                        if d >= 0:
                            continue
                        need = int(-d)
                        # Dùng cỡ lớn GẦN NHẤT trước.
                        for src in reversed(sources):
                            if need <= 0:
                                break
                            if src[1] <= 0:
                                continue
                            use = min(need, src[1])
                            if use > 0:
                                transfers.append((src[0], k, use))
                                src[1] -= use
                                need -= use
                                transfer_used += use
                        residual_under[k] = need
                    # Sau khi hạ cỡ, chỉ phần dương CHƯA DÙNG mới là dương thực sự.
                    final_positive_surplus = sum(max(0, int(src[1])) for src in sources)
                elif allow_under:
                    residual_under = {k: max(0, -raw_diff[k]) for k in keys}
                    final_positive_surplus = sum(max(0, raw_diff[k]) for k in keys)
                else:
                    # Các nhóm vải khác không được âm.
                    if any(raw_diff[k] < 0 for k in keys):
                        continue
                    residual_under = {k: 0 for k in keys}
                    final_positive_surplus = sum(max(0, raw_diff[k]) for k in keys)

                # Với DỰNG/BÔNG, chỉ phần âm CÒN LẠI sau khi hạ cỡ mới phải
                # nằm trong giới hạn âm của cỡ đó.
                if allow_under and any(residual_under[k] > under_limit(k) for k in keys):
                    continue

                # V117: DỰNG/BÔNG không được chấp nhận phương án dương tổng quá rộng.
                # Tổng dương này được tính SAU khi cỡ lớn đã hạ xuống bù cỡ bé.
                if allow_under and total_surplus_cap >= 0 and final_positive_surplus > total_surplus_cap:
                    continue

                residual_short = sum(residual_under.values())
                total_abs_diff = sum(abs(v) for v in raw_diff.values())
                balanced_abs_diff = residual_short + final_positive_surplus

                # Không ép cứng mọi bàn phải >=2 cỡ; chấm phạt bàn đơn cỡ.
                total_size_links = sum(size_counts)
                target_mid = ((min_len + max_len) / 2.0) if max_len > 0 else min_len
                length_pen = sum(abs(L - target_mid) for L in lens)

                # V119 - quy tắc chung cho TẤT CẢ LOẠI VẢI:
                # bàn có SỐ LÁ ÍT NHẤT là bàn vét/bàn cuối. Khi so các phương án
                # cùng chất lượng sản lượng, ưu tiên bàn này có:
                #   1) tổng tỷ lệ ít hơn;
                #   2) chiều dài sơ đồ ngắn hơn;
                #   3) ít cỡ hơn.
                tail_idx = min(range(m), key=lambda j: (int(lays[j]), j))
                tail_ratio_total = int(rps[tail_idx])
                tail_length = float(lens[tail_idx])
                tail_size_count = int(size_counts[tail_idx])

                # V128: ngoài giới hạn cứng ở trên, còn ưu tiên mềm để bàn ít lá
                # tự chọn tỷ lệ ít và chiều dài ngắn hơn trong các nghiệm cùng chất lượng.
                _max_lay_score = max(int(n) for n in lays) if lays else 1
                low_ply_length_score = 0.0
                for _j in range(m):
                    _share = float(lays[_j]) / float(max(1, _max_lay_score))
                    # Bàn càng ít lá thì trọng số chiều dài càng lớn.
                    low_ply_length_score += float(lens[_j]) * max(0.0, 1.0 - _share)

                if allow_under:
                    # V117 - thứ tự ưu tiên cho DỰNG/BÔNG:
                    # 1) âm còn lại sau hạ cỡ thấp nhất;
                    # 2) dương thực sự sau hạ cỡ thấp nhất;
                    # 3) ít bàn hơn;
                    # 4) nhiều lá hơn;
                    # 5) marker hợp lý / ghép cỡ tốt.
                    score = (
                        residual_short,
                        final_positive_surplus,
                        m,
                        transfer_used,
                        # V128: cùng chất lượng sản lượng/số bàn thì bàn ít lá phải gọn trước.
                        tail_ratio_total,
                        tail_length,
                        low_ply_length_score,
                        -sum(lays),
                        singleton_count,
                        -multi_count,
                        -total_size_links,
                        balanced_abs_diff,
                        total_abs_diff,
                        length_pen,
                        rt,
                        max(lens),
                        max(lens) - min(lens),
                        -min(lays),
                        tail_size_count,
                    )
                else:
                    score = (
                        ov,                         # dương thấp nhất
                        # V128: sau dương, ưu tiên bàn ít lá có tỷ lệ/chiều dài gọn.
                        tail_ratio_total,
                        tail_length,
                        low_ply_length_score,
                        singleton_count,
                        -multi_count,
                        -total_size_links,
                        rt,
                        length_pen,
                        -sum(lays),
                        max(lens),
                        max(lens) - min(lens),
                        -min(lays),
                        tail_size_count,
                    )

                if best is None or score < best[0]:
                    # Gắn thông tin cân cỡ vào state phụ để lấy lại sau khi chọn.
                    best = (score, st, {
                        'raw_diff': raw_diff,
                        'residual_under': residual_under,
                        'transfers': transfers,
                        'transfer_used': transfer_used,
                        'final_positive_surplus': final_positive_surplus,
                        'total_surplus_cap': total_surplus_cap,
                    })
            return best

        # Sinh số lá ứng viên quanh q/r. V105 giữ dải rộng hơn cho 2-4 bàn.
        cand = {min_lays}
        anchor_score = {}
        for k in keys:
            q = int(total_by_size[k])
            for r in range(1, ratio_cap + 1):
                base = int(round(q / r))
                for d in range(-8, 9):
                    n = base + d
                    if min_lays <= n <= max_lays:
                        cand.add(n)
        step = max(1, max_lays // 70)
        cand.update(range(min_lays, max_lays + 1, step))
        cand = sorted(cand)

        for n in cand:
            anchor_score[n] = min(
                abs(n - int(round(int(total_by_size[k]) / r)))
                for k in keys for r in range(1, ratio_cap + 1)
            )

        # Không cắt cand quá mạnh như V104 vì có thể làm mất đúng số lá cần ghép.
        if len(cand) > 130:
            keep = {n for _, n in sorted((anchor_score[n], n) for n in cand)[:105]}
            keep.update(cand[::max(1, len(cand) // 24)])
            cand = sorted(keep)

        # Tập gọn cho 4-6 bàn phải giữ cả các số lá "phần dư". Ví dụ một
        # cỡ 229 có thể được chia 203 + 26; nếu chỉ giữ q/r thì số 26 biến mất.
        exact_anchors = set()
        split_values = set()
        qvals = [int(total_by_size[k]) for k in keys]
        for qv in qvals:
            for r in range(1, ratio_cap + 1):
                for n in (qv // r, int(math.ceil(qv / r))):
                    if min_lays <= n <= max_lays:
                        exact_anchors.add(n)
        for a in qvals:
            for b in qvals:
                if a <= b:
                    continue
                d = a - b
                if min_lays <= d <= max_lays:
                    split_values.add(d)
                for r in range(2, min(ratio_cap, 4) + 1):
                    for bb in (b // r, int(math.ceil(b / r))):
                        d2 = a - bb
                        if min_lays <= d2 <= max_lays:
                            split_values.add(d2)

        compact_pool = set(sorted(cand, key=lambda n: (anchor_score[n], -n))[:16])
        compact_pool.update(exact_anchors)
        compact_pool.update(split_values)
        compact_pool = {n for n in compact_pool if min_lays <= n <= max_lays}

        def compact_score(n):
            support = 0
            for qv in qvals:
                _tol = max(max(over_limit(k), under_limit(k)) for k in keys)
                if any(abs(qv - r*n) <= _tol
                       for r in range(1, ratio_cap + 1)):
                    support += 3
            for a in qvals:
                for b in qvals:
                    if a > b and abs((a-b) - n) <= 3:
                        support += 2
            return (-support, anchor_score.get(n, 9999), -n)

        _compact_keep = 18 if allow_under else 24
        compact = sorted(compact_pool, key=compact_score)[:_compact_keep]
        compact = sorted(compact)

        # Tập số lá dùng cho tìm 2-3 bàn: DỰNG/BÔNG dùng tập gọn hơn để vẫn
        # thử được nhiều số bàn mà không làm chậm xuất Excel.
        _search_keep = 18 if allow_under else 22
        search_cand = sorted(cand, key=lambda n: (anchor_score[n], -n))[:_search_keep]
        search_cand = sorted(set(search_cand + [cand[0], cand[-1]]))

        # V107 FAST PREFILTER: V106 gọi options_for_size() cho HÀNG NGHÌN
        # tổ hợp số lá chỉ để xếp hạng. Đây là phần làm TOÀN CỤC rất chậm.
        # Ta chỉ kiểm tra nhanh khả năng biểu diễn SL bằng DP số nguyên; chỉ các
        # tổ hợp tốt nhất mới đi vào solve_lays() đầy đủ (chiều dài/ghép cỡ).
        from bisect import bisect_left as _bisect_left
        max_hi_all = max(int(total_by_size[k]) + over_limit(k) for k in keys)
        _reach_cache = {}

        def _reachable_outputs(lays):
            lays = tuple(lays)
            hit = _reach_cache.get(lays)
            if hit is not None:
                return hit
            reachable = {0}
            for n in lays:
                nxt = set()
                for got in reachable:
                    max_r = min(ratio_cap, (max_hi_all - got) // n)
                    for r in range(max_r + 1):
                        nxt.add(got + r * n)
                reachable = nxt
                if not reachable:
                    break
            vals = tuple(sorted(reachable))
            _reach_cache[lays] = vals
            return vals

        def _cheap_combo_score(lays):
            vals = _reachable_outputs(lays)
            if not vals:
                return None
            total_dev = 0
            for k in keys:
                q = int(total_by_size[k])
                if allow_under:
                    _idx = keys.index(k)
                    _transfer_cap = (sum(over_limit(x) for x in keys[_idx + 1:])
                                     if downgrade_large_to_small else 0)
                    lo = max(0, q - under_limit(k) - _transfer_cap)
                else:
                    lo = q
                hi = q + over_limit(k)
                left = _bisect_left(vals, lo)
                right = _bisect_left(vals, hi + 1)
                if left >= right:
                    return None
                pos = _bisect_left(vals, q)
                candidates = []
                for ii in (left, right - 1, pos, pos - 1):
                    if left <= ii < right:
                        candidates.append(vals[ii])
                if not candidates:
                    return None
                best_v = min(candidates, key=lambda v: (abs(v - q), 0 if v >= q else 1, v))
                total_dev += abs(best_v - q) if allow_under else max(0, best_v - q)
            # Sau độ lệch, ưu tiên các số lá gần điểm q/r rồi tổng lá cao.
            anch = sum(anchor_score.get(n, 9999) for n in lays)
            return (total_dev, anch, -sum(lays), max(lays) - min(lays))

        # 4-6 bàn dùng tập nhỏ hơn để tránh C(24,6)=134,596 tổ hợp.
        # 18 ứng viên vẫn giữ các điểm q/r và số lá phần dư quan trọng.
        _large_keep = 12 if allow_under else 18
        compact_large_ranked = sorted(compact_pool, key=compact_score)[:_large_keep]
        compact_large = sorted(compact_large_ranked)

        chosen = None
        _search_all_table_counts = bool(allow_under and total_surplus_cap >= 0)

        def _keep_solution(sol, lays):
            nonlocal chosen
            if sol is None:
                return
            candidate = (sol[0], tuple(lays), sol[1], sol[2])
            if chosen is None or candidate[0] < chosen[0]:
                chosen = candidate

        def _primary_perfect():
            # Với DỰNG/BÔNG, 0 âm còn lại + 0 dương sau hạ cỡ là tối ưu tuyệt đối
            # cho hai tiêu chí quan trọng nhất; không cần thử thêm nhiều bàn hơn.
            return bool(_search_all_table_counts and chosen is not None
                        and len(chosen[0]) >= 2
                        and chosen[0][0] == 0 and chosen[0][1] == 0)

        def _fast_flexible_good_enough():
            """V125: với BÔNG/DỰNG định mức nhỏ, sau khi đã thử 2 bàn thì
            dừng sớm nếu không còn âm sau hạ cỡ và lượng hạ cỡ ở mức nhỏ.
            Tránh tiếp tục quét 3-6 bàn rất lâu chỉ để cải thiện vài sản phẩm.
            """
            if not _fast_low_norm_mode or chosen is None or len(chosen) < 4:
                return False
            bi = chosen[3] if isinstance(chosen[3], dict) else {}
            residual = sum(max(0, int(v or 0)) for v in (bi.get('residual_under', {}) or {}).values())
            positive = int(bi.get('final_positive_surplus', 0) or 0)
            transfer = int(bi.get('transfer_used', 0) or 0)
            total_target = sum(int(total_by_size.get(k, 0) or 0) for k in keys)
            soft_transfer = max(5,
                                (int(total_surplus_cap) + 5) if total_surplus_cap >= 0 else 30,
                                int(math.floor(total_target * 0.012 + 1e-9)))
            pos_cap = int(total_surplus_cap) if total_surplus_cap >= 0 else max(3, int(total_target * 0.01))
            return residual == 0 and positive <= pos_cap and transfer <= soft_transfer

        # 1 bàn
        for n in search_cand:
            sol = solve_lays((n,), beam_width=350)
            if sol is not None:
                _keep_solution(sol, (n,))
                if _primary_perfect():
                    break
        # Với các loại vải thường, nếu 1 bàn đã có nghiệm thì giữ nguyên ưu tiên
        # ít bàn như trước. DỰNG/BÔNG phải tiếp tục thử 2..6 bàn để so tổng dương.
        if chosen is not None and not _search_all_table_counts:
            pass
        else:
            # 2 bàn: DP nhẹ để xếp hạng, solver sâu cho nhóm ứng viên tốt.
            ranked = []
            for lays in _comb(search_cand, 2):
                if math.gcd(lays[0], lays[1]) > 3:
                    continue
                cs = _cheap_combo_score(lays)
                if cs is not None:
                    ranked.append((*cs, lays))
            ranked.sort()
            _found_for_count = False
            _feasible_seen = 0
            for *_, lays in ranked[:140]:
                sol = solve_lays(lays, beam_width=320)
                if sol is None:
                    continue
                _keep_solution(sol, lays)
                _found_for_count = True
                _feasible_seen += 1
                if _primary_perfect():
                    break
                # V118: vải thường vẫn ưu tiên ít bàn, nhưng thử thêm một nhóm nhỏ
                # nghiệm CÙNG số bàn để chọn được bàn ít lá có tỷ lệ/chiều dài đẹp.
                if (not _search_all_table_counts) and _feasible_seen >= 12:
                    break

            # 3 bàn
            if (not _primary_perfect()) and (not _fast_flexible_good_enough()) and (_search_all_table_counts or (chosen is None)):
                ranked = []
                for lays in _comb(compact, 3):
                    if math.gcd(math.gcd(lays[0], lays[1]), lays[2]) > 3:
                        continue
                    cs = _cheap_combo_score(lays)
                    if cs is not None:
                        ranked.append((*cs, lays))
                ranked.sort()
                _feasible_seen = 0
                for *_, lays in ranked[:200]:
                    sol = solve_lays(lays, beam_width=380)
                    if sol is None:
                        continue
                    _keep_solution(sol, lays)
                    _feasible_seen += 1
                    if _primary_perfect():
                        break
                    if (not _search_all_table_counts) and _feasible_seen >= 14:
                        break

            # 4..6 bàn
            for table_count in range(4, 7):
                if _primary_perfect() or _fast_flexible_good_enough():
                    break
                if chosen is not None and not _search_all_table_counts:
                    break
                ranked = []
                for lays in _comb(compact_large, table_count):
                    g = lays[0]
                    for n in lays[1:]:
                        g = math.gcd(g, n)
                    if g > 3:
                        continue
                    cs = _cheap_combo_score(lays)
                    if cs is not None:
                        ranked.append((*cs, lays))
                ranked.sort()
                limit = 120 if table_count == 4 else (90 if table_count == 5 else 60)
                _feasible_seen = 0
                for *_, lays in ranked[:limit]:
                    sol = solve_lays(lays, beam_width=320)
                    if sol is None:
                        continue
                    _keep_solution(sol, lays)
                    _feasible_seen += 1
                    if _primary_perfect():
                        break
                    if (not _search_all_table_counts) and _feasible_seen >= 8:
                        break

        if chosen is None:
            # V120: trước tiên dùng bộ cứu hộ khả thi 1-2 bàn/cỡ. Bộ này mạnh hơn
            # build_forced_singletons vì không bắt q phải gần đúng một bội r*n.
            # Nhờ vậy không còn trường hợp beam bỏ sót nghiệm rồi báo thiếu toàn bộ
            # 100/110/120/... dù thực tế vẫn có thể trải trong Min-Max.
            emergency = build_feasible_emergency()
            if emergency is not None:
                return emergency, {
                    'unresolved': {},
                    'optimizer': f'global_v120_emergency_{len(emergency)}_tables',
                    'note': ('Bộ toàn cục không tìm được nghiệm trong vùng beam; '
                             'đã dùng bộ cứu hộ khả thi 1-2 bàn/cỡ và ghép lại các bàn cùng số lá.')
                }

            # Fallback đơn cỡ 1 bàn/cỡ cũ vẫn giữ lại cho trường hợp đơn giản.
            rescue = build_forced_singletons()
            if rescue is not None:
                # V117: DỰNG/BÔNG cũng phải tôn trọng giới hạn dương tổng 1%.
                if allow_under and total_surplus_cap >= 0:
                    _r_actual = {k: 0 for k in keys}
                    for _tb in rescue:
                        for _k, _v in (_tb.get('sizes', {}) or {}).items():
                            _r_actual[_k] = _r_actual.get(_k, 0) + int(_v or 0)
                    _r_pos = sum(max(0, int(_r_actual.get(k, 0)) - int(total_by_size[k])) for k in keys)
                    if _r_pos > total_surplus_cap:
                        rescue = None
                if rescue is not None:
                    return rescue, {
                        'unresolved': {},
                        'optimizer': 'global_v120_rescue_singletons',
                        'note': 'Bộ tối ưu toàn cục không tìm được tổ hợp ghép cỡ; dùng phương án cứu hộ đủ sản lượng trong giới hạn dương tổng.'
                    }
            # V119: nếu beam toàn cục bỏ sót nghiệm, thử thuật toán tuần tự như
            # một phương án cứu hộ THỰC SỰ trước khi báo thiếu toàn bộ. Kết quả
            # cứu hộ vẫn phải đủ sản lượng theo điều kiện của loại vải.
            try:
                _seq_tables, _seq_info = self.optimize_cutting(
                    dict(total_by_size), dict(size_factor), norm, max_len,
                    max_products, fabric_mode, min_marker_length, balance_pct
                )
                if _seq_tables and not (_seq_info or {}).get('unresolved'):
                    _seq_info = dict(_seq_info or {})
                    _seq_info['optimizer'] = 'global_v120_rescue_sequential'
                    _seq_info['note'] = ('Bộ toàn cục không tìm được nghiệm trong vùng beam; '
                                         'đã dùng phương án cứu hộ tuần tự đủ sản lượng.')
                    return _seq_tables, _seq_info
            except Exception:
                pass
            return [], {'unresolved': {k: int(total_by_size[k]) for k in keys},
                        'optimizer': 'global_v120_no_solution'}

        score, lays, st, balance_info = chosen
        ov, rt, lens, rps, dicts = st
        tables = []
        for idx, (n, L, ratios) in enumerate(zip(lays, lens, dicts), start=1):
            sizes = {k: int(r) * n for k, r in ratios.items() if int(r) > 0}
            tables.append({
                'table': f'B{idx}', 'sizes': sizes, 'ratio': fmt(ratios), 'length': L,
                'raw_length': L, 'plies': n, 'ratio_map': dict(ratios),
                'total_output': sum(sizes.values()), 'size_count': len(ratios),
                'left_total': 0, 'small_left_count': 0, 'small_left_sum': 0,
                'zeroed': 0, 'over_total': 0, 'size_span': 0,
                'meter_rate': L / max(1, sum(ratios.values()))
            })
        return tables, {
            'unresolved': {},
            'optimizer': f'global_v128_{len(tables)}_tables',
            'fabric_mode': profile.get('mode', fabric_mode),
            'fabric_mode_label': profile.get('label', ''),
            'over_limits': over_limits,
            'under_limits': under_limits,
            'allow_under': allow_under,
            'downgrade_large_to_small': downgrade_large_to_small,
            'raw_diff': dict(balance_info.get('raw_diff', {})),
            'residual_under': dict(balance_info.get('residual_under', {})),
            'size_transfers': list(balance_info.get('transfers', [])),
            'transfer_used': int(balance_info.get('transfer_used', 0) or 0),
            'final_positive_surplus': int(balance_info.get('final_positive_surplus', 0) or 0),
            'total_surplus_cap': int(balance_info.get('total_surplus_cap', total_surplus_cap) or 0),
            'total_surplus_pct': total_surplus_pct,
        }

    def optimize_cutting(self, total_by_size, size_factor, norm, max_len, max_products=0, fabric_mode='main', min_marker_length=1.0, balance_pct=1.0):
        """V81: tối ưu theo chế độ giác của từng nhóm vật tư.

        Vải chính = chính xác; Vải lót = nhiều cỡ; Kẹp tầng = ít bàn/tỷ lệ gọn;
        Dựng-Mex = tỷ lệ lớn, tránh marker quá ngắn; Bông = ít bàn/tận dụng khổ.
        MỌI BÀN, kể cả bàn cuối, phải có chiều dài sơ đồ >= min_marker_length.
        Giá trị này lưu RIÊNG cho từng loại vải; mặc định gợi ý 1,00 m và người dùng có thể sửa.
        """
        tables = []
        name_map = {s['key']: s['name'] for s in self.sizes}
        size_order = {s['key']: i for i, s in enumerate(self.sizes)}

        profile = self._fabric_cut_profile(fabric_mode, total_by_size, norm, max_len, balance_pct)
        over_limits = dict(profile.get('over_limits', {}))
        under_limits = dict(profile.get('under_limits', {}))
        allow_under = bool(profile.get('allow_under', False))
        downgrade_large_to_small = bool(profile.get('downgrade_large_to_small', False))
        total_surplus_cap = int(profile.get('total_surplus_cap', -1))
        total_surplus_pct = float(profile.get('total_surplus_pct', 0.0) or 0.0)
        max_over_any = max(0, int(profile.get('max_over_any', self.MAX_OVER) or 0))
        target_min_marker = max(0.0, float(profile.get('target_min_marker', 0.0) or 0.0))
        merge_style = str(profile.get('merge_style', 'balanced') or 'balanced')
        score_style = str(profile.get('score_style', 'exact') or 'exact')
        prefer_size_spread = bool(profile.get('prefer_size_spread', False))

        def over_limit_for(size_key):
            return max(0, int(over_limits.get(size_key, self.MAX_OVER) or 0))

        def under_limit_for(size_key):
            return max(0, int(under_limits.get(size_key, 0) or 0)) if allow_under else 0

        def format_ratio(ratios):
            # Luôn hiển thị từ cỡ bé -> lớn theo thứ tự size trên giao diện.
            ordered = sorted(
                ((k, int(v)) for k, v in ratios.items() if int(v) > 0),
                key=lambda kv: size_order.get(kv[0], 10**6)
            )
            return ' + '.join(f"{name_map.get(k, k)}/{v}" for k, v in ordered)

        size_length = {}
        remaining = {}

        for size, qty in total_by_size.items():
            qty = int(qty or 0)
            if qty <= 0:
                continue
            # V127: chiều dài 1 đơn vị tỷ lệ = DMTB, không nhân hệ số cỡ.
            length = float(norm)
            if length <= 0:
                continue
            size_length[size] = length
            remaining[size] = qty

        if not remaining:
            return tables, {'unresolved': {}}

        max_len = max(0.0, float(max_len or 0))
        try:
            max_products = max(0, int(float(max_products or 0)))
        except Exception:
            max_products = 0

        # V76: sàn chiều dài sơ đồ lấy RIÊNG từ từng loại vải và áp dụng cho tất cả bàn.
        # Nếu người dùng đặt chiều dài tối đa < sàn này thì bài toán không thể hợp lệ.
        HARD_MIN_MARKER_LENGTH = max(0.0, float(min_marker_length if min_marker_length is not None else 1.0))
        if max_len > 0 and max_len + 1e-9 < HARD_MIN_MARKER_LENGTH:
            raise ValueError(
                f"Chiều dài sơ đồ tối đa {max_len:.2f} m nhỏ hơn chiều dài tối thiểu "
                f"{HARD_MIN_MARKER_LENGTH:.2f} m. Hãy tăng Chiều dài tối đa."
            )

        # Mục tiêu riêng từng loại vẫn được giữ (Lót 1.2m, Mex 1.5m...),
        # nhưng tuyệt đối không loại nào được có mục tiêu thấp hơn sàn 1m.
        target_min_marker = max(HARD_MIN_MARKER_LENGTH, target_min_marker)
        if max_len > 0:
            target_min_marker = min(target_min_marker, max_len)

        if max_len <= 0 and max_products <= 0:
            return tables, {'unresolved': dict(remaining)}

        # Làm tròn về mm để tránh sai số float. Nếu không giới hạn chiều dài
        # thì dùng một sức chứa rất lớn; khi đó chỉ giới hạn theo SP / sơ đồ.
        scale = 1000
        length_int = {s: max(1, int(round(v * scale))) for s, v in size_length.items()}
        cap_int = max(1, int(round(max_len * scale))) if max_len > 0 else 10**15

        # V129: áp dụng cùng quy tắc "ít lá -> marker ngắn" cho cả TUẦN TỰ.
        # So số lá của bàn đang xét với bàn nhiều lá nhất đã có trong kế hoạch.
        #   <=10%: tối đa 40% MAX; <=25%: 60%; <=50%: 80%; >50%: 100%.
        # Không bao giờ ép thấp hơn chiều dài tối thiểu người dùng đã nhập.
        def sequential_dynamic_marker_cap(plies, reference_tables=None):
            if max_len <= 0:
                return None
            try:
                p = max(1, int(plies or 0))
            except Exception:
                p = 1
            refs = [p]
            src_tabs = tables if reference_tables is None else reference_tables
            for tb in (src_tabs or []):
                try:
                    tp = int(tb.get('plies', 0) or 0)
                except Exception:
                    tp = 0
                if tp > 0:
                    refs.append(tp)
            max_p = max(refs) if refs else p
            share = float(p) / float(max(1, max_p))
            if share <= 0.10 + 1e-12:
                frac = 0.40
            elif share <= 0.25 + 1e-12:
                frac = 0.60
            elif share <= 0.50 + 1e-12:
                frac = 0.80
            else:
                frac = 1.00
            return min(max_len, max(HARD_MIN_MARKER_LENGTH, max_len * frac))

        def marker_within_limits(ratios, raw_len=None, plies=None, reference_tables=None):
            if max_products > 0 and sum(max(0, int(v)) for v in ratios.values()) > max_products:
                return False
            if raw_len is None:
                raw_len = sum(float(size_length[k]) * int(v) for k, v in ratios.items())
            if max_len > 0 and float(raw_len) > max_len + 1e-9:
                return False
            if plies is not None:
                dyn_cap = sequential_dynamic_marker_cap(plies, reference_tables)
                if dyn_cap is not None and float(raw_len) > float(dyn_cap) + 1e-9:
                    return False
            return True

        # V76: dùng đúng chiều dài thực của marker và áp dụng sàn riêng của loại vải cho MỌI bàn.
        # target_min_marker chỉ là mức ƯU TIÊN riêng của từng loại vật tư;
        # HARD_MIN_MARKER_LENGTH mới là giới hạn cứng không được thấp hơn.
        MIN_MARKER_LENGTH = HARD_MIN_MARKER_LENGTH
        FINAL_MIN_MARKER_LENGTH = HARD_MIN_MARKER_LENGTH

        def build_candidate(source_remaining, lays, preferred_main=None):
            """Tao 1 marker tai mot muc so la, cho phep dương toi da 3 SP/co."""
            if not source_remaining or lays < 4:
                return None

            # Co duoc tham gia neu voi so la nay phan dương khong vuot MAX_OVER.
            eligible = [
                s for s, q in source_remaining.items()
                if q + over_limit_for(s) >= lays
            ]
            if not eligible:
                return None

            # V71: không ép cặp nhỏ/lớn; bàn chính ưu tiên ghép nhiều cỡ.
            # Cỡ nào đi với cỡ nào không quan trọng; chương trình chọn từng nhịp
            # tỷ lệ theo hiệu quả thực tế của bàn cắt:
            #   1) tránh tạo phần thiếu 1..3 SP;
            #   2) hạn chế sản lượng dương / cắt thừa;
            #   3) ưu tiên triệt tiêu cỡ đang còn;
            #   4) tận dụng chiều dài marker còn trống tốt nhất.
            # Nhờ vậy thứ tự XS/S/M/L/XL không còn là tiêu chí ghép cỡ.
            # Cỡ chính (SL còn lớn nhất) chỉ được dùng làm điểm bắt đầu để giữ
            # mục tiêu ít bàn; các tỷ lệ tiếp theo được chọn hoàn toàn theo điểm tối ưu.
            ratios = {}
            used = 0
            ratio_pieces = 0

            # V129: TUẦN TỰ cũng dùng cap động theo số lá của bàn.
            dyn_cap = sequential_dynamic_marker_cap(lays)
            dyn_cap_int = cap_int if dyn_cap is None else max(1, int(round(dyn_cap * scale)))

            # Tỷ lệ tối đa hợp lệ của từng cỡ tại mức số lá hiện tại.
            max_ratio_map = {}
            for s in eligible:
                max_ratio = int((source_remaining[s] + over_limit_for(s)) // lays)
                if max_ratio <= 0:
                    continue
                max_ratio = min(max_ratio, int(dyn_cap_int // length_int[s]))
                if max_products > 0:
                    max_ratio = min(max_ratio, int(max_products))
                if max_ratio > 0:
                    max_ratio_map[s] = max_ratio

            if not max_ratio_map:
                return None

            # Bắt đầu bằng cỡ chính nếu có thể. Nếu cỡ chính không thể nằm trên
            # marker thì lấy cỡ còn lại có SL lớn nhất, không dựa vào vị trí size.
            if preferred_main in max_ratio_map:
                start_size = preferred_main
            else:
                start_size = max(
                    max_ratio_map,
                    key=lambda s: (source_remaining[s], -length_int[s], str(s))
                )

            ratios[start_size] = 1
            used = length_int[start_size]
            ratio_pieces = 1

            # Thêm từng nhịp tỷ lệ. Mỗi lần đều xét TẤT CẢ cỡ có thể thêm,
            # kể cả tăng tỷ lệ cỡ đã có hoặc thêm một cỡ mới. Đây là điểm khác
            # V65: không có danh sách cặp nhỏ-lớn cố định nữa.
            while True:
                if max_products > 0 and ratio_pieces >= max_products:
                    break

                options = []
                for s, max_ratio in max_ratio_map.items():
                    cur_ratio = int(ratios.get(s, 0))
                    if cur_ratio >= max_ratio:
                        continue
                    if used + length_int[s] > dyn_cap_int:
                        continue

                    q = int(source_remaining[s])
                    before_prod = cur_ratio * lays
                    after_prod = (cur_ratio + 1) * lays
                    before_left = max(0, q - before_prod)
                    after_left = max(0, q - after_prod)
                    after_over = max(0, after_prod - q)

                    small_left_penalty = 1 if 0 < after_left < 4 else 0
                    zero_penalty = 0 if after_left == 0 else 1
                    useful_added = min(lays, before_left)
                    gap_after = (dyn_cap_int - (used + length_int[s])) if max_len > 0 else 0

                    # V71: với bàn nhiều lá (bàn đầu/bàn chính), ưu tiên THÊM CỠ MỚI
                    # để một marker ghép được nhiều cỡ. Với bàn ít lá (bàn vét/bàn cuối),
                    # không cần ép ghép cỡ; ưu tiên giữ marker gọn và giảm dương.
                    low_plies_limit = max(4, int(getattr(self, 'MIN_PREFERRED_PLIES', 10)))
                    prefer_merge = lays >= low_plies_limit
                    is_new_size = s not in ratios
                    if merge_style == 'strong':
                        merge_penalty = 0 if is_new_size else (2 if prefer_merge else 1)
                    elif merge_style == 'simple':
                        merge_penalty = 2 if is_new_size else 0
                    else:
                        merge_penalty = (0 if is_new_size else 1) if prefer_merge else (1 if is_new_size else 0)

                    # Vải chính/lót/mex/bông: khi thêm cỡ mới, ưu tiên mở rộng
                    # khoảng size (cỡ nhỏ + cỡ lớn) để tăng cơ hội lấp khoảng trống khi giác CAD.
                    spread_gain = 0
                    if prefer_size_spread and is_new_size and ratios:
                        old_idx = [size_order.get(k, 0) for k in ratios]
                        old_span = max(old_idx) - min(old_idx) if old_idx else 0
                        new_idx = old_idx + [size_order.get(s, 0)]
                        new_span = max(new_idx) - min(new_idx) if new_idx else 0
                        spread_gain = max(0, new_span - old_span)

                    option_score = (
                        small_left_penalty,
                        after_over,
                        merge_penalty,
                        -spread_gain,
                        zero_penalty,
                        -useful_added,
                        gap_after,
                        -before_left,
                        length_int[s],
                        str(s),
                    )
                    options.append((option_score, s))

                if not options:
                    break

                options.sort(key=lambda x: x[0])
                _, picked = options[0]
                ratios[picked] = int(ratios.get(picked, 0)) + 1
                used += length_int[picked]
                ratio_pieces += 1

            chosen = list(ratios.keys())
            if not chosen:
                return None

            produced = {s: ratios[s] * lays for s in chosen}
            over = {s: max(0, produced[s] - source_remaining[s]) for s in chosen}
            if any(v > over_limit_for(s) for s, v in over.items()):
                return None

            remaining_after = dict(source_remaining)
            for s, qty_cut in produced.items():
                remaining_after[s] = max(0, remaining_after[s] - qty_cut)

            raw_marker_len = sum(length_int[s] * ratios[s] for s in chosen) / scale
            if not marker_within_limits(ratios, raw_marker_len, plies=lays):
                return None
            display_marker_len = raw_marker_len
            small_left = [q for q in remaining_after.values() if 0 < q < 4]

            return {
                'sizes': produced,
                'ratio': format_ratio(ratios),
                'length': display_marker_len,
                'raw_length': raw_marker_len,
                'plies': lays,
                'ratio_map': ratios,
                'total_output': sum(produced.values()),
                'size_count': len(chosen),
                'left_total': sum(remaining_after.values()),
                'small_left_count': len(small_left),
                'small_left_sum': sum(small_left),
                'zeroed': sum(1 for s in chosen if remaining_after[s] == 0),
                'over_total': sum(over.values()),
                'size_span': (max([size_order.get(s, 0) for s in chosen]) - min([size_order.get(s, 0) for s in chosen])) if chosen else 0,
                'meter_rate': (raw_marker_len / max(1, sum(int(v) for v in ratios.values()))),
            }

        def choose_pattern(source_remaining):
            """
            V71 - bàn đầu ưu tiên ghép nhiều cỡ; bàn vét/bàn cuối không ép ghép.

            Thu tu uu tien:
            1) Ban hien tai phai co co dang con so luong LON NHAT (co chinh).
            2) Khong de lai phan thieu 1..3 SP neu co phuong an khac.
            3) Triet tieu duoc nhieu co nhat tren ban hien tai.
            4) Voi cung muc triet tieu, tang TY LE cua co chinh toi da trong
               chieu dai marker. Vi du M=243, DMTB=1.5, max=4.0 thi M/2
               (122 la, cat 244, duong 1) duoc uu tien hon M/1 x 243 la.
            5) Sau do moi uu tien duong it, san luong con lai it, nhieu size
               tren marker va tan dung chieu dai.
            """
            if not source_remaining:
                return None

            size_order = {s['key']: i for i, s in enumerate(self.sizes)}
            main_size = max(
                source_remaining,
                key=lambda s: (source_remaining[s], -size_order.get(s, 9999))
            )

            max_lays = max(source_remaining.values())
            best = None

            for lays in range(4, max_lays + 1):
                cand = build_candidate(source_remaining, lays, main_size)
                if cand is None:
                    continue

                main_ratio = int(cand.get('ratio_map', {}).get(main_size, 0))
                main_missing_penalty = 0 if main_ratio > 0 else 1
                # Chi uu tien ty le cao neu so la ly tuong cua co chinh van >= 4.
                # VD XS con 5SP: XS/2 can ly tuong 3 la (<4), khong nen ep thanh
                # 4 la de duong +3; XS/1 x 5 la se hop ly hon.
                if main_ratio > 0:
                    ideal_main_lays = (source_remaining[main_size] + main_ratio - 1) // main_ratio
                    effective_main_ratio = main_ratio if ideal_main_lays >= 4 else 0
                else:
                    effective_main_ratio = 0
                balance_cost = cand['left_total'] + 2 * cand['over_total']

                # V71:
                # - BÀN ĐẦU / BÀN CHÍNH (nhiều lá): ưu tiên ghép NHIỀU CỠ trước,
                #   sau đó mới so dương và độ tận dụng marker.
                # - BÀN VÉT / BÀN CUỐI (ít lá): KHÔNG ép ghép cỡ; ưu tiên ít cỡ,
                #   marker ngắn, dương thấp. Điều này cũng phù hợp yêu cầu bàn cuối
                #   ít cỡ + chiều dài sơ đồ ngắn.
                low_plies_limit = max(4, int(getattr(self, 'MIN_PREFERRED_PLIES', 10)))
                low_plies = cand['plies'] < low_plies_limit

                short_penalty = max(0.0, target_min_marker - float(cand['raw_length']))
                span_score = -int(cand.get('size_span', 0) or 0) if prefer_size_spread else 0
                low_plies_penalty = 1 if low_plies else 0

                # V73: mọi ứng viên dùng cùng cấu trúc điểm trong từng chế độ.
                # Không dùng hai tuple khác nghĩa cho bàn ít lá/nhiều lá vì điều đó
                # có thể khiến marker 4-9 lá thắng marker 100-200 lá chỉ do vị trí tuple.
                if score_style == 'exact':
                    # VẢI CHÍNH: dương thấp -> hoàn thành nhiều SL -> ít bàn -> hiệu suất marker.
                    score = (
                        main_missing_penalty, cand['over_total'], cand['left_total'],
                        cand['small_left_count'], low_plies_penalty, cand['meter_rate'],
                        span_score, -cand['size_count'], -effective_main_ratio,
                        -cand['zeroed'], -cand['raw_length'], -cand['total_output'], cand['plies'],
                    )
                elif score_style == 'lining':
                    # VẢI LÓT: marker đủ dài, nhiều cỡ và trải rộng size; vẫn kiểm soát dương.
                    score = (
                        main_missing_penalty, short_penalty, cand['over_total'],
                        cand['left_total'], cand['small_left_count'], low_plies_penalty,
                        -cand['size_count'], span_score, cand['meter_rate'],
                        -cand['total_output'], -cand['raw_length'], cand['plies'],
                    )
                elif score_style == 'high_ratio':
                    # DỰNG/MEX: tránh marker ngắn, tăng tỷ lệ/nhiều cỡ để có cơ hội kín khổ.
                    score = (
                        main_missing_penalty, short_penalty, cand['left_total'],
                        cand['small_left_count'], low_plies_penalty, -cand['size_count'],
                        span_score, cand['over_total'], cand['meter_rate'],
                        -cand['raw_length'], -cand['total_output'], cand['plies'],
                    )
                else:
                    # V73 - KẸP TẦNG/BÔNG đều ưu tiên ít bàn, nhưng KHÔNG được
                    # chọn một bàn chính dương quá lớn chỉ vì left_total nhỏ hơn.
                    #
                    # BÔNG: trước hết phân biệt phương án đã xong trong 1 bàn hay
                    # còn phải có bàn vét. Nếu đều còn cần bàn vét thì cân bằng
                    # (SL còn + 3 x SL dương) để giữ chỗ cho bàn cuối xử lý đẹp.
                    # Ví dụ BÔNG 80G trong ca thực tế: B1 x52 lá tạo +49 SP rồi
                    # vẫn phải B2. B1 x50 lá vẫn 2 bàn nhưng bàn vét có thể cân
                    # phần còn lại với dương rất thấp -> phải ưu tiên x50.
                    #
                    # KẸP TẦNG: vẫn ưu tiên ít bàn/tỷ lệ đơn giản hơn BÔNG vì vật
                    # tư ít quan trọng; tuy vậy cùng số bàn thì dương thấp hơn thắng.
                    simple_penalty = cand['size_count'] if merge_style == 'simple' else -cand['size_count']
                    needs_followup = 0 if int(cand['left_total']) <= 0 else 1
                    if profile.get('mode') == 'padding':
                        balance_cost = int(cand['left_total']) + 3 * int(cand['over_total'])
                        score = (
                            main_missing_penalty, needs_followup, balance_cost,
                            cand['over_total'], cand['small_left_count'], low_plies_penalty,
                            short_penalty, simple_penalty, span_score,
                            -cand['total_output'], cand['meter_rate'],
                            -cand['raw_length'], cand['plies'],
                        )
                    else:
                        balance_cost = int(cand['left_total']) + int(cand['over_total'])
                        score = (
                            main_missing_penalty, needs_followup, balance_cost,
                            low_plies_penalty, cand['over_total'], cand['small_left_count'],
                            short_penalty, simple_penalty, span_score,
                            -cand['total_output'], cand['meter_rate'],
                            -cand['raw_length'], cand['plies'],
                        )
                if best is None or score < best[0]:
                    best = (score, cand)

            return best[1] if best else None

        def calc_actual(source_tables):
            actual = {k: 0 for k in total_by_size}
            for table in source_tables:
                for k, v in table.get('sizes', {}).items():
                    actual[k] = actual.get(k, 0) + int(v)
            return actual

        def rebuild_table(table):
            """Tinh lai sizes/ratio/length sau khi sua ratio hoac so la."""
            ratios = dict(table.get('ratio_map', {}))
            lays = int(table.get('plies', 0))
            raw_len = sum(size_length[k] * r for k, r in ratios.items())
            table['raw_length'] = raw_len
            table['length'] = raw_len
            table['sizes'] = {k: int(r) * lays for k, r in ratios.items()}
            table['ratio'] = format_ratio(ratios)
            table['total_output'] = sum(table['sizes'].values())
            table['size_count'] = len(ratios)

        # V73: riêng BÔNG, khi đã có bàn chính thì thử đóng toàn bộ phần
        # còn lại bằng MỘT bàn cân. Tỷ lệ mỗi cỡ = ceil(SL còn / số lá).
        # Cách này ngăn trường hợp bàn chính cắt dương rất nhiều rồi bàn cuối
        # chỉ còn 1 cỡ cực ngắn. Với cùng 2 bàn, phương án dương thấp hơn thắng.
        def build_padding_finish_candidate(source_remaining):
            if profile.get('mode') != 'padding' or not source_remaining:
                return None
            upper = max(
                [int(q) + over_limit_for(s) for s, q in source_remaining.items()] or [4]
            )
            best = None
            for lays in range(4, max(4, upper) + 1):
                ratios = {}
                produced = {}
                valid = True
                for s, q in source_remaining.items():
                    q = int(q or 0)
                    if q <= 0:
                        continue
                    r = int(math.ceil(q / lays))
                    if r <= 0:
                        continue
                    cut = r * lays
                    if cut - q > over_limit_for(s):
                        valid = False
                        break
                    ratios[s] = r
                    produced[s] = cut
                if not valid or not ratios:
                    continue
                raw_len = sum(float(size_length[s]) * int(r) for s, r in ratios.items())
                if not marker_within_limits(ratios, raw_len, plies=lays):
                    continue
                over = {s: max(0, produced[s] - int(source_remaining[s])) for s in ratios}
                over_total = sum(over.values())
                ratio_pieces = sum(ratios.values())
                # Bàn cuối: dương thấp nhất trước; nếu bằng nhau thì marker ngắn
                # và tổng tỷ lệ nhỏ hơn để dễ giác/cắt hơn.
                score = (over_total, raw_len, ratio_pieces, -lays)
                if best is None or score < best[0]:
                    best = (score, {
                        'sizes': produced,
                        'ratio': format_ratio(ratios),
                        'length': raw_len,
                        'raw_length': raw_len,
                        'plies': lays,
                        'ratio_map': ratios,
                        'total_output': sum(produced.values()),
                        'size_count': len(ratios),
                        'left_total': 0,
                        'small_left_count': 0,
                        'small_left_sum': 0,
                        'zeroed': len(ratios),
                        'over_total': over_total,
                        'size_span': (max([size_order.get(s, 0) for s in ratios]) - min([size_order.get(s, 0) for s in ratios])) if ratios else 0,
                        'meter_rate': raw_len / max(1, ratio_pieces),
                    })
            return best[1] if best else None

        # -------------------- BUOC 1: LAP BAN CHINH --------------------
        table_num = 1
        while remaining:
            # Neu chi con 1..3 SP/co thi khong tao them ban moi.
            if all(q < 4 for q in remaining.values()):
                break

            # Sau ít nhất một bàn chính của BÔNG, nếu phần còn lại có thể gói
            # vào đúng một marker thì dùng bàn cân trực tiếp.
            if tables and profile.get('mode') == 'padding':
                finish_pattern = build_padding_finish_candidate(remaining)
                if finish_pattern is not None:
                    tables.append({'table': f'B{table_num}', **finish_pattern})
                    remaining = {}
                    table_num += 1
                    break

            pattern = choose_pattern(remaining)
            if pattern is None:
                too_long = [
                    f"{name_map[s]} ({size_length[s]:.2f}m)"
                    for s in remaining
                    if max_len > 0 and length_int[s] > cap_int
                ]
                if too_long:
                    raise ValueError(
                        "Khong the lap marker: " + ', '.join(too_long) +
                        f" vuot chieu dai toi da {max_len:.2f}m."
                    )
                break

            tables.append({'table': f'B{table_num}', **pattern})
            for s, qty_cut in pattern['sizes'].items():
                remaining[s] -= qty_cut
                if remaining[s] <= 0:
                    del remaining[s]
            table_num += 1

        # -------------------- BUOC 2: TRIET TIEU PHAN THIEU 1..3 --------------------
        # Khong tao ban moi. Thu ghep co thieu vao ban co san; neu khong duoc,
        # thu tang SO LA cua mot ban dang co co do.
        for _ in range(20):
            actual = calc_actual(tables)
            deficits = {
                k: int(req) - actual.get(k, 0)
                for k, req in total_by_size.items()
                if int(req) - actual.get(k, 0) > 0
            }
            if not deficits:
                break

            changed_any = False

            # Xu ly phan thieu nho truoc.
            for s, deficit in sorted(deficits.items(), key=lambda x: x[1]):
                best_change = None

                # A) Them co nay vao mot marker co san voi ty le 1.
                for ti, table in enumerate(tables):
                    lays = int(table.get('plies', 0))
                    if lays < deficit or lays > deficit + over_limit_for(s):
                        continue
                    ratios = dict(table.get('ratio_map', {}))
                    if s in ratios:
                        continue
                    raw_len = sum(size_length[k] * r for k, r in ratios.items()) + size_length[s]
                    trial_ratios = dict(ratios)
                    trial_ratios[s] = 1
                    if not marker_within_limits(trial_ratios, raw_len, plies=lays):
                        continue

                    trial = [dict(t) for t in tables]
                    trial[ti] = dict(table)
                    trial[ti]['ratio_map'] = ratios
                    trial[ti]['ratio_map'][s] = 1
                    rebuild_table(trial[ti])
                    trial_actual = calc_actual(trial)
                    diffs = {k: trial_actual.get(k, 0) - int(req) for k, req in total_by_size.items()}
                    if any(v > over_limit_for(k) for k, v in diffs.items()):
                        continue
                    neg_total = sum(-v for v in diffs.values() if v < 0)
                    pos_total = sum(v for v in diffs.values() if v > 0)
                    score = (neg_total, pos_total, trial[ti]['raw_length'])
                    if best_change is None or score < best_change[0]:
                        best_change = (score, trial)

                # B) Tang ty le cua co nay +1 tren marker da co.
                for ti, table in enumerate(tables):
                    ratios = dict(table.get('ratio_map', {}))
                    if s not in ratios:
                        continue
                    lays = int(table.get('plies', 0))
                    if lays < deficit or lays > deficit + over_limit_for(s):
                        continue
                    raw_len = sum(size_length[k] * r for k, r in ratios.items()) + size_length[s]
                    trial_ratios = dict(ratios)
                    trial_ratios[s] = int(trial_ratios.get(s, 0)) + 1
                    if not marker_within_limits(trial_ratios, raw_len, plies=lays):
                        continue

                    trial = [dict(t) for t in tables]
                    trial[ti] = dict(table)
                    trial[ti]['ratio_map'] = ratios
                    trial[ti]['ratio_map'][s] += 1
                    rebuild_table(trial[ti])
                    trial_actual = calc_actual(trial)
                    diffs = {k: trial_actual.get(k, 0) - int(req) for k, req in total_by_size.items()}
                    if any(v > over_limit_for(k) for k, v in diffs.items()):
                        continue
                    neg_total = sum(-v for v in diffs.values() if v < 0)
                    pos_total = sum(v for v in diffs.values() if v > 0)
                    score = (neg_total, pos_total, trial[ti]['raw_length'])
                    if best_change is None or score < best_change[0]:
                        best_change = (score, trial)

                # C) Tang so la cua ban co chua co nay. Chi nhan neu khong co co nao dương >3.
                for ti, table in enumerate(tables):
                    ratios = dict(table.get('ratio_map', {}))
                    if s not in ratios:
                        continue
                    old_lays = int(table.get('plies', 0))
                    for delta in range(1, max_over_any + 1):
                        trial = [dict(t) for t in tables]
                        trial[ti] = dict(table)
                        trial[ti]['ratio_map'] = ratios
                        trial[ti]['plies'] = old_lays + delta
                        rebuild_table(trial[ti])
                        trial_actual = calc_actual(trial)
                        diffs = {k: trial_actual.get(k, 0) - int(req) for k, req in total_by_size.items()}
                        if any(v > over_limit_for(k) for k, v in diffs.items()):
                            continue
                        neg_total = sum(-v for v in diffs.values() if v < 0)
                        pos_total = sum(v for v in diffs.values() if v > 0)
                        # Chi coi la cai thien neu tong thieu giam.
                        current_neg = sum(
                            max(0, int(req) - actual.get(k, 0))
                            for k, req in total_by_size.items()
                        )
                        if neg_total >= current_neg:
                            continue
                        score = (neg_total, pos_total, delta)
                        if best_change is None or score < best_change[0]:
                            best_change = (score, trial)

                if best_change is not None:
                    tables = best_change[1]
                    changed_any = True
                    break

            if not changed_any:
                break

        # -------------------- V76 - BUOC 3: BAN IT LA -> GIAM TY LE / RUT NGAN MARKER --------------------
        # Quy tac moi:
        # - Bàn có số lá < MIN_PREFERRED_PLIES (mặc định 10) được coi là bàn ít lá.
        # - Thử TĂNG số lá và GIẢM tổng tỷ lệ để marker ngắn lại.
        # - Marker sau rút gọn KHÔNG được thấp hơn CHIỀU DÀI TỐI THIỂU của loại vải.
        # - Tổng thực cắt toàn bộ kế hoạch vẫn phải >= nhu cầu và không vượt giới hạn dương
        #   riêng của từng chế độ giác.
        # - Chỉ nhận phương án nếu tổng tỷ lệ thực sự giảm và marker thực sự ngắn hơn.
        #
        # Ví dụ: một bàn 4 lá đang có tỷ lệ lớn và dài 3.0m; nếu có thể đổi thành
        # 8-12 lá với tỷ lệ nhỏ hơn, chương trình sẽ kéo marker về gần mức tối thiểu
        # (ví dụ 1.0m) thay vì giữ một marker dài nhưng chỉ trải vài lá.
        preferred_plies = max(4, int(getattr(self, 'MIN_PREFERRED_PLIES', 10)))

        def _compact_low_plies_marker(table):
            old_lays = int(table.get('plies', 0) or 0)
            old_ratios = {k: int(v) for k, v in (table.get('ratio_map', {}) or {}).items() if int(v) > 0}
            if old_lays <= 0 or old_lays >= preferred_plies or not old_ratios:
                return False

            rebuild_table(table)
            old_raw = float(table.get('raw_length', 0) or 0)
            old_ratio_pieces = sum(old_ratios.values())

            # Nếu marker hiện đã ở sát/ dưới sàn thì không rút nữa.
            # Phần V76 phía sau sẽ chịu trách nhiệm nâng marker quá ngắn lên lại sàn.
            if old_raw <= FINAL_MIN_MARKER_LENGTH + 1e-9:
                return False

            # Sản lượng do tất cả bàn KHÁC đã cắt. Từ đây tính khoảng sản lượng
            # mà bàn hiện tại được phép đảm nhận cho từng cỡ.
            actual_all = calc_actual(tables)
            old_sizes = {k: int(v or 0) for k, v in (table.get('sizes', {}) or {}).items()}
            base_actual = {
                k: int(actual_all.get(k, 0)) - int(old_sizes.get(k, 0))
                for k in total_by_size
            }

            # Số lá không cần thử vô hạn. Với tỷ lệ tối thiểu 1, số lá lớn hơn
            # lượng tối đa còn được phép cắt của mọi cỡ sẽ không tạo được candidate.
            max_lays_allowed = max([
                max(0, int(total_by_size.get(k, 0)) + over_limit_for(k) - int(base_actual.get(k, 0)))
                for k in total_by_size if k in size_length
            ] or [old_lays])
            max_lays_allowed = max(old_lays, max_lays_allowed)

            best = None

            # Chỉ tăng hoặc giữ số lá; mục đích của bước này là biến bàn ít lá
            # thành bàn nhiều lá hơn với tỷ lệ nhỏ hơn.
            for lays in range(max(4, old_lays), max_lays_allowed + 1):
                ratios = {}
                rmax_map = {}
                valid = True

                for s in total_by_size:
                    if s not in size_length:
                        continue
                    req = int(total_by_size.get(s, 0) or 0)
                    base = int(base_actual.get(s, 0) or 0)
                    lo_qty = max(0, req - base)
                    hi_qty = max(0, req + over_limit_for(s) - base)

                    rmin = int(math.ceil(lo_qty / lays)) if lo_qty > 0 else 0
                    rmax = int(hi_qty // lays) if hi_qty > 0 else 0
                    if rmin > rmax:
                        valid = False
                        break
                    if rmin > 0:
                        ratios[s] = rmin
                    rmax_map[s] = rmax

                if not valid or not ratios:
                    continue

                ratio_pieces = sum(int(v) for v in ratios.values())
                if ratio_pieces >= old_ratio_pieces:
                    continue
                if max_products > 0 and ratio_pieces > max_products:
                    continue

                raw_len = sum(float(size_length[s]) * int(r) for s, r in ratios.items())
                if max_len > 0 and raw_len > max_len + 1e-9:
                    continue

                # Sau khi giảm tỷ lệ, nếu marker ngắn hơn sàn thì tăng lại NHẸ NHẤT
                # có thể để chạm/gần sàn. Không quay lại marker dài như cũ.
                guard = 0
                while raw_len + 1e-9 < FINAL_MIN_MARKER_LENGTH and guard < 200:
                    guard += 1
                    options = []
                    for s in total_by_size:
                        if s not in size_length:
                            continue
                        cur = int(ratios.get(s, 0))
                        if cur >= int(rmax_map.get(s, 0)):
                            continue
                        next_ratio_pieces = ratio_pieces + 1
                        if next_ratio_pieces >= old_ratio_pieces:
                            continue
                        if max_products > 0 and next_ratio_pieces > max_products:
                            continue
                        nl = raw_len + float(size_length[s])
                        if max_len > 0 and nl > max_len + 1e-9:
                            continue

                        # Tính dương toàn kế hoạch nếu thêm 1 nhịp tỷ lệ của cỡ này.
                        trial_cut = (cur + 1) * lays
                        trial_total = int(base_actual.get(s, 0)) + trial_cut
                        over_after = max(0, trial_total - int(total_by_size.get(s, 0) or 0))
                        options.append((
                            0 if nl >= FINAL_MIN_MARKER_LENGTH - 1e-9 else 1,
                            abs(nl - FINAL_MIN_MARKER_LENGTH),
                            over_after,
                            size_order.get(s, 9999),
                            s,
                            nl,
                        ))

                    if not options:
                        break
                    options.sort()
                    _, _, _, _, picked, nl = options[0]
                    ratios[picked] = int(ratios.get(picked, 0)) + 1
                    ratio_pieces += 1
                    raw_len = nl

                # Không chấp nhận bàn dưới chiều dài tối thiểu.
                if raw_len + 1e-9 < FINAL_MIN_MARKER_LENGTH:
                    continue
                # Mục tiêu là RÚT NGẮN marker. Nếu không ngắn hơn thì giữ phương án cũ.
                if raw_len >= old_raw - 1e-9:
                    continue
                if ratio_pieces >= old_ratio_pieces:
                    continue
                if not marker_within_limits(ratios, raw_len, plies=lays):
                    continue

                produced = {s: int(r) * lays for s, r in ratios.items() if int(r) > 0}
                trial_actual = {
                    k: int(base_actual.get(k, 0)) + int(produced.get(k, 0))
                    for k in total_by_size
                }
                diffs = {
                    k: int(trial_actual.get(k, 0)) - int(total_by_size.get(k, 0) or 0)
                    for k in total_by_size
                }
                if any(v < 0 or v > over_limit_for(k) for k, v in diffs.items()):
                    continue

                over_total = sum(max(0, v) for v in diffs.values())
                size_count = sum(1 for v in ratios.values() if int(v) > 0)

                # Ưu tiên marker NGẮN NHẤT nhưng vẫn >= sàn; sau đó mới xét
                # tổng tỷ lệ, dương và số lá. Vì vậy bàn ít lá sẽ có xu hướng
                # tự kéo chiều dài về gần mức tối thiểu người dùng đã nhập.
                score = (
                    raw_len,
                    ratio_pieces,
                    over_total,
                    size_count,
                    0 if lays >= preferred_plies else 1,
                    -lays,
                )
                if best is None or score < best[0]:
                    best = (score, lays, dict(ratios))

            if best is None:
                return False

            _, lays, ratios = best
            table['plies'] = int(lays)
            table['ratio_map'] = {k: int(v) for k, v in ratios.items() if int(v) > 0}
            rebuild_table(table)
            return True

        # Xử lý bàn ít lá nhất trước. Sau mỗi lần thay đổi, hàm tự tính lại sản lượng
        # toàn bộ các bàn nên các bàn tiếp theo vẫn không làm âm hoặc dương quá giới hạn.
        low_ply_indexes = sorted(
            range(len(tables)),
            key=lambda i: (int(tables[i].get('plies', 0) or 0), -float(tables[i].get('raw_length', 0) or 0), i)
        )
        for _idx in low_ply_indexes:
            _compact_low_plies_marker(tables[_idx])

        # -------------------- V76: KHÔNG BÀN NÀO ĐƯỢC < CHIỀU DÀI TỐI THIỂU --------------------
        # Nếu một marker dưới 1m, cố ghép thêm cỡ/tăng tỷ lệ nhưng chỉ khi sản lượng
        # dương của cỡ đó vẫn <= MAX_OVER. Sau cùng đưa marker ngắn nhất xuống cuối.
        def _try_raise_short_marker(table):
            """Tìm lại tỷ lệ + số lá cho marker ngắn để đạt khoảng >=1m nếu có thể.

            Giữ tổng sản lượng toàn bộ kế hoạch trong khoảng yêu cầu .. yêu cầu+MAX_OVER.
            Cách này cho phép ví dụ XS/1+S/1 x7 lá (0.63m) đổi thành
            XS/2+S/2 x4 lá (1.26m) mà sản lượng chỉ dương +1/cỡ.
            """
            rebuild_table(table)
            current_raw = float(table.get('raw_length', 0) or 0)
            if current_raw + 1e-9 >= FINAL_MIN_MARKER_LENGTH:
                return

            actual_all = calc_actual(tables)
            old_sizes = {k:int(v or 0) for k,v in (table.get('sizes',{}) or {}).items()}
            base_actual = {k:int(actual_all.get(k,0))-int(old_sizes.get(k,0)) for k in total_by_size}
            max_hi = max([max(0, int(total_by_size.get(k,0))+over_limit_for(k)-base_actual.get(k,0))
                          for k in total_by_size] or [4])
            best = None

            for lays in range(4, max(4, max_hi) + 1):
                ratios = {}
                rmax_map = {}
                valid = True
                for s in total_by_size:
                    if s not in size_length:
                        continue
                    lo = max(0, int(total_by_size.get(s,0)) - int(base_actual.get(s,0)))
                    hi = max(0, int(total_by_size.get(s,0)) + over_limit_for(s) - int(base_actual.get(s,0)))
                    rmin = int(math.ceil(lo / lays)) if lo > 0 else 0
                    rmax = int(hi // lays)
                    if rmin > rmax:
                        valid = False
                        break
                    if rmin > 0:
                        ratios[s] = rmin
                    rmax_map[s] = rmax
                if not valid or not ratios:
                    continue

                raw_len = sum(float(size_length[s]) * int(r) for s,r in ratios.items())
                if not marker_within_limits(ratios, raw_len, plies=lays):
                    continue

                # Nếu còn dưới 1m, tăng tỷ lệ hợp lệ từng bước sao cho gần 1m nhất.
                guard = 0
                while raw_len + 1e-9 < FINAL_MIN_MARKER_LENGTH and guard < 50:
                    guard += 1
                    options = []
                    for s in total_by_size:
                        if s not in size_length:
                            continue
                        cur = int(ratios.get(s,0))
                        if cur >= int(rmax_map.get(s,0)):
                            continue
                        nl = raw_len + float(size_length[s])
                        trial_ratio_sum = sum(int(v) for v in ratios.values()) + 1
                        if (max_products <= 0 or trial_ratio_sum <= max_products) and (max_len <= 0 or nl <= max_len + 1e-9):
                            options.append((0 if nl >= FINAL_MIN_MARKER_LENGTH-1e-9 else 1,
                                            abs(nl-FINAL_MIN_MARKER_LENGTH),
                                            size_order.get(s,9999), s, nl))
                    if not options:
                        break
                    options.sort()
                    _,_,_,s,raw_len = options[0]
                    ratios[s] = int(ratios.get(s,0)) + 1

                produced = {s:int(r)*lays for s,r in ratios.items() if int(r)>0}
                trial_actual = {k:int(base_actual.get(k,0))+int(produced.get(k,0)) for k in total_by_size}
                diffs = {k:trial_actual.get(k,0)-int(total_by_size.get(k,0)) for k in total_by_size}
                if any(v < 0 or v > over_limit_for(k) for k, v in diffs.items()):
                    continue
                reach_penalty = 0 if raw_len >= FINAL_MIN_MARKER_LENGTH-1e-9 else 1
                score = (reach_penalty, abs(raw_len-FINAL_MIN_MARKER_LENGTH),
                         sum(max(0,v) for v in diffs.values()), raw_len, lays)
                if best is None or score < best[0]:
                    best = (score, lays, ratios)

            if best is not None:
                _, lays, ratios = best
                table['plies'] = int(lays)
                table['ratio_map'] = {k:int(v) for k,v in ratios.items() if int(v)>0}
                rebuild_table(table)

        # -------------------- V78: SÀN CHIỀU DÀI LÀ GIỚI HẠN CỨNG --------------------
        # Trước tiên vẫn thử sửa RIÊNG bàn ngắn. Nếu không đủ sàn, phần mềm không
        # bắt người dùng thêm sản lượng đơn hàng; thay vào đó nó tự giảm số lá của
        # một bàn trước để CHỪA LẠI nhiều cỡ cho bàn ngắn, rồi tính lại tỷ lệ bàn
        # ngắn sao cho chiều dài >= sàn và toàn bộ sản lượng vẫn nằm trong giới hạn.

        def _build_strict_finish_marker(base_actual):
            """Tạo một bàn kết thúc từ phần sản lượng còn lại sau các bàn khác.

            Kết quả bắt buộc:
            - đủ toàn bộ sản lượng còn thiếu;
            - dương từng cỡ không vượt giới hạn của chế độ giác;
            - chiều dài marker >= FINAL_MIN_MARKER_LENGTH;
            - không vượt chiều dài tối đa / SP tối đa mỗi sơ đồ.
            """
            # Nếu các bàn nền đã dương quá giới hạn thì không thể cứu bằng bàn cuối.
            for _k, _req in total_by_size.items():
                _base = int(base_actual.get(_k, 0) or 0)
                if _base > int(_req) + over_limit_for(_k):
                    return None

            # Số lá tối đa hữu ích: với tỷ lệ tối thiểu 1, lớn hơn sức chứa dương
            # còn lại của mọi cỡ thì không thể tạo thêm sản lượng hợp lệ.
            _max_hi = max([
                max(0, int(total_by_size.get(_k, 0)) + over_limit_for(_k) - int(base_actual.get(_k, 0) or 0))
                for _k in total_by_size if _k in size_length
            ] or [4])
            _best = None

            for _lays in range(4, max(4, _max_hi) + 1):
                _ratios = {}
                _rmax_map = {}
                _valid = True

                for _sz in total_by_size:
                    if _sz not in size_length:
                        continue
                    _base = int(base_actual.get(_sz, 0) or 0)
                    _req = int(total_by_size.get(_sz, 0) or 0)
                    _lo = max(0, _req - _base)
                    _hi = _req + over_limit_for(_sz) - _base
                    if _hi < 0:
                        _valid = False
                        break
                    _rmin = int(math.ceil(_lo / _lays)) if _lo > 0 else 0
                    _rmax = int(_hi // _lays) if _hi > 0 else 0
                    if _rmin > _rmax:
                        _valid = False
                        break
                    if _rmin > 0:
                        _ratios[_sz] = _rmin
                    _rmax_map[_sz] = _rmax

                if not _valid:
                    continue

                # Nếu không còn thiếu gì thì không cần tạo bàn kết thúc nữa.
                if not _ratios:
                    _diffs = {
                        _k: int(base_actual.get(_k, 0) or 0) - int(total_by_size.get(_k, 0) or 0)
                        for _k in total_by_size
                    }
                    if all(0 <= _v <= over_limit_for(_k) for _k, _v in _diffs.items()):
                        return {'remove_table': True}
                    continue

                _ratio_pieces = sum(int(v) for v in _ratios.values())
                if max_products > 0 and _ratio_pieces > max_products:
                    continue
                _raw = sum(float(size_length[_sz]) * int(_r) for _sz, _r in _ratios.items())
                if max_len > 0 and _raw > max_len + 1e-9:
                    continue

                # Marker còn ngắn: thêm từng nhịp tỷ lệ trong phần dương còn cho phép.
                # Chọn nhịp đưa chiều dài tới sàn gần nhất; không tăng vô ích.
                _guard = 0
                while _raw + 1e-9 < FINAL_MIN_MARKER_LENGTH and _guard < 200:
                    _guard += 1
                    _options = []
                    for _sz in total_by_size:
                        if _sz not in size_length:
                            continue
                        _cur = int(_ratios.get(_sz, 0) or 0)
                        if _cur >= int(_rmax_map.get(_sz, 0) or 0):
                            continue
                        _next_count = _ratio_pieces + 1
                        if max_products > 0 and _next_count > max_products:
                            continue
                        _next_len = _raw + float(size_length[_sz])
                        if max_len > 0 and _next_len > max_len + 1e-9:
                            continue

                        _options.append((
                            0 if _next_len + 1e-9 >= FINAL_MIN_MARKER_LENGTH else 1,
                            abs(_next_len - FINAL_MIN_MARKER_LENGTH),
                            size_order.get(_sz, 9999),
                            _sz, _next_len
                        ))
                    if not _options:
                        break
                    _options.sort()
                    _, _, _, _sz, _raw = _options[0]
                    _ratios[_sz] = int(_ratios.get(_sz, 0) or 0) + 1
                    _ratio_pieces += 1

                # V78: khác V77, dưới sàn là KHÔNG HỢP LỆ.
                if _raw + 1e-9 < FINAL_MIN_MARKER_LENGTH:
                    continue
                if not marker_within_limits(_ratios, _raw, plies=_lays):
                    continue

                _produced = {_sz: int(_r) * _lays for _sz, _r in _ratios.items() if int(_r) > 0}
                _final_actual = {
                    _k: int(base_actual.get(_k, 0) or 0) + int(_produced.get(_k, 0) or 0)
                    for _k in total_by_size
                }
                _diffs = {
                    _k: int(_final_actual.get(_k, 0) or 0) - int(total_by_size.get(_k, 0) or 0)
                    for _k in total_by_size
                }
                if any(_v < 0 or _v > over_limit_for(_k) for _k, _v in _diffs.items()):
                    continue

                _over = sum(max(0, _v) for _v in _diffs.values())
                _size_count = sum(1 for _v in _ratios.values() if int(_v) > 0)
                _score = (
                    _over,
                    abs(_raw - FINAL_MIN_MARKER_LENGTH),
                    _ratio_pieces,
                    0 if _lays >= preferred_plies else 1,
                    _size_count,
                    -_lays,
                )
                if _best is None or _score < _best[0]:
                    _best = (_score, {
                        'sizes': _produced,
                        'ratio': format_ratio(_ratios),
                        'length': _raw,
                        'raw_length': _raw,
                        'plies': int(_lays),
                        'ratio_map': {k: int(v) for k, v in _ratios.items() if int(v) > 0},
                        'total_output': sum(_produced.values()),
                        'size_count': _size_count,
                    })

            return _best[1] if _best is not None else None

        def _rebalance_one_short_marker(short_idx):
            """Chừa sản lượng từ bàn trước cho một marker đang dưới sàn.

            Ưu tiên giữ nguyên số bàn. Mỗi lần thử giảm 1, 2, 3... lá của MỘT
            bàn trước; phần sản lượng được chừa lại sẽ được gom cùng phần của bàn
            ngắn để tạo marker mới đủ chiều dài tối thiểu.
            """
            nonlocal tables
            if short_idx < 0 or short_idx >= len(tables):
                return False

            # 1) Thử xây lại bàn ngắn từ các bàn khác mà chưa đụng bàn trước.
            _base_tables = []
            for _i, _tb in enumerate(tables):
                if _i == short_idx:
                    continue
                _cp = dict(_tb)
                _cp['ratio_map'] = dict(_tb.get('ratio_map', {}) or {})
                rebuild_table(_cp)
                _base_tables.append(_cp)
            _base_actual = calc_actual(_base_tables)
            _direct = _build_strict_finish_marker(_base_actual)
            if isinstance(_direct, dict) and _direct.get('remove_table'):
                del tables[short_idx]
                return True
            if _direct is not None:
                _direct['table'] = tables[short_idx].get('table', f'B{short_idx+1}')
                tables[short_idx] = _direct
                return True

            # 2) Không đủ: giảm số lá của một bàn khác để chừa thêm nhiều cỡ.
            _best = None
            _donor_indexes = [
                _i for _i, _tb in enumerate(tables)
                if _i != short_idx and int(_tb.get('plies', 0) or 0) > 4
            ]
            # Ưu tiên bàn có nhiều cỡ / nhiều lá vì chỉ cần giảm ít lá thường đã
            # tạo đủ phần còn lại cho bàn cuối đạt sàn.
            _donor_indexes.sort(key=lambda _i: (
                -int(tables[_i].get('size_count', 0) or 0),
                -int(tables[_i].get('plies', 0) or 0),
                -float(tables[_i].get('raw_length', 0) or 0),
            ))

            for _di in _donor_indexes:
                _old_p = int(tables[_di].get('plies', 0) or 0)
                # Dừng tại phương án khả thi ĐẦU TIÊN của từng donor để không làm
                # chậm xuất Excel và cũng đúng mục tiêu: chừa ít nhất có thể.
                for _delta in range(1, max(1, _old_p - 4) + 1):
                    _trial_base = []
                    for _i, _tb in enumerate(tables):
                        if _i == short_idx:
                            continue
                        _cp = dict(_tb)
                        _cp['ratio_map'] = dict(_tb.get('ratio_map', {}) or {})
                        if _i == _di:
                            _cp['plies'] = _old_p - _delta
                        rebuild_table(_cp)
                        _trial_base.append(_cp)

                    _base_actual = calc_actual(_trial_base)
                    _finish = _build_strict_finish_marker(_base_actual)
                    if _finish is None or _finish.get('remove_table'):
                        continue

                    _trial_all = list(_trial_base) + [_finish]
                    _fa = calc_actual(_trial_all)
                    _diffs = {
                        _k: int(_fa.get(_k, 0) or 0) - int(total_by_size.get(_k, 0) or 0)
                        for _k in total_by_size
                    }
                    if any(_v < 0 or _v > over_limit_for(_k) for _k, _v in _diffs.items()):
                        continue

                    _over = sum(max(0, _v) for _v in _diffs.values())
                    _meters = sum(float(_t.get('raw_length', 0) or 0) * int(_t.get('plies', 0) or 0) for _t in _trial_all)
                    _score = (
                        _over,
                        _delta,
                        abs(float(_finish.get('raw_length', 0) or 0) - FINAL_MIN_MARKER_LENGTH),
                        _meters,
                        -int(_finish.get('plies', 0) or 0),
                    )
                    if _best is None or _score < _best[0]:
                        _best = (_score, _di, _old_p - _delta, _finish)
                    break

            if _best is None:
                return False

            _, _di, _new_p, _finish = _best
            tables[_di]['plies'] = int(_new_p)
            rebuild_table(tables[_di])
            _finish['table'] = tables[short_idx].get('table', f'B{short_idx+1}')
            tables[short_idx] = _finish
            return True

        # Bước A: sửa riêng marker ngắn nếu có thể.
        if FINAL_MIN_MARKER_LENGTH > 0 and tables:
            for _tb in tables:
                if float(_tb.get('raw_length', 0) or 0) + 1e-9 < FINAL_MIN_MARKER_LENGTH:
                    _try_raise_short_marker(_tb)

        # Bước B: marker nào vẫn ngắn thì tự chừa sản lượng từ bàn trước.
        if FINAL_MIN_MARKER_LENGTH > 0 and tables:
            for _round in range(10):
                _short = [
                    _i for _i, _tb in enumerate(tables)
                    if float(_tb.get('raw_length', 0) or 0) + 1e-9 < FINAL_MIN_MARKER_LENGTH
                ]
                if not _short:
                    break
                _changed = False
                # Bàn ngắn nhất sửa trước.
                for _si in sorted(_short, key=lambda _i: float(tables[_i].get('raw_length', 0) or 0)):
                    if _rebalance_one_short_marker(_si):
                        _changed = True
                        break
                if not _changed:
                    break

        # -------------------- V81: CÒN THIẾU 1..3 SP -> TỰ CÂN LẠI TOÀN BỘ BÀN --------------------
        # V80 chỉ tự cân lại khi có marker < chiều dài tối thiểu. Vì vậy có trường hợp
        # mọi marker đều >= sàn nhưng cuối kế hoạch vẫn còn thiếu 1..3 SP (ví dụ XXS thiếu 2),
        # calculate_cutting_plan() sẽ chặn xuất Excel.
        #
        # V81 xử lý phần thiếu nhỏ theo đúng nguyên tắc đã thống nhất:
        #   1) KHÔNG yêu cầu người dùng tăng số lượng đơn hàng;
        #   2) thử xây lại một bàn hiện có để gom phần thiếu vào bàn đó;
        #   3) nếu chưa được, giảm ít nhất số lá của một bàn khác để chừa thêm nhiều cỡ;
        #   4) chỉ khi cần mới thêm 1 bàn mới;
        #   5) mọi marker sau cân lại vẫn phải >= chiều dài tối thiểu, <= chiều dài tối đa,
        #      không âm sản lượng và không dương quá giới hạn của chế độ giác.

        def _plan_diffs(_tabs):
            _act = calc_actual(_tabs)
            return {
                _k: int(_act.get(_k, 0) or 0) - int(total_by_size.get(_k, 0) or 0)
                for _k in total_by_size
            }

        def _plan_is_valid(_tabs):
            if not _tabs:
                return False
            _diffs = _plan_diffs(_tabs)
            if any(_v < 0 or _v > over_limit_for(_k) for _k, _v in _diffs.items()):
                return False
            for _tb in _tabs:
                rebuild_table(_tb)
                _raw = float(_tb.get('raw_length', 0) or 0)
                if FINAL_MIN_MARKER_LENGTH > 0 and _raw + 1e-9 < FINAL_MIN_MARKER_LENGTH:
                    return False
                if not marker_within_limits(_tb.get('ratio_map', {}) or {}, _raw, plies=int(_tb.get('plies', 0) or 0), reference_tables=_tabs):
                    return False
                if int(_tb.get('plies', 0) or 0) < 4:
                    return False
            return True

        def _clone_table(_tb):
            _cp = dict(_tb)
            _cp['ratio_map'] = dict(_tb.get('ratio_map', {}) or {})
            _cp['sizes'] = dict(_tb.get('sizes', {}) or {})
            return _cp

        def _score_repair_plan(_tabs, _change_cost=0, _added_table=0):
            _diffs = _plan_diffs(_tabs)
            _over = sum(max(0, _v) for _v in _diffs.values())
            _meters = sum(
                float(_t.get('raw_length', 0) or 0) * int(_t.get('plies', 0) or 0)
                for _t in _tabs
            )
            _last_gap = min(
                [abs(float(_t.get('raw_length', 0) or 0) - FINAL_MIN_MARKER_LENGTH) for _t in _tabs]
                or [0.0]
            )
            # V118: trong các phương án sửa tương đương, bàn ÍT LÁ NHẤT phải
            # có tổng tỷ lệ ít + chiều dài ngắn + ít cỡ để làm bàn cuối.
            if _tabs:
                _tail = min(
                    _tabs,
                    key=lambda _t: (
                        int(_t.get('plies', 0) or 0),
                        sum(int(v or 0) for v in (_t.get('ratio_map', {}) or {}).values()),
                        float(_t.get('raw_length', 0) or 0),
                    )
                )
                _tail_ratio = sum(int(v or 0) for v in (_tail.get('ratio_map', {}) or {}).values())
                _tail_len = float(_tail.get('raw_length', 0) or 0)
                _tail_sizes = int(_tail.get('size_count', len(_tail.get('ratio_map', {}) or {})) or 0)
            else:
                _tail_ratio = 0
                _tail_len = 0.0
                _tail_sizes = 0
            # Không tăng bàn trước; sau đó thay đổi ít lá nhất; tiếp theo dương.
            # Sau đó mới tối ưu bàn vét và tổng mét.
            return (
                int(_added_table), int(_change_cost), int(_over),
                int(_tail_ratio), float(_tail_len), int(_tail_sizes),
                float(_meters), float(_last_gap)
            )

        def _repair_unresolved_deficits():
            nonlocal tables
            _diffs0 = _plan_diffs(tables)
            _def0 = {_k: -_v for _k, _v in _diffs0.items() if _v < 0}
            if not _def0:
                return True

            _best = None

            # A) Giữ nguyên số bàn: bỏ 1 bàn khỏi kế hoạch rồi xây lại bàn đó từ toàn bộ
            # phần còn thiếu. Đây thường là cách tốt nhất cho trường hợp chỉ thiếu 1..3 SP.
            for _ri in range(len(tables)):
                _base_tabs = [_clone_table(_tb) for _i, _tb in enumerate(tables) if _i != _ri]
                for _tb in _base_tabs:
                    rebuild_table(_tb)
                _base_actual = calc_actual(_base_tabs)
                _finish = _build_strict_finish_marker(_base_actual)
                if _finish is None:
                    continue
                if isinstance(_finish, dict) and _finish.get('remove_table'):
                    _trial = _base_tabs
                else:
                    _finish = dict(_finish)
                    _finish['ratio_map'] = dict(_finish.get('ratio_map', {}) or {})
                    _finish['table'] = tables[_ri].get('table', f'B{_ri+1}')
                    rebuild_table(_finish)
                    _trial = list(_base_tabs)
                    # Giữ vị trí gần bàn cũ để không làm thứ tự nhảy quá mạnh.
                    _trial.insert(min(_ri, len(_trial)), _finish)
                if not _plan_is_valid(_trial):
                    continue
                _score = _score_repair_plan(_trial, _change_cost=0, _added_table=max(0, len(_trial)-len(tables)))
                if _best is None or _score < _best[0]:
                    _best = (_score, _trial)

            # B) Vẫn giữ số bàn: giảm một ít lá của một bàn donor rồi xây lại một bàn khác.
            # Giảm 1 lá của marker nhiều cỡ sẽ chừa đồng thời nhiều size, giúp bàn cuối đủ
            # chiều dài tối thiểu thay vì chỉ vá XXS/1 rất ngắn.
            if _best is None and len(tables) >= 2:
                _targets = list(range(len(tables)))
                _targets.sort(key=lambda _i: (
                    int(tables[_i].get('size_count', 0) or 0),
                    float(tables[_i].get('raw_length', 0) or 0),
                    int(tables[_i].get('plies', 0) or 0),
                ))
                _donors = list(range(len(tables)))
                _donors.sort(key=lambda _i: (
                    -int(tables[_i].get('size_count', 0) or 0),
                    -int(tables[_i].get('plies', 0) or 0),
                ))

                for _ri in _targets:
                    for _di in _donors:
                        if _di == _ri:
                            continue
                        _old_p = int(tables[_di].get('plies', 0) or 0)
                        if _old_p <= 4:
                            continue
                        # Chừa ít nhất có thể; giới hạn thử để giữ tốc độ xuất Excel.
                        _max_delta = min(_old_p - 4, 12)
                        for _delta in range(1, _max_delta + 1):
                            _base_tabs = []
                            for _i, _tb in enumerate(tables):
                                if _i == _ri:
                                    continue
                                _cp = _clone_table(_tb)
                                if _i == _di:
                                    _cp['plies'] = _old_p - _delta
                                rebuild_table(_cp)
                                _base_tabs.append(_cp)
                            _finish = _build_strict_finish_marker(calc_actual(_base_tabs))
                            if _finish is None or (isinstance(_finish, dict) and _finish.get('remove_table')):
                                continue
                            _finish = dict(_finish)
                            _finish['ratio_map'] = dict(_finish.get('ratio_map', {}) or {})
                            _finish['table'] = tables[_ri].get('table', f'B{_ri+1}')
                            rebuild_table(_finish)
                            _trial = list(_base_tabs)
                            _trial.insert(min(_ri, len(_trial)), _finish)
                            if not _plan_is_valid(_trial):
                                continue
                            _score = _score_repair_plan(_trial, _change_cost=_delta, _added_table=0)
                            if _best is None or _score < _best[0]:
                                _best = (_score, _trial)
                            # Với donor/target này, delta nhỏ nhất hợp lệ là đủ.
                            break

            # C) Nếu thật sự không thể giữ nguyên số bàn, cho phép thêm đúng 1 bàn.
            # Trước khi thêm vẫn thử giảm ít lá của một donor để tạo đủ nhiều cỡ cho
            # marker mới >= sàn. Điều này phù hợp yêu cầu "thêm bàn nếu tối ưu".
            if _best is None:
                _donors = list(range(len(tables)))
                _donors.sort(key=lambda _i: (
                    -int(tables[_i].get('size_count', 0) or 0),
                    -int(tables[_i].get('plies', 0) or 0),
                ))

                # C1: thử thêm bàn trực tiếp trước.
                _base_tabs = [_clone_table(_tb) for _tb in tables]
                for _tb in _base_tabs:
                    rebuild_table(_tb)
                _finish = _build_strict_finish_marker(calc_actual(_base_tabs))
                if _finish is not None and not (isinstance(_finish, dict) and _finish.get('remove_table')):
                    _finish = dict(_finish)
                    _finish['ratio_map'] = dict(_finish.get('ratio_map', {}) or {})
                    rebuild_table(_finish)
                    _trial = _base_tabs + [_finish]
                    if _plan_is_valid(_trial):
                        _best = (_score_repair_plan(_trial, _change_cost=0, _added_table=1), _trial)

                # C2: chừa thêm từ một donor rồi mới thêm bàn.
                if _best is None:
                    for _di in _donors:
                        _old_p = int(tables[_di].get('plies', 0) or 0)
                        if _old_p <= 4:
                            continue
                        _max_delta = min(_old_p - 4, 12)
                        for _delta in range(1, _max_delta + 1):
                            _base_tabs = []
                            for _i, _tb in enumerate(tables):
                                _cp = _clone_table(_tb)
                                if _i == _di:
                                    _cp['plies'] = _old_p - _delta
                                rebuild_table(_cp)
                                _base_tabs.append(_cp)
                            _finish = _build_strict_finish_marker(calc_actual(_base_tabs))
                            if _finish is None or (isinstance(_finish, dict) and _finish.get('remove_table')):
                                continue
                            _finish = dict(_finish)
                            _finish['ratio_map'] = dict(_finish.get('ratio_map', {}) or {})
                            rebuild_table(_finish)
                            _trial = _base_tabs + [_finish]
                            if not _plan_is_valid(_trial):
                                continue
                            _score = _score_repair_plan(_trial, _change_cost=_delta, _added_table=1)
                            if _best is None or _score < _best[0]:
                                _best = (_score, _trial)
                            break

            if _best is None:
                return False

            tables = [_clone_table(_tb) for _tb in _best[1]]
            for _tb in tables:
                rebuild_table(_tb)
            return True

        # Chạy sửa phần thiếu sau khi đã xử lý chiều dài tối thiểu. Có thể lặp vài vòng
        # vì một lần xây lại bàn có thể làm thay đổi bàn nào nên đứng cuối.
        for _repair_round in range(4):
            _now_diffs = _plan_diffs(tables)
            if not any(_v < 0 for _v in _now_diffs.values()):
                break
            if not _repair_unresolved_deficits():
                break

        # V118: QUY TẮC BÀN CUỐI CHO TẤT CẢ LOẠI VẢI.
        # Bàn có SỐ LÁ ÍT NHẤT phải xuống cuối. Nếu có nhiều bàn cùng số lá ít
        # nhất thì chọn bàn có TỔNG TỶ LỆ ÍT hơn, CHIỀU DÀI NGẮN hơn, rồi ít cỡ hơn.
        # Các bàn chính còn lại: nhiều lá trước; cùng lá thì tỷ lệ/marker lớn hơn trước
        # để bàn nhỏ-gọn luôn nằm về cuối.
        if len(tables) > 1:
            for _tb in tables:
                rebuild_table(_tb)

            def _ratio_total(_tb):
                return sum(int(v or 0) for v in (_tb.get('ratio_map', {}) or {}).values())

            last_idx = min(
                range(len(tables)),
                key=lambda i: (
                    int(tables[i].get('plies', 0) or 0),
                    _ratio_total(tables[i]),
                    float(tables[i].get('raw_length', 0) or 0),
                    int(tables[i].get('size_count', 0) or 0),
                    int(tables[i].get('total_output', 0) or 0),
                    i,
                )
            )
            last_table = tables.pop(last_idx)

            tables.sort(key=lambda t: (
                -int(t.get('plies', 0) or 0),
                -_ratio_total(t),
                -float(t.get('raw_length', 0) or 0),
                -int(t.get('size_count', 0) or 0),
            ))
            tables.append(last_table)

        # Danh lai so ban sau moi dieu chinh.
        for i, table in enumerate(tables, start=1):
            table['table'] = f'B{i}'
            rebuild_table(table)

        # V78 - SAU KHI ĐÃ TỰ CÂN LẠI BÀN TRƯỚC, SÀN LÀ GIỚI HẠN CỨNG.
        # Nếu vẫn không thể đạt sàn thì đây là bài toán thực sự không khả thi với
        # sản lượng + mức dương + chiều dài tối đa hiện tại. Không tự tạo marker
        # dưới sàn và cũng không yêu cầu người dùng phải tăng số lượng đơn hàng.
        short_tables = [
            t for t in tables
            if float(t.get('raw_length', t.get('length', 0)) or 0) + 1e-9 < HARD_MIN_MARKER_LENGTH
        ]
        if short_tables:
            _detail = ', '.join(
                f"{t.get('table','B?')} {float(t.get('raw_length', t.get('length',0)) or 0):.2f}m"
                for t in short_tables
            )
            raise ValueError(
                f"Không thể tạo tất cả sơ đồ >= {HARD_MIN_MARKER_LENGTH:.2f} m sau khi đã tự cân lại các bàn trước "
                f"({_detail}). Hãy giảm Chiều dài tối thiểu, tăng Chiều dài tối đa hoặc chọn chế độ giác cho phép dương rộng hơn."
            )
        short_marker_warning = []

        # V117 - KIỂM TRA CUỐI.
        # VẢI CHÍNH/LÓT/KẸP vẫn theo quy tắc cũ: không âm.
        # DỰNG/MEX và BÔNG: cho phép âm/dương; dương cỡ lớn được hạ xuống bù cỡ bé.
        final_actual = calc_actual(tables)
        ordered_keys = [x['key'] for x in self.sizes if x['key'] in total_by_size]
        raw_diff = {
            k: int(final_actual.get(k, 0) or 0) - int(total_by_size.get(k, 0) or 0)
            for k in ordered_keys
        }
        unresolved = {}
        over_too_high = {}
        for k in ordered_keys:
            diff = raw_diff[k]
            if diff > over_limit_for(k):
                over_too_high[k] = diff
            elif diff < 0 and not allow_under:
                unresolved[k] = -diff

        size_transfers = []
        residual_under = {k: max(0, -raw_diff[k]) for k in ordered_keys}
        transfer_used = 0
        final_positive_surplus = sum(max(0, raw_diff[k]) for k in ordered_keys)
        if allow_under and downgrade_large_to_small:
            sources = []
            residual_under = {k: 0 for k in ordered_keys}
            for k in reversed(ordered_keys):
                d = raw_diff[k]
                if d > 0:
                    sources.append([k, int(d)])
                    continue
                if d >= 0:
                    continue
                need = int(-d)
                # Cỡ lớn gần nhất hạ xuống trước.
                for src in reversed(sources):
                    if need <= 0:
                        break
                    if src[1] <= 0:
                        continue
                    use = min(need, src[1])
                    if use > 0:
                        size_transfers.append((src[0], k, use))
                        src[1] -= use
                        need -= use
                        transfer_used += use
                residual_under[k] = need
            final_positive_surplus = sum(max(0, int(src[1])) for src in sources)
            for k, qty in residual_under.items():
                if qty > under_limit_for(k):
                    unresolved[k] = qty - under_limit_for(k)
        elif allow_under:
            final_positive_surplus = sum(max(0, raw_diff[k]) for k in ordered_keys)
            for k, qty in residual_under.items():
                if qty > under_limit_for(k):
                    unresolved[k] = qty - under_limit_for(k)

        if over_too_high:
            raise ValueError(
                f"Sản lượng dương vượt giới hạn chế độ {profile.get('label','')}: " + ', '.join(
                    f"{name_map.get(k, k)} +{v} (max +{over_limit_for(k)})"
                    for k, v in over_too_high.items()
                )
            )

        if allow_under and total_surplus_cap >= 0 and final_positive_surplus > total_surplus_cap:
            raise ValueError(
                f"Tổng sản lượng dương sau khi hạ cỡ còn {final_positive_surplus} SP, "
                f"vượt giới hạn {total_surplus_cap} SP ({total_surplus_pct * 100:g}% tổng sản lượng). "
                f"Hãy dùng TOÀN CỤC để phần mềm thử thêm bàn và giảm dương."
            )

        return tables, {
            'unresolved': unresolved,
            'fabric_mode': profile.get('mode', fabric_mode),
            'fabric_mode_label': profile.get('label', ''),
            'over_limits': over_limits,
            'under_limits': under_limits,
            'allow_under': allow_under,
            'downgrade_large_to_small': downgrade_large_to_small,
            'raw_diff': raw_diff,
            'residual_under': residual_under,
            'size_transfers': size_transfers,
            'transfer_used': transfer_used,
            'final_positive_surplus': final_positive_surplus,
            'total_surplus_cap': total_surplus_cap,
            'total_surplus_pct': total_surplus_pct,
            'target_min_marker': target_min_marker,
            'short_marker_warning': short_marker_warning,
        }

    # ==================== TÍNH TOÁN VÀ XEM TRƯỚC ====================
    def calculate_cutting_plan(self, force_recalculate=False):
        # V93: lấy cả dữ liệu PO/MÀU vừa gõ nhưng chưa FocusOut trước khi tính/xuất Excel.
        try:
            self._sync_po_grid_from_ui()
        except Exception:
            pass

        if not self.po_list:
            return None, "Chưa có dữ liệu PO!"

        if not self.fabric_list:
            return None, "Chưa có dữ liệu loại vải!"

        # Trước mỗi lần tính/xuất, đồng bộ kho LOT dùng chung theo phạm vi LOẠI VẢI + PO.
        # Nếu PO thay đổi, số mét LOT được chia lại theo sản lượng hiện tại.
        self._sync_all_shade_lots()

        # V62: commit % tăng từng cỡ trước khi tính. Kế hoạch Python và Excel dùng cùng số lượng.
        try:
            self._sync_size_percent_from_ui(silent=False)
        except ValueError as e:
            return None, str(e)

        # V107: tạo chữ ký từ đúng dữ liệu ảnh hưởng tới kế hoạch cắt.
        # Xuất Excel ngay sau Xem trước sẽ dùng lại kết quả, không tối ưu lần nữa.
        cache_key = None
        try:
            cache_payload = {
                'sizes': self.sizes,
                'po_list': self.po_list,
                'fabric_list': self.fabric_list,
                'global_lot_rows': self.global_lot_rows,
                'increase_enabled': bool(self.increase_enabled_var.get()),
                'increase_mode': str(self.increase_mode_var.get()),
                'max_over': int(self.MAX_OVER),
            }
            cache_key = json.dumps(cache_payload, ensure_ascii=False, sort_keys=True, default=str)
            if (not force_recalculate and
                    cache_key == getattr(self, '_cut_plan_cache_key', None) and
                    getattr(self, '_cut_plan_cache_results', None) is not None):
                self._export_progress(55, 'Dùng lại kết quả tối ưu đã tính')
                return self._cut_plan_cache_results, None
        except Exception:
            cache_key = None

        size_keys = [s['key'] for s in self.sizes]
        production_percent = 0.0  # giữ field cũ để tương thích dự án trước
        size_factor = {s['key']: s.get('factor', 1.0) for s in self.sizes}

        results = []
        _fabric_total_count = max(1, len(self.fabric_list))
        for _fabric_progress_idx, fabric in enumerate(self.fabric_list):
            _p0 = 8 + int(47 * _fabric_progress_idx / _fabric_total_count)
            self._export_progress(_p0, f"Đang tối ưu {fabric.get('name', 'loại vải')}")
            # V137: % thật cho nút TÍNH TOÀN BỘ.
            _cp0 = 5 + int(85 * _fabric_progress_idx / _fabric_total_count)
            self._calc_all_progress(_cp0, f"Đang tính {fabric.get('name', 'loại vải')}")
            raw_total_by_size = self._fabric_total_by_size(fabric)
            total_by_size = self._fabric_planned_total_by_size(fabric)
            if sum(total_by_size.values()) <= 0:
                return None, (f"Loại vải '{fabric['name']}' không có sản lượng từ PO đã chọn. "
                              f"PO áp dụng: {self._fabric_po_display(fabric)}")

            norm = fabric['norm']
            min_len = max(0.0, float(fabric.get('min_length', 1.0) or 0))
            max_len = float(fabric.get('max_length', 0) or 0)
            max_products = int(fabric.get('max_products', 0) or 0)
            balance_pct = float(fabric.get('balance_pct', 1.0) if fabric.get('balance_pct', 1.0) is not None else 1.0)

            resolved_mode = self._resolved_fabric_mode(fabric)
            optimizer_mode = self._optimizer_mode_key_from_label(fabric.get('optimizer_mode', 'global'))
            try:
                cutting_tables, adjust_info = self._run_optimizer_strategy(
                    optimizer_mode, dict(total_by_size), size_factor, norm,
                    max_len, max_products, resolved_mode, min_len, balance_pct,
                    fabric=fabric
                )
            except ValueError as e:
                return None, f"{fabric.get('name','Loại vải')}: {e}"
            except Exception as e:
                return None, f"Lỗi tính loại vải '{fabric.get('name','')}': {e}"

            unresolved = adjust_info.get('unresolved', {}) if isinstance(adjust_info, dict) else {}
            if unresolved:
                names_missing = {s['key']: s['name'] for s in self.sizes}
                detail = ', '.join(f"{names_missing.get(k, k)} thiếu {v}" for k, v in unresolved.items())
                return None, ("Phần mềm đã tự cân lại các bàn nhưng vẫn chưa thể đủ sản lượng: " + detail +
                              ". Không cần tăng số lượng đơn hàng. Hãy thử giảm Chiều dài tối thiểu, tăng Chiều dài tối đa "
                              "hoặc chọn chế độ giác cho phép dương rộng hơn.")

            # V130: BÀN CHÍNH - tăng chiều dài để giảm số lá trải.
            # Phép đổi này KHÔNG làm đổi sản lượng: nếu nhân toàn bộ tỷ lệ của
            # một bàn lên k lần và chia số lá cho k (k phải là ước của số lá),
            # thì sản lượng từng cỡ và tổng mét vải của bàn vẫn giữ nguyên.
            #
            # Mục tiêu:
            #   - bàn nhiều lá: ưu tiên kéo marker dài lên trong giới hạn MAX
            #     để giảm số lá, giảm thời gian trải;
            #   - bàn vét rất ít lá vẫn giữ tỷ lệ/chiều dài gọn, không kéo dài.
            # Áp dụng chung cho cả TOÀN CỤC và TUẦN TỰ, mọi loại vải.
            def _stretch_main_tables(_tables):
                if not _tables or max_len <= 0:
                    return _tables

                _name_map = {x['key']: x['name'] for x in self.sizes}
                _size_order = {x['key']: i for i, x in enumerate(self.sizes)}
                if optimizer_mode in ('high_plies', 'production'):
                    return _tables
                if optimizer_mode == 'long_marker':
                    _preferred = 4
                else:
                    _preferred = max(4, int(getattr(self, 'MIN_PREFERRED_PLIES', 10) or 10))
                _max_plies = max([int(t.get('plies', 0) or 0) for t in _tables] or [0])
                _min_plies = min([int(t.get('plies', 0) or 0) for t in _tables if int(t.get('plies', 0) or 0) > 0] or [0])

                # Chỉ coi là bàn vét cần bảo vệ khi thực sự ít lá hơn nhiều so với bàn chính.
                # VD 115 lá + 4 lá -> 4 lá phải giữ ngắn.
                # VD 144 lá + 110 lá -> cả hai đều là bàn chính và đều có thể kéo dài.
                _protect_tail = (_max_plies > 0 and _min_plies > 0 and
                                 (_min_plies < _preferred or _min_plies <= 0.50 * _max_plies))

                for _tb in _tables:
                    _n = int(_tb.get('plies', 0) or 0)
                    _rm = {k: int(v or 0) for k, v in (_tb.get('ratio_map', {}) or {}).items()
                           if int(v or 0) > 0}
                    if _n <= 0 or not _rm:
                        continue

                    # Bàn vét ít lá giữ marker gọn/ngắn theo logic trước.
                    if _protect_tail and _n == _min_plies:
                        continue

                    _raw = float(_tb.get('raw_length', _tb.get('length', 0)) or 0)
                    if _raw <= 0:
                        # V127: chiều dài = DMTB × tổng tỷ lệ.
                        _raw = float(norm) * sum(_rm.values())
                    if _raw <= 0:
                        continue

                    _ratio_total = sum(_rm.values())
                    if _ratio_total <= 0:
                        continue

                    # Giữ bàn sau khi co vẫn ít nhất khoảng MIN_PREFERRED_PLIES.
                    # Nhờ vậy không tạo bàn 4-5 lá dài gần MAX chỉ để giảm lá.
                    _max_factor_by_plies = max(1, _n // _preferred)
                    _max_factor_by_len = max(1, int((max_len + 1e-9) // _raw))
                    _max_factor = min(_max_factor_by_plies, _max_factor_by_len)
                    if max_products > 0:
                        _max_factor = min(_max_factor, max(1, int(max_products // _ratio_total)))
                    if _max_factor < 2:
                        continue

                    # Chọn hệ số LỚN NHẤT có thể chia hết số lá.
                    # VD 144 lá, marker 1.03m, MAX 4m -> k=3 -> 48 lá, 3.09m.
                    # VD 110 lá, marker 1.03m -> k=2 -> 55 lá, 2.06m.
                    _k = 1
                    for _f in range(_max_factor, 1, -1):
                        if _n % _f == 0:
                            _k = _f
                            break
                    if _k <= 1:
                        continue

                    _new_n = _n // _k
                    _new_rm = {k: int(v) * _k for k, v in _rm.items()}
                    _new_raw = _raw * _k
                    _new_ratio_total = sum(_new_rm.values())
                    if _new_n < _preferred:
                        continue
                    if _new_raw > max_len + 1e-9:
                        continue
                    if max_products > 0 and _new_ratio_total > max_products:
                        continue

                    # Kiểm tra bất biến sản lượng từng cỡ trước khi nhận.
                    _ok = True
                    for _k_size, _old_r in _rm.items():
                        if int(_old_r) * _n != int(_new_rm[_k_size]) * _new_n:
                            _ok = False
                            break
                    if not _ok:
                        continue

                    _tb['plies'] = int(_new_n)
                    _tb['ratio_map'] = dict(_new_rm)
                    _tb['raw_length'] = float(_new_raw)
                    _tb['length'] = float(_new_raw)
                    _tb['ratio'] = ' + '.join(
                        f"{_name_map.get(k, k)}/{int(_new_rm[k])}"
                        for k in sorted(_new_rm, key=lambda x: _size_order.get(x, 10**6))
                    )
                    _tb['size_count'] = len(_new_rm)
                    _tb['meter_rate'] = float(_new_raw) / max(1, _new_ratio_total)
                    # sizes/total_output giữ nguyên vì sản lượng không đổi.

                return _tables

            cutting_tables = _stretch_main_tables([dict(tb) for tb in cutting_tables])

            # V119: quy tắc chung sau khi tính xong cho TẤT CẢ LOẠI VẢI và
            # cả hai kiểu TOÀN CỤC / TUẦN TỰ:
            #   - nhiều lá đặt trước;
            #   - bàn có ít lá nhất đặt cuối;
            #   - nếu nhiều bàn cùng số lá ít nhất, bàn có tổng tỷ lệ ít hơn và
            #     chiều dài sơ đồ ngắn hơn phải nằm sau cùng.
            # Chỉ đổi THỨ TỰ, không đổi sản lượng/tỷ lệ của phương án đã chọn.
            base_cutting_tables = [dict(tb) for tb in cutting_tables]

            def _final_ratio_total(_tb):
                _rm = _tb.get('ratio_map', {}) or {}
                if _rm:
                    return sum(int(v or 0) for v in _rm.values())
                # Fallback hiếm cho dữ liệu cũ không có ratio_map.
                return int(_tb.get('size_count', 0) or 0)

            if len(base_cutting_tables) > 1:
                _last_idx = min(
                    range(len(base_cutting_tables)),
                    key=lambda _i: (
                        int(base_cutting_tables[_i].get('plies', 0) or 0),
                        _final_ratio_total(base_cutting_tables[_i]),
                        float(base_cutting_tables[_i].get(
                            'raw_length', base_cutting_tables[_i].get('length', 0)
                        ) or 0),
                        int(base_cutting_tables[_i].get('size_count', 0) or 0),
                        _i,
                    )
                )
                _last_tb = base_cutting_tables.pop(_last_idx)
                base_cutting_tables.sort(
                    key=lambda tb: (
                        -int(tb.get('plies', 0) or 0),
                        -_final_ratio_total(tb),
                        -float(tb.get('raw_length', tb.get('length', 0)) or 0),
                        -int(tb.get('size_count', 0) or 0),
                        -int(tb.get('total_output', 0) or 0),
                    )
                )
                base_cutting_tables.append(_last_tb)

            for _bi, _tb in enumerate(base_cutting_tables, start=1):
                _tb['table'] = f'B{_bi}'

            # Phần xem trước vẫn dùng bộ phân LOT Python để người dùng thấy kế hoạch
            # dự kiến ngay trong giao diện trước khi xuất.
            preview_tables, lot_summary = self.allocate_lots_to_tables(fabric, base_cutting_tables)

            results.append({
                'fabric': fabric,
                'raw_total_by_size': dict(raw_total_by_size),
                'total_by_size': dict(total_by_size),
                'production_percent': production_percent,
                'cutting_tables': base_cutting_tables,
                'preview_tables': preview_tables,
                'lot_summary': lot_summary,
                'adjust_info': adjust_info,
                'fabric_mode': resolved_mode,
                'fabric_mode_label': self.FABRIC_MODE_LABELS.get(resolved_mode, 'VẢI CHÍNH')
            })
            _p1 = 8 + int(47 * (_fabric_progress_idx + 1) / _fabric_total_count)
            self._export_progress(_p1, f"Đã tối ưu {fabric.get('name', 'loại vải')}")
            _cp1 = 5 + int(85 * (_fabric_progress_idx + 1) / _fabric_total_count)
            self._calc_all_progress(_cp1, f"Đã tính {fabric.get('name', 'loại vải')}")

        if cache_key is not None:
            self._cut_plan_cache_key = cache_key
            self._cut_plan_cache_results = results
        return results, None

    def preview_calculation(self):
        # V149: không có tab XUẤT EXCEL nên XEM TRƯỚC dùng cửa sổ riêng.
        try:
            ok = hasattr(self, 'preview_text') and self.preview_text is not None and self.preview_text.winfo_exists()
        except Exception:
            ok = False
        if not ok:
            top = tk.Toplevel(self.root)
            top.title('XEM TRƯỚC KẾ HOẠCH CẮT')
            try:
                top.geometry('980x680')
                top.minsize(760, 520)
            except Exception:
                pass
            top.configure(bg=self.UI_BG)

            head = tk.Frame(top, bg=self.UI_NAVY_DARK, height=42)
            head.pack(fill='x')
            head.pack_propagate(False)
            tk.Label(
                head, text='👁  XEM TRƯỚC KẾ HOẠCH CẮT',
                font=('Segoe UI', 11, 'bold'),
                bg=self.UI_NAVY_DARK, fg='white'
            ).pack(side='left', padx=12, pady=10)

            body = tk.Frame(top, bg=self.UI_BG)
            body.pack(fill='both', expand=True, padx=10, pady=10)
            scroll = ttk.Scrollbar(body, orient='vertical')
            scroll.pack(side='right', fill='y')
            self.preview_text = tk.Text(
                body, font=('Consolas', 9),
                bg='white', fg=self.UI_TEXT,
                relief='flat', bd=0,
                highlightthickness=1,
                highlightbackground=self.UI_BORDER,
                padx=10, pady=8,
                yscrollcommand=scroll.set
            )
            self.preview_text.pack(side='left', fill='both', expand=True)
            scroll.configure(command=self.preview_text.yview)
            self._preview_window = top

        results, error = self.calculate_cutting_plan()

        if error:
            self.preview_text.delete('1.0', tk.END)
            self.preview_text.insert('1.0', f"LỖI: {error}")
            return

        self.preview_text.delete('1.0', tk.END)
        info = self.get_current_info()
        names = [s['name'] for s in self.sizes]
        keys = [s['key'] for s in self.sizes]
        name_map = {s['key']: s['name'] for s in self.sizes}

        preview = "=" * 70 + "\n"
        preview += "XEM TRƯỚC KẾ HOẠCH CẮT (TỐI ƯU)\n"
        preview += "=" * 70 + "\n\n"

        preview += f"KHÁCH HÀNG/CUSTOMER: {info['customer']}\n"
        preview += f"MÃ HÀNG/STYLE: {info['style']}\n"
        preview += f"ĐỢT/BATCH: {info['batch']}\n"
        preview += f"MÙA/SEASON: {info['season']}\n"
        preview += f"MÀU/COLOR: {info['color']}\n"
        preview += f"CODE: {info['code']}\n"
        preview += f"DATE: {info['date']}\n\n"

        preview += "📌 V77: Chiều dài tối thiểu là mục tiêu; bàn ít lá tự giảm tỷ lệ tới gần sàn. Nếu sản lượng không cho phép đạt sàn, vẫn giữ bàn tốt nhất và cho xuất Excel.\n\n"

        preview += "-" * 70 + "\n"
        preview += "TỔNG HỢP SỐ LƯỢNG THEO CỠ\n"
        preview += "-" * 70 + "\n"
        header = f"{'PO':<10}" + ''.join(f"{n[:8]:>8}" for n in names) + f"{'TỔNG':>8}\n"
        preview += header

        total_all = {key: 0 for key in keys}
        for po in self.po_list:
            row = f"{po['po']:<10}" + ''.join(f"{po.get(key, 0):>8}" for key in keys)
            row += f"{sum(po.get(key, 0) for key in keys):>8}\n"
            preview += row
            for key in keys:
                total_all[key] += po.get(key, 0)

        total_qty = sum(total_all.values())
        preview += "-" * 70 + "\n"
        preview += f"{'TỔNG ĐH':<10}" + ''.join(f"{total_all[k]:>8}" for k in keys) + f"{total_qty:>8}\n"

        preview += "% dương/tăng sản lượng sẽ nhập RIÊNG cho từng cỡ trong file Excel sau khi xuất.\n\n"

        for result in results:
            fabric = result['fabric']
            tables = result.get('preview_tables', result['cutting_tables'])
            preview += "=" * 70 + "\n"
            preview += f"LOẠI VẢI: {fabric['name']}\n"
            preview += f"CHẾ ĐỘ GIÁC: {result.get('fabric_mode_label', self._fabric_mode_display(fabric))}\n"
            preview += f"PO áp dụng: {self._fabric_po_display(fabric)}\n"
            fabric_targets = result.get('raw_total_by_size', {})
            preview += "Sản lượng áp dụng: " + ", ".join(
                f"{name_map.get(k, k)}={fabric_targets.get(k, 0)}" for k in keys
            ) + "\n"
            _minl = max(0.0, float(fabric.get('min_length',1.0) or 0))
            _ml = float(fabric.get('max_length',0) or 0)
            _mp = int(fabric.get('max_products',0) or 0)
            _limits = [f"Chiều dài tối thiểu: {_minl:.2f} m"]
            if _ml > 0: _limits.append(f"Chiều dài tối đa: {_ml:.2f} m")
            if _mp > 0: _limits.append(f"SP tối đa/sơ đồ: {_mp}")
            preview += f"Định mức: {fabric['norm']:.2f} m | " + " | ".join(_limits) + "\n"
            preview += f"Số bàn: {len(tables)}\n"
            preview += "=" * 70 + "\n"

            preview += f"{'Bàn':<8} {'Tỉ lệ sơ đồ':<28} {'Dài':>7} {'Lá':>6} {'LOT':<16} {'Mét dùng':>10}\n"
            preview += "-" * 90 + "\n"

            total_plies = 0
            size_output = {key: 0 for key in keys}

            for table in tables:
                lot_name = table.get('lot', '')
                meters_need = float(table.get('meters_needed', float(table['length']) * int(table['plies']) * 1.01))
                preview += f"{table['table']:<8} {table['ratio']:<28} {table['length']:>7.2f} {table['plies']:>6} {lot_name:<16} {meters_need:>10.2f}\n"
                total_plies += table['plies']
                for size, qty in table['sizes'].items():
                    size_output[size] += qty

            # SẢN LƯỢNG THỰC CẮT = đúng tổng sản lượng thể hiện trên các bàn.

            preview += "-" * 70 + "\n"
            preview += f"{'Tổng số lá':<50} {total_plies}\n"
            preview += "\n"

            preview += "SO SÁNH SẢN LƯỢNG (Định mức / Thực cắt / Chênh lệch):\n"
            for key, name in zip(keys, names):
                required = result['total_by_size'].get(key, 0)
                actual = size_output.get(key, 0)
                diff = actual - required
                diff_str = f"+{diff}" if diff > 0 else str(diff)
                if required > 0 or actual > 0:
                    _tag = '(DƯƠNG)' if diff > 0 else ('(ÂM)' if diff < 0 else '')
                    preview += f"  {name.upper():>8}: {required:>6} / {actual:>6} / {diff_str:>5} {_tag}\n"

            _transfers = (result.get('adjust_info') or {}).get('size_transfers', [])
            if _transfers:
                preview += "  HẠ CỠ (cỡ lớn -> cỡ bé): " + ', '.join(
                    f"{name_map.get(src, src)}->{name_map.get(dst, dst)}: {qty}"
                    for src, dst, qty in _transfers if int(qty or 0) > 0
                ) + "\n"

            over_limit = []
            _limits_map = (result.get('adjust_info') or {}).get('over_limits', {})
            for key, name in zip(keys, names):
                required = result['total_by_size'].get(key, 0)
                actual = size_output.get(key, 0)
                diff = actual - required
                _cap = int(_limits_map.get(key, self.MAX_OVER) or 0)
                if diff > _cap:
                    over_limit.append(f"{name.upper()}(+{diff}, max +{_cap})")

            if over_limit:
                preview += f"\n⚠️  CẢNH BÁO DƯƠNG: {', '.join(over_limit)}\n"

            lot_summary = result.get('lot_summary', [])
            if lot_summary:
                preview += "\nPHÂN BỔ LOT (m):\n"
                for lot in lot_summary:
                    preview += f"  {lot['name']}: nhập {lot['meters']:.2f} | dùng {lot['used']:.2f} | còn {lot['remaining']:.2f}\n"
            missing = sum(float(t.get('meters_needed', 0)) for t in tables if t.get('lot') == 'THIẾU VẢI')
            if missing > 0:
                preview += f"  ⚠️ THIẾU VẢI: {missing:.2f} m chưa có LOT đủ để phân.\n"

            preview += "\n"

        self.preview_text.insert('1.0', preview)
        try:
            if hasattr(self, 'fabric_nav_tree') and self.fabric_nav_tree.selection():
                _idx = int(str(self.fabric_nav_tree.selection()[0]).replace('fabric_', ''))
                self._show_fabric_dashboard(_idx)
        except Exception:
            pass
        self.status_var.set("Đã xem trước kết quả tính toán tối ưu")

    def get_current_info(self):
        return {
            'customer': self.entry_customer.get(),
            'style': self.entry_style.get(),
            'batch': self.entry_batch.get(),
            'season': self.entry_season.get(),
            'color': self.entry_color.get(),
            'code': self.entry_code.get(),
            'date': self.entry_date.get()
        }
    
    # ==================== V36: LƯU / MỞ DỰ ÁN ====================
    def _project_logo_payload(self):
        """Nhúng logo vào file .cutplan để dự án có thể mang sang máy khác."""
        path = str(getattr(self, 'logo_path', '') or '').strip()
        if not path or not os.path.isfile(path):
            return None
        try:
            # Tránh làm file dự án quá nặng nếu người dùng chọn nhầm ảnh rất lớn.
            if os.path.getsize(path) > 8 * 1024 * 1024:
                return {'name': os.path.basename(path), 'path': path, 'embedded': False}
            with open(path, 'rb') as f:
                raw = f.read()
            return {
                'name': os.path.basename(path),
                'path': path,
                'embedded': True,
                'data_base64': base64.b64encode(raw).decode('ascii')
            }
        except Exception:
            return {'name': os.path.basename(path), 'path': path, 'embedded': False}

    def _build_project_payload(self):
        """Tạo dữ liệu JSON thuần để lưu toàn bộ trạng thái có ý nghĩa của phần mềm."""
        try:
            # Ép các Entry đang sửa phát FocusOut để dữ liệu lưới PO/CÂY được commit trước khi lưu.
            self.root.focus_set()
            self.root.update_idletasks()
        except Exception:
            pass

        # V122: commit trực tiếp % DƯƠNG đang gõ trước khi tạo payload.
        # Chỉ dựa vào FocusOut có thể bỏ sót giá trị nếu người dùng vừa sửa % rồi bấm LƯU DỰ ÁN ngay.
        self._sync_size_percent_from_ui(silent=False)
        try:
            self._sync_po_grid_from_ui()
        except Exception:
            pass

        info = self.get_current_info()
        surplus_percent_state = {
            'enabled': self._increase_enabled(),
            'mode': self._increase_mode(),
            'by_size': {
                str(sz.get('key', '')): float(sz.get('increase_pct', 0.0) or 0.0)
                for sz in self.sizes if str(sz.get('key', '') or '').strip()
            },
            # Lưu theo thứ tự PO để cả lựa chọn DƯƠNG TỪNG PO cũng được khôi phục đúng.
            'po_apply': [bool(po.get('apply_increase', False)) for po in self.po_list],
        }
        return {
            'format': self.PROJECT_MAGIC,
            'schema_version': self.PROJECT_SCHEMA,
            'app_version': self.APP_VERSION,
            'info': info,
            'custom_info_list': self.custom_info_list,
            'sizes': self.sizes,
            'next_size_number': self.next_size_number,
            'po_list': self.po_list,
            'fabric_list': self.fabric_list,
            'global_lot_rows': self.global_lot_rows,
            # V122: lưu riêng toàn bộ cấu hình % DƯƠNG để dự án mở lại đúng như lúc lưu.
            'surplus_percent_state': surplus_percent_state,
            'settings': {
                'MAX_OVER': self.MAX_OVER,
                'MIN_PREFERRED_PLIES': self.MIN_PREFERRED_PLIES,
                'MIN_MARKER_LENGTH': self.MIN_MARKER_LENGTH,
                'increase_enabled': self._increase_enabled(),
                'increase_mode': self._increase_mode(),
                'EXTRA_SURPLUS_ROWS': self._get_extra_surplus_rows(silent=True),
                'ROLL_EXTRA_BLANK_ROWS': self._get_roll_extra_blank_rows(silent=True),
            },
            # V113: lưu luôn toàn bộ dữ liệu ở menu PHÂN SỐ CẮT & BIỂU 10.
            # Hai nút XUẤT BẢNG CẮT / XUẤT FORM 10 dùng chung bộ dữ liệu này,
            # nên khi mở lại dự án sẽ tiếp tục xuất được đúng trạng thái đã lưu.
            'aux_cut_state': (
                self.aux_cut_panel.get_project_state()
                if hasattr(self, 'aux_cut_panel') and self.aux_cut_panel is not None
                else None
            ),
            'logo': self._project_logo_payload(),
        }

    def _set_cutplan_hidden(self, filename, hidden=True):
        """Đặt/bỏ thuộc tính Hidden cho file .cutplan trên Windows.

        Chỉ thay thuộc tính của file, không đổi tên/đuôi/nội dung nên phần mềm
        vẫn có thể mở trực tiếp bằng đường dẫn đầy đủ.
        """
        try:
            path = os.path.abspath(str(filename or ''))
            if not path.lower().endswith('.cutplan') or not os.path.isfile(path):
                return False
            if os.name != 'nt':
                return True

            import ctypes
            FILE_ATTRIBUTE_HIDDEN = 0x2
            INVALID_FILE_ATTRIBUTES = 0xFFFFFFFF
            kernel32 = ctypes.windll.kernel32
            kernel32.GetFileAttributesW.argtypes = [ctypes.c_wchar_p]
            kernel32.GetFileAttributesW.restype = ctypes.c_uint32
            kernel32.SetFileAttributesW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32]
            kernel32.SetFileAttributesW.restype = ctypes.c_int
            attrs = kernel32.GetFileAttributesW(path)
            if attrs == INVALID_FILE_ATTRIBUTES:
                return False
            new_attrs = (attrs | FILE_ATTRIBUTE_HIDDEN) if hidden else (attrs & ~FILE_ATTRIBUTE_HIDDEN)
            return bool(kernel32.SetFileAttributesW(path, new_attrs))
        except Exception:
            # Không để lỗi thuộc tính Hidden làm hỏng thao tác LƯU/MỞ dự án.
            return False

    def _project_picker_initial_dir(self):
        """Thư mục khởi đầu cho cửa sổ MỞ DỰ ÁN riêng của phần mềm."""
        candidates = []
        try:
            if self.current_project_path:
                candidates.append(os.path.dirname(os.path.abspath(self.current_project_path)))
        except Exception:
            pass
        try:
            last_dir = str(getattr(self, '_last_project_dir', '') or '').strip()
            if last_dir:
                candidates.append(last_dir)
        except Exception:
            pass
        try:
            candidates.append(os.path.join(os.path.expanduser('~'), 'Documents'))
        except Exception:
            pass
        candidates.append(os.getcwd())
        for folder in candidates:
            try:
                if folder and os.path.isdir(folder):
                    return os.path.abspath(folder)
            except Exception:
                pass
        return os.getcwd()

    def _choose_project_file_in_app(self):
        """Mở trực tiếp hộp chọn file Windows và ép hiện cả .cutplan đang Hidden.

        Không tạo thêm cửa sổ danh sách riêng. Trên Windows dùng GetOpenFileNameW
        với OFN_FORCESHOWHIDDEN để file .cutplan vẫn Hidden trong Explorer nhưng
        vẫn xuất hiện ngay trong hộp MỞ của phần mềm.
        """
        initial_dir = self._project_picker_initial_dir()

        # Windows: dùng Common File Dialog native + OFN_FORCESHOWHIDDEN.
        if os.name == 'nt':
            try:
                import ctypes
                from ctypes import wintypes

                OFN_READONLY = 0x00000001
                OFN_HIDEREADONLY = 0x00000004
                OFN_PATHMUSTEXIST = 0x00000800
                OFN_FILEMUSTEXIST = 0x00001000
                OFN_EXPLORER = 0x00080000
                OFN_NOCHANGEDIR = 0x00000008
                OFN_FORCESHOWHIDDEN = 0x10000000

                LPOFNHOOKPROC = ctypes.c_void_p

                class OPENFILENAMEW(ctypes.Structure):
                    _fields_ = [
                        ('lStructSize', wintypes.DWORD),
                        ('hwndOwner', wintypes.HWND),
                        ('hInstance', wintypes.HINSTANCE),
                        ('lpstrFilter', wintypes.LPCWSTR),
                        ('lpstrCustomFilter', wintypes.LPWSTR),
                        ('nMaxCustFilter', wintypes.DWORD),
                        ('nFilterIndex', wintypes.DWORD),
                        ('lpstrFile', wintypes.LPWSTR),
                        ('nMaxFile', wintypes.DWORD),
                        ('lpstrFileTitle', wintypes.LPWSTR),
                        ('nMaxFileTitle', wintypes.DWORD),
                        ('lpstrInitialDir', wintypes.LPCWSTR),
                        ('lpstrTitle', wintypes.LPCWSTR),
                        ('Flags', wintypes.DWORD),
                        ('nFileOffset', wintypes.WORD),
                        ('nFileExtension', wintypes.WORD),
                        ('lpstrDefExt', wintypes.LPCWSTR),
                        ('lCustData', wintypes.LPARAM),
                        ('lpfnHook', LPOFNHOOKPROC),
                        ('lpTemplateName', wintypes.LPCWSTR),
                        ('pvReserved', ctypes.c_void_p),
                        ('dwReserved', wintypes.DWORD),
                        ('FlagsEx', wintypes.DWORD),
                    ]

                # Bộ lọc: mặc định chỉ hiện dự án .cutplan.
                filter_text = (
                    'Dự án Cutting Plan (*.cutplan)\0*.cutplan\0'
                    'Tất cả file (*.*)\0*.*\0\0'
                )
                file_buffer = ctypes.create_unicode_buffer(32768)

                try:
                    self.root.update_idletasks()
                    owner = wintypes.HWND(int(self.root.winfo_id()))
                except Exception:
                    owner = None

                ofn = OPENFILENAMEW()
                ofn.lStructSize = ctypes.sizeof(OPENFILENAMEW)
                ofn.hwndOwner = owner
                ofn.lpstrFilter = filter_text
                ofn.nFilterIndex = 1
                ofn.lpstrFile = ctypes.cast(file_buffer, wintypes.LPWSTR)
                ofn.nMaxFile = len(file_buffer)
                ofn.lpstrInitialDir = initial_dir
                ofn.lpstrTitle = 'Mở dự án Cutting Plan (.cutplan)'
                ofn.Flags = (
                    OFN_EXPLORER
                    | OFN_FILEMUSTEXIST
                    | OFN_PATHMUSTEXIST
                    | OFN_HIDEREADONLY
                    | OFN_NOCHANGEDIR
                    | OFN_FORCESHOWHIDDEN
                )
                ofn.lpstrDefExt = 'cutplan'

                comdlg32 = ctypes.windll.comdlg32
                comdlg32.GetOpenFileNameW.argtypes = [ctypes.POINTER(OPENFILENAMEW)]
                comdlg32.GetOpenFileNameW.restype = wintypes.BOOL

                ok = bool(comdlg32.GetOpenFileNameW(ctypes.byref(ofn)))
                if not ok:
                    # 0 = người dùng bấm Cancel. Mã khác = lỗi dialog.
                    err = int(comdlg32.CommDlgExtendedError())
                    if err:
                        raise OSError(f'Windows OpenFile dialog error: 0x{err:08X}')
                    return None

                filename = os.path.abspath(file_buffer.value)
                if filename:
                    try:
                        self._last_project_dir = os.path.dirname(filename)
                    except Exception:
                        pass
                    return filename
                return None

            except Exception:
                # Nếu máy Windows nào đó không gọi được Common Dialog native,
                # fallback về hộp thoại Tkinter để vẫn mở dự án được.
                pass

        # Fallback (hoặc khi chạy ngoài Windows).
        filename = filedialog.askopenfilename(
            title='Mở dự án Cutting Plan (.cutplan)',
            initialdir=initial_dir,
            defaultextension='.cutplan',
            filetypes=[
                ('Cutting Plan Project', '*.cutplan'),
                ('All files', '*.*'),
            ],
            parent=self.root,
        )
        if filename:
            try:
                self._last_project_dir = os.path.dirname(os.path.abspath(filename))
            except Exception:
                pass
            return os.path.abspath(filename)
        return None

    def save_project(self, filename=None, silent=False):
        """Lưu dự án ra .cutplan. Trả về đường dẫn nếu thành công, None nếu lỗi/hủy."""
        self._last_project_error = ''
        if not filename:
            initial = ''
            style = ''
            try:
                style = self.entry_style.get().strip()
            except Exception:
                pass
            if self.current_project_path:
                initial = os.path.basename(self.current_project_path)
            else:
                initial = f"BC_{style or 'DU_AN'}.cutplan"
            filename = filedialog.asksaveasfilename(
                title='Lưu dự án Cutting Plan',
                defaultextension='.cutplan',
                filetypes=[('Cutting Plan Project', '*.cutplan'), ('JSON', '*.json'), ('All files', '*.*')],
                initialfile=initial
            )
            if not filename:
                return None
        if not os.path.splitext(filename)[1]:
            filename += '.cutplan'
        try:
            payload = self._build_project_payload()
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
            # 2.12-HIDDEN-CUTPLAN: .cutplan được ẩn trong File Explorer,
            # nhưng phần mềm vẫn mở trực tiếp bằng đường dẫn.
            self._set_cutplan_hidden(filename, True)
            self.current_project_path = os.path.abspath(filename)
            try:
                self._last_project_dir = os.path.dirname(self.current_project_path)
            except Exception:
                pass
            if hasattr(self, 'status_var'):
                self.status_var.set(f"Đã lưu dự án: {self.current_project_path}")
            if hasattr(self, 'export_status') and not silent:
                self.export_status.config(text=f"✓ Đã lưu dự án: {os.path.basename(filename)}", fg='#8e44ad')
            if not silent:
                messagebox.showinfo('Lưu dự án', f'Đã lưu toàn bộ dữ liệu dự án (bao gồm % DƯƠNG từng cỡ):\n\n{filename}')
            return filename
        except Exception as e:
            self._last_project_error = str(e)
            if not silent:
                messagebox.showerror('Lỗi lưu dự án', f'Không thể lưu file dự án:\n\n{e}')
            return None

    def save_project_manual(self):
        """V159 - SAVE.

        Nút LƯU trên thanh menu:
        - Có file hiện tại -> lưu đè vào đúng file đó, không hỏi lại đường dẫn.
        - Chưa có file hiện tại -> hỏi đường dẫn/tên file lần đầu.
        """
        if self.current_project_path:
            return self.save_project(self.current_project_path, silent=False)
        return self.save_project(None, silent=False)

    def save_project_as(self):
        """V159 - SAVE AS / LƯU DỰ ÁN MỚI.

        Luôn mở hộp thoại để người dùng chọn:
        - thư mục
        - tên file mới

        Sau khi lưu, file mới trở thành dự án hiện tại.
        Những lần bấm LƯU trên thanh menu sau đó sẽ lưu vào file mới này.
        """
        initial_file = ''
        initial_dir = ''

        try:
            style = self.entry_style.get().strip()
        except Exception:
            style = ''

        if self.current_project_path:
            try:
                initial_dir = os.path.dirname(os.path.abspath(self.current_project_path))
                initial_file = os.path.basename(self.current_project_path)
            except Exception:
                initial_dir = ''
                initial_file = ''

        if not initial_file:
            initial_file = f"BC_{style or 'DU_AN'}.cutplan"

        kwargs = {
            'title': 'Lưu dự án mới - Save As',
            'defaultextension': '.cutplan',
            'filetypes': [
                ('Cutting Plan Project', '*.cutplan'),
                ('JSON', '*.json'),
                ('All files', '*.*')
            ],
            'initialfile': initial_file,
        }
        if initial_dir and os.path.isdir(initial_dir):
            kwargs['initialdir'] = initial_dir

        filename = filedialog.asksaveasfilename(**kwargs)
        if not filename:
            return None

        if not os.path.splitext(filename)[1]:
            filename += '.cutplan'

        # Gọi save_project với đường dẫn cụ thể để không hiện hộp Save lần hai.
        saved = self.save_project(filename, silent=False)
        if saved:
            try:
                self.status_var.set(f"Đã LƯU DỰ ÁN MỚI: {os.path.abspath(saved)}")
            except Exception:
                pass
            try:
                self.export_status.config(
                    text=f"✓ Save As: {os.path.basename(saved)}",
                    fg=self.UI_PURPLE
                )
            except Exception:
                pass
        return saved

    def _restore_project_logo(self, logo_info):
        """Khôi phục logo nhúng trong dự án; nếu không có thì thử đường dẫn cũ."""
        if not isinstance(logo_info, dict):
            return
        path = str(logo_info.get('path', '') or '').strip()
        restored = None
        try:
            if logo_info.get('embedded') and logo_info.get('data_base64'):
                name = str(logo_info.get('name', '') or 'project_logo.png')
                ext = os.path.splitext(name)[1].lower()
                if ext not in ('.png', '.jpg', '.jpeg', '.bmp', '.webp'):
                    ext = '.png'
                restored = os.path.join(self._logo_config_dir(), 'project_logo' + ext)
                raw = base64.b64decode(str(logo_info.get('data_base64')).encode('ascii'))
                with open(restored, 'wb') as f:
                    f.write(raw)
            elif path and os.path.isfile(path):
                restored = path
        except Exception:
            restored = path if path and os.path.isfile(path) else None
        if restored and os.path.isfile(restored):
            self.logo_path = restored
            if hasattr(self, 'logo_name_var'):
                self.logo_name_var.set(str(logo_info.get('name', '') or os.path.basename(restored)))
            try:
                self._update_logo_preview()
            except Exception:
                pass

    def _apply_project_payload(self, data):
        if not isinstance(data, dict) or data.get('format') != self.PROJECT_MAGIC:
            raise ValueError('File không phải dự án Cutting Plan hợp lệ.')

        # ----- Dữ liệu cỡ -----
        sizes = data.get('sizes') or []
        clean_sizes = []
        seen_keys = set()
        for i, item in enumerate(sizes, start=1):
            if not isinstance(item, dict):
                continue
            key = str(item.get('key', '') or '').strip() or f'size{i}'
            if key in seen_keys:
                continue
            seen_keys.add(key)
            name = str(item.get('name', '') or '').strip() or f'SIZE {i}'
            try:
                factor = float(item.get('factor', 1.0) or 1.0)
            except Exception:
                factor = 1.0
            try:
                increase_pct = max(0.0, float(item.get('increase_pct', 0.0) or 0.0))
            except Exception:
                increase_pct = 0.0
            clean_sizes.append({'key': key, 'name': name, 'factor': factor, 'increase_pct': increase_pct})
        if not clean_sizes:
            clean_sizes = [
                {'key': 'size1', 'name': 'XS', 'factor': 0.90, 'increase_pct': 0.0},
                {'key': 'size2', 'name': 'S',  'factor': 0.95, 'increase_pct': 0.0},
                {'key': 'size3', 'name': 'M',  'factor': 1.00, 'increase_pct': 0.0},
                {'key': 'size4', 'name': 'L',  'factor': 1.05, 'increase_pct': 0.0},
                {'key': 'size5', 'name': 'XL', 'factor': 1.10, 'increase_pct': 0.0},
            ]
        self.sizes = clean_sizes

        # V122: nếu dự án có block % DƯƠNG riêng thì ưu tiên dùng block này.
        # Dự án cũ vẫn dùng increase_pct nằm trong từng size như trước.
        surplus_state = data.get('surplus_percent_state') if isinstance(data.get('surplus_percent_state'), dict) else {}
        saved_by_size = surplus_state.get('by_size') if isinstance(surplus_state.get('by_size'), dict) else {}
        if saved_by_size:
            for sz in self.sizes:
                key = str(sz.get('key', '') or '')
                if key in saved_by_size:
                    try:
                        sz['increase_pct'] = max(0.0, float(saved_by_size.get(key, 0.0) or 0.0))
                    except Exception:
                        pass

        try:
            self.next_size_number = max(int(data.get('next_size_number', 0) or 0), 1)
        except Exception:
            self.next_size_number = 1
        nums = []
        for s in self.sizes:
            m = re.search(r'(\d+)$', str(s.get('key', '')))
            if m:
                nums.append(int(m.group(1)))
        if nums:
            self.next_size_number = max(self.next_size_number, max(nums) + 1)

        # ----- PO -----
        self.po_list = []
        for item in data.get('po_list') or []:
            if not isinstance(item, dict):
                continue
            po = {'po': str(item.get('po', '') or '').strip(),
                  'color': str(item.get('color', '') or '').strip(),
                  'apply_increase': bool(item.get('apply_increase', True))}
            for sz in self.sizes:
                try:
                    po[sz['key']] = max(0, int(float(item.get(sz['key'], 0) or 0)))
                except Exception:
                    po[sz['key']] = 0
            po['total'] = sum(po[sz['key']] for sz in self.sizes)
            self.po_list.append(po)

        saved_po_apply = surplus_state.get('po_apply') if isinstance(surplus_state.get('po_apply'), list) else None
        if saved_po_apply is not None:
            for i, po in enumerate(self.po_list):
                if i < len(saved_po_apply):
                    po['apply_increase'] = bool(saved_po_apply[i])

        # ----- Kho LOT/CÂY -----
        raw_rows = data.get('global_lot_rows') or []
        self.global_lot_rows = [x for x in raw_rows if isinstance(x, dict)]
        for row in self.global_lot_rows:
            row.setdefault('lot', '')
            row.setdefault('lot_mark', '')
            self._ensure_lot_roll_details(row)
            self._recalc_lot_from_roll_details(row)

        # ----- Loại vải -----
        self.fabric_list = []
        for item in data.get('fabric_list') or []:
            if not isinstance(item, dict):
                continue
            f = dict(item)
            f['name'] = str(f.get('name', '') or '').strip()
            try:
                f['norm'] = float(f.get('norm', 0) or 0)
            except Exception:
                f['norm'] = 0.0
            try:
                f['min_length'] = max(0.0, float(f.get('min_length', 1.0) if f.get('min_length', 1.0) is not None else 1.0))
            except Exception:
                f['min_length'] = 1.0
            try:
                f['max_length'] = float(f.get('max_length', 0) or 0)
            except Exception:
                f['max_length'] = 0.0
            if f['max_length'] > 0 and f['min_length'] > f['max_length']:
                # Dự án cũ/giá trị lỗi: không làm hỏng file; hạ min về max để vẫn mở được.
                f['min_length'] = f['max_length']
            try:
                f['max_products'] = max(0, int(float(f.get('max_products', 0) or 0)))
            except Exception:
                f['max_products'] = 0
            f.setdefault('cut_mode', 'auto')
            f.setdefault('optimizer_mode', 'global')
            try:
                f['balance_pct'] = max(0.0, min(100.0, float(f.get('balance_pct', 1.0) if f.get('balance_pct', 1.0) is not None else 1.0)))
            except Exception:
                f['balance_pct'] = 1.0
            # V163: dự án cũ chưa có 2 trường này sẽ tự dùng mặc định 1 m / 1 lá.
            try:
                f['reserve_m'] = max(0.0, float(f.get('reserve_m', 1.0) if f.get('reserve_m', 1.0) is not None else 1.0))
            except Exception:
                f['reserve_m'] = 1.0
            try:
                f['reserve_plies'] = max(1, int(float(f.get('reserve_plies', 1) or 1)))
            except Exception:
                f['reserve_plies'] = 1
            f.setdefault('po_mode', 'all')
            f.setdefault('po_targets', [])
            f.setdefault('lot_mode', 'none')
            f.setdefault('lot_targets', [])
            f.setdefault('export_roll', True)
            f.setdefault('roll_po_targets', [])
            f.setdefault('roll_po_selection_set', False)
            f.setdefault('export_edit', True)
            f.setdefault('lots', [])
            f.setdefault('rolls', [])
            f.setdefault('shades', [])
            self.fabric_list.append(f)

        # ----- Thông tin chung / bổ sung -----
        info = data.get('info') if isinstance(data.get('info'), dict) else {}
        defaults = {'customer':'', 'style':'', 'batch':'', 'season':'', 'color':'',
                    'code':'F-TECH-17', 'date':'15/12/2023'}
        defaults.update({k: str(v or '') for k, v in info.items() if k in defaults})
        self.info = defaults
        for key, value in defaults.items():
            ent = getattr(self, f'entry_{key}', None)
            if ent is not None:
                ent.delete(0, tk.END)
                ent.insert(0, value)
        self.custom_info_list = [x for x in (data.get('custom_info_list') or []) if isinstance(x, dict)]

        settings = data.get('settings') if isinstance(data.get('settings'), dict) else {}
        try:
            self.MAX_OVER = int(settings.get('MAX_OVER', self.MAX_OVER))
        except Exception:
            pass
        try:
            self.MIN_PREFERRED_PLIES = int(settings.get('MIN_PREFERRED_PLIES', self.MIN_PREFERRED_PLIES))
        except Exception:
            pass
        try:
            self.MIN_MARKER_LENGTH = max(0.0, float(settings.get('MIN_MARKER_LENGTH', self.MIN_MARKER_LENGTH)))
        except Exception:
            self.MIN_MARKER_LENGTH = 1.0
        try:
            enabled_value = surplus_state.get('enabled', settings.get('increase_enabled', True))
            self.increase_enabled_var.set(bool(enabled_value))
        except Exception:
            pass
        try:
            mode = str(surplus_state.get('mode', settings.get('increase_mode', 'all')) or 'all').strip().lower()
            self.increase_mode_var.set(mode if mode in ('all', 'selected') else 'all')
        except Exception:
            pass
        try:
            self.EXTRA_SURPLUS_ROWS = min(20, max(0, int(float(settings.get('EXTRA_SURPLUS_ROWS', self.EXTRA_SURPLUS_ROWS) or 0))))
            if hasattr(self, 'extra_surplus_rows_var'):
                self.extra_surplus_rows_var.set(str(self.EXTRA_SURPLUS_ROWS))
        except Exception:
            self.EXTRA_SURPLUS_ROWS = 3
            if hasattr(self, 'extra_surplus_rows_var'):
                self.extra_surplus_rows_var.set('3')
        try:
            self.ROLL_EXTRA_BLANK_ROWS = min(20, max(0, int(float(
                settings.get('ROLL_EXTRA_BLANK_ROWS', self.ROLL_EXTRA_BLANK_ROWS) or 0
            ))))
            if hasattr(self, 'roll_extra_blank_rows_var'):
                self.roll_extra_blank_rows_var.set(str(self.ROLL_EXTRA_BLANK_ROWS))
        except Exception:
            self.ROLL_EXTRA_BLANK_ROWS = 3
            if hasattr(self, 'roll_extra_blank_rows_var'):
                self.roll_extra_blank_rows_var.set('3')

        # ----- Vẽ lại toàn bộ giao diện dựa trên dữ liệu vừa nạp -----
        self.refresh_size_ui()
        self.update_custom_info_table()
        self._refresh_fabric_po_selector()
        self._refresh_fabric_lot_selector()
        if self.fabric_list:
            self._sync_global_lots()
        self.update_fabric_table()
        if hasattr(self, 'refresh_global_lot_inventory'):
            self.refresh_global_lot_inventory()
        self.refresh_lot_table()
        self.update_summary()
        if hasattr(self, 'preview_text'):
            self.preview_text.delete('1.0', tk.END)
        self._restore_project_logo(data.get('logo'))

        # V113: khôi phục luôn dữ liệu dùng chung cho XUẤT BẢNG CẮT + FORM 10.
        # File dự án cũ không có aux_cut_state vẫn mở bình thường.
        aux_state = data.get('aux_cut_state')
        if aux_state is not None and hasattr(self, 'aux_cut_panel') and self.aux_cut_panel is not None:
            try:
                self.aux_cut_panel.apply_project_state(aux_state)
            except Exception as e:
                # Không làm hỏng việc mở toàn bộ dự án nếu riêng phần phụ có dữ liệu cũ/lỗi.
                if hasattr(self, 'status_var'):
                    self.status_var.set(f"Đã mở dự án; phần BẢNG CẮT/FORM 10 chưa khôi phục hết: {e}")

    def load_project(self, filename=None, confirm=True, silent=False):
        """Mở file .cutplan và nạp lại trạng thái để tiếp tục chỉnh sửa."""
        if not filename:
            # 2.12-HIDDEN-CUTPLAN: mở thẳng hộp chọn file Windows và ép hiển thị
            # cả .cutplan đang Hidden; không tạo thêm cửa sổ danh sách riêng.
            filename = self._choose_project_file_in_app()
            if not filename:
                return None
        if confirm and (self.po_list or self.fabric_list or self.global_lot_rows):
            ok = messagebox.askyesno(
                'Mở dự án',
                'Dữ liệu hiện tại sẽ được thay bằng dữ liệu trong file dự án.\n\nBạn có tiếp tục không?'
            )
            if not ok:
                return None
        try:
            with open(filename, 'r', encoding='utf-8-sig') as f:
                data = json.load(f)
            self._apply_project_payload(data)
            self.current_project_path = os.path.abspath(filename)
            # File .cutplan cũ nếu đang hiện sẽ được chuyển sang Hidden sau khi mở thành công.
            self._set_cutplan_hidden(self.current_project_path, True)
            try:
                self._last_project_dir = os.path.dirname(self.current_project_path)
            except Exception:
                pass
            if hasattr(self, 'status_var'):
                self.status_var.set(f"Đã mở dự án: {self.current_project_path}")
            if hasattr(self, 'export_status'):
                self.export_status.config(text=f"✓ Đã mở: {os.path.basename(filename)}", fg='#2471a3')
            if not silent:
                messagebox.showinfo(
                    'Mở dự án thành công',
                    f'Đã nạp lại dữ liệu để tiếp tục chỉnh sửa.\n\n{filename}'
                )
            return filename
        except Exception as e:
            if not silent:
                messagebox.showerror('Lỗi mở dự án', f'Không thể mở file dự án:\n\n{e}')
            return None

    # ==================== XUẤT FILE EXCEL ====================
    def _export_progress_begin(self):
        """V150: bắt đầu xuất, khóa nút và giữ cửa sổ phản hồi."""
        self._export_progress_active = True
        self._export_progress_value = 0
        self._export_progress_started = time.monotonic()
        self._export_busy = True
        btn = getattr(self, 'fixed_export_button', None)
        if btn is not None:
            try:
                btn.config(
                    state='disabled',
                    text='⏳ ĐANG XUẤT... 0%',
                    bg='#9aa4ad', fg='white',
                    activebackground='#9aa4ad',
                    activeforeground='white',
                    disabledforeground='white',
                    relief='sunken'
                )
            except Exception:
                pass
        try:
            self.root.configure(cursor='watch')
            self.root.update()
        except Exception:
            pass

    def _export_progress(self, percent, stage=''):
        """V150: cập nhật tiến độ thật và xử lý event Windows."""
        if not getattr(self, '_export_progress_active', False):
            return
        try:
            pct = max(
                int(getattr(self, '_export_progress_value', 0) or 0),
                min(100, int(percent))
            )
        except Exception:
            pct = 0
        self._export_progress_value = pct

        btn = getattr(self, 'fixed_export_button', None)
        if btn is not None:
            try:
                btn.config(text=f'⏳ ĐANG XUẤT... {pct}%')
            except Exception:
                pass

        if stage and hasattr(self, 'status_var'):
            try:
                self.status_var.set(f'{stage} ({pct}%)')
            except Exception:
                pass

        try:
            self.root.update()
        except Exception:
            pass

    def _export_progress_end(self, success=True):
        """V150: kết thúc xuất và khôi phục trạng thái cửa sổ."""
        btn = getattr(self, 'fixed_export_button', None)
        if btn is not None:
            try:
                if success:
                    btn.config(
                        text='✅ HOÀN TẤT 100%',
                        bg='#7f8c8d', fg='white'
                    )
                self.root.update()
                btn.config(
                    state='normal',
                    text='📤  XUẤT EXCEL',
                    bg='#15945b', fg='white',
                    activebackground='#107c4b',
                    activeforeground='white',
                    relief='flat'
                )
            except Exception:
                pass

        self._export_progress_active = False
        self._export_progress_value = 0
        self._export_busy = False
        try:
            self.root.configure(cursor='')
            self.root.update()
        except Exception:
            pass

    def export_excel(self):
        # V107: hỏi nơi lưu trước; chỉ khi người dùng xác nhận mới chạy tối ưu nặng.
        filename = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
            initialfile=_suggest_excel_filename("BIỂU CẮT", self.entry_style.get(), self.entry_batch.get())
        )
        if not filename:
            return

        self._export_progress_begin()
        self._export_progress(3, 'Đang chuẩn bị dữ liệu')

        try:
            results, error = self.calculate_cutting_plan()
            if error:
                self._export_progress_end(success=False)
                messagebox.showerror("Lỗi", error)
                return

            self._export_progress(60, 'Đang tạo file Excel')
            self.generate_excel(filename, results)
            self._export_progress(97, 'Đang lưu dự án')

            # V38: luôn lưu một file dự án cùng tên với Excel để có thể mở lại và sửa tiếp.
            project_filename = os.path.splitext(filename)[0] + '.cutplan'
            saved_project = self.save_project(project_filename, silent=True)
            self._export_progress(100, 'Hoàn tất xuất Excel')
            self.export_status.config(text=f"✓ Đã xuất: {os.path.basename(filename)}", fg='#27ae60')

            if saved_project:
                self.status_var.set(f"Đã xuất Excel + dự án: {filename}")
                self._export_progress_end(success=True)
                messagebox.showinfo(
                    "Thành công",
                    f"Đã xuất Excel và lưu bộ nhớ dự án!\n\n"
                    f"Excel: {filename}\n"
                    f"Dự án: {saved_project}\n\n"
                    "Lần sau bấm MỞ DỰ ÁN và chọn file .cutplan để chỉnh sửa tiếp."
                )
            else:
                self.status_var.set(f"Đã xuất Excel nhưng lỗi lưu dự án: {filename}")
                self._export_progress_end(success=True)
                messagebox.showwarning(
                    "Đã xuất Excel",
                    f"Excel đã xuất thành công:\n{filename}\n\n"
                    f"Nhưng không lưu được file dự án .cutplan:\n{self._last_project_error}"
                )
        except Exception as e:
            self._export_progress_end(success=False)
            messagebox.showerror("Lỗi", f"Không thể xuất file: {str(e)}")

    def generate_excel(self, filename, results):
        # V123: phần tạo Excel chiếm 60-96% tiến độ xuất.
        self._export_progress(60, 'Đang khởi tạo Excel')
        # V53: sắp xếp cây theo BEST-FIT + quy tắc chừa đầu tấm mới.
        wb = Workbook()
        ws = wb.active
        ws.title = "BIỂU CẮT"

        # V25: sheet phụ chứa công thức phân LOT động. Sheet này được ẩn để
        # người dùng chỉ làm việc trên BIỂU CẮT. Khi sửa CHIỀU DÀI SƠ ĐỒ hoặc
        # SỐ LÁ trong BIỂU CẮT, Excel sẽ tự tính lại LOT và phần GHI CHÚ.
        lot_ws = wb.create_sheet("_LOT_CALC")
        lot_ws.sheet_state = 'hidden'
        wb.calculation.calcMode = 'auto'
        wb.calculation.fullCalcOnLoad = True
        wb.calculation.forceFullCalc = True
        wb.calculation.calcOnSave = True

        font_title = Font(name='Calibri', size=32, bold=True)
        font_normal = Font(name='Calibri', size=11)
        font_bold = Font(name='Calibri', size=11, bold=True)
        # Tiêu đề song ngữ: ưu tiên giữ nguyên cụm tiếng Anh ở dòng dưới.
        # Font nhỏ hơn một chút để các tiêu đề dài vẫn nằm gọn trong khung.
        font_bilingual = Font(name='Calibri', size=9, bold=True)
        font_bilingual_small = Font(name='Calibri', size=8, bold=True)

        align_center = Alignment(horizontal='center', vertical='center', wrap_text=False)
        align_center_wrap = Alignment(horizontal='center', vertical='center', wrap_text=True)
        align_bilingual = Alignment(horizontal='center', vertical='center', wrap_text=True, shrink_to_fit=True)

        thin = Side(style='thin', color='000000')
        medium = Side(style='medium', color='000000')
        none_side = Side(style=None)

        fill_theme4_tint60 = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')
        fill_theme8_tint0 = PatternFill(start_color='D9D9D9', end_color='D9D9D9', fill_type='solid')
        fill_theme9_tint80 = PatternFill(start_color='E2EFDA', end_color='E2EFDA', fill_type='solid')
        fill_theme6_tint80 = PatternFill(start_color='FFF2CC', end_color='FFF2CC', fill_type='solid')
        fill_theme8_tint80 = PatternFill(start_color='F2F2F2', end_color='F2F2F2', fill_type='solid')
        fill_theme9_tint60 = PatternFill(start_color='C6E0B4', end_color='C6E0B4', fill_type='solid')
        fill_percent_row = PatternFill(start_color='EDE3BD', end_color='EDE3BD', fill_type='solid')
        fill_total_order = PatternFill(start_color='EFC9A9', end_color='EFC9A9', fill_type='solid')
        fill_plan_row = PatternFill(start_color='F4EBC1', end_color='F4EBC1', fill_type='solid')

        def make_border(left=None, right=None, top=None, bottom=None):
            return Border(
                left=left if left else none_side,
                right=right if right else none_side,
                top=top if top else none_side,
                bottom=bottom if bottom else none_side
            )

        def set_cell(cell_ref, value=None, font=None, alignment=None, border=None, fill=None):
            cell = ws[cell_ref]
            if value is not None:
                cell.value = value
            if font:
                cell.font = font
            if alignment:
                cell.alignment = alignment
            if border:
                cell.border = border
            if fill:
                cell.fill = fill

        def col_letter(num):
            result = ''
            while num:
                num, rem = divmod(num - 1, 26)
                result = chr(65 + rem) + result
            return result

        # V82: luôn chừa đúng 3 BÀN DỰ PHÒNG cho mỗi loại vải.
        # Các bàn này ẩn mặc định và mở lần lượt từng bàn bằng dấu + của Outline.
        # Chỉ dùng 3 cấp Outline để phần bên trái gọn hơn bản 8 bàn.
        RESERVE_TABLES_PER_FABRIC = 3

        def reserve_rows_for(table_count):
            return RESERVE_TABLES_PER_FABRIC

        # ===== V60: SHEET SỬA PHÂN CÂY DÙNG EXCEL TABLE TƯƠNG THÍCH =====
        # Người dùng nhập dữ liệu trong một Excel Table thật. Khi nhập ở dòng cuối
        # hoặc dòng ngay dưới bảng, Excel tự mở rộng bảng mà không cần VBA.
        # Các helper ẩn bên dưới đọc trực tiếp từ Table bằng công thức nên BIỂU CẮT,
        # SỐ MÉT LOT CÒN LẠI và PHÂN CÂY bám theo dữ liệu mới.
        edit_ws = wb.create_sheet("SỬA PHÂN CÂY")
        edit_sheet_ref = edit_ws.title.replace("'", "''")
        EDIT_TABLE_NAME = 'tblSuaPhanCay'
        MAX_DYNAMIC_LOTS = 50
        # V65: mỗi LOT có vùng cây riêng. Tổng vùng nguồn của một loại vải phải đủ
        # chứa toàn bộ LOT để khi đổi LOT từ CHƯA GÁN sang một loại vải trong Excel,
        # BIỂU CẮT/PHÂN CÂY vẫn nhận đủ cây.
        # V85: số dòng công thức không còn cố định 100 cây/LOT + 3 dòng dư.
        # Chỉ chừa đúng số cây thực tế lớn nhất + số dòng dư người dùng chọn trước khi xuất.
        requested_extra_rows = self._get_extra_surplus_rows(silent=True)
        _max_existing_roll_rows = 0
        for _g in (getattr(self, 'global_lot_rows', []) or []):
            if not str(_g.get('lot','') or '').strip():
                continue
            try:
                _max_existing_roll_rows = max(_max_existing_roll_rows, len(self._ensure_lot_roll_details(_g) or []))
            except Exception:
                pass
        if _max_existing_roll_rows <= 0:
            _count_by_lot = {}
            for _f in self.fabric_list:
                for _r in (_f.get('rolls', []) or []):
                    _ln = str(_r.get('lot', _r.get('shade','')) or '').strip()
                    if _ln:
                        _count_by_lot[_ln] = _count_by_lot.get(_ln, 0) + 1
            _max_existing_roll_rows = max(_count_by_lot.values(), default=0)
        MAX_TREE_ROWS_PER_LOT = max(1, int(_max_existing_roll_rows) + int(requested_extra_rows))
        _global_lot_count = len([g for g in (getattr(self, 'global_lot_rows', []) or [])
                                 if str(g.get('lot','') or '').strip()])
        if _global_lot_count <= 0:
            _lot_names_tmp = set()
            for _f in self.fabric_list:
                for _l in (_f.get('lots',[]) or []):
                    _n = str(_l.get('name','') or '').strip()
                    if _n: _lot_names_tmp.add(_n)
                for _r in (_f.get('rolls',[]) or []):
                    _n = str(_r.get('lot', _r.get('shade','')) or '').strip()
                    if _n: _lot_names_tmp.add(_n)
            _global_lot_count = max(1, len(_lot_names_tmp))
        MAX_TREE_ROWS_PER_FABRIC = max(1, MAX_TREE_ROWS_PER_LOT * max(1, _global_lot_count))
        supp_lot_input_rows = {}
        supp_lot_helper_info = {}
        result_by_fabric_id = {id(r.get('fabric')): r for r in results}
        hidden_cursor = 10000
        for fabric in self.fabric_list:
            if not bool(fabric.get('export_edit', True)):
                continue
            # 50 dòng tổng LOT ẩn: mỗi dòng là một LOT duy nhất của loại vải.
            lot_rows = list(range(hidden_cursor, hidden_cursor + MAX_DYNAMIC_LOTS))
            mirror_start = hidden_cursor + MAX_DYNAMIC_LOTS + 5
            mirror_end = mirror_start + MAX_TREE_ROWS_PER_FABRIC - 1
            section = {
                'start_row': 0, 'input_header_row': 0, 'input_rows': lot_rows,
                'existing_lots': [], 'existing_map': {},
                'blank_rows': lot_rows, 'detail_rows_info': [],
                'mirror_start': mirror_start, 'mirror_end': mirror_end
            }
            supp_lot_input_rows[id(fabric)] = section
            hidden_cursor = mirror_end + 20
        edit_cursor = 5
        # V82: 3 bàn dự phòng dùng Outline lồng nhau level 1..3.
        # Khi đóng: chỉ thấy dấu + ở bàn thật cuối. Mở lần 1 hiện bàn dự phòng 1,
        # sau đó xuất hiện dấu + tiếp theo để mở bàn 2 rồi bàn 3.
        # Không cần dòng summary siêu mỏng nên không tạo khoảng trắng khi in.
        reserve_row_groups = []

        def ratio_value_formula(excel_row, size_name):
            """Đọc hệ số của một size trực tiếp từ ô TỈ LỆ SƠ ĐỒ (cột C).

            Ví dụ C = "S/1 + M/2 + L/1" -> S=1, M=2, L=1.
            Công thức chỉ dùng hàm Excel cũ để tương thích nhiều phiên bản.
            """
            token_name = str(size_name or '').strip().upper().replace('"', '""')
            token = f'+{token_name}/'
            wrapped = f'"+"&SUBSTITUTE(UPPER($C{excel_row})," ","")&"+"'
            start = f'FIND("{token}",{wrapped})+{len(token)}'
            end = f'FIND("+",{wrapped},{start})'
            return f'IFERROR(VALUE(MID({wrapped},{start},({end})-({start}))),0)'

        def edited_ratio_plies_formula(excel_row, first_table_row, target_by_col, size_names, size_cols):
            """Tự tính số lá khi người dùng sửa tỷ lệ sơ đồ trong Excel.

            Lấy sản lượng còn thiếu trước dòng hiện tại và chọn số lá nhỏ nhất
            giúp hoàn tất ít nhất một cỡ đang có trong marker. Các dòng phía sau
            tiếp tục tự cân lại theo sản lượng còn thiếu.
            """
            active_flags = []
            choices = []
            for size_name, col in zip(size_names, size_cols):
                ratio_expr = ratio_value_formula(excel_row, size_name)
                if excel_row > first_table_row:
                    prev = f'SUM({col}${first_table_row}:{col}{excel_row-1})'
                else:
                    prev = '0'
                target_expr = target_by_col.get(col, '0')
                remaining = f'MAX(0,({target_expr})-{prev})'
                active = f'AND(({ratio_expr})>0,({remaining})>0)'
                active_flags.append(f'IF({active},1,0)')
                choices.append(
                    f'IF({active},ROUNDUP(({remaining})/({ratio_expr}),0),1000000000)'
                )

            active_count = '+'.join(active_flags) if active_flags else '0'
            candidate = f'MIN({",".join(choices)})' if choices else '0'
            return f'=IF(TRIM($C{excel_row})="",0,IF(({active_count})<=0,0,MAX(0,{candidate})))'

        def dynamic_plies_formula(table_index, tables, excel_row, first_table_row, target_by_col,
                                  size_keys, size_cols, base_target_by_key=None):
            """
            V60 - thay đổi % dương chỉ ĐIỀU CHỈNH TĂNG từ kế hoạch gốc,
            tuyệt đối không tính lại số lá từ đầu.

            Lý do: với tỷ lệ marker cố định, nếu tính lại tuần tự từ dòng B1,
            một bàn đầu có thể lấy quá nhiều một cỡ; bàn sau buộc phải giảm mạnh
            số lá để giữ dương <= MAX_OVER, làm các cỡ khác bị âm rất lớn.

            Quy tắc V60:
            1) Kế hoạch optimizer lúc xuất là nền cố định (base plan).
            2) Khi vừa xuất file: giữ nguyên tuyệt đối số lá của phần mềm.
               Chỉ khi mục tiêu/% dương trong Excel thay đổi mới xét phần tăng thêm.
            3) Một bàn chỉ được tăng thêm lá nếu sau phần tăng đó mọi cỡ trên
               marker vẫn <= mục tiêu hiện tại + MAX_OVER.
            4) Không bao giờ tự giảm số lá gốc chỉ vì một cỡ khác đã đủ.
               Nếu tỷ lệ marker hiện tại không thể đạt mục tiêu mới trong biên
               0..MAX_OVER, giữ kế hoạch gần nhất và để số âm nhỏ hiện ra để
               người dùng đổi tỷ lệ marker / dùng cột ĐIỀU CHỈNH SỐ LÁ.
            """
            ratio_map = tables[table_index].get('ratio_map', {}) or {}
            participants = [(k, int(ratio_map.get(k, 0) or 0))
                            for k in size_keys if int(ratio_map.get(k, 0) or 0) > 0]
            original_plies = int(tables[table_index].get('plies', 0) or 0)
            if not participants:
                return f'={original_plies}'

            col_map = dict(zip(size_keys, size_cols))

            # Sản lượng thực cắt của KẾ HOẠCH GỐC trên toàn bộ các bàn.
            base_actual = {k: 0 for k in size_keys}
            for _t in tables:
                _p = int(_t.get('plies', 0) or 0)
                _rm = _t.get('ratio_map', {}) or {}
                for _k in size_keys:
                    _r = int(_rm.get(_k, 0) or 0)
                    if _r > 0 and _p > 0:
                        base_actual[_k] += _r * _p

            extra_remaining = {}
            extra_required = {}
            safe_extra = {}
            last_chance = []

            for key, ratio in participants:
                col = col_map[key]
                target_expr = target_by_col.get(col, '0')

                # Phần tăng thêm đã được các bàn trước lấy so với số lá gốc.
                prev_terms = []
                for j in range(table_index):
                    prev_ratio = int((tables[j].get('ratio_map', {}) or {}).get(key, 0) or 0)
                    if prev_ratio <= 0:
                        continue
                    prev_base_plies = int(tables[j].get('plies', 0) or 0)
                    prev_row = first_table_row + j
                    prev_terms.append(
                        f'MAX(0,F{prev_row}-{prev_base_plies})*{prev_ratio}'
                    )
                prev_extra = '+'.join(prev_terms) if prev_terms else '0'

                # Chỉ bù phần mục tiêu mới vượt quá THỰC CẮT GỐC.
                rem = f'MAX(0,({target_expr})-{int(base_actual.get(key, 0))}-({prev_extra}))'
                extra_remaining[key] = rem
                extra_required[key] = f'ROUNDUP(({rem})/{ratio},0)'

                # Số lá được phép TĂNG thêm tối đa ở bàn hiện tại mà vẫn
                # không làm cỡ này vượt mục tiêu mới + MAX_OVER.
                headroom = (
                    f'(({target_expr})+{int(self.MAX_OVER)}-'
                    f'{int(base_actual.get(key, 0))}-({prev_extra}))'
                )
                safe_extra[key] = f'MAX(0,ROUNDDOWN(({headroom})/{ratio},0))'

                has_future = any(
                    int((future.get('ratio_map', {}) or {}).get(key, 0) or 0) > 0
                    for future in tables[table_index + 1:]
                )
                if not has_future:
                    last_chance.append(key)

            # Bàn chưa phải cơ hội cuối: tăng rất bảo thủ theo phần thiếu nhỏ nhất
            # của các cỡ đang cần tăng. Bàn cuối của một cỡ: cố bù cỡ đó trước.
            if last_chance:
                reqs = [extra_required[k] for k in last_chance]
                candidate_extra = f'MAX({",".join(reqs)})' if len(reqs) > 1 else reqs[0]
            else:
                choices = [
                    f'IF(({extra_remaining[k]})>0,{extra_required[k]},1000000000)'
                    for k, _r in participants
                ]
                min_need = f'MIN({",".join(choices)})' if len(choices) > 1 else choices[0]
                candidate_extra = f'IF(({min_need})>=1000000000,0,{min_need})'

            safe_parts = [safe_extra[k] for k, _r in participants]
            max_safe_extra = f'MIN({",".join(safe_parts)})' if len(safe_parts) > 1 else safe_parts[0]
            delta = f'MAX(0,MIN(({max_safe_extra}),({candidate_extra})))'

            # V162:
            # Khi vừa XUẤT EXCEL, số lá phải giữ đúng tuyệt đối số lá trên phần mềm.
            # Không tự bù phần âm của phương án gốc.
            # Chỉ khi mục tiêu/% dương trong Excel thay đổi mới cho phép tăng lá.
            changed_flags = []
            base_target_by_key = base_target_by_key or {}
            for key, _ratio in participants:
                col = col_map[key]
                target_expr = target_by_col.get(col, '0')
                try:
                    base_target = int(base_target_by_key.get(key, 0) or 0)
                except Exception:
                    base_target = 0
                changed_flags.append(
                    f'ABS(({target_expr})-{base_target})>0.000001'
                )

            target_changed = (
                f'OR({",".join(changed_flags)})'
                if len(changed_flags) > 1
                else (changed_flags[0] if changed_flags else 'FALSE')
            )

            return f'=IF({target_changed},{original_plies}+({delta}),{original_plies})'

        main_sheet_ref = ws.title.replace("'", "''")
        helper_sheet_ref = lot_ws.title.replace("'", "''")

        # V60: theo dõi lượng LOT đã dùng ở các loại vải đứng trước để GHI CHÚ
        # trên BIỂU CẮT hiển thị tổng LOT theo kiểu dây chuyền:
        #   vải 1: Tổng = tổng LOT gốc
        #   vải 2: Tổng = phần dư sau vải 1
        #   vải 3: Tổng = phần dư sau vải 1 + vải 2 ...
        # Chỉ thay cách HIỂN THỊ tổng/dư; việc phân cây vẫn giữ nguyên nguyên tắc
        # 1 LOT có thể dùng cho nhiều loại vải nhưng 1 cây chỉ thuộc 1 loại vải.
        prior_lot_note_blocks = []

        def build_dynamic_lot_formulas(fabric, main_rows, helper_start_row):
            """
            Tạo công thức Excel động để chia LOT theo SỐ LÁ nguyên.

            - Mỗi bàn vẫn giữ nguyên một dòng trong BIỂU CẮT.
            - Cột LOT (E) có thể hiện nhiều LOT nếu một bàn phải dùng nhiều LOT,
              ví dụ: LOT A: 40 lá | LOT B: 12 lá.
            - Khi người dùng sửa chiều dài ở cột D, mét/lá thay đổi và toàn bộ
              phân LOT + ghi chú dùng/dư tự tính lại.
            - LOT được ưu tiên theo thứ tự đã nhập. Một LOT được tiếp tục dùng
              cho các bàn sau nếu phần mét còn lại vẫn đủ cho ít nhất 1 lá.
            """
            lots = []
            section = supp_lot_input_rows.get(id(fabric), {})
            existing_map = section.get('existing_map', {})
            for i, lot in enumerate(fabric.get('lots', []) or []):
                lot_name = str(lot.get('name', '') or '').strip()
                if lot_name and i in existing_map:
                    try: meters = max(0.0, float(lot.get('meters', 0) or 0))
                    except Exception: meters = 0.0
                    lots.append({'name': lot_name, 'meters': meters, 'source_index': i,
                                 'edit_row': int(existing_map[i]), 'editable': True})
            for slot_no, edit_row in enumerate(section.get('blank_rows', []), start=1):
                lots.append({'name': '', 'meters': 0.0, 'source_index': None,
                             'supplemental': True, 'editable': True,
                             'slot_no': slot_no, 'edit_row': int(edit_row)})

            if not lots or not main_rows:
                return helper_start_row, None

            # Cấu trúc block helper:
            # A: dòng Sheet1, B: mét/1 lá, C: tổng số lá, D: số lá thiếu
            # E...: số lá được lấy từ từng LOT.
            title_row = helper_start_row
            cap_row = title_row + 1
            used_row = title_row + 2
            remain_row = title_row + 3
            note_row = title_row + 4
            data_start = title_row + 6
            data_end = data_start + len(main_rows) - 1

            lot_ws.cell(title_row, 1, f"LOẠI VẢI: {fabric.get('name', '')}")
            lot_ws.cell(title_row, 2, 'MÉT / 1 LÁ')
            lot_ws.cell(title_row, 3, 'SỐ LÁ')
            lot_ws.cell(title_row, 4, 'THIẾU LÁ')
            lot_ws.cell(cap_row, 4, 'SL MÉT LOT')
            lot_ws.cell(used_row, 4, 'ĐÃ DÙNG')
            lot_ws.cell(remain_row, 4, 'CÒN DƯ')
            lot_ws.cell(note_row, 4, 'GHI CHÚ')

            lot_first_col_idx = 5  # E
            lot_cols = []
            for j, lot in enumerate(lots):
                ci = lot_first_col_idx + j
                c = col_letter(ci)
                lot_cols.append(c)
                if lot.get('editable'):
                    er = int(lot.get('edit_row'))
                    slot_no = int(lot.get('slot_no', j + 1))
                    lot_ws.cell(title_row, ci, f"=IF('{edit_sheet_ref}'!B{er}<>\"\",'{edit_sheet_ref}'!B{er},IF(N('{edit_sheet_ref}'!E{er})>0,\"LOT MỚI {slot_no}\",\"\"))")
                    lot_ws.cell(cap_row, ci, f"=IFERROR(IF('{edit_sheet_ref}'!B{er}=\"\",0,MAX(0,N('{edit_sheet_ref}'!E{er}))),0)")
                else:
                    lot_ws.cell(title_row, ci, lot['name'])
                    lot_ws.cell(cap_row, ci, lot['meters'])
                lot_ws.cell(cap_row, ci).number_format = '0.00'

            # Dữ liệu và ma trận số lá / LOT.
            for offset, main_row in enumerate(main_rows):
                hr = data_start + offset
                lot_ws.cell(hr, 1, main_row)
                # V38: dòng dự phòng chưa nhập phải là 0 thật trong helper, không để
                # chuỗi rỗng đi vào phép chia/SUMPRODUCT gây #VALUE!/DIV0.
                lot_ws.cell(
                    hr, 2,
                    f"=IFERROR(IF(OR(TRIM('{main_sheet_ref}'!C{main_row})=\"\","
                    f"'{main_sheet_ref}'!D{main_row}=\"\"),0,'{main_sheet_ref}'!D{main_row}*1.01),0)"
                )
                lot_ws.cell(
                    hr, 3,
                    f"=IFERROR(IF(TRIM('{main_sheet_ref}'!C{main_row})=\"\",0,N('{main_sheet_ref}'!F{main_row})),0)"
                )
                lot_ws.cell(hr, 2).number_format = '0.0000'
                lot_ws.cell(hr, 3).number_format = '0'

                for j, c in enumerate(lot_cols):
                    # Số lá còn thiếu của bàn sau các LOT trước.
                    if j == 0:
                        remain_plies = f'$C{hr}'
                    else:
                        prev_c = lot_cols[j - 1]
                        remain_plies = f'$C{hr}-SUM(${lot_cols[0]}{hr}:${prev_c}{hr})'

                    # Số mét còn lại của LOT này sau các bàn phía trên.
                    if hr == data_start:
                        used_before = '0'
                    else:
                        used_before = f'SUMPRODUCT({c}${data_start}:{c}{hr-1},$B${data_start}:$B{hr-1})'

                    capacity = f'{c}${cap_row}'
                    # MAX(...,0.000001) chỉ là lớp bảo vệ; khi B<=0 nhánh ngoài trả 0.
                    cap_plies = f'INT(MAX(0,{capacity}-{used_before})/MAX($B{hr},0.000001))'
                    candidate_plies = f'MAX(0,MIN({remain_plies},{cap_plies}))'
                    # V50: dùng đầu tấm đến khi KHÔNG CÒN ĐỦ 1 LÁ.
                    # Không bỏ phần chỉ đủ 1-2 lá nữa; nếu đủ ít nhất 1 lá thì vẫn chuyển sang bàn tiếp theo.
                    formula = (
                        f'=IFERROR(IF(OR($B{hr}<=0,$C{hr}<=0),0,{candidate_plies}),0)'
                    )
                    lot_ws.cell(hr, lot_first_col_idx + j, formula)
                    lot_ws.cell(hr, lot_first_col_idx + j).number_format = '0'

                lot_range = f'{lot_cols[0]}{hr}:{lot_cols[-1]}{hr}'
                lot_ws.cell(hr, 4, f'=MAX(0,$C{hr}-SUM({lot_range}))')
                lot_ws.cell(hr, 4).number_format = '0'

                # Cột LOT trên BIỂU CẮT: tương thích cả Excel cũ.
                # Không dùng TEXTJOIN (Excel cũ sẽ báo #NAME?). Thay bằng IF + &.
                lot_formula_parts = []
                previous_refs = []
                for c in lot_cols:
                    lot_ref = f"'{helper_sheet_ref}'!{c}{hr}"
                    lot_name_ref = f"'{helper_sheet_ref}'!{c}${title_row}"
                    if previous_refs:
                        prev_sum = 'SUM(' + ','.join(previous_refs) + ')'
                        prefix = f'IF({prev_sum}>0," | ","")&'
                    else:
                        prefix = ''
                    lot_formula_parts.append(
                        f'IF({lot_ref}>0,{prefix}{lot_name_ref}&": "&{lot_ref}&" lá","")'
                    )
                    previous_refs.append(lot_ref)

                missing_ref = f"'{helper_sheet_ref}'!$D{hr}"
                if previous_refs:
                    prev_sum = 'SUM(' + ','.join(previous_refs) + ')'
                    missing_prefix = f'IF({prev_sum}>0," | ","")&'
                else:
                    missing_prefix = ''
                lot_formula_parts.append(
                    f'IF({missing_ref}>0,{missing_prefix}"THIẾU: "&{missing_ref}&" lá","")'
                )
                total_cap_expr = f"SUM('{helper_sheet_ref}'!{lot_cols[0]}${cap_row}:{lot_cols[-1]}${cap_row})"
                # V38: LOT chỉ tính khi dòng có đủ TỈ LỆ + CHIỀU DÀI + SỐ LÁ.
                # Dòng dự phòng trống luôn hiển thị trống thay vì #VALUE!.
                lot_concat_expr = '&'.join(lot_formula_parts)
                ws[f'E{main_row}'] = (
                    f'=IF(OR(TRIM($C{main_row})="",$D{main_row}="",$F{main_row}=""),"",'
                    f'IFERROR(IF({total_cap_expr}<=0,"",{lot_concat_expr}),""))'
                )
                ws[f'E{main_row}'].alignment = Alignment(
                    horizontal='center', vertical='center', wrap_text=False,
                    shrink_to_fit=False
                )

            # Tổng mét đã dùng / còn dư từng LOT.
            # V60: nếu cùng một LOT xuất hiện ở nhiều loại vải, cột GHI CHÚ của
            # BIỂU CẮT phải chạy theo số dư của LOT qua từng loại vải.
            #
            # Tổng LOT gốc được đọc động từ SỬA PHÂN CÂY bằng cột MÉT HIỆU LỰC
            # (cột ẩn ngay sau mỗi cụm LOT). Cột này đã tự trừ phần đầu tấm chuyển
            # đi và cộng dòng đầu tấm nhận lại nên tổng vật lý của LOT không bị nhân đôi.
            def _original_lot_total_expr(current_lot_name_ref):
                _parts = []
                _block_count = max(1, int(_global_lot_count or 0))
                _first = 7
                _last = 7 + int(MAX_TREE_ROWS_PER_LOT) - 1
                _span = 8
                for _li in range(_block_count):
                    _bs = 1 + _li * _span
                    _lot_col = col_letter(_bs + 2)
                    _eff_col = col_letter(_bs + 7)
                    _parts.append(
                        f"SUMIFS('{edit_sheet_ref}'!${_eff_col}${_first}:${_eff_col}${_last},"
                        f"'{edit_sheet_ref}'!${_lot_col}${_first}:${_lot_col}${_last},{current_lot_name_ref})"
                    )
                return '+'.join(_parts) if _parts else '0'

            for j, c in enumerate(lot_cols):
                lot_ws[f'{c}{used_row}'] = f'=SUMPRODUCT({c}{data_start}:{c}{data_end},$B{data_start}:$B{data_end})'

                # Tổng đã dùng của CÙNG LOT ở tất cả loại vải đứng trước.
                _prev_used_terms = []
                for _pb in prior_lot_note_blocks:
                    _prev_used_terms.append(
                        f'SUMIF(${_pb["first_col"]}${_pb["title_row"]}:${_pb["last_col"]}${_pb["title_row"]},'
                        f'{c}${title_row},'
                        f'${_pb["first_col"]}${_pb["used_row"]}:${_pb["last_col"]}${_pb["used_row"]})'
                    )
                _prev_used_expr = '+'.join(_prev_used_terms) if _prev_used_terms else '0'
                _original_total_expr = _original_lot_total_expr(f'{c}${title_row}')

                # Nếu dữ liệu nguồn đặc biệt làm tổng LOT gốc không đọc được, ít nhất
                # vẫn giữ Tổng hiện tại >= phần mét đã cấp cho loại vải này.
                _cascade_total_expr = (
                    f'MAX({c}{cap_row},MAX(0,({_original_total_expr})-({_prev_used_expr})))'
                )
                _cascade_remain_expr = f'MAX(0,({_cascade_total_expr})-{c}{used_row})'

                # Hàng CÒN DƯ của helper cũng dùng cùng số dư dây chuyền để các công thức
                # kiểm tra/đối chiếu trong file Excel nhất quán với GHI CHÚ.
                lot_ws[f'{c}{remain_row}'] = f'={_cascade_remain_expr}'
                lot_ws[f'{c}{note_row}'] = (
                    f'=IF(AND({c}{cap_row}>0,{c}{title_row}<>""),'
                    f'{c}{title_row}&": Tổng "&TEXT(({_cascade_total_expr}),"0.00")&'
                    f'" m | dùng "&TEXT({c}{used_row},"0.00")&'
                    f'" m | dư "&TEXT(({_cascade_remain_expr}),"0.00")&" m","")'
                )
                lot_ws[f'{c}{used_row}'].number_format = '0.00'
                lot_ws[f'{c}{remain_row}'].number_format = '0.00'

            # Tổng mét chưa được cấp LOT (do thiếu mét).
            lot_ws[f'D{used_row}'] = f'=SUMPRODUCT($D{data_start}:$D{data_end},$B{data_start}:$B{data_end})'
            lot_ws[f'D{used_row}'].number_format = '0.00'

            # Công thức GHI CHÚ trên BIỂU CẮT - chỉ hiện LOT có TỔNG MÉT > 0.
            # LOT chưa nhập mét vẫn tồn tại để người dùng điều chỉnh sau khi xuất,
            # nhưng tên LOT đó không xuất hiện trong GHI CHÚ cho tới khi có giá trị mét.
            note_parts = []
            previous_caps = []
            for c in lot_cols:
                cap_ref = f"'{helper_sheet_ref}'!{c}${cap_row}"
                note_ref = f"'{helper_sheet_ref}'!{c}{note_row}"
                if previous_caps:
                    prev_sum = 'SUM(' + ','.join(previous_caps) + ')'
                    prefix = f'IF({prev_sum}>0,CHAR(10),"")&'
                else:
                    prefix = ''
                note_parts.append(f'IF({cap_ref}>0,{prefix}{note_ref},"")')
                previous_caps.append(cap_ref)

            # V34: BIỂU CẮT không hiển thị dòng THIẾU VẢI theo mét.
            # Thiếu mét được tổng hợp riêng tại SỬA PHÂN CÂY.
            note_formula = '=' + '&'.join(note_parts) if note_parts else '=""'

            # V48: lưu tọa độ helper + ánh xạ dòng SỬA PHÂN CÂY -> cột LOT helper.
            supp_cols = []
            edit_lot_cols = {}
            for j, lot in enumerate(lots):
                if lot.get('editable'):
                    er = int(lot.get('edit_row'))
                    info = {'col': lot_cols[j], 'edit_row': er, 'slot_no': int(lot.get('slot_no', j + 1)),
                            'supplemental': bool(lot.get('supplemental'))}
                    edit_lot_cols[er] = lot_cols[j]
                    if lot.get('supplemental'): supp_cols.append(info)
            supp_lot_helper_info[id(fabric)] = {
                'title_row': title_row, 'cap_row': cap_row, 'used_row': used_row, 'remain_row': remain_row,
                'data_start': data_start, 'data_end': data_end, 'main_rows': list(main_rows),
                'supp_cols': supp_cols, 'all_lot_cols': list(lot_cols), 'edit_lot_cols': edit_lot_cols}

            # V60: ghi lại block LOT của loại vải hiện tại để loại vải sau
            # trừ đúng lượng đã dùng của cùng LOT.
            if lot_cols:
                prior_lot_note_blocks.append({
                    'title_row': title_row,
                    'used_row': used_row,
                    'first_col': lot_cols[0],
                    'last_col': lot_cols[-1],
                })

            # Chừa khoảng cách giữa các block vải.
            return data_end + 3, note_formula

        size_keys = [s['key'] for s in self.sizes]
        size_names = [s['name'] for s in self.sizes]
        size_cols = [col_letter(7 + i) for i in range(len(self.sizes))]  # bắt đầu G
        total_col = col_letter(7 + len(self.sizes))
        norm_col = col_letter(8 + len(self.sizes))
        need_col = col_letter(9 + len(self.sizes))
        note_col = col_letter(10 + len(self.sizes))  # 5 size mặc định => cột O
        # V25: cột điều chỉnh số lá nằm NGAY SAU GHI CHÚ và luôn ở ngoài vùng in A4.
        # Khi thêm/xóa size, cột này tự dịch theo vì được tính động từ note_col.
        adjust_col = col_letter(11 + len(self.sizes))  # 5 size mặc định => cột P
        # V32: cột chỉnh tổng mét LOT nằm ngay bên phải cột chỉnh số lá,
        # cũng nằm ngoài vùng in A4. 5 size mặc định => cột Q.
        adjust_lot_col = col_letter(12 + len(self.sizes))
        first_size_col = size_cols[0]
        last_size_col = size_cols[-1]

        # Kích thước cột. Cột GHI CHÚ tự ước lượng theo tên LOT nhưng được
        # giới hạn để không chiếm quá nhiều bề ngang A4; chữ dài sẽ wrap.
        lot_note_samples = []
        # V41: LOT va GHI CHU tu co dan theo noi dung thuc te.
        # LOT rong toi thieu vua tieu de; neu co ten LOT dai / nhieu LOT thi tang rong.
        lot_cell_samples = []
        for fabric in self.fabric_list:
            fabric_lot_parts = []
            for lot in fabric.get('lots', []) or []:
                name = str(lot.get('name', '')).strip() or 'LOT'
                # Mau gan voi noi dung thuc te trong cot LOT: "TEN LOT: 000 la".
                part = f"{name}: 000 lá"
                fabric_lot_parts.append(part)
                lot_cell_samples.append(part)
                try:
                    meters = float(lot.get('meters', 0) or 0)
                except (TypeError, ValueError):
                    meters = 0.0
                if meters > 0:
                    lot_note_samples.append(f"{name}: Tổng {meters:.2f} m | dùng 0000.00 m | dư 0000.00 m")

            # Một bàn có thể dùng nhiều LOT. Đồng thời phải tính cả trường hợp
            # bàn dùng một phần LOT rồi còn THIẾU, vì đây là chuỗi dài nhất thường gặp.
            if fabric_lot_parts:
                joined = ' | '.join(fabric_lot_parts)
                lot_cell_samples.append(joined)
                lot_cell_samples.append(joined + ' | THIẾU: 000 lá')
            else:
                lot_cell_samples.append('THIẾU: 000 lá')

        max_lot_len = max([len(x) for x in lot_cell_samples], default=3)
        # Excel không có AutoFit thật sự cho ô công thức khi tạo bằng openpyxl,
        # nên ước lượng độ rộng theo chuỗi LOT dài nhất có thể xuất hiện.
        # Dùng hệ số rộng hơn để tránh trường hợp công thức tính ra "LOT | THIẾU" bị cắt.
        lot_width = max(9.0, max_lot_len * 1.15 + 2.0)

        max_note_len = max([len(x) for x in lot_note_samples], default=24)
        # GHI CHÚ ưu tiên rộng hơn nhưng không thu nhỏ chữ; nội dung dài sẽ wrap.
        note_width = min(48.0, max(28.0, max_note_len * 0.66))

        column_widths = {
            'A': 12.43, 'B': 7.43, 'C': 45.71, 'D': 14.29,
            'E': lot_width, 'F': 8.43,
            norm_col: 11.86,
            need_col: 17.43,
            note_col: note_width,
            # Các cột nhập tay ngoài vùng in, có kẻ ô nhưng không đưa vào Print Area.
            adjust_col: 15.0,
        }
        for col in size_cols:
            column_widths[col] = 8.43
        column_widths[total_col] = 10.0
        for col, width in column_widths.items():
            ws.column_dimensions[col].width = width
        # V60: bỏ hẳn cột ĐIỀU CHỈNH TỔNG LOT khỏi giao diện BIỂU CẮT.
        # Tổng LOT chỉ lấy từ SỬA PHÂN CÂY. Giữ cột kỹ thuật ẩn để không làm đổi vị trí các cột khác.
        ws.column_dimensions[adjust_lot_col].hidden = True
        ws.column_dimensions[adjust_lot_col].width = 0.1

        # ===== V32: ĐIỀU CHỈNH TỔNG LOT THEO TỪNG KHỐI LOẠI VẢI =====
        # Ô chỉnh LOT sẽ được tạo đúng tại các dòng của loại vải tương ứng,
        # ngay bên phải cột ĐIỀU CHỈNH SỐ LÁ và vẫn nằm ngoài vùng in A4.
        lot_adjust_cells = {}

        # ===== THÔNG TIN ĐƠN HÀNG + BẢNG PO ĐỘNG =====
        # V34: thông tin bổ sung không còn mặc định đẩy toàn bộ bảng PO xuống.
        # Chỉ khi đúng vị trí đó va vào vùng dữ liệu thì phần phía dưới mới dịch đều.
        ws.row_dimensions[1].height = 48.0
        info = self.get_current_info()

        # ===== LOGO: bỏ khung tại vị trí logo và phủ vừa A1:B3 =====
        # Không tạo khung/merge cho logo. Chỉ chèn ảnh và xóa mọi viền ở vùng A1:B3.
        logo_buffer = None
        for rr in range(1, 4):
            for cc in range(1, 3):
                set_cell(f'{col_letter(cc)}{rr}', border=make_border(), fill=PatternFill(fill_type=None))

        if getattr(self, 'logo_path', None) and os.path.isfile(self.logo_path):
            try:
                if PILImage is None:
                    raise RuntimeError("Thiếu thư viện Pillow (pip install pillow)")

                # Kích thước vùng A1:B3 xấp xỉ theo bố cục hiện tại.
                box_w, box_h = 145, 78
                with PILImage.open(self.logo_path) as pil_logo:
                    pil_logo.load()
                    pil_logo = pil_logo.convert('RGBA')
                    if pil_logo.width <= 0 or pil_logo.height <= 0:
                        raise ValueError("Kích thước logo không hợp lệ")

                    resized = pil_logo.resize((box_w, box_h), PILImage.LANCZOS)
                    logo_buffer = io.BytesIO()
                    resized.save(logo_buffer, format='PNG')
                    logo_buffer.seek(0)

                logo_img = XLImage(logo_buffer)
                logo_img.width = box_w
                logo_img.height = box_h
                logo_img.anchor = 'A1'
                ws.add_image(logo_img)
            except Exception as logo_error:
                messagebox.showwarning(
                    "Logo không được chèn",
                    f"File Excel vẫn được xuất nhưng logo không thể chèn:\n{logo_error}"
                )

        set_cell('E1', 'TÁC NGHIỆP CẮT -CUTTING PLAN', font=font_title,
                 alignment=Alignment(horizontal='center', vertical='center', wrap_text=False))

        def excel_col_to_index(col_name):
            n = 0
            for ch in str(col_name).upper():
                if 'A' <= ch <= 'Z':
                    n = n * 26 + (ord(ch) - 64)
            return n

        # Các ô thông tin chuẩn đã chiếm ở phần đầu trang.
        occupied_info = {(1, 5)}  # E1: tiêu đề
        if getattr(self, 'logo_path', None):
            occupied_info.update({(r, c) for r in range(1, 4) for c in range(1, 3)})
        max_info_row = 4
        # CODE + DATE: đóng khung như hình mẫu 2, nằm gọn trong cột O.
        # Dùng khung O1:O2, chữ canh trái, có 2 dòng CODE và DATE.
        info_box_start_col = 'O'
        info_box_end_col = 'O'
        info_box_start_row = 1
        info_box_end_row = 2
        info_box_start_idx = excel_col_to_index(info_box_start_col)
        info_box_end_idx = excel_col_to_index(info_box_end_col)
        info_box_range = f'{info_box_start_col}{info_box_start_row}:{info_box_end_col}{info_box_end_row}'

        code_text = str(info.get('code', '') or '').strip()
        date_text = str(info.get('date', '') or '').strip()
        info_lines = []
        if code_text:
            info_lines.append(f'CODE: {code_text}')
        if date_text:
            info_lines.append(f'DATE: {date_text}')

        if info_lines:
            try:
                ws.merge_cells(info_box_range)
            except Exception:
                pass

            for rr in range(info_box_start_row, info_box_end_row + 1):
                for cc in range(info_box_start_idx, info_box_end_idx + 1):
                    left_side = medium if cc == info_box_start_idx else None
                    right_side = medium if cc == info_box_end_idx else None
                    top_side = medium if rr == info_box_start_row else None
                    bottom_side = medium if rr == info_box_end_row else None
                    set_cell(
                        f'{col_letter(cc)}{rr}',
                        border=make_border(left=left_side, right=right_side, top=top_side, bottom=bottom_side)
                    )
                    occupied_info.add((rr, cc))

            set_cell(
                f'{info_box_start_col}{info_box_start_row}',
                '\n\n'.join(info_lines),
                font=font_bold,
                alignment=Alignment(horizontal='left', vertical='center', wrap_text=True)
            )
            max_info_row = max(max_info_row, info_box_end_row)
            ws.row_dimensions[1].height = max(float(ws.row_dimensions[1].height or 15), 24.0)
            ws.row_dimensions[2].height = max(float(ws.row_dimensions[2].height or 15), 24.0)

        # Thông tin chuẩn. Ô nào để trống thì không xuất.
        color_col_idx = max(8, min(12, 10 + len(self.sizes)))
        standard_info = [
            ('customer', 'KHÁCH HÀNG/CUSTOMER', 'C', 3, True),
            ('style', 'MÃ HÀNG/STYLE', 'C', 4, True),
            ('batch', 'ĐỢT/BATCH', 'H', 3, True),
            ('season', 'MÙA/SEASON', 'H', 4, True),
            ('color', 'MÀU/COLOR', col_letter(color_col_idx), 3, True),
        ]
        for key, label, col, row, bold in standard_info:
            value = str(info.get(key, '') or '').strip()
            if not value:
                continue
            ci = excel_col_to_index(col)
            set_cell(f'{col}{row}', f'{label}: {value}',
                     font=font_bold if bold else font_normal,
                     alignment=Alignment(vertical='center', wrap_text=False, shrink_to_fit=False))
            occupied_info.add((row, ci))
            max_info_row = max(max_info_row, row)
            ws.row_dimensions[row].height = max(float(ws.row_dimensions[row].height or 15), 25.0)

        # Chuẩn hóa thông tin bổ sung trước khi tính vị trí các khối.
        # Nếu trùng đúng ô thông tin ở phần đầu trang thì dời riêng thông tin đó xuống
        # ô trống kế tiếp trong cùng cột; không đụng đến toàn bộ bố cục.
        pending_custom_info = []
        custom_taken = set()
        for item in getattr(self, 'custom_info_list', []) or []:
            col = str(item.get('col', '') or '').strip().upper()
            if not re.fullmatch(r'[A-Z]{1,2}', col):
                continue
            ci = excel_col_to_index(col)
            try:
                row = max(1, int(item.get('row', 1)))
            except (TypeError, ValueError):
                row = 1
            name = str(item.get('name', '') or '').strip()
            value = str(item.get('value', '') or '').strip()
            text_value = f'{name}: {value}' if name and value else (name or value)
            if not text_value:
                continue

            while (row, ci) in occupied_info or (row, ci) in custom_taken:
                row += 1
            custom_taken.add((row, ci))
            pending_custom_info.append({
                'col': col, 'ci': ci, 'row': row, 'text': text_value
            })

        # ===== TÍNH VỊ TRÍ BẢNG PO =====
        # PO mặc định bắt đầu từ dòng 5. Chỉ những thông tin bổ sung thực sự nằm
        # trong vùng C -> TỔNG của bảng PO mới khiến cả khối PO dịch xuống đều.
        po_first_col_idx = excel_col_to_index('C')
        po_last_col_idx = excel_col_to_index(total_col)

        # V160:
        # - Không tích ÁP DỤNG % DƯƠNG -> Excel không có dòng % DƯƠNG.
        # - Có tích -> xuất dòng % DƯƠNG.
        export_increase_row = bool(self._increase_enabled())
        percent_row = 5

        increase_po_count = sum(1 for po in self.po_list if self._po_increase_active(po))
        po_span_rows = (
            len(self.po_list) + increase_po_count
            + (4 if export_increase_row else 3)
        )
        while True:
            po_end_row = percent_row + po_span_rows - 1
            conflicts = [
                x['row'] for x in pending_custom_info
                if po_first_col_idx <= x['ci'] <= po_last_col_idx
                and percent_row <= x['row'] <= po_end_row
            ]
            if not conflicts:
                break
            new_percent_row = max(conflicts) + 1
            if new_percent_row <= percent_row:
                break
            percent_row = new_percent_row

        po_header_row = percent_row + (1 if export_increase_row else 0)
        po_data_start = po_header_row + 1
        projected_total_row = (
            po_data_start + len(self.po_list) + increase_po_count + 1
        )

        # ===== LẬP KẾ HOẠCH VỊ TRÍ CÁC KHỐI LOẠI VẢI =====
        # Nếu thông tin bổ sung nằm đúng trong một khối vải, chỉ khối đó và các
        # khối phía sau dịch xuống. Nếu nằm ở ô/cột trống thì giữ nguyên vị trí.
        note_col_idx = excel_col_to_index(note_col)
        adjust_col_idx = excel_col_to_index(adjust_col)
        adjust_lot_col_idx = excel_col_to_index(adjust_lot_col)

        def custom_conflicts_fabric_cell(item, fabric, header_row, end_row):
            if not (header_row <= item['row'] <= end_row):
                return False
            ci = item['ci']
            if 1 <= ci <= note_col_idx:
                return True
            if ci == adjust_col_idx:
                return True
            if ci == adjust_lot_col_idx and (fabric.get('lots', []) or []):
                return True
            return False

        fabric_spacer_rows = []
        planned_spacer = projected_total_row + 3
        for result in results:
            fabric = result['fabric']
            table_count = len(result['cutting_tables']) + RESERVE_TABLES_PER_FABRIC
            lot_count = len([lot for lot in (fabric.get('lots', []) or [])
                             if str(lot.get('name', '')).strip()]) + len(supp_lot_input_rows.get(id(fabric), {}).get('blank_rows', []))
            while True:
                header_row = planned_spacer + 1
                # Header 2 dòng + bàn + thực cắt + dương. LOT chỉnh tay có thể dài hơn số bàn.
                main_end = planned_spacer + table_count + RESERVE_TABLES_PER_FABRIC + 4
                lot_adjust_end = planned_spacer + lot_count + 2 if lot_count else main_end
                occupied_end = max(main_end, lot_adjust_end)
                conflicts = [
                    x['row'] for x in pending_custom_info
                    if custom_conflicts_fabric_cell(x, fabric, header_row, occupied_end)
                ]
                if not conflicts:
                    break
                # Để nguyên thông tin ở đúng dòng được yêu cầu; đẩy cả khối vải xuống dưới nó.
                planned_spacer = max(conflicts)
            fabric_spacer_rows.append(planned_spacer)
            # Sau dòng DƯƠNG có 2 dòng cách như bố cục hiện tại.
            planned_spacer = planned_spacer + table_count + 6

        # Hàng có thông tin bổ sung được tăng chiều cao nhưng không làm dịch dòng.
        for x in pending_custom_info:
            ws.row_dimensions[x['row']].height = max(float(ws.row_dimensions[x['row']].height or 15), 24.0)

        # Toàn bộ phần THÔNG TIN CHUNG luôn một dòng, không xuống dòng và KHÔNG thu nhỏ font.
        # Nếu ô kế bên trống, Excel sẽ cho chữ hiển thị tràn sang cột sau.
        for rr in range(1, max_info_row + 1):
            for cc in range(1, 11 + len(self.sizes)):
                cell = ws.cell(rr, cc)
                if cell.value is not None:
                    cell.alignment = Alignment(
                        horizontal=cell.alignment.horizontal,
                        vertical=cell.alignment.vertical or 'center',
                        text_rotation=cell.alignment.textRotation,
                        wrap_text=False,
                        shrink_to_fit=False,
                        indent=cell.alignment.indent
                    )


        # Khôi phục định dạng xuống dòng cho khung CODE/DATE sau bước chuẩn hóa NO WRAP.
        if info_lines:
            ws[f'{info_box_start_col}1'].alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)

        if export_increase_row:
            ws.row_dimensions[percent_row].height = 36.0
        ws.row_dimensions[po_header_row].height = 32.0

        # V160: dòng % DƯƠNG chỉ xuất khi bật ÁP DỤNG % DƯƠNG.
        # Người dùng nhập trực tiếp 1%, 2.5%... tại đúng cột size.
        # Không còn một ô % chung cho tất cả size.
        percent_cells_by_col = {}

        if export_increase_row:
            for col in ['C', 'D', 'E', 'F']:
                set_cell(
                    f'{col}{percent_row}',
                    border=make_border(
                        left=medium if col == 'C' else None,
                        right=medium if col == 'F' else None,
                        top=medium, bottom=medium
                    ),
                    fill=fill_percent_row
                )
            ws.merge_cells(f'C{percent_row}:F{percent_row}')

            _pct_mode_label = (
                'TẤT CẢ PO'
                if self._increase_mode() == 'all'
                else 'TỪNG PO ĐƯỢC CHỌN'
            )
            set_cell(
                f'C{percent_row}',
                f'% DƯƠNG TỪNG CỠ / INCREASE BY SIZE (%) - {_pct_mode_label}',
                font=font_bilingual,
                alignment=align_bilingual,
                border=make_border(
                    left=medium, right=medium,
                    top=medium, bottom=medium
                ),
                fill=fill_percent_row
            )

            for idx, (col, name) in enumerate(zip(size_cols, size_names)):
                left = medium if idx == 0 else thin
                right = medium if idx == len(size_cols) - 1 else thin

                pct_raw = max(
                    0.0,
                    float(self.sizes[idx].get('increase_pct', 0.0) or 0.0)
                )

                # Chỉ cỡ có % dương mới hiện số; cỡ 0% để trống.
                pct_value = (pct_raw / 100.0) if pct_raw > 0 else None

                set_cell(
                    f'{col}{percent_row}',
                    pct_value,
                    font=font_bold,
                    alignment=align_center,
                    border=make_border(
                        left=left, right=right,
                        top=medium, bottom=medium
                    ),
                    fill=fill_percent_row
                )
                ws[f'{col}{percent_row}'].number_format = '0.00%'

                percent_cells_by_col[col] = (
                    f'${col}${percent_row}' if pct_raw > 0 else '0'
                )

            # Tổng % được gán công thức sau khi đã có dòng tổng đơn hàng/kế hoạch.
            set_cell(
                f'{total_col}{percent_row}',
                None,
                font=font_bold,
                alignment=align_center,
                border=make_border(
                    left=medium, right=medium,
                    top=medium, bottom=medium
                ),
                fill=fill_percent_row
            )
            ws[f'{total_col}{percent_row}'].number_format = '0.00%'

        else:
            # Tắt áp dụng dương: không có dòng % và mọi công thức tăng dùng 0.
            percent_cells_by_col = {col: '0' for col in size_cols}

        # V68: tách phần đầu bảng thành PO | MÀU/COLOR giống mẫu người dùng.
        for col in ['C', 'D']:
            set_cell(f'{col}{po_header_row}', border=make_border(
                left=medium if col == 'C' else None,
                right=medium if col == 'D' else None,
                top=medium, bottom=medium), fill=fill_theme4_tint60)
        for col in ['E', 'F']:
            set_cell(f'{col}{po_header_row}', border=make_border(
                left=medium if col == 'E' else None,
                right=medium if col == 'F' else None,
                top=medium, bottom=medium), fill=fill_theme4_tint60)
        ws.merge_cells(f'C{po_header_row}:D{po_header_row}')
        ws.merge_cells(f'E{po_header_row}:F{po_header_row}')
        set_cell(f'C{po_header_row}', 'PO', font=font_bold, alignment=align_center,
                 border=make_border(left=medium, right=medium, top=medium, bottom=medium),
                 fill=fill_theme4_tint60)
        set_cell(f'E{po_header_row}', 'MÀU/COLOR', font=font_bold, alignment=align_center,
                 border=make_border(left=medium, right=medium, top=medium, bottom=medium),
                 fill=fill_theme4_tint60)

        for idx, (col, name) in enumerate(zip(size_cols, size_names)):
            set_cell(f'{col}{po_header_row}', name, font=font_normal, alignment=align_center,
                     border=make_border(left=thin if idx > 0 else None,
                                        right=medium if idx == len(size_cols)-1 else thin,
                                        top=medium, bottom=medium),
                     fill=fill_theme8_tint0)
        set_cell(f'{total_col}{po_header_row}', 'TỔNG', font=font_bold, alignment=align_center,
                 border=make_border(left=medium, right=medium, top=medium, bottom=medium))

        current_row = po_data_start
        # V64:
        # - PO có tích TĂNG %: xuất dòng PO + dòng SẢN LƯỢNG DƯƠNG.
        # - PO không tích: chỉ xuất đúng 1 dòng PO, không chừa dòng dương trống.
        # - Ô không có số lượng / không phát sinh dương hiển thị trống thay vì 0.
        po_excel_rows = {}
        po_excess_excel_rows = {}
        raw_po_rows_all = []
        excess_po_rows_all = []
        for po in self.po_list:
            po_name_for_map = str(po.get('po', '')).strip()
            raw_row = current_row
            po_excel_rows.setdefault(po_name_for_map, []).append(raw_row)
            raw_po_rows_all.append(raw_row)
            ws.row_dimensions[raw_row].height = 23.0
            for col in ['C', 'D']:
                set_cell(f'{col}{raw_row}', border=make_border(
                    left=medium if col == 'C' else None,
                    right=medium if col == 'D' else None,
                    top=thin, bottom=thin))
            for col in ['E', 'F']:
                set_cell(f'{col}{raw_row}', border=make_border(
                    left=medium if col == 'E' else None,
                    right=medium if col == 'F' else None,
                    top=thin, bottom=thin))
            ws.merge_cells(f'C{raw_row}:D{raw_row}')
            ws.merge_cells(f'E{raw_row}:F{raw_row}')
            set_cell(f'C{raw_row}', int(po['po']) if str(po['po']).isdigit() else po['po'],
                     font=font_normal, alignment=align_center,
                     border=make_border(left=medium, right=medium, top=thin, bottom=thin))
            set_cell(f'E{raw_row}', str(po.get('color', '') or '').strip() or None,
                     font=font_normal, alignment=align_center,
                     border=make_border(left=medium, right=medium, top=thin, bottom=thin))
            for idx, (key, col) in enumerate(zip(size_keys, size_cols)):
                val = po.get(key, 0)
                set_cell(f'{col}{raw_row}', val if val > 0 else None,
                         font=font_normal, alignment=align_center,
                         border=make_border(left=thin if idx > 0 else None,
                                            right=medium if idx == len(size_cols)-1 else thin,
                                            top=thin, bottom=thin))
            # Nếu toàn bộ cỡ của PO trống thì tổng cũng để trống.
            set_cell(f'{total_col}{raw_row}',
                     f'=IF(COUNT({first_size_col}{raw_row}:{last_size_col}{raw_row})=0,"",SUM({first_size_col}{raw_row}:{last_size_col}{raw_row}))',
                     font=font_normal, alignment=align_center,
                     border=make_border(left=thin, right=medium, top=thin, bottom=thin))

            po_apply_increase = self._po_increase_active(po)
            if po_apply_increase:
                # Dòng ngay dưới PO: chỉ tạo khi PO được tích TĂNG %.
                current_row += 1
                excess_row = current_row
                po_excess_excel_rows.setdefault(po_name_for_map, []).append(excess_row)
                excess_po_rows_all.append(excess_row)
                ws.row_dimensions[excess_row].height = 22.0
                for col in ['C', 'D', 'E', 'F']:
                    set_cell(f'{col}{excess_row}', border=make_border(
                        left=medium if col == 'C' else None,
                        right=medium if col == 'F' else None,
                        top=thin, bottom=thin), fill=fill_theme9_tint80)
                ws.merge_cells(f'C{excess_row}:F{excess_row}')
                set_cell(f'C{excess_row}', 'SẢN LƯỢNG DƯƠNG / EXCESS QTY',
                         font=Font(name='Calibri', size=9, bold=True), alignment=align_center,
                         border=make_border(left=medium, right=medium, top=thin, bottom=thin),
                         fill=fill_theme9_tint80)
                for idx, (key, col) in enumerate(zip(size_keys, size_cols)):
                    pct_ref = percent_cells_by_col.get(col, '0')
                    # Không có SL gốc hoặc % không làm phát sinh thêm SP -> để trống.
                    extra_expr = f'ROUNDUP({col}{raw_row}*(1+{pct_ref}),0)-{col}{raw_row}'
                    formula = f'=IF({col}{raw_row}="","",IF({extra_expr}>0,{extra_expr},""))'
                    set_cell(f'{col}{excess_row}', formula, font=font_normal, alignment=align_center,
                             border=make_border(left=thin if idx > 0 else None,
                                                right=medium if idx == len(size_cols)-1 else thin,
                                                top=thin, bottom=thin), fill=fill_theme9_tint80)
                set_cell(f'{total_col}{excess_row}',
                         f'=IF(COUNT({first_size_col}{excess_row}:{last_size_col}{excess_row})=0,"",SUM({first_size_col}{excess_row}:{last_size_col}{excess_row}))',
                         font=font_bold, alignment=align_center,
                         border=make_border(left=thin, right=medium, top=thin, bottom=thin),
                         fill=fill_theme9_tint80)
            else:
                # Giữ vị trí tương ứng với raw_rows cho trường hợp trùng tên PO.
                po_excess_excel_rows.setdefault(po_name_for_map, []).append(None)

            current_row += 1

        # TỔNG ĐƠN HÀNG: merge C:F và tăng chiều cao.
        base_total_row = current_row
        ws.row_dimensions[base_total_row].height = 30.0
        for col in ['C', 'D', 'E', 'F']:
            set_cell(f'{col}{base_total_row}', border=make_border(
                left=medium if col == 'C' else None,
                right=medium if col == 'F' else None,
                top=medium, bottom=thin), fill=fill_total_order)
        ws.merge_cells(f'C{base_total_row}:F{base_total_row}')
        set_cell(f'C{base_total_row}', 'TỔNG ĐƠN HÀNG/TOTAL ORDER', font=font_bold, alignment=Alignment(horizontal='center', vertical='center', wrap_text=False, shrink_to_fit=True),
                 border=make_border(left=medium, right=medium, top=medium, bottom=thin),
                 fill=fill_total_order)
        for idx, (key, col) in enumerate(zip(size_keys, size_cols)):
            raw_refs = ','.join(f'{col}{rr}' for rr in raw_po_rows_all)
            base_formula = (f'=IF(SUM({raw_refs})=0,"",SUM({raw_refs}))' if raw_refs else '=""')
            set_cell(f'{col}{base_total_row}', base_formula,
                     font=font_normal, alignment=align_center,
                     border=make_border(left=thin if idx > 0 else None,
                                        right=medium if idx == len(size_cols)-1 else thin,
                                        top=medium, bottom=thin), fill=fill_total_order)
        set_cell(f'{total_col}{base_total_row}',
                 f'=IF(COUNT({first_size_col}{base_total_row}:{last_size_col}{base_total_row})=0,"",SUM({first_size_col}{base_total_row}:{last_size_col}{base_total_row}))',
                 font=font_normal, alignment=align_center,
                 border=make_border(left=thin, right=medium, top=medium, bottom=thin),
                 fill=fill_total_order)

        # SẢN LƯỢNG KẾ HOẠCH: merge C:F và tăng chiều cao.
        total_row = base_total_row + 1
        ws.row_dimensions[total_row].height = 30.0
        for col in ['C', 'D', 'E', 'F']:
            set_cell(f'{col}{total_row}', border=make_border(
                left=medium if col == 'C' else None,
                right=medium if col == 'F' else None,
                top=thin, bottom=medium), fill=fill_plan_row)
        ws.merge_cells(f'C{total_row}:F{total_row}')
        set_cell(f'C{total_row}', 'SẢN LƯỢNG KẾ HOẠCH/PLANNED QTY', font=font_bilingual, alignment=align_bilingual,
                 border=make_border(left=medium, right=medium, top=thin, bottom=medium),
                 fill=fill_plan_row)
        for idx, (key, col) in enumerate(zip(size_keys, size_cols)):
            excess_refs = ','.join(f'{col}{rr}' for rr in excess_po_rows_all)
            extra_formula = f'SUM({excess_refs})' if excess_refs else '0'
            formula = f'=IF(N({col}{base_total_row})+{extra_formula}=0,"",N({col}{base_total_row})+{extra_formula})'
            set_cell(f'{col}{total_row}', formula, font=font_bold, alignment=align_center,
                     border=make_border(left=thin if idx > 0 else None,
                                        right=medium if idx == len(size_cols)-1 else thin,
                                        top=thin, bottom=medium), fill=fill_plan_row)
        set_cell(f'{total_col}{total_row}',
                 f'=IF(COUNT({first_size_col}{total_row}:{last_size_col}{total_row})=0,"",SUM({first_size_col}{total_row}:{last_size_col}{total_row}))',
                 font=font_bold, alignment=align_center,
                 border=make_border(left=thin, right=medium, top=thin, bottom=medium),
                 fill=fill_plan_row)

        # % tăng tổng có trọng số chỉ xuất khi đang bật % DƯƠNG.
        if export_increase_row:
            ws[f'{total_col}{percent_row}'] = (
                f'=IF({total_col}{base_total_row}>0,'
                f'IF({total_col}{total_row}/{total_col}{base_total_row}-1>0,'
                f'{total_col}{total_row}/{total_col}{base_total_row}-1,""),"")'
            )
            ws[f'{total_col}{percent_row}'].number_format = '0.00%'
            ws[f'{total_col}{percent_row}'].font = font_bold
            ws[f'{total_col}{percent_row}'].alignment = align_center
            ws[f'{total_col}{percent_row}'].fill = fill_percent_row
            ws[f'{total_col}{percent_row}'].border = make_border(
                left=medium, right=medium, top=medium, bottom=medium
            )

        current_row = total_row + 3
        lot_helper_next_row = 1

        # ===== TỰ CÂN TRANG A4 NGANG =====
        # Excel đang dùng Fit to 1 page wide nên toàn bộ chiều cao cũng bị thu theo
        # cùng tỷ lệ bề ngang. V21 dùng ngưỡng cố định 500 pt nên ngắt trang quá sớm,
        # làm trang in còn rất nhiều khoảng trắng. V23 tính ngưỡng chiều cao theo
        # chính độ rộng các cột hiện tại để tận dụng gần hết khổ A4 nhưng vẫn không
        # chẻ đôi một khối loại vải.
        from openpyxl.worksheet.pagebreak import Break

        A4_LANDSCAPE_WIDTH_PT = 841.89
        A4_LANDSCAPE_HEIGHT_PT = 595.28
        PRINT_MARGIN_LEFT_IN = 0.10
        PRINT_MARGIN_RIGHT_IN = 0.10
        PRINT_MARGIN_TOP_IN = 0.10
        PRINT_MARGIN_BOTTOM_IN = 0.10

        def excel_width_to_points(width):
            # Xấp xỉ cách Excel chuyển ColumnWidth -> pixel -> point.
            # Đủ chính xác để tính page break; Excel vẫn là nơi quyết định scale in cuối cùng.
            try:
                width = float(width)
            except (TypeError, ValueError):
                width = 8.43
            if width < 1:
                pixels = int(width * 12)
            else:
                pixels = int(((256 * width + int(128 / 7)) / 256) * 7)
            return pixels * 0.75

        # Tổng độ rộng từ A đến cột GHI CHÚ. Cột ĐIỀU CHỈNH SỐ LÁ cố ý KHÔNG tính vào A4.
        last_print_col_idx = 10 + len(self.sizes)
        total_width_points = 0.0
        for cc in range(1, last_print_col_idx + 1):
            col = col_letter(cc)
            width = ws.column_dimensions[col].width
            total_width_points += excel_width_to_points(width)

        printable_width_points = (
            A4_LANDSCAPE_WIDTH_PT
            - (PRINT_MARGIN_LEFT_IN + PRINT_MARGIN_RIGHT_IN) * 72.0
        )
        printable_height_points = (
            A4_LANDSCAPE_HEIGHT_PT
            - (PRINT_MARGIN_TOP_IN + PRINT_MARGIN_BOTTOM_IN) * 72.0
        )

        # Tỷ lệ mà Excel phải thu bề ngang để vừa đúng 1 trang. Khi sheet rộng,
        # scale < 1 và theo đó một trang chứa được nhiều row point hơn.
        estimated_print_scale = min(1.0, printable_width_points / max(total_width_points, 1.0))

        # V25 dùng gần tối đa chiều cao A4; chừa 1.5% cho sai số driver máy in.
        PAGE_BODY_POINTS = (printable_height_points / max(estimated_print_scale, 0.10)) * 0.985
        page_start_row = 1

        def row_height_points(row_num):
            return float(ws.row_dimensions[row_num].height or 15.0)

        def used_points_on_page(start_row, end_row):
            if end_row < start_row:
                return 0.0
            return sum(row_height_points(r) for r in range(start_row, end_row + 1))

        def build_fabric_target_by_col(fabric):
            """Công thức sản lượng kế hoạch theo từng cỡ cho đúng PO của loại vải."""
            mode = str(fabric.get('po_mode', 'all') or 'all').lower()
            if mode == 'all':
                return {col: f'{col}${total_row}' for col in size_cols}

            selected = [str(x).strip() for x in (fabric.get('po_targets', []) or []) if str(x).strip()]
            result_map = {}
            for col in size_cols:
                refs = []
                for po_name in selected:
                    raw_rows = po_excel_rows.get(po_name, [])
                    excess_rows = po_excess_excel_rows.get(po_name, [])
                    for pos, rr in enumerate(raw_rows):
                        er = excess_rows[pos] if pos < len(excess_rows) else None
                        refs.append(f'(N({col}${rr})+N({col}${er}))' if er else f'N({col}${rr})')
                result_map[col] = ('+'.join(refs)) if refs else '0'
            return result_map

        def build_fabric_order_by_col(fabric):
            """Công thức số lượng gốc theo từng cỡ cho đúng PO của loại vải.

            - Nếu loại vải áp dụng TẤT CẢ PO: lấy dòng TỔNG ĐƠN HÀNG.
            - Nếu loại vải áp dụng theo PO: cộng đúng các dòng PO đã chọn.
            """
            mode = str(fabric.get('po_mode', 'all') or 'all').lower()
            if mode == 'all':
                return {col: f'{col}${base_total_row}' for col in size_cols}

            selected = [str(x).strip() for x in (fabric.get('po_targets', []) or []) if str(x).strip()]
            result_map = {}
            for col in size_cols:
                refs = []
                for po_name in selected:
                    for rr in po_excel_rows.get(po_name, []):
                        refs.append(f'N({col}${rr})')
                result_map[col] = ('+'.join(refs)) if refs else '0'
            return result_map


        def estimate_fabric_block_points(tables):
            # 1 dòng cách + 3 dòng header (tiêu đề / tên cỡ / SL theo cỡ) + các bàn + 2 dòng tổng kết + 1 dòng cách.
            # V82: 3 dòng bàn dự phòng đang ẩn mặc định nên không tính chiều cao khi phân trang in.
            pts = 15.75 + 42.0 + 26.25 + 20.0 + 18.0 + 18.0 + 15.0
            for table in tables:
                ratio_text = str(table.get('ratio', ''))
                approx_lines = max(1, math.ceil(len(ratio_text) / 42))
                pts += max(26.25, 17.0 * approx_lines)
            return pts

        fabric_excel_info = {}

        _excel_result_count = max(1, len(results))
        for fabric_idx, result in enumerate(results):
            fabric = result['fabric']
            self._export_progress(66 + int(26 * fabric_idx / _excel_result_count),
                                  f"Đang ghi Excel: {fabric.get('name', 'loại vải')}")
            tables = result['cutting_tables']
            # V40: mục tiêu sản lượng của khối này là theo PO áp dụng của chính loại vải.
            fabric_target_by_col = build_fabric_target_by_col(fabric)

            # V34: nếu thông tin đơn hàng chiếm vị trí của khối này thì chỉ khối này
            # và các khối phía sau dịch xuống; các phần phía trên giữ nguyên.
            if fabric_idx < len(fabric_spacer_rows):
                current_row = max(current_row, fabric_spacer_rows[fabric_idx])

            # Chỉ ngắt trang khi khối mới không còn vừa phần còn lại của A4.
            block_points = estimate_fabric_block_points(tables)
            used_points = used_points_on_page(page_start_row, current_row - 1)
            if used_points > 0 and used_points + block_points > PAGE_BODY_POINTS:
                break_after = max(1, current_row - 1)
                ws.row_breaks.append(Break(id=break_after))
                page_start_row = current_row

            ws.row_dimensions[current_row].height = 15.75
            current_row += 1
            ws.row_dimensions[current_row].height = 42.0

            header_row = current_row
            size_name_row = header_row + 1
            size_qty_row = header_row + 2
            ws.row_dimensions[size_name_row].height = 26.25
            ws.row_dimensions[size_qty_row].height = 20.0

            # Số lượng gốc dưới từng cỡ:
            # - TẤT CẢ PO -> lấy TỔNG ĐƠN HÀNG
            # - Theo PO -> lấy tổng đúng PO áp dụng của loại vải.
            fabric_order_by_col = build_fabric_order_by_col(fabric)

            # ===== HEADER THEO MAU HINH 2 =====
            # A:F gop doc 3 dong; cac cot TONG / DINH MUC / SO M CAN DUNG cung gop doc.
            header_map = {
                'A': 'LOẠI VẢI\nFABRIC TYPE', 'B': 'SỐ BÀN\nTABLE NO.', 'C': 'TỈ LỆ SƠ ĐỒ/MARKER RATE',
                'D': 'CHIỀU DÀI SƠ ĐỒ\nMARKER LENGTH', 'E': 'LOT', 'F': 'SỐ LÁ\nPLIES'
            }
            for col, value in header_map.items():
                fill = fill_theme4_tint60 if col == 'C' else None
                set_cell(f'{col}{header_row}', value,
                         font=font_bold if col == 'E' else font_bilingual,
                         alignment=align_center if col == 'E' else align_bilingual,
                         border=make_border(left=medium, right=medium, top=medium, bottom=medium),
                         fill=fill)
                set_cell(f'{col}{size_name_row}', border=make_border(left=medium, right=medium), fill=fill)
                set_cell(f'{col}{size_qty_row}', border=make_border(left=medium, right=medium, bottom=medium), fill=fill)
                ws.merge_cells(f'{col}{header_row}:{col}{size_qty_row}')

            # Vùng SẢN LƯỢNG TỪNG CỠ: dòng 1 tiêu đề, dòng 2 tên cỡ, dòng 3 số lượng theo cỡ.
            marker_title_range = f'{first_size_col}{header_row}:{last_size_col}{header_row}'
            for idx, col in enumerate(size_cols):
                set_cell(f'{col}{header_row}',
                         border=make_border(left=medium if idx == 0 else thin,
                                            right=medium if idx == len(size_cols)-1 else thin,
                                            top=medium, bottom=thin),
                         fill=fill_theme8_tint0)
            ws.merge_cells(marker_title_range)
            set_cell(f'{first_size_col}{header_row}', 'SẢN LƯỢNG TỪNG CỠ/QTY BY SIZE', font=font_bilingual,
                     alignment=align_bilingual,
                     border=make_border(left=medium, right=medium, top=medium, bottom=thin),
                     fill=fill_theme8_tint0)

            for idx, (col, name) in enumerate(zip(size_cols, size_names)):
                left = medium if idx == 0 else thin
                right = medium if idx == len(size_cols)-1 else thin
                set_cell(f'{col}{size_name_row}', name, font=font_normal, alignment=align_center,
                         border=make_border(left=left, right=right, top=thin, bottom=thin),
                         fill=fill_theme8_tint0)
                qty_expr = fabric_order_by_col.get(col, '0')
                qty_formula = f'=IFERROR({qty_expr},0)' if qty_expr != '0' else '=0'
                set_cell(f'{col}{size_qty_row}', qty_formula, font=font_normal, alignment=align_center,
                         border=make_border(left=left, right=right, top=thin, bottom=medium),
                         fill=fill_total_order)

            # TONG / DINH MUC / SO M CAN DUNG merge doc 3 dong nhu hinh 2.
            side_headers = [
                (total_col, 'TỔNG\nTOTAL', fill_theme8_tint0),
                (norm_col, 'ĐỊNH MỨC\nCONSUMPTION', None),
                (need_col, 'SỐ M CẦN DÙNG\nFABRIC REQUIRED', None),
                (note_col, 'GHI CHÚ/REMARKS', None),
            ]
            for col, value, fill in side_headers:
                set_cell(f'{col}{header_row}', value, font=font_bilingual_small, alignment=align_bilingual,
                         border=make_border(left=medium, right=medium, top=medium, bottom=medium), fill=fill)
                set_cell(f'{col}{size_name_row}', border=make_border(left=medium, right=medium), fill=fill)
                set_cell(f'{col}{size_qty_row}', border=make_border(left=medium, right=medium, bottom=medium), fill=fill)
                ws.merge_cells(f'{col}{header_row}:{col}{size_qty_row}')

            # V25: cột ĐIỀU CHỈNH SỐ LÁ vẫn nằm ngoài A4 nhưng được kẻ ô rõ ràng.
            set_cell(f'{adjust_col}{header_row}', 'ĐIỀU CHỈNH SỐ LÁ\nADJUST PLIES',
                     font=font_bilingual_small, alignment=align_bilingual,
                     border=make_border(left=medium, right=medium, top=medium, bottom=medium),
                     fill=fill_plan_row)
            set_cell(f'{adjust_col}{size_name_row}', border=make_border(left=medium, right=medium), fill=fill_plan_row)
            set_cell(f'{adjust_col}{size_qty_row}', border=make_border(left=medium, right=medium, bottom=medium), fill=fill_plan_row)
            ws.merge_cells(f'{adjust_col}{header_row}:{adjust_col}{size_qty_row}')

            # V60: không còn cột ĐIỀU CHỈNH TỔNG LOT trên BIỂU CẮT.
            # LOT/tổng mét được đọc duy nhất từ Excel Table ở SỬA PHÂN CÂY.
            fabric_lot_slots = []
            current_row = size_qty_row + 1
            first_table_row = current_row

            table_excel_rows = []
            reserve_count = reserve_rows_for(len(tables))
            total_table_rows = len(tables) + reserve_count
            reserve_start_row = first_table_row + len(tables)
            reserve_end_row = reserve_start_row + reserve_count - 1
            if reserve_count > 0:
                reserve_row_groups.append(list(range(reserve_start_row, reserve_end_row + 1)))
            last_table_row = first_table_row + total_table_rows - 1

            for table_idx in range(total_table_rows):
                is_reserve = table_idx >= len(tables)
                if is_reserve:
                    reserve_no = table_idx - len(tables) + 1
                    table = {
                        'table': f'B{table_idx + 1}',
                        'ratio': '',
                        'length': '',
                        'ratio_map': {},
                    }
                else:
                    table = tables[table_idx]
                    reserve_no = 0

                # Marker dài được wrap và tự tăng chiều cao dòng để không bị che chữ.
                ratio_text = str(table.get('ratio', '') or '')
                approx_lines = max(1, math.ceil(len(ratio_text) / 42))
                ws.row_dimensions[current_row].height = max(26.25, 17.0 * approx_lines)
                top_border = thin if table_idx > 0 else medium

                set_cell(f'A{current_row}', border=make_border(left=medium, right=medium, top=top_border))
                set_cell(f'B{current_row}', table.get('table', f'B{table_idx + 1}'),
                         font=font_normal, alignment=align_center,
                         border=make_border(right=thin, top=top_border, bottom=thin))
                set_cell(f'C{current_row}', table.get('ratio', '') or None,
                         font=font_normal, alignment=align_center_wrap,
                         border=make_border(left=thin, right=thin, top=top_border, bottom=thin),
                         fill=fill_theme9_tint80)

                length_value = table.get('length', '')
                if length_value not in ('', None):
                    try:
                        length_value = round(float(length_value), 2)
                    except (TypeError, ValueError):
                        pass
                else:
                    length_value = None
                set_cell(f'D{current_row}', length_value, font=font_normal, alignment=align_center,
                         border=make_border(left=thin, right=thin, top=top_border, bottom=thin))
                ws[f'D{current_row}'].number_format = '0.##'

                # LOT là công thức động; giá trị sẽ được gán sau khi tạo block helper.
                set_cell(f'E{current_row}', font=font_normal,
                         alignment=Alignment(horizontal='center', vertical='center', wrap_text=True, shrink_to_fit=False),
                         border=make_border(left=thin, right=thin, top=top_border, bottom=thin))

                # SỐ LÁ:
                # - Dòng gốc giữ đúng thuật toán cũ nếu tỷ lệ C chưa bị sửa.
                # - Nếu sửa C hoặc dùng dòng dự phòng, tự đọc tỷ lệ mới trong C và tính lại.
                edited_formula = edited_ratio_plies_formula(
                    current_row, first_table_row, fabric_target_by_col, size_names, size_cols
                )
                edited_expr = edited_formula[1:]

                if not is_reserve:
                    original_formula = dynamic_plies_formula(
                        table_idx, tables, current_row, first_table_row, fabric_target_by_col,
                        size_keys, size_cols, result.get('total_by_size', {})
                    )
                    original_expr = original_formula[1:] if original_formula.startswith('=') else original_formula
                    original_ratio = str(table.get('ratio', '') or '').replace('"', '""')
                    auto_expr = (
                        f'IF($C{current_row}="{original_ratio}",({original_expr}),({edited_expr}))'
                    )
                else:
                    auto_expr = edited_expr

                final_plies_formula = (
                    f'=IF(TRIM($C{current_row})="","",'
                    f'IF({adjust_col}{current_row}<>"",{adjust_col}{current_row},{auto_expr}))'
                )
                set_cell(f'F{current_row}', final_plies_formula, font=font_normal, alignment=align_center,
                         border=make_border(left=thin, right=thin, top=top_border, bottom=thin),
                         fill=fill_plan_row)

                # Ô chỉnh số lá để trống, CÓ viền nhưng vẫn nằm ngoài Print Area.
                ws[f'{adjust_col}{current_row}'].border = make_border(
                    left=medium, right=medium, top=top_border, bottom=thin)
                ws[f'{adjust_col}{current_row}'].alignment = align_center
                ws[f'{adjust_col}{current_row}'].fill = fill_theme6_tint80
                ws[f'{adjust_col}{current_row}'].number_format = '0'

                # V38: sản lượng từng cỡ đọc TRỰC TIẾP tỷ lệ trong cột C.
                # Vì vậy sửa tỷ lệ sơ đồ ở bất kỳ hàng nào sẽ cập nhật cả hàng đó.
                for idx, (size_name, col) in enumerate(zip(size_names, size_cols)):
                    ratio_expr = ratio_value_formula(current_row, size_name)
                    qty_formula = (
                        f'=IF(OR(TRIM($C{current_row})="",F{current_row}=""),"",'
                        f'IF(({ratio_expr})>0,F{current_row}*({ratio_expr}),""))'
                    )
                    set_cell(f'{col}{current_row}', qty_formula, font=font_normal, alignment=align_center,
                             border=make_border(left=medium if idx == 0 else thin,
                                                right=medium if idx == len(size_cols)-1 else thin,
                                                top=thin, bottom=thin), fill=fill_theme8_tint80)

                set_cell(f'{total_col}{current_row}',
                         f'=IF(TRIM($C{current_row})="","",SUM({first_size_col}{current_row}:{last_size_col}{current_row}))',
                         font=font_normal, alignment=align_center,
                         border=make_border(left=medium, right=thin, bottom=thin))
                # SỐ M CẦN DÙNG = chiều dài sơ đồ x số lá x 1.01 (cộng 1%).
                set_cell(f'{need_col}{current_row}',
                         f'=IF(OR(TRIM($C{current_row})="",D{current_row}="",F{current_row}=""),"",ROUND(D{current_row}*F{current_row}*1.01,2))',
                         font=font_normal, alignment=align_center,
                         border=make_border(left=thin, right=thin, bottom=thin))
                ws[f'{need_col}{current_row}'].number_format = '0.00'

                # ĐỊNH MỨC TỪNG BÀN = SỐ MÉT CẦN DÙNG / TỔNG SỐ LƯỢNG CỦA BÀN.
                set_cell(f'{norm_col}{current_row}',
                         f'=IFERROR(IF(OR({need_col}{current_row}="",{total_col}{current_row}="",{total_col}{current_row}=0),"",ROUND({need_col}{current_row}/{total_col}{current_row},4)),"")',
                         font=font_normal, alignment=align_center,
                         border=make_border(left=thin, right=thin, bottom=thin))
                ws[f'{norm_col}{current_row}'].number_format = '0.00'

                set_cell(f'{note_col}{current_row}', border=make_border(left=thin, right=medium, bottom=thin))

                table_excel_rows.append(current_row)
                current_row += 1

            last_table_row = table_excel_rows[-1] if table_excel_rows else first_table_row

            # Tạo công thức LOT động cho cả bàn gốc + 3 dòng dự phòng.
            lot_helper_next_row, dynamic_note_formula = build_dynamic_lot_formulas(
                fabric, table_excel_rows, lot_helper_next_row
            )

            # Không tạo dòng trống không có bàn; dòng tổng kết nằm ngay sau bàn cuối.

            # Dòng SẢN LƯỢNG THỰC CẮT
            ws.row_dimensions[current_row].height = 18.0
            actual_row = current_row
            set_cell(f'A{actual_row}', border=make_border(left=medium, right=medium))

            # Merge B:F giong hinh 2.
            for col in ['B', 'C', 'D', 'E', 'F']:
                set_cell(f'{col}{actual_row}', border=make_border(
                    left=medium if col == 'B' else None,
                    right=medium if col == 'F' else None,
                    top=medium, bottom=thin), fill=fill_theme9_tint80)
            ws.merge_cells(f'B{actual_row}:F{actual_row}')
            set_cell(f'B{actual_row}', 'SẢN LƯỢNG THỰC CẮT/ACTUAL CUT QTY', font=Font(name='Calibri', size=9), alignment=Alignment(horizontal='center', vertical='center', wrap_text=False, shrink_to_fit=True),
                     border=make_border(left=medium, right=medium, top=medium, bottom=thin), fill=fill_theme9_tint80)

            for idx, (key, col) in enumerate(zip(size_keys, size_cols)):
                left = medium if idx == 0 else thin
                right = medium if idx == len(size_cols)-1 else thin
                # THUC CAT = tong san luong that su cua co do tren cac ban.
                formula = f'=SUM({col}{first_table_row}:{col}{last_table_row})' if table_excel_rows else '=0'
                set_cell(f'{col}{actual_row}', formula, font=font_normal, alignment=align_center,
                         border=make_border(left=left, right=right, top=medium, bottom=thin), fill=fill_theme9_tint60)

            set_cell(f'{total_col}{actual_row}',
                     f'=SUM({first_size_col}{actual_row}:{last_size_col}{actual_row})',
                     font=font_bold, alignment=align_center,
                     border=make_border(left=medium, right=thin, top=medium, bottom=thin),
                     fill=fill_theme9_tint60)
            set_cell(f'{norm_col}{actual_row}', border=make_border(left=thin, right=thin, top=medium, bottom=thin))
            # Tổng SỐ M CẦN DÙNG = tổng bàn gốc + 3 dòng dự phòng (dòng trống tự cho 0/blank).
            last_table_row = table_excel_rows[-1] if table_excel_rows else first_table_row
            set_cell(f'{need_col}{actual_row}', f'=ROUND(SUM({need_col}{first_table_row}:{need_col}{last_table_row}),2)',
                     font=font_normal, alignment=align_center,
                     border=make_border(left=thin, right=thin, top=medium, bottom=thin))
            ws[f'{need_col}{actual_row}'].number_format = '0.00'
            set_cell(f'{note_col}{actual_row}', border=make_border(left=thin, right=medium, top=medium, bottom=thin))
            ws[f'{adjust_col}{actual_row}'].border = make_border(left=medium, right=medium, top=medium, bottom=thin)
            ws[f'{adjust_col}{actual_row}'].fill = fill_theme6_tint80

            current_row += 1

            # Dòng SẢN LƯỢNG DƯƠNG = THỰC CẮT - TỔNG SẢN LƯỢNG CỠ.
            ws.row_dimensions[current_row].height = 18.0
            diff_row = current_row
            set_cell(f'A{diff_row}', border=make_border(left=medium, right=medium, bottom=medium))

            for col in ['B', 'C', 'D', 'E', 'F']:
                set_cell(f'{col}{diff_row}', border=make_border(
                    left=medium if col == 'B' else None,
                    right=medium if col == 'F' else None,
                    top=thin, bottom=medium), fill=fill_theme9_tint80)
            ws.merge_cells(f'B{diff_row}:F{diff_row}')
            _fabric_mode_for_diff = str(result.get('fabric_mode', '') or '')
            _diff_label = ('SẢN LƯỢNG ÂM/DƯƠNG / +/- QTY'
                           if _fabric_mode_for_diff in ('interlining', 'padding')
                           else 'SẢN LƯỢNG DƯƠNG/EXCESS QTY')
            set_cell(f'B{diff_row}', _diff_label, font=Font(name='Calibri', size=9), alignment=Alignment(horizontal='center', vertical='center', wrap_text=False, shrink_to_fit=True),
                     border=make_border(left=medium, right=medium, top=thin, bottom=medium), fill=fill_theme9_tint80)

            for idx, (key, col) in enumerate(zip(size_keys, size_cols)):
                left = medium if idx == 0 else thin
                right = medium if idx == len(size_cols)-1 else thin
                target_expr = fabric_target_by_col.get(col, '0')
                formula = f'={col}{actual_row}-({target_expr})'
                set_cell(f'{col}{diff_row}', formula, font=font_normal, alignment=align_center,
                         border=make_border(left=left, right=right, top=thin, bottom=medium),
                         fill=fill_theme9_tint60)

            set_cell(f'{total_col}{diff_row}', f'=SUM({first_size_col}{diff_row}:{last_size_col}{diff_row})',
                     font=font_bold, alignment=align_center,
                     border=make_border(left=medium, right=thin, top=thin, bottom=medium),
                     fill=fill_theme9_tint60)
            set_cell(f'{norm_col}{diff_row}', border=make_border(left=thin, right=thin, top=thin, bottom=medium))
            # Theo mau hinh 2: dong duong hien dinh muc thuc te binh quan = Tong met / Tong thuc cat.
            set_cell(f'{need_col}{diff_row}', f'=ROUND(IFERROR({need_col}{actual_row}/{total_col}{actual_row},0),2)',
                     font=font_normal, alignment=align_center,
                     border=make_border(left=thin, right=thin, top=thin, bottom=medium))
            ws[f'{need_col}{diff_row}'].number_format = '0.00'
            set_cell(f'{note_col}{diff_row}', border=make_border(left=thin, right=medium, top=thin, bottom=medium))
            ws[f'{adjust_col}{diff_row}'].border = make_border(left=medium, right=medium, top=thin, bottom=medium)
            ws[f'{adjust_col}{diff_row}'].fill = fill_theme6_tint80

            # GHI CHÚ LOT V21: là công thức động. Khi sửa chiều dài sơ đồ / số lá
            # trong Excel, số mét dùng, LOT đã dùng và mét dư tự cập nhật.
            ws.merge_cells(f'{note_col}{first_table_row}:{note_col}{diff_row}')
            set_cell(
                f'{note_col}{first_table_row}',
                dynamic_note_formula if dynamic_note_formula else None,
                font=font_normal,
                alignment=Alignment(horizontal='left', vertical='center', wrap_text=True),
                border=make_border(left=medium, right=medium, top=medium, bottom=medium)
            )

            # MERGE phần LOẠI VẢI theo toàn bộ khối từ B1 đến SẢN LƯỢNG DƯƠNG.
            ws.merge_cells(start_row=first_table_row, start_column=1,
                           end_row=diff_row, end_column=1)
            set_cell(f'A{first_table_row}', fabric['name'], font=font_normal,
                     alignment=Alignment(horizontal='center', vertical='center', wrap_text=True),
                     border=make_border(left=medium, right=medium, top=medium, bottom=medium))

            # V32: lưu vùng BIỂU CẮT của từng loại vải để SỬA PHÂN CÂY có thể
            # tự chia một LOT cho 1 hoặc nhiều loại vải theo số mét còn thiếu.
            fabric_excel_info[id(fabric)] = {
                'first_table_row': first_table_row,
                'last_table_row': last_table_row,
                'actual_row': actual_row,
                'diff_row': diff_row,
                'need_total_ref': f"SUM('{main_sheet_ref}'!{need_col}{first_table_row}:{need_col}{last_table_row})",
                'label_cell': f'A{first_table_row}',
            }

            current_row += 2

        # ===== GHI THÔNG TIN ĐƠN HÀNG BỔ SUNG =====
        # Ghi ở cuối quá trình dựng bố cục để không bị các bảng PO/vải ghi đè.
        # Các vị trí đã được lập kế hoạch ở trên nên ô trống giữ nguyên đúng dòng.
        max_custom_print_row = 0
        for item in pending_custom_info:
            row = item['row']
            ci = item['ci']
            col = item['col']

            # Lớp bảo vệ cuối: nếu có một ô phát sinh ngoài dự kiến, chỉ dời riêng
            # thông tin này tới ô trống kế tiếp; tuyệt đối không ghi đè dữ liệu.
            while True:
                cell = ws.cell(row, ci)
                merged_hit = any(cell.coordinate in rng for rng in ws.merged_cells.ranges)
                if cell.value is None and not merged_hit:
                    break
                row += 1

            set_cell(f'{col}{row}', item['text'], font=font_bold,
                     alignment=Alignment(vertical='center', wrap_text=False))
            ws.row_dimensions[row].height = max(float(ws.row_dimensions[row].height or 15), 24.0)
            if ci <= note_col_idx:
                max_custom_print_row = max(max_custom_print_row, row)

        # ===== V82: 3 BÀN DỰ PHÒNG - MỞ TỪNG BÀN =====
        # Dùng 3 cấp Outline lồng nhau. Bàn thật luôn level 0 và không bị ẩn.
        # Khi đóng chỉ có 1 dấu + cạnh bàn thật cuối; bấm + hiện đúng 1 bàn dự phòng.
        # Sau khi bàn đó hiện, dấu + kế tiếp cho phép mở bàn tiếp theo.
        ws.sheet_properties.outlinePr.summaryBelow = False
        ws.sheet_view.showOutlineSymbols = True

        for reserve_rows in reserve_row_groups:
            if not reserve_rows:
                continue
            for pos, reserve_row in enumerate(reserve_rows, start=1):
                rd = ws.row_dimensions[reserve_row]
                rd.outlineLevel = min(pos, 3)
                rd.hidden = True
                rd.collapsed = False

            # Bàn thật cuối là summary của cấp 1: luôn hiển thị, không bị Outline ẩn.
            outer_summary = reserve_rows[0] - 1
            if outer_summary >= 1:
                rd = ws.row_dimensions[outer_summary]
                rd.outlineLevel = 0
                rd.hidden = False
                rd.collapsed = True

            # Mỗi bàn dự phòng đã mở trở thành summary để mở bàn kế tiếp.
            for i in range(1, len(reserve_rows)):
                ws.row_dimensions[reserve_rows[i-1]].collapsed = True

        # ===== IN A4 NGANG =====
        # Thu đúng 1 trang theo bề ngang; chiều dọc để tự chạy nhiều trang.
        # Manual page break phía trên đã được tính theo scale thực tế của bề ngang,
        # vì vậy mỗi trang sẽ tận dụng khổ A4 tốt hơn nhưng vẫn giữ nguyên từng khối vải.
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.page_setup.orientation = ws.ORIENTATION_LANDSCAPE
        ws.page_setup.paperSize = ws.PAPERSIZE_A4
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.page_margins.left = PRINT_MARGIN_LEFT_IN
        ws.page_margins.right = PRINT_MARGIN_RIGHT_IN
        ws.page_margins.top = PRINT_MARGIN_TOP_IN
        ws.page_margins.bottom = PRINT_MARGIN_BOTTOM_IN
        ws.page_margins.header = 0.0
        ws.page_margins.footer = 0.0
        ws.print_options.horizontalCentered = True
        print_bottom_row = max(1, current_row - 1, max_custom_print_row)
        ws.print_area = f'A1:{note_col}{print_bottom_row}'  # adjust_col + adjust_lot_col nằm ngoài vùng in
        ws.sheet_view.showGridLines = False

        # Mọi ô MERGE đều có viền ngoài đậm (medium).
        # Làm ở cuối để không bị mất viền sau thao tác merge của openpyxl.
        from copy import copy
        for merged in list(ws.merged_cells.ranges):
            min_col, min_row, max_col, max_row = merged.bounds
            for rr in range(min_row, max_row + 1):
                for cc in range(min_col, max_col + 1):
                    cell = ws.cell(rr, cc)
                    old_border = cell.border
                    cell.border = Border(
                        left=medium if cc == min_col else old_border.left,
                        right=medium if cc == max_col else old_border.right,
                        top=medium if rr == min_row else old_border.top,
                        bottom=medium if rr == max_row else old_border.bottom
                    )

        # Chỉ xuống dòng ở những tiêu đề đã chủ động chèn \n vì cột hẹp.
        # Ô đủ rộng giữ Việt/Anh trên cùng một dòng. Phần thông tin chung luôn NO WRAP.
        for row in ws.iter_rows(min_row=percent_row, max_row=max(percent_row, current_row - 1),
                                min_col=1, max_col=10 + len(self.sizes)):
            for cell in row:
                if cell.value is not None:
                    al = copy(cell.alignment)
                    # Cột GHI CHÚ luôn giữ nguyên cỡ chữ, không shrink; nội dung dài tự xuống dòng.
                    if cell.column == excel_col_to_index(note_col):
                        al.wrap_text = True
                        al.shrink_to_fit = False
                    # V67: ô LOẠI VẢI ở cột A là ô merge dọc. Luôn WRAP để tên dài
                    # tự xuống dòng thay vì bị ép trên một dòng / thu nhỏ chữ.
                    elif cell.column == 1 and cell.coordinate in ws.merged_cells:
                        al.wrap_text = True
                        al.shrink_to_fit = False
                    else:
                        al.wrap_text = ('\n' in str(cell.value))
                        # Chỉ ô MERGE mới thu nhỏ chữ. Ô thường không shrink để chữ có thể tràn sang ô kế bên nếu ô đó trống.
                        al.shrink_to_fit = (cell.coordinate in ws.merged_cells)
                    cell.alignment = al

        # ===== V58: SỬA PHÂN CÂY - 1 LOT NHIỀU LOẠI VẢI, 1 CÂY / 1 LOẠI VẢI =====
        # Mỗi cây có ô LOẠI VẢI riêng và người dùng có thể sửa trực tiếp.
        # Tự động: một cây chỉ thuộc đúng một loại vải.
        # Thủ công: muốn chuyển đầu tấm sang loại vải khác thì nhập lại cùng LOT + SỐ CÂY
        # ở dòng khác với số mét đầu tấm; cây gốc tự trừ phần đã chuyển.
        edit_title_font = Font(name='Calibri', size=18, bold=True)
        edit_header_font = Font(name='Calibri', size=10, bold=True)
        edit_font = Font(name='Calibri', size=10)
        edit_fill_title = PatternFill('solid', fgColor='1F4E78')
        edit_fill_header = PatternFill('solid', fgColor='D9EAF7')
        edit_fill_input = PatternFill('solid', fgColor='FFF2CC')
        edit_fill_calc = PatternFill('solid', fgColor='E2F0D9')
        edit_fill_assign = PatternFill('solid', fgColor='FCE4D6')
        edit_thin = Side(style='thin', color='808080')
        edit_border = Border(left=edit_thin, right=edit_thin, top=edit_thin, bottom=edit_thin)

        edit_ws.sheet_view.showGridLines = False
        visible_edit_headers = ['LOẠI VẢI','LOT GHI TRÊN CÂY','LOT','SỐ CÂY','SỐ MÉT','TRẠNG THÁI','GHI CHÚ']
        edit_range_info_by_fabric = {}
        edit_table_info_by_fabric = edit_range_info_by_fabric

        # Lập danh sách LOT nguồn. Luôn giữ đủ LOT trong kho, kể cả LOT chưa gán.
        lot_blocks = []
        if getattr(self, 'global_lot_rows', None):
            for gi, grow in enumerate(self.global_lot_rows):
                lotn = str(grow.get('lot','') or '').strip()
                if not lotn:
                    continue
                lotmark = str(grow.get('lot_mark','') or '').strip()
                assigned = str(grow.get('assigned_fabric_name','') or '').strip() or 'CHƯA GÁN'
                details = list(self._ensure_lot_roll_details(grow) or [])
                roll_fabric_map = {}
                for _fname, _rolls in (grow.get('assigned_rolls_by_fabric', {}) or {}).items():
                    for _rn in (_rolls or []):
                        _raw_key = str(_rn or '').strip()
                        if '||' in _raw_key:
                            _rno, _rmark = _raw_key.split('||', 1)
                        else:
                            # Dự án cũ: chỉ có số cây, giữ tương thích với mark rỗng.
                            _rno, _rmark = _raw_key, ''
                        _rk = (str(_rno).strip().lower(), str(_rmark).strip().lower())
                        if _rk[0] and _rk not in roll_fabric_map:
                            roll_fabric_map[_rk] = str(_fname or '').strip()
                lot_blocks.append({'lot':lotn, 'lot_mark':lotmark, 'assigned':assigned,
                                   'details':details, 'global_index':gi,
                                   'roll_fabric_map':roll_fabric_map})
        else:
            seen = {}
            for fabric in self.fabric_list:
                fname = str(fabric.get('name','') or '')
                for rr in (fabric.get('rolls',[]) or []):
                    lotn = str(rr.get('lot', rr.get('shade','')) or '').strip()
                    if not lotn:
                        continue
                    if lotn not in seen:
                        seen[lotn] = {'lot':lotn, 'lot_mark':str(rr.get('lot_mark', rr.get('shade','')) or ''),
                                      'assigned':fname or 'CHƯA GÁN', 'details':[], 'global_index':None,
                                      'roll_fabric_map':{}}
                    _roll_name = str(rr.get('roll','') or '')
                    seen[lotn]['details'].append({'roll':_roll_name,
                                                  'lot_mark':str(rr.get('lot_mark', rr.get('shade','')) or ''),
                                                  'meters':float(rr.get('length',0) or 0)})
                    if _roll_name.strip() and fname:
                        _rmark = str(rr.get('lot_mark', rr.get('shade','')) or '').strip()
                        seen[lotn]['roll_fabric_map'][(_roll_name.strip().lower(), _rmark.lower())] = fname
            lot_blocks = list(seen.values())

        # V51: sắp xếp ban đầu phải dùng CÙNG logic BEST-FIT với _ROLL_CALC.
        # V50 dùng allocate_rolls_to_tables() (logic tuần tự cũ) nên có thể dự đoán sai
        # cây nào Excel thực sự chọn; kết quả là trạng thái ĐÃ DÙNG nằm xen giữa CHƯA DÙNG.
        # V53 mô phỏng đúng CAP/FIT/RANK/ALLOC của Excel trước khi ghi sheet:
        #   - ưu tiên LOT theo thứ tự;
        #   - trong LOT ưu tiên cây có sức chứa gần số lá bàn nhất;
        #   - cây đã dùng ở bàn trước chỉ đi tiếp nếu còn trải được >= 3 lá;
        #   - cây đã dùng xếp lên trên, rồi theo MÉT CÒN LẠI tăng dần.
        initial_usage = {}

        def _excel_initial_tables(_res):
            """Tính SỐ LÁ ban đầu đúng như công thức F trên BIỂU CẮT (khi % từng cỡ = 0).

            Python optimize_cutting() có thể cho số lá gốc hơi khác công thức động Excel ở
            một vài bàn cuối. Dùng lại đúng quy tắc dynamic_plies_formula để việc sắp cây
            khớp trạng thái ĐÃ DÙNG sau khi Excel tính công thức.
            """
            _tables = [dict(x) for x in ((_res or {}).get('cutting_tables', []) or [])]
            _targets = dict((_res or {}).get('total_by_size', {}) or {})
            _size_keys = [x.get('key') for x in self.sizes]
            _actual = {k: 0 for k in _size_keys}
            _out = []
            for _ti, _t in enumerate(_tables):
                _ratio_map = dict(_t.get('ratio_map', {}) or {})
                _parts = [(k, int(_ratio_map.get(k, 0) or 0)) for k in _size_keys
                          if int(_ratio_map.get(k, 0) or 0) > 0]
                if not _parts:
                    _plies = 0
                else:
                    _remaining = {k: max(0, int(_targets.get(k, 0) or 0) - int(_actual.get(k, 0) or 0))
                                  for k, _r in _parts}
                    _last = []
                    for k, _r in _parts:
                        _has_future = any(
                            int(((_ft.get('ratio_map', {}) or {}).get(k, 0) or 0)) > 0
                            for _ft in _tables[_ti + 1:]
                        )
                        if not _has_future:
                            _last.append((k, _r))
                    if sum(_remaining.values()) <= 0:
                        _plies = 0
                    elif _last:
                        _plies = max(
                            int(math.ceil(float(_remaining[k]) / float(r))) if r > 0 else 0
                            for k, r in _last
                        )
                    else:
                        _choices = [
                            int(math.ceil(float(_remaining[k]) / float(r)))
                            for k, r in _parts if r > 0 and _remaining[k] > 0
                        ]
                        _plies = min(_choices) if _choices else 0
                _nt = dict(_t)
                _nt['plies'] = max(0, int(_plies))
                _out.append(_nt)
                for k, r in _parts:
                    _actual[k] = int(_actual.get(k, 0) or 0) + int(_plies) * int(r)
            return _out

        def _estimate_bestfit_roll_states(_fabric, _tables):
            _reserve_m, _reserve_plies = self._fabric_roll_reserve_settings(_fabric)
            _states = []
            for _i, _r in enumerate((_fabric or {}).get('rolls', []) or []):
                try:
                    _length = max(0.0, float(_r.get('length', 0) or 0))
                except Exception:
                    _length = 0.0
                if _length <= 0:
                    continue
                _states.append({
                    'source_index': _i,
                    'lot': str(_r.get('lot','') or '').strip(),
                    'roll': str(_r.get('roll','') or '').strip() or str(_i + 1),
                    'lot_mark': str(_r.get('lot_mark', _r.get('shade','')) or '').strip(),
                    'length': _length,
                    'remaining': _length,
                    'used': 0.0,
                    'had_alloc': False,
                })

            # Thứ tự LOT đúng theo thứ tự nguồn đang có trong fabric['rolls'].
            _lot_order = {}
            for _st in _states:
                _ln = _st['lot']
                if _ln not in _lot_order:
                    _lot_order[_ln] = len(_lot_order) + 1

            _eps = 1e-9
            for _t in (_tables or []):
                try:
                    _target = max(0, int(_t.get('plies', 0) or 0))
                    _mpp = max(0.0, float(_t.get('length', 0) or 0)) * 1.01
                except Exception:
                    continue
                if _target <= 0 or _mpp <= 0:
                    continue

                _cands = []
                for _st in _states:
                    _raw_cap = max(0, int((_st['remaining'] + _eps) // _mpp))
                    # V163: ngưỡng mét đầu tấm + số lá chừa lấy từ từng loại vải.
                    if _raw_cap > 0:
                        _rem_after_raw = max(0.0, _st['remaining'] - _raw_cap * _mpp)
                        _reserve_cap = (max(0, _raw_cap - _reserve_plies)
                                        if _rem_after_raw < _reserve_m - _eps else _raw_cap)
                    else:
                        _reserve_cap = 0
                    # Đồng bộ công thức effective_cap trong _ROLL_CALC.
                    _cap = 0 if (_st['had_alloc'] and _reserve_cap < 3) else _reserve_cap
                    if _cap <= 0:
                        continue
                    if _cap <= _target:
                        _rem_full = max(0.0, _st['remaining'] - _cap * _mpp)
                        _fit = ((_target - _cap) * 100000000
                                + round(_rem_full * 1000) * 1000
                                + (100000 - _cap))
                    else:
                        _rem_finish = max(0.0, _st['remaining'] - _target * _mpp)
                        _fit = (1000000000000
                                + round(_rem_finish * 1000) * 1000
                                + (_cap - _target))
                    # V91: trong cùng LOT, cây đã mở ở bàn trước luôn đứng trước cây mới
                    # nếu cây đang dở vẫn còn sức chứa >= 3 lá (đã được effective_cap lọc).
                    # Chỉ sau khi không còn cây đang dở phù hợp mới mở cây chưa dùng.
                    if not _st['had_alloc']:
                        _fit += 100000000000000
                    _cands.append((_lot_order.get(_st['lot'], 10**9), _fit, _st['source_index'], _cap, _st))

                # Chính là RANK của Excel: LOT trước -> FIT tốt hơn -> thứ tự nguồn phá hòa.
                _cands.sort(key=lambda x: (x[0], x[1], x[2]))
                _prior_capacity = 0
                for _lotord, _fit, _src, _cap, _st in _cands:
                    _need = max(0, _target - _prior_capacity)
                    if _need <= 0:
                        break
                    _alloc = min(_cap, _need)
                    if _alloc <= 0:
                        continue
                    _meters = _alloc * _mpp
                    _st['remaining'] = max(0.0, _st['remaining'] - _meters)
                    _st['used'] += _meters
                    _st['had_alloc'] = True
                    # SUMIFS(prior capacity) của Excel dùng CAP của các cây xếp trước,
                    # không dùng số lá thực tế của cây chốt.
                    _prior_capacity += _cap

            return _states

        try:
            for _res in results:
                _fabric = _res.get('fabric')
                _tables = _excel_initial_tables(_res)
                for _st in _estimate_bestfit_roll_states(_fabric, _tables):
                    _key = (
                        str(_st.get('lot','') or '').strip(),
                        str(_st.get('lot_mark','') or '').strip(),
                        str(_st.get('roll','') or '').strip(),
                    )
                    _used = max(0.0, float(_st.get('used',0) or 0))
                    _rem = max(0.0, float(_st.get('remaining',0) or 0))
                    _old = initial_usage.get(_key)
                    if _old is None:
                        initial_usage[_key] = {'used': _used, 'remaining': _rem}
                    else:
                        _old['used'] += _used
                        _old['remaining'] = min(_old['remaining'], _rem)

            for _block in lot_blocks:
                _lotn = str(_block.get('lot','') or '').strip()
                _details = list(_block.get('details',[]) or [])
                _indexed = list(enumerate(_details))

                def _sort_tree(_item):
                    _idx, _d = _item
                    _roll = str(_d.get('roll','') or '').strip()
                    _mark = str(_d.get('lot_mark', _block.get('lot_mark','')) or '').strip()
                    _u = initial_usage.get((_lotn, _mark, _roll), {})
                    _used = float(_u.get('used',0) or 0)
                    _rem = float(_u.get('remaining', _d.get('meters',0) or 0) or 0)
                    # ĐÃ DÙNG trước -> còn ít mét nhất -> giữ thứ tự gốc khi bằng nhau.
                    return (0 if _used > 1e-9 else 1, _rem if _used > 1e-9 else 1e18, _idx)

                _block['details'] = [d for _, d in sorted(_indexed, key=_sort_tree)]
        except Exception as _sort_err:
            # Không chặn xuất Excel nếu bước sắp xếp dự đoán gặp dữ liệu lạ.
            pass

        # 7 cột dữ liệu + 1 cột cách.
        LOT_BLOCK_SPAN = 8
        lot_data_first_row = 7
        lot_data_last_row = lot_data_first_row + MAX_TREE_ROWS_PER_LOT - 1
        edit_last_visible_col = max(7, len(lot_blocks) * LOT_BLOCK_SPAN - 1 if lot_blocks else 7)

        if lot_blocks:
            try:
                edit_ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=edit_last_visible_col)
                edit_ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=edit_last_visible_col)
            except Exception:
                pass
        edit_ws['A1'] = 'SỬA PHÂN CÂY - GÁN LOẠI VẢI THEO TỪNG CÂY'
        edit_ws['A1'].font = Font(name='Calibri', size=20, bold=True, color='FFFFFF')
        edit_ws['A1'].fill = edit_fill_title
        edit_ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
        edit_ws.row_dimensions[1].height = 32
        edit_ws['A2'] = (
            'Mỗi LOT là một cụm độc lập. 1 LOT có thể dùng cho nhiều loại vải nhưng mỗi CÂY chỉ chọn 1 LOẠI VẢI. '
            'Số dòng trống có công thức ở cuối mỗi LOT được chọn trên phần mềm trước khi xuất (gợi ý 3). '
            'Các dòng này để trống như dòng nhập bình thường, không còn nhãn THÊM DÒNG DƯ; khi cần chỉ việc nhập LOẠI VẢI + LOT GHI TRÊN CÂY + LOT + SỐ CÂY + SỐ MÉT.'
        )
        edit_ws['A2'].alignment = Alignment(wrap_text=True, vertical='center')
        edit_ws['A2'].font = edit_font
        edit_ws.row_dimensions[2].height = 42

        # Cụm LOT nhìn thấy.
        for li, block in enumerate(lot_blocks):
            bs = 1 + li * LOT_BLOCK_SPAN
            be = bs + 6
            block['start_col'] = bs
            block['end_col'] = be
            block['assign_cell'] = f'{col_letter(bs+1)}5'
            block['summary_start_col'] = bs + 2
            block['first_row'] = lot_data_first_row
            block['last_row'] = lot_data_last_row
            block['effective_meter_col'] = bs + 7

            try:
                edit_ws.merge_cells(start_row=4, start_column=bs, end_row=4, end_column=be)
            except Exception:
                pass
            tc = edit_ws.cell(4, bs, f"LOT: {block['lot']}")
            tc.font = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
            tc.fill = edit_fill_title
            tc.alignment = Alignment(horizontal='center', vertical='center')

            edit_ws.cell(5, bs, 'GỢI Ý BAN ĐẦU').font = edit_header_font
            edit_ws.cell(5, bs).fill = edit_fill_header
            edit_ws.cell(5, bs).border = edit_border
            edit_ws.cell(5, bs+1, block.get('assigned','CHƯA GÁN'))
            edit_ws.cell(5, bs+1).font = edit_header_font
            edit_ws.cell(5, bs+1).fill = edit_fill_assign
            edit_ws.cell(5, bs+1).border = edit_border
            try:
                edit_ws.merge_cells(start_row=5, start_column=bs+2, end_row=5, end_column=be)
            except Exception:
                pass
            edit_ws.cell(5, bs+2, 'PHÂN BỔ: chưa sử dụng')
            edit_ws.cell(5, bs+2).font = edit_font
            edit_ws.cell(5, bs+2).fill = edit_fill_calc
            edit_ws.cell(5, bs+2).border = edit_border
            edit_ws.cell(5, bs+2).alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)

            for off, hv in enumerate(visible_edit_headers):
                c = edit_ws.cell(6, bs + off, hv)
                c.font = edit_header_font
                c.fill = edit_fill_header
                c.border = edit_border
                c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

            details = block.get('details',[]) or []
            default_mark = str(block.get('lot_mark','') or '')
            lotn = str(block.get('lot','') or '')
            assign_abs = f'${col_letter(bs+1)}$5'

            # V85: chừa đúng số DÒNG DƯ người dùng đã chọn trên phần mềm trước khi xuất.
            # Chọn 0 = không sinh dòng dư/công thức thừa; chọn N = thêm N dòng dư cho mỗi LOT.
            extra_row_count = min(int(requested_extra_rows), max(0, MAX_TREE_ROWS_PER_LOT - len(details)))
            extra_rows = [lot_data_first_row + len(details) + i for i in range(extra_row_count)]
            block['extra_rows'] = extra_rows

            for j, rr in enumerate(range(lot_data_first_row, lot_data_last_row+1)):
                is_extra_row = rr in extra_rows
                d = details[j] if j < len(details) else {}
                mark = str(d.get('lot_mark', default_mark) or default_mark)
                roll = str(d.get('roll','') or '')
                try: meters = max(0.0, float(d.get('meters',0) or 0))
                except Exception: meters = 0.0
                # Cột: LOẠI VẢI | MARK | LOT | CÂY | MÉT | TRẠNG THÁI | GHI CHÚ
                # V58: mặc định LOẠI VẢI theo TỪNG CÂY, không lấy tên chung của cả LOT.
                _rfmap = block.get('roll_fabric_map', {}) or {}
                _rk = (str(roll or '').strip().lower(), str(mark or '').strip().lower())
                row_fabric = str(_rfmap.get(_rk, '') or '').strip()
                # Tương thích file/dự án cũ từng lưu map chỉ theo số cây.
                if not row_fabric:
                    row_fabric = str(_rfmap.get(str(roll or '').strip().lower(), '') or '').strip()
                if not row_fabric:
                    _assigned = str(block.get('assigned','') or '').strip()
                    if _assigned and _assigned.upper() != 'CHƯA GÁN' and ' + ' not in _assigned:
                        row_fabric = _assigned

                # V86: dòng dư là dòng nhập bình thường, không còn hàng vàng / chữ "THÊM DÒNG DƯ".
                # Vẫn chừa đúng số dòng người dùng chọn trên phần mềm để helper có công thức sẵn.
                if is_extra_row and j >= len(details):
                    vals = ['', default_mark, lotn, '', '', '', '']
                else:
                    vals = [row_fabric if (roll or meters > 0) else '', mark, lotn if (roll or meters > 0) else '', roll, meters if (roll or meters > 0) else '', '', '']
                for off,val in enumerate(vals):
                    c=edit_ws.cell(rr,bs+off,val)
                    c.border=edit_border
                    c.font=edit_font
                    c.alignment=Alignment(horizontal='center',vertical='center',wrap_text=(off==6))
                    c.fill=edit_fill_input if off in (0,1,2,3,4) else edit_fill_calc
                edit_ws.cell(rr,bs+4).number_format='0.00'

                # V58: cùng LOT+CÂY nhập lại ở dòng dưới với LOẠI VẢI khác
                # được xem là chuyển đầu tấm, không phải thêm tồn kho mới.
                _fab_col = col_letter(bs)
                _mark_col_v = col_letter(bs+1)
                _lot_col_v = col_letter(bs+2)
                _roll_col_v = col_letter(bs+3)
                _meter_col_v = col_letter(bs+4)
                _mark_ref = f'{_mark_col_v}{rr}'
                _lot_ref = f'{_lot_col_v}{rr}'
                _roll_ref = f'{_roll_col_v}{rr}'
                _fab_ref = f'{_fab_col}{rr}'
                _meter_ref = f'{_meter_col_v}{rr}'
                _seen_count = (
                    f'COUNTIFS(${_lot_col_v}${lot_data_first_row}:{_lot_col_v}{rr},{_lot_ref},'
                    f'${_mark_col_v}${lot_data_first_row}:{_mark_col_v}{rr},{_mark_ref},'
                    f'${_roll_col_v}${lot_data_first_row}:{_roll_col_v}{rr},{_roll_ref})'
                )
                if rr < lot_data_last_row:
                    _later_m = f'${_meter_col_v}${rr+1}:${_meter_col_v}${lot_data_last_row}'
                    _later_l = f'${_lot_col_v}${rr+1}:${_lot_col_v}${lot_data_last_row}'
                    _later_k = f'${_mark_col_v}${rr+1}:${_mark_col_v}${lot_data_last_row}'
                    _later_r = f'${_roll_col_v}${rr+1}:${_roll_col_v}${lot_data_last_row}'
                    _later_f = f'${_fab_col}${rr+1}:${_fab_col}${lot_data_last_row}'
                    _later_nonblank = f'SUMIFS({_later_m},{_later_l},{_lot_ref},{_later_k},{_mark_ref},{_later_r},{_roll_ref},{_later_f},"<>")'
                    _later_same = f'SUMIFS({_later_m},{_later_l},{_lot_ref},{_later_k},{_mark_ref},{_later_r},{_roll_ref},{_later_f},{_fab_ref})'
                    _transfer_out = f'MAX(0,({_later_nonblank})-({_later_same}))'
                else:
                    _transfer_out = '0'
                _eff_formula = (
                    f'=IF(OR({_lot_ref}="",{_roll_ref}="",N({_meter_ref})<=0),0,'
                    f'IF(({_seen_count})=1,MAX(0,N({_meter_ref})-({_transfer_out})),N({_meter_ref})))'
                )
                edit_ws.cell(rr,int(block['effective_meter_col']),_eff_formula)
                edit_ws.cell(rr,int(block['effective_meter_col'])).number_format=';;;'

            widths=[22,18,12,12,12,14,34]
            for off,w in enumerate(widths):
                edit_ws.column_dimensions[col_letter(bs+off)].width=w
            edit_ws.column_dimensions[col_letter(be+1)].width=2.0

        # Vùng nguồn ẩn theo từng loại vải. Một LOT có thể xuất hiện ở nhiều loại vải,
        # nhưng tổng mét được chia tuần tự theo nhu cầu còn thiếu nên không bị nhân đôi.
        source_base_col = edit_last_visible_col + 5
        export_edit_fabrics = [f for f in self.fabric_list if bool(f.get('export_edit', True))]
        source_first_row = lot_data_first_row
        source_last_row = source_first_row + MAX_TREE_ROWS_PER_FABRIC - 1
        source_total_slots = max(1, len(lot_blocks))
        prior_fabric_source_infos = []

        for fidx, fabric in enumerate(export_edit_fabrics):
            fname = str(fabric.get('name','') or '')
            safe_fname = fname.replace('"','""')
            normalized_fname = fname.upper().replace(' ','').replace('"','""')
            bs = source_base_col + fidx * 12
            mark_col = col_letter(bs)
            lot_col = col_letter(bs+1)
            roll_col = col_letter(bs+2)
            meter_col = col_letter(bs+3)
            status_col = col_letter(bs+4)
            note_col_src = col_letter(bs+5)
            hrow = col_letter(bs+6)
            hvalid = col_letter(bs+7)
            hfirst = col_letter(bs+8)
            hlotorder = col_letter(bs+9)
            htreeorder = col_letter(bs+10)
            hallow = col_letter(bs+11)

            for hc in range(bs, bs+12):
                edit_ws.column_dimensions[col_letter(hc)].hidden = True

            finfo = fabric_excel_info.get(id(fabric), {}) or {}
            required_expr = str(finfo.get('need_total_ref','0') or '0')

            for li in range(source_total_slots):
                block = lot_blocks[li] if li < len(lot_blocks) else None
                block_sr1 = source_first_row + li * MAX_TREE_ROWS_PER_LOT
                block_sr2 = min(source_last_row, block_sr1 + MAX_TREE_ROWS_PER_LOT - 1)
                if block_sr1 > source_last_row:
                    break
                if block is not None:
                    vbs = int(block['start_col'])
                    # V34: lấy LOẠI VẢI trực tiếp từ từng dòng cây nhìn thấy.
                    vis_assign_col = col_letter(vbs)
                    vis_mark_col = col_letter(vbs+1)
                    vis_lot_col = col_letter(vbs+2)
                    vis_roll_col = col_letter(vbs+3)
                    vis_meter_col = col_letter(vbs+4)
                else:
                    vis_assign_col = vis_mark_col = vis_lot_col = vis_roll_col = vis_meter_col = None

                for j in range(MAX_TREE_ROWS_PER_LOT):
                    sr = block_sr1 + j
                    if sr > block_sr2:
                        break
                    if block is not None:
                        vr = lot_data_first_row + j
                        # V58: mỗi DÒNG CÂY chỉ khớp đúng 1 LOẠI VẢI.
                        row_assign_ref = f'{vis_assign_col}{vr}'
                        safe_fname_upper = fname.upper().replace('"','""')
                        cond = f'UPPER(TRIM({row_assign_ref}))="{safe_fname_upper}"'
                        _eff_ref = f'{col_letter(vbs+7)}{vr}'
                        meter_formula = f'=IFERROR(IF({cond},MAX(0,N({_eff_ref})),0),0)'
                        edit_ws.cell(sr,bs+3,meter_formula)
                        edit_ws.cell(sr,bs,   f'=IF(N({meter_col}{sr})>0,{vis_mark_col}{vr},"")')
                        edit_ws.cell(sr,bs+1, f'=IF(N({meter_col}{sr})>0,{vis_lot_col}{vr},"")')
                        edit_ws.cell(sr,bs+2, f'=IF(N({meter_col}{sr})>0,{vis_roll_col}{vr},"")')
                    else:
                        edit_ws.cell(sr,bs,'')
                        edit_ws.cell(sr,bs+1,'')
                        edit_ws.cell(sr,bs+2,'')
                        edit_ws.cell(sr,bs+3,0)
                    edit_ws.cell(sr,bs+3).number_format='0.00'
                    edit_ws.cell(sr,bs+6, sr-source_first_row+1)
                    edit_ws.cell(sr,bs+7, f'=IF(AND({lot_col}{sr}<>"",{roll_col}{sr}<>"",N({meter_col}{sr})>0),1,0)')
                    edit_ws.cell(sr,bs+8, f'=IF({lot_col}{sr}="",0,IF(COUNTIF(${lot_col}${source_first_row}:{lot_col}{sr},{lot_col}{sr})=1,1,0))')
                    edit_ws.cell(sr,bs+9, f'=IF({hfirst}{sr}=1,COUNTIF(${hfirst}${source_first_row}:{hfirst}{sr},1),0)')
                    edit_ws.cell(sr,bs+10,f'=IF({hvalid}{sr}=1,COUNTIF(${hvalid}${source_first_row}:{hvalid}{sr},1),0)')
                    edit_ws.cell(sr,bs+11,f'=IF({hvalid}{sr}=1,1,0)')

            info={
                'start_col':bs, 'first_row':source_first_row, 'last_row':source_last_row,
                'mark_col':mark_col, 'lot_col':lot_col, 'roll_col':roll_col, 'meter_col':meter_col,
                'status_col':status_col, 'note_col':note_col_src,
                'row_idx_col':hrow, 'valid_col':hvalid, 'lot_first_col':hfirst,
                'lot_order_col':hlotorder, 'tree_order_col':htreeorder, 'allow_col':hallow,
            }
            edit_range_info_by_fabric[id(fabric)] = info
            prior_fabric_source_infos.append(info)

        # Trạng thái/GHI CHÚ nhìn thấy sẽ được nối lại sau khi _ROLL_CALC tính xong.
        for li, block in enumerate(lot_blocks):
            vbs=int(block['start_col'])
            for vr in range(lot_data_first_row, lot_data_last_row+1):
                lot_ref=f'{col_letter(vbs+2)}{vr}'
                roll_ref=f'{col_letter(vbs+3)}{vr}'
                meter_ref=f'{col_letter(vbs+4)}{vr}'
                edit_ws.cell(vr,vbs+5, f'=IF(OR({lot_ref}="",{roll_ref}="",N({meter_ref})<=0),"","CHƯA DÙNG")')
                edit_ws.cell(vr,vbs+6, f'=IF(OR({lot_ref}="",{roll_ref}="",N({meter_ref})<=0),"","Chưa dùng")')

        visible_last_row = lot_data_last_row
        for rr in range(visible_last_row+1, source_last_row+1):
            edit_ws.row_dimensions[rr].hidden = True

        # Helper LOT + helper cây ẩn cho từng loại vải, đọc vùng nguồn ẩn ở trên.
        for fabric in export_edit_fabrics:
            sec = supp_lot_input_rows.get(id(fabric), {}) or {}
            info = edit_range_info_by_fabric.get(id(fabric))
            if not info:
                continue
            fr, lr = info['first_row'], info['last_row']
            lot_rng = f"${info['lot_col']}${fr}:${info['lot_col']}${lr}"
            mark_rng = f"${info['mark_col']}${fr}:${info['mark_col']}${lr}"
            roll_rng = f"${info['roll_col']}${fr}:${info['roll_col']}${lr}"
            meter_rng = f"${info['meter_col']}${fr}:${info['meter_col']}${lr}"
            row_idx_rng = f"${info['row_idx_col']}${fr}:${info['row_idx_col']}${lr}"
            lot_order_rng = f"${info['lot_order_col']}${fr}:${info['lot_order_col']}${lr}"
            tree_order_rng = f"${info['tree_order_col']}${fr}:${info['tree_order_col']}${lr}"
            lot_rows = list(sec.get('input_rows',[]) or [])
            for n, agg_row in enumerate(lot_rows, start=1):
                src_idx = f'SUMIFS({row_idx_rng},{lot_order_rng},{n})'
                edit_ws.cell(agg_row,2, f'=IF(({src_idx})=0,"",INDEX({lot_rng},{src_idx}))')
                edit_ws.cell(agg_row,3, f'=IF(B{agg_row}="","",IFERROR(LOOKUP(2,1/(({lot_rng}=B{agg_row})*({mark_rng}<>"")),{mark_rng}),""))')
                edit_ws.cell(agg_row,4, f'=IF(B{agg_row}="",0,COUNTIFS({lot_rng},B{agg_row},{roll_rng},"<>",{meter_rng},">0"))')
                edit_ws.cell(agg_row,5, f'=IF(B{agg_row}="",0,SUMIFS({meter_rng},{lot_rng},B{agg_row}))')
                edit_ws.row_dimensions[agg_row].hidden = True

            ms = int(sec.get('mirror_start',0) or 0)
            me = int(sec.get('mirror_end',0) or 0)
            detail_infos=[]
            if ms > 0 and me >= ms:
                for idx, rr in enumerate(range(ms, me + 1), start=1):
                    src_idx=f'SUMIFS({row_idx_rng},{tree_order_rng},{idx})'
                    edit_ws.cell(rr,1,idx)
                    edit_ws.cell(rr,2,f'=IF(({src_idx})=0,"",INDEX({lot_rng},{src_idx}))')
                    edit_ws.cell(rr,3,f'=IF(({src_idx})=0,"",INDEX({mark_rng},{src_idx}))')
                    edit_ws.cell(rr,4,f'=IF(({src_idx})=0,"",INDEX({roll_rng},{src_idx}))')
                    edit_ws.cell(rr,5,f'=IF(({src_idx})=0,0,N(INDEX({meter_rng},{src_idx})))')
                    edit_ws.row_dimensions[rr].hidden=True
                    detail_infos.append({'row':rr})
            sec['detail_rows_info']=detail_infos

        edit_ws.freeze_panes='A7'
        edit_ws.sheet_properties.pageSetUpPr.fitToPage=True
        edit_ws.page_setup.orientation=edit_ws.ORIENTATION_LANDSCAPE
        edit_ws.page_setup.paperSize=edit_ws.PAPERSIZE_A4
        edit_ws.page_setup.fitToWidth=1
        edit_ws.page_setup.fitToHeight=0
        edit_ws.print_area=f'A1:{col_letter(edit_last_visible_col)}{visible_last_row}'

        # ===== V84: SHEET SỐ MÉT LOT CÒN LẠI sẽ tạo sau khi _ROLL_CALC hoàn tất =====

        # ===== V62: HELPER PHÂN CÂY ĐỌC TRỰC TIẾP VÙNG SỬA PHÂN CÂY =====
        # Không đi qua các dòng mirror/helper trên SỬA PHÂN CÂY nữa. Mỗi dòng helper
        # tương ứng trực tiếp với dòng thứ n của tblSuaPhanCay, vì vậy SỐ CÂY mới
        # thêm vào Table có thể được PHÂN CÂY dùng ngay.
        roll_calc_ws = wb.create_sheet("_ROLL_CALC")
        roll_calc_ws.sheet_state = 'hidden'
        roll_calc_ref = roll_calc_ws.title.replace("'", "''")
        roll_calc_info = {}
        rc_cursor = 1

        for res in results:
            fabric = res.get('fabric')
            helper = supp_lot_helper_info.get(id(fabric), {})
            main_rows_rc = list(helper.get('main_rows', []) or [])
            tables = res.get('cutting_tables', []) or []
            if not main_rows_rc:
                continue

            fname = str(fabric.get('name','') or '')
            safe_fname = fname.replace('"','""')
            reserve_m, reserve_plies = self._fabric_roll_reserve_settings(fabric)
            reserve_m_excel = (f"{reserve_m:.10f}".rstrip('0').rstrip('.') or '0')
            info_rc = edit_range_info_by_fabric.get(id(fabric))
            title_r = rc_cursor
            data_r1 = title_r + 2
            data_r2 = data_r1 + MAX_TREE_ROWS_PER_FABRIC - 1

            # A:G = nguồn trực tiếp từ vùng SỬA PHÂN CÂY.
            roll_calc_ws.cell(title_r,1,'STT TABLE')
            roll_calc_ws.cell(title_r,2,'LOẠI VẢI')
            roll_calc_ws.cell(title_r,3,'LOT')
            roll_calc_ws.cell(title_r,4,'LOT GHI TRÊN CÂY')
            roll_calc_ws.cell(title_r,5,'SỐ CÂY')
            roll_calc_ws.cell(title_r,6,'SỐ MÉT')
            roll_calc_ws.cell(title_r,7,'CHO PHÉP DÙNG')

            # V91: ƯU TIÊN CÂY ĐANG DỞ + BEST-FIT CÂY MỚI TRONG TỪNG LOT, tự cập nhật theo CHIỀU DÀI SƠ ĐỒ.
            # -------------------------------------------------------------------------
            # Với mỗi bàn, Excel tự tính số lá tối đa từng cây còn có thể trải.
            # Sau đó xếp ưu tiên trong LOT:
            #   1) cây có sức chứa <= số lá bàn: chọn cây có sức chứa gần số lá bàn nhất
            #      để dùng hết tối đa số vải của cây đó;
            #   2) nếu cây lớn hơn số lá bàn: chọn cây để lại ít mét dư nhất;
            #   3) chỉ khi LOT hiện tại hết khả năng mới chuyển sang LOT kế tiếp.
            # Cây đã dùng ở bàn trước chỉ tiếp tục nếu phần vải còn lại có thể trải >= 3 lá.
            # Do CAP / FIT / RANK đều là công thức nên đổi CHIỀU DÀI SƠ ĐỒ sẽ tự đổi
            # cây được chọn, số cây và số lá từng cây mà không cần xuất lại Excel.
            table_count = len(main_rows_rc)

            # H... = sức chứa động (số lá tối đa) cho từng bàn.
            first_cap_col = 8
            cap_cols=[]
            for ti in range(table_count):
                ci=first_cap_col+ti
                cap_cols.append(col_letter(ci))
                roll_calc_ws.cell(title_r,ci,f'B{ti+1} SỨC CHỨA')

            # Sau CAP là điểm phù hợp (FIT) dùng để lọc cây trong cùng LOT.
            first_fit_col = first_cap_col + table_count
            fit_cols=[]
            for ti in range(table_count):
                ci=first_fit_col+ti
                fit_cols.append(col_letter(ci))
                roll_calc_ws.cell(title_r,ci,f'B{ti+1} FIT')

            # Sau FIT là số lá thực tế cấp cho cây.
            first_alloc_col = first_fit_col + table_count
            alloc_cols=[]
            for ti in range(table_count):
                ci=first_alloc_col+ti
                alloc_cols.append(col_letter(ci))
                roll_calc_ws.cell(title_r,ci,f'B{ti+1} LÁ')

            # RANK = thứ tự cây sau khi lọc best-fit. Các cây thực sự được dùng luôn
            # có rank liên tục 1..N nên PHÂN CÂY có thể lấy bằng MATCH như cũ.
            first_rank_col = first_alloc_col + table_count
            rank_cols=[]
            for ti in range(table_count):
                ci=first_rank_col+ti
                rank_cols.append(col_letter(ci))
                roll_calc_ws.cell(title_r,ci,f'B{ti+1} THỨ TỰ')

            # V50: đầu tấm chỉ được tính vào TỔNG của bàn nếu cây KHÔNG được dùng tiếp ở bàn sau.
            first_rem_col = first_rank_col + table_count
            remnant_cols=[]
            for ti in range(table_count):
                ci=first_rem_col+ti
                remnant_cols.append(col_letter(ci))
                roll_calc_ws.cell(title_r,ci,f'B{ti+1} ĐẦU TẤM TÍNH TỔNG')

            used_m_col_idx = first_rem_col + table_count
            used_m_col = col_letter(used_m_col_idx)
            roll_calc_ws.cell(title_r,used_m_col_idx,'MÉT ĐÃ DÙNG')
            first_flag_col_idx = used_m_col_idx + 1
            first_flag_col = col_letter(first_flag_col_idx)
            lot_order_col_idx = first_flag_col_idx + 1
            lot_order_col = col_letter(lot_order_col_idx)
            roll_calc_ws.cell(title_r,first_flag_col_idx,'LOT ĐẦU TIÊN')
            roll_calc_ws.cell(title_r,lot_order_col_idx,'THỨ TỰ LOT')
            # V88: bảng tổng hợp PHÂN CÂY chỉ lấy những cây THỰC SỰ ĐÃ ĐƯỢC DÙNG trong các bàn.
            # Tách riêng MÉT CÒN LẠI + THỨ TỰ CÒN LẠI để tránh công thức mảng AGGREGATE
            # phức tạp, giúp Excel tính ổn định và bảng tổng hợp luôn hiện số mét dư.
            remaining_m_col_idx = lot_order_col_idx + 1
            remaining_m_col = col_letter(remaining_m_col_idx)
            remaining_rank_col_idx = remaining_m_col_idx + 1
            remaining_rank_col = col_letter(remaining_rank_col_idx)
            roll_calc_ws.cell(title_r, remaining_m_col_idx, 'MÉT CÒN LẠI')
            roll_calc_ws.cell(title_r, remaining_rank_col_idx, 'THỨ TỰ CÂY CÒN LẠI')

            for j in range(MAX_TREE_ROWS_PER_FABRIC):
                rr = data_r1 + j
                src_n = j + 1
                roll_calc_ws.cell(rr,1,src_n)
                if info_rc:
                    _fr, _lr = info_rc['first_row'], info_rc['last_row']
                    _lot_rng = f"'{edit_sheet_ref}'!${info_rc['lot_col']}${_fr}:${info_rc['lot_col']}${_lr}"
                    _mark_rng = f"'{edit_sheet_ref}'!${info_rc['mark_col']}${_fr}:${info_rc['mark_col']}${_lr}"
                    _roll_rng = f"'{edit_sheet_ref}'!${info_rc['roll_col']}${_fr}:${info_rc['roll_col']}${_lr}"
                    _meter_rng = f"'{edit_sheet_ref}'!${info_rc['meter_col']}${_fr}:${info_rc['meter_col']}${_lr}"
                    _allow_rng = f"'{edit_sheet_ref}'!${info_rc['allow_col']}${_fr}:${info_rc['allow_col']}${_lr}"
                    roll_calc_ws.cell(rr,2,f'=IFERROR(IF(INDEX({_lot_rng},$A{rr})<>"","{safe_fname}",""),"")')
                    roll_calc_ws.cell(rr,3,f'=IFERROR(INDEX({_lot_rng},$A{rr}),"")')
                    roll_calc_ws.cell(rr,4,f'=IFERROR(INDEX({_mark_rng},$A{rr}),"")')
                    roll_calc_ws.cell(rr,5,f'=IFERROR(INDEX({_roll_rng},$A{rr}),"")')
                    roll_calc_ws.cell(rr,6,f'=IFERROR(N(INDEX({_meter_rng},$A{rr})),0)')
                    roll_calc_ws.cell(rr,7,f'=IFERROR(N(INDEX({_allow_rng},$A{rr})),0)')
                else:
                    roll_calc_ws.cell(rr,2,'')
                    roll_calc_ws.cell(rr,3,'')
                    roll_calc_ws.cell(rr,4,'')
                    roll_calc_ws.cell(rr,5,'')
                    roll_calc_ws.cell(rr,6,0)
                    roll_calc_ws.cell(rr,7,0)
                roll_calc_ws.cell(rr,6).number_format='0.00'

                # Mét của cùng một cây đã được loại vải đứng trước sử dụng.
                prior_fabric_used_terms=[]
                for _pinfo in roll_calc_info.values():
                    _prr=int(_pinfo.get('data_start',0) or 0)+j
                    if _prr <= int(_pinfo.get('data_end',0) or 0):
                        prior_fabric_used_terms.append(
                            f"N('{roll_calc_ref}'!${_pinfo['used_m_col']}${_prr})"
                        )
                prior_fabric_used = '+'.join(prior_fabric_used_terms) if prior_fabric_used_terms else '0'

                # LOT order theo block 100 cây/LOT của SỬA PHÂN CÂY.
                # Ghi order cho MỌI cây trong LOT để có thể xếp hạng động bằng COUNTIFS/SUMIFS.
                lot_seq = int(j // MAX_TREE_ROWS_PER_LOT) + 1
                roll_calc_ws.cell(
                    rr, lot_order_col_idx,
                    f'=IF(AND(B{rr}="{safe_fname}",C{rr}<>"",E{rr}<>"",F{rr}>0,G{rr}=1),{lot_seq},0)'
                )

                # 1) CAP + FIT cho từng bàn.
                for ti, main_r in enumerate(main_rows_rc):
                    capc=cap_cols[ti]
                    fitc=fit_cols[ti]
                    mpp=f"(N('{main_sheet_ref}'!D{main_r})*1.01)"
                    target=f"N('{main_sheet_ref}'!F{main_r})"
                    prev_meter_terms=[]
                    prev_alloc_terms=[]
                    for pti, prev_main in enumerate(main_rows_rc[:ti]):
                        pac=alloc_cols[pti]
                        prev_meter_terms.append(
                            f"N({pac}{rr})*(N('{main_sheet_ref}'!D{prev_main})*1.01)"
                        )
                        prev_alloc_terms.append(f'N({pac}{rr})')
                    prev_used_m='+'.join(prev_meter_terms) if prev_meter_terms else '0'
                    prev_alloc='+'.join(prev_alloc_terms) if prev_alloc_terms else '0'
                    base_meter=f'MAX(0,N($F{rr})-({prior_fabric_used}))'
                    available_m=f'MAX(0,({base_meter})-({prev_used_m}))'
                    raw_cap=f'IF({mpp}>0,INT(({available_m})/{mpp}),0)'
                    # V163: sức chứa thực tế chừa đầu tấm theo thiết lập từng loại vải.
                    # Mặc định: nếu phần dư < 1.00 m thì bớt 1 lá.
                    raw_rem=f'MAX(0,({available_m})-({raw_cap})*({mpp}))'
                    reserve_cap=(
                        f'IF(AND(({raw_cap})>0,({raw_rem})<{reserve_m_excel}),'                         f'MAX(0,({raw_cap})-{reserve_plies}),({raw_cap}))'
                    )

                    # Cây đã xuất hiện ở bàn trước: nếu phần còn lại chỉ trải được 1-2 lá
                    # thì không cho vào bàn hiện tại; giữ lại để xét bàn ngắn hơn phía sau.
                    effective_cap=f'IF(AND(({prev_alloc})>0,({reserve_cap})<3),0,({reserve_cap}))'
                    roll_calc_ws.cell(
                        rr, first_cap_col+ti,
                        f'=IFERROR(IF(OR($B{rr}<>"{safe_fname}",TRIM($C{rr})="",TRIM($E{rr})="",'
                        f'N($F{rr})<=0,N($G{rr})<>1,{mpp}<=0,{target}<=0),0,MAX(0,{effective_cap})),0)'
                    )
                    roll_calc_ws.cell(rr, first_cap_col+ti).number_format='0'

                    # FIT càng nhỏ càng tốt.
                    # - CAP <= target: ưu tiên CAP gần target, rồi ưu tiên phần mét lẻ sau khi
                    #   trải hết CAP càng nhỏ càng tốt.
                    # - CAP > target: cây này là cây chốt; ưu tiên phần mét còn lại sau khi
                    #   hoàn tất target càng nhỏ càng tốt.
                    remainder_full=f'MAX(0,({available_m})-N({capc}{rr})*({mpp}))'
                    remainder_finish=f'MAX(0,({available_m})-({target})*({mpp}))'
                    # V91: ưu tiên cây ĐÃ MỞ trước cây mới trong cùng LOT.
                    # prev_alloc > 0 nghĩa là cây này đã được dùng ở ít nhất một bàn trước.
                    # Cây mới bị cộng một offset rất lớn vào FIT, nhưng vẫn nhỏ hơn 1E+15
                    # (giá trị vô hiệu), nên RANK sẽ luôn xếp cây đang dở trước cây chưa dùng.
                    opened_priority=f'IF(({prev_alloc})>0,0,100000000000000)'
                    fit_formula=(
                        f'=IF(N({capc}{rr})<=0,1E+15,({opened_priority})+'
                        f'IF(N({capc}{rr})<=({target}),'
                        f'(({target})-N({capc}{rr}))*100000000+ROUND(({remainder_full})*1000,0)*1000+(100000-N({capc}{rr})),'
                        f'1000000000000+ROUND(({remainder_finish})*1000,0)*1000+(N({capc}{rr})-({target}))))'
                    )
                    roll_calc_ws.cell(rr, first_fit_col+ti, fit_formula)
                    roll_calc_ws.cell(rr, first_fit_col+ti).number_format='0'

                # 2) RANK + ALLOC cho từng bàn.
                for ti, main_r in enumerate(main_rows_rc):
                    capc=cap_cols[ti]
                    fitc=fit_cols[ti]
                    ac=alloc_cols[ti]
                    rc=rank_cols[ti]
                    target=f"N('{main_sheet_ref}'!F{main_r})"
                    cap_rng=f'${capc}${data_r1}:${capc}${data_r2}'
                    fit_rng=f'${fitc}${data_r1}:${fitc}${data_r2}'
                    lotord_rng=f'${lot_order_col}${data_r1}:${lot_order_col}${data_r2}'
                    idx_rng=f'$A${data_r1}:$A${data_r2}'
                    rank_rng=f'${rc}${data_r1}:${rc}${data_r2}'
                    lotord_ref=f'${lot_order_col}{rr}'
                    fit_ref=f'${fitc}{rr}'

                    # Số cây hợp lệ ở các LOT trước + số cây có FIT tốt hơn trong cùng LOT
                    # + thứ tự nguồn để phá hòa. Kết quả rank liên tục 1..N.
                    rank_formula=(
                        f'=IF(OR(N({capc}{rr})<=0,N({lotord_ref})<=0),0,'
                        f'COUNTIFS({lotord_rng},">0",{lotord_rng},"<"&{lotord_ref},{cap_rng},">0")+'
                        f'COUNTIFS({lotord_rng},{lotord_ref},{cap_rng},">0",{fit_rng},"<"&{fit_ref})+'
                        f'COUNTIFS({lotord_rng},{lotord_ref},{cap_rng},">0",{fit_rng},{fit_ref},{idx_rng},"<="&$A{rr}))'
                    )
                    roll_calc_ws.cell(rr, first_rank_col+ti, rank_formula)
                    roll_calc_ws.cell(rr, first_rank_col+ti).number_format='0'

                    # Tổng sức chứa của các cây xếp trước. Các cây trước được dùng hết;
                    # cây chốt chỉ lấy phần còn thiếu. Khi đổi marker length, CAP/RANK đổi
                    # nên số cây được dùng cũng tự đổi.
                    prior_capacity=(
                        f'SUMIFS({cap_rng},{rank_rng},">0",{rank_rng},"<"&N({rc}{rr}))'
                    )
                    need=f'MAX(0,({target})-({prior_capacity}))'
                    alloc_formula=(
                        f'=IFERROR(IF(OR(N({rc}{rr})<=0,N({capc}{rr})<=0,({need})<=0),0,'
                        f'MIN(N({capc}{rr}),({need}))),0)'
                    )
                    roll_calc_ws.cell(rr, first_alloc_col+ti, alloc_formula)
                    roll_calc_ws.cell(rr, first_alloc_col+ti).number_format='0'

                # V50: phần đầu tấm được phép hiển thị ở từng bàn, nhưng chỉ cộng vào
                # dòng TỔNG của bàn cuối cùng mà cây đó thực sự xuất hiện. Nếu cây còn
                # được lấy sang bất kỳ bàn phía sau thì đầu tấm tại bàn hiện tại = 0 khi tính tổng.
                base_meter_for_rem=f'MAX(0,N($F{rr})-({prior_fabric_used}))'
                for ti, main_r in enumerate(main_rows_rc):
                    ac=alloc_cols[ti]
                    later_alloc_terms=[f'N({alloc_cols[k]}{rr})' for k in range(ti+1, len(main_rows_rc))]
                    later_alloc='+'.join(later_alloc_terms) if later_alloc_terms else '0'
                    used_through_terms=[]
                    for k, _mr in enumerate(main_rows_rc[:ti+1]):
                        used_through_terms.append(
                            f"N({alloc_cols[k]}{rr})*(N('{main_sheet_ref}'!D{_mr})*1.01)"
                        )
                    used_through='+'.join(used_through_terms) if used_through_terms else '0'
                    rem_formula=(
                        f'=IF(N({ac}{rr})<=0,0,IF(({later_alloc})>0,0,'
                        f'MAX(0,({base_meter_for_rem})-({used_through}))))'
                    )
                    roll_calc_ws.cell(rr, first_rem_col+ti, rem_formula)
                    roll_calc_ws.cell(rr, first_rem_col+ti).number_format='0.00'

                used_terms=[]
                for ti, main_r in enumerate(main_rows_rc):
                    ac=alloc_cols[ti]
                    used_terms.append(f"N({ac}{rr})*(N('{main_sheet_ref}'!D{main_r})*1.01)")
                roll_calc_ws.cell(rr,used_m_col_idx,'=' + ('+'.join(used_terms) if used_terms else '0'))
                roll_calc_ws.cell(rr,used_m_col_idx).number_format='0.00'

                # V88: số mét còn lại thật; bảng tổng hợp chỉ xếp hạng cây có MÉT ĐÃ DÙNG > 0.
                # prior_fabric_used đã được tính ở trên theo cùng vị trí cây.
                roll_calc_ws.cell(
                    rr, remaining_m_col_idx,
                    f'=IFERROR(IF(OR($B{rr}<>"{safe_fname}",TRIM($C{rr})="",TRIM($E{rr})="",N($F{rr})<=0,N($G{rr})<>1),0,'
                    f'MAX(0,N($F{rr})-({prior_fabric_used})-N(${used_m_col}{rr}))),0)'
                )
                roll_calc_ws.cell(rr, remaining_m_col_idx).number_format='0.00'
                # Rank liên tục 1..N cho các cây còn mét, theo đúng thứ tự nguồn.
                _rem_rng = f'${remaining_m_col}${data_r1}:${remaining_m_col}${data_r2}'
                _used_rng = f'${used_m_col}${data_r1}:${used_m_col}${data_r2}'
                _b_rng = f'$B${data_r1}:$B${data_r2}'
                _g_rng = f'$G${data_r1}:$G${data_r2}'
                _e_rng = f'$E${data_r1}:$E${data_r2}'
                _a_rng = f'$A${data_r1}:$A${data_r2}'
                # Chỉ xếp hạng cây đã thực sự cấp mét cho ít nhất một bàn của loại vải này.
                # Cây CHƯA DÙNG dù còn nguyên mét sẽ không xuất hiện ở bảng tổng hợp.
                roll_calc_ws.cell(
                    rr, remaining_rank_col_idx,
                    f'=IF(OR($B{rr}<>"{safe_fname}",N(${used_m_col}{rr})<=0,N(${remaining_m_col}{rr})<=0,N($G{rr})<>1,TRIM($E{rr})=""),0,'
                    f'COUNTIFS({_b_rng},"{safe_fname}",{_g_rng},1,{_e_rng},"<>",{_used_rng},">0",{_rem_rng},">0",{_a_rng},"<="&$A{rr}))'
                )
                roll_calc_ws.cell(rr, remaining_rank_col_idx).number_format='0'

                # SỬA PHÂN CÂY hiển thị ĐÃ DÙNG / CHƯA DÙNG theo phân bổ thật.
                if info_rc:
                    _er = int(info_rc['first_row']) + j
                    _lotc = f"{info_rc['lot_col']}{_er}"
                    _rollc = f"{info_rc['roll_col']}{_er}"
                    _metc = f"{info_rc['meter_col']}{_er}"
                    _usedref = f"'{roll_calc_ref}'!${used_m_col}${rr}"
                    edit_ws[f"{info_rc['status_col']}{_er}"] = (
                        f'=IF(OR({_lotc}="",{_rollc}="",N({_metc})<=0),"",IF(N({_usedref})>0,"ĐÃ DÙNG","CHƯA DÙNG"))'
                    )
                    edit_ws[f"{info_rc['note_col']}{_er}"] = (
                        f'=IF(OR({_lotc}="",{_rollc}="",N({_metc})<=0),"",'
                        f'IF(N({_usedref})>0,"Cây đã dùng | còn "&TEXT(MAX(0,N({_metc})-N({_usedref})),"0.00")&" m","Chưa dùng"))'
                    )

                # Đánh dấu dòng đầu tiên của LOT; summary vẫn lấy LOT theo lot_order.
                if rr == data_r1:
                    prev_count='0'
                else:
                    prev_count=f'COUNTIFS($B${data_r1}:B{rr-1},"{safe_fname}",$C${data_r1}:C{rr-1},C{rr})'
                roll_calc_ws.cell(
                    rr, first_flag_col_idx,
                    f'=IF(AND(B{rr}="{safe_fname}",C{rr}<>"",E{rr}<>"",F{rr}>0,G{rr}=1,({prev_count})=0),1,0)'
                )

            # Tối đa 50 LOT / loại vải; LOT mới thêm trong vùng nhập được nhận tự động.
            summary_r1 = data_r2 + 2
            summary_r2 = summary_r1 + MAX_DYNAMIC_LOTS - 1
            sum_name_col=1; sum_cap_col=2; sum_used_col=3; sum_note_col=4; sum_first_plies_col=5
            roll_calc_ws.cell(summary_r1-1,sum_name_col,'TỔNG HỢP LOT')
            roll_calc_ws.cell(summary_r1-1,sum_cap_col,'TỔNG MÉT')
            roll_calc_ws.cell(summary_r1-1,sum_used_col,'MÉT ĐÃ DÙNG')
            roll_calc_ws.cell(summary_r1-1,sum_note_col,'GHI CHÚ LOT')
            for ti in range(len(main_rows_rc)):
                roll_calc_ws.cell(summary_r1-1,sum_first_plies_col+ti,f'B{ti+1} LÁ / LOT')

            for si in range(MAX_DYNAMIC_LOTS):
                sr=summary_r1+si
                order_no=si+1
                pos_expr=f'MATCH({order_no},${lot_order_col}${data_r1}:${lot_order_col}${data_r2},0)'
                roll_calc_ws.cell(sr,sum_name_col,
                    f'=IFERROR(INDEX($C${data_r1}:$C${data_r2},{pos_expr}),"")')
                roll_calc_ws.cell(sr,sum_cap_col,
                    f'=IF($A{sr}="",0,SUMIFS($F${data_r1}:$F${data_r2},$B${data_r1}:$B${data_r2},"{safe_fname}",$C${data_r1}:$C${data_r2},$A{sr},$G${data_r1}:$G${data_r2},1))')
                roll_calc_ws.cell(sr,sum_used_col,
                    f'=IF($A{sr}="",0,SUMIFS(${used_m_col}${data_r1}:${used_m_col}${data_r2},$B${data_r1}:$B${data_r2},"{safe_fname}",$C${data_r1}:$C${data_r2},$A{sr},$G${data_r1}:$G${data_r2},1))')
                roll_calc_ws.cell(sr,sum_cap_col).number_format='0.00'
                roll_calc_ws.cell(sr,sum_used_col).number_format='0.00'
                if sr==summary_r1:
                    note_prefix='""'
                else:
                    note_prefix=f'IF(COUNTIF($B${summary_r1}:B{sr-1},">0")>0,CHAR(10),"")'
                roll_calc_ws.cell(sr,sum_note_col,
                    f'=IF(AND($A{sr}<>"",$B{sr}>0),{note_prefix}&$A{sr}&": Tổng "&TEXT($B{sr},"0.00")&'
                    f'" m | dùng "&TEXT($C{sr},"0.00")&" m | dư "&TEXT(MAX(0,$B{sr}-$C{sr}),"0.00")&" m","")')
                for ti,ac in enumerate(alloc_cols):
                    pc=col_letter(sum_first_plies_col+ti)
                    roll_calc_ws.cell(sr,sum_first_plies_col+ti,
                        f'=IF($A{sr}="",0,SUMIFS(${ac}${data_r1}:${ac}${data_r2},$B${data_r1}:$B${data_r2},"{safe_fname}",$C${data_r1}:$C${data_r2},$A{sr}))')
                    roll_calc_ws.cell(sr,sum_first_plies_col+ti).number_format='0'

            # BIỂU CẮT: LOT chỉ hiện một lần / LOT; nếu thiếu thì thêm THIẾU.
            for ti,main_r in enumerate(main_rows_rc):
                ac=alloc_cols[ti]
                pc=col_letter(sum_first_plies_col+ti)
                lot_parts=[]
                for sr in range(summary_r1,summary_r2+1):
                    name_ref=f"'{roll_calc_ref}'!$A${sr}"
                    plies_ref=f"'{roll_calc_ref}'!${pc}${sr}"
                    if sr==summary_r1:
                        prefix='""'
                    else:
                        prev_range=f"'{roll_calc_ref}'!${pc}${summary_r1}:${pc}{sr-1}"
                        prefix=f'IF(COUNTIF({prev_range},">0")>0," | ","")'
                    lot_parts.append(f'IF({plies_ref}>0,{prefix}&{name_ref}&": "&{plies_ref}&" lá","")')
                total_alloc_expr=f"SUM('{roll_calc_ref}'!{ac}${data_r1}:{ac}${data_r2})"
                missing=f"MAX(0,N('{main_sheet_ref}'!F{main_r})-({total_alloc_expr}))"
                all_plies_range=f"'{roll_calc_ref}'!${pc}${summary_r1}:${pc}${summary_r2}"
                miss_prefix=f'IF(COUNTIF({all_plies_range},">0")>0," | ","")'
                lot_parts.append(f'IF(({missing})>0,{miss_prefix}&"THIẾU: "&({missing})&" lá","")')
                ws[f'E{main_r}']='=IF(OR(TRIM($C%d)="",$D%d="",$F%d=""),"",%s)' % (
                    main_r,main_r,main_r,'&'.join(lot_parts))
                ws[f'E{main_r}'].alignment=Alignment(horizontal='center',vertical='center',wrap_text=False,shrink_to_fit=False)

            note_refs=[f"'{roll_calc_ref}'!$D${sr}" for sr in range(summary_r1,summary_r2+1)]
            note_formula='='+'&'.join(note_refs) if note_refs else '=""'
            for main_r in main_rows_rc:
                _note_cell=ws[f'{note_col}{main_r}']
                if _note_cell.__class__.__name__=='MergedCell':
                    continue
                _note_cell.value=note_formula
                _note_cell.alignment=Alignment(horizontal='left',vertical='center',wrap_text=True,shrink_to_fit=False)

            roll_calc_info[id(fabric)]={
                'title_row':title_r,'data_start':data_r1,'data_end':data_r2,
                'alloc_cols':alloc_cols,'rank_cols':rank_cols,'remnant_cols':remnant_cols,'used_m_col':used_m_col,
                'remaining_m_col': remaining_m_col, 'remaining_rank_col': remaining_rank_col,
                'main_rows':main_rows_rc,'source_fabric_col':'B','source_lot_col':'C',
                'source_mark_col':'D','source_roll_col':'E','source_meter_col':'F','source_allow_col':'G',
                'summary_start':summary_r1,'summary_end':summary_r2,
                'summary_first_plies_col':col_letter(sum_first_plies_col)
            }
            rc_cursor=summary_r2+3

        # ===== V32: ĐỒNG BỘ TRẠNG THÁI/GHI CHÚ CÂY + THIẾU MÉT THEO LOẠI VẢI =====
        # Sau khi _ROLL_CALC đã tính xong, nối ngược kết quả về từng cụm LOT.
        # Mỗi dòng cây chỉ thuộc 1 loại vải; dòng trùng LOT+CÂY là đầu tấm được chuyển thủ công sang loại vải khác.
        for li, block in enumerate(lot_blocks):
            vbs = int(block['start_col'])
            used_refs_by_fabric = []
            for fabric in export_edit_fabrics:
                rinfo = roll_calc_info.get(id(fabric))
                if not rinfo:
                    continue
                fname = str(fabric.get('name','') or '')
                used_refs_by_fabric.append((fname, rinfo))

            for j, vr in enumerate(range(lot_data_first_row, lot_data_last_row+1)):
                lot_ref=f'{col_letter(vbs+2)}{vr}'
                roll_ref=f'{col_letter(vbs+3)}{vr}'
                meter_ref=f'{col_letter(vbs+4)}{vr}'
                per_fabric_parts=[]
                used_refs=[]
                for fname, rinfo in used_refs_by_fabric:
                    rr = int(rinfo['data_start']) + li * MAX_TREE_ROWS_PER_LOT + j
                    if rr > int(rinfo['data_end']):
                        continue
                    uref=f"'{roll_calc_ref}'!${rinfo['used_m_col']}${rr}"
                    used_refs.append(uref)
                    safe_label=fname.replace('"','""')
                    if per_fabric_parts:
                        prev_sum='+'.join(f'N({x})' for x in used_refs[:-1]) or '0'
                        prefix=f'IF(({prev_sum})>0," | ","")&'
                    else:
                        prefix=''
                    per_fabric_parts.append(
                        f'IF(N({uref})>0,{prefix}"{safe_label}: "&TEXT(N({uref}),"0.00")&" m","")'
                    )
                total_used_expr = '+'.join(f'N({x})' for x in used_refs) if used_refs else '0'
                detail_expr = '&'.join(per_fabric_parts) if per_fabric_parts else '""'

                # V58: GHI CHÚ cây gốc tự trừ phần đầu tấm đã chuyển sang dòng khác.
                _fab_col = col_letter(vbs)
                _mark_col_v = col_letter(vbs+1)
                _lot_col_v = col_letter(vbs+2)
                _roll_col_v = col_letter(vbs+3)
                _meter_col_v = col_letter(vbs+4)
                _fab_ref = f'{_fab_col}{vr}'
                _mark_ref = f'{_mark_col_v}{vr}'
                _seen_count = (
                    f'COUNTIFS(${_lot_col_v}${lot_data_first_row}:{_lot_col_v}{vr},{lot_ref},'
                    f'${_mark_col_v}${lot_data_first_row}:${_mark_col_v}{vr},{_mark_ref},'
                    f'${_roll_col_v}${lot_data_first_row}:${_roll_col_v}{vr},{roll_ref})'
                )
                if vr < lot_data_last_row:
                    _later_m = f'${_meter_col_v}${vr+1}:${_meter_col_v}${lot_data_last_row}'
                    _later_l = f'${_lot_col_v}${vr+1}:${_lot_col_v}${lot_data_last_row}'
                    _later_k = f'${_mark_col_v}${vr+1}:${_mark_col_v}${lot_data_last_row}'
                    _later_r = f'${_roll_col_v}${vr+1}:${_roll_col_v}${lot_data_last_row}'
                    _later_f = f'${_fab_col}${vr+1}:${_fab_col}${lot_data_last_row}'
                    _later_nonblank = f'SUMIFS({_later_m},{_later_l},{lot_ref},{_later_k},{_mark_ref},{_later_r},{roll_ref},{_later_f},"<>")'
                    _later_same = f'SUMIFS({_later_m},{_later_l},{lot_ref},{_later_k},{_mark_ref},{_later_r},{roll_ref},{_later_f},{_fab_ref})'
                    transfer_out_expr = f'IF(({_seen_count})=1,MAX(0,({_later_nonblank})-({_later_same})),0)'
                else:
                    transfer_out_expr = '0'
                _transfer_text = f'IF(({transfer_out_expr})>0," | chuyển "&TEXT(({transfer_out_expr}),"0.00")&" m","")'
                _activity_expr = f'(({total_used_expr})+({transfer_out_expr}))'
                edit_ws.cell(vr,vbs+5,
                    f'=IF(OR({lot_ref}="",{roll_ref}="",N({meter_ref})<=0),"",IF({_activity_expr}>0,"ĐÃ DÙNG","CHƯA DÙNG"))')
                edit_ws.cell(vr,vbs+6,
                    f'=IF(OR({lot_ref}="",{roll_ref}="",N({meter_ref})<=0),"",'
                    f'IF({_activity_expr}>0,'
                    f'IF(({total_used_expr})>0,{detail_expr},"Chưa cắt")&({_transfer_text})&'
                    f'" | còn "&TEXT(MAX(0,N({meter_ref})-({total_used_expr})-({transfer_out_expr})),"0.00")&" m",'
                    f'"Chưa dùng"))')

            # Dòng 5 của cụm: tổng hợp loại vải nào thực tế đã dùng bao nhiêu mét từ LOT này.
            summary_parts=[]
            summary_used_refs=[]
            for fname, rinfo in used_refs_by_fabric:
                rr1 = int(rinfo['data_start']) + li * MAX_TREE_ROWS_PER_LOT
                rr2 = min(int(rinfo['data_end']), rr1 + MAX_TREE_ROWS_PER_LOT - 1)
                if rr1 > int(rinfo['data_end']):
                    continue
                sref=f"SUM('{roll_calc_ref}'!${rinfo['used_m_col']}${rr1}:${rinfo['used_m_col']}${rr2})"
                summary_used_refs.append(sref)
                safe_label=fname.replace('"','""')
                if summary_parts:
                    prev_sum='+'.join(f'({x})' for x in summary_used_refs[:-1]) or '0'
                    prefix=f'IF(({prev_sum})>0," | ","")&'
                else:
                    prefix=''
                summary_parts.append(f'IF(({sref})>0,{prefix}"{safe_label}: "&TEXT(({sref}),"0.00")&" m","")')
            visible_meter_col=col_letter(vbs+4)
            effective_meter_col=col_letter(int(block.get('effective_meter_col', vbs+7)))
            lot_total_expr=f'SUM({effective_meter_col}${lot_data_first_row}:{effective_meter_col}${lot_data_last_row})'
            lot_used_expr='+'.join(f'({x})' for x in summary_used_refs) if summary_used_refs else '0'
            summary_text='&'.join(summary_parts) if summary_parts else '""'
            summary_cell=edit_ws.cell(5,vbs+2)
            summary_cell.value=(
                f'=IF(({lot_used_expr})>0,"PHÂN BỔ: "&({summary_text})&" | DƯ LOT: "&'
                f'TEXT(MAX(0,({lot_total_expr})-({lot_used_expr})),"0.00")&" m","PHÂN BỔ: chưa sử dụng | DƯ LOT: "&TEXT(({lot_total_expr}),"0.00")&" m")'
            )
            summary_cell.alignment=Alignment(horizontal='left',vertical='center',wrap_text=True)

        # V34: KHÔNG ghi thiếu mét lên BIỂU CẮT. Thiếu mét chỉ hiển thị tại SỬA PHÂN CÂY.
        # Dòng 3 của SỬA PHÂN CÂY tổng hợp thiếu mét theo từng loại vải và tự cập nhật.
        shortage_parts=[]
        for fabric in export_edit_fabrics:
            rinfo = roll_calc_info.get(id(fabric))
            finfo = fabric_excel_info.get(id(fabric), {}) or {}
            need_expr = str(finfo.get('need_total_ref','0') or '0')
            if not rinfo:
                continue
            used_expr=f"SUM('{roll_calc_ref}'!${rinfo['used_m_col']}${rinfo['data_start']}:${rinfo['used_m_col']}${rinfo['data_end']})"
            missing_expr=f'MAX(0,({need_expr})-({used_expr}))'
            safe_name=str(fabric.get('name','') or '').replace('"','""')
            prefix='""' if not shortage_parts else '" | "'
            shortage_parts.append(f'{prefix}&"{safe_name}: "&TEXT(({missing_expr}),"0.00")&" m"')
        if shortage_parts:
            try:
                edit_ws.merge_cells(start_row=3,start_column=1,end_row=3,end_column=edit_last_visible_col)
            except Exception:
                pass
            edit_ws['A3']='="THIẾU VẢI: "&' + '&'.join(shortage_parts)
            edit_ws['A3'].font=Font(name='Calibri',size=11,bold=True,color='C00000')
            edit_ws['A3'].fill=PatternFill('solid',fgColor='FCE4D6')
            edit_ws['A3'].alignment=Alignment(horizontal='left',vertical='center',wrap_text=True)
            edit_ws.row_dimensions[3].height=24

        # ===== V84: SỐ MÉT LOT CÒN LẠI =====
        # Chỉ giữ 4 cột: LOT | LOT GHI TRÊN CÂY | SỐ CÂY | SỐ MÉT CÒN LẠI.
        # Công thức liên kết trực tiếp SỬA PHÂN CÂY + _ROLL_CALC nên khi đổi
        # chiều dài/số lá/phân cây hoặc nhập DÒNG DƯ, số mét còn lại tự cập nhật.
        remain_ws = wb.create_sheet('SỐ MÉT LOT CÒN LẠI')
        remain_ws.sheet_view.showGridLines = False
        remain_ws.merge_cells('A1:D1')
        remain_ws['A1'] = 'SỐ MÉT LOT CÒN LẠI'
        remain_ws['A1'].font = Font(name='Calibri', size=18, bold=True, color='FFFFFF')
        remain_ws['A1'].fill = edit_fill_title
        remain_ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
        remain_ws.merge_cells('A2:D2')
        remain_ws['A2'] = 'Tự cập nhật theo SỬA PHÂN CÂY. Dòng đã dùng hết sẽ để trống; dòng còn mét hoặc dòng dư mới nhập sẽ hiện số mét còn lại.'
        remain_ws['A2'].alignment = Alignment(wrap_text=True, vertical='center')
        remain_ws.row_dimensions[1].height = 30
        remain_ws.row_dimensions[2].height = 34
        remain_headers = ['LOT', 'LOT GHI TRÊN CÂY', 'SỐ CÂY', 'SỐ MÉT CÒN LẠI']
        for ci, hv in enumerate(remain_headers, start=1):
            c = remain_ws.cell(4, ci, hv)
            c.font = edit_header_font
            c.fill = edit_fill_header
            c.border = edit_border
            c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

        remain_row = 5
        for li, block in enumerate(lot_blocks):
            vbs = int(block['start_col'])
            details = list(block.get('details', []) or [])
            source_rows = list(range(lot_data_first_row, lot_data_first_row + min(len(details), MAX_TREE_ROWS_PER_LOT)))
            for er in (block.get('extra_rows', []) or []):
                if er not in source_rows:
                    source_rows.append(er)
            source_rows = sorted(set(r for r in source_rows if lot_data_first_row <= r <= lot_data_last_row))

            for vr in source_rows:
                j = vr - lot_data_first_row
                lot_ref = f"'{edit_sheet_ref}'!{col_letter(vbs+2)}{vr}"
                mark_ref = f"'{edit_sheet_ref}'!{col_letter(vbs+1)}{vr}"
                roll_ref = f"'{edit_sheet_ref}'!{col_letter(vbs+3)}{vr}"
                meter_ref = f"'{edit_sheet_ref}'!{col_letter(vbs+4)}{vr}"
                fab_ref = f"'{edit_sheet_ref}'!{col_letter(vbs)}{vr}"

                used_refs = []
                for fabric in export_edit_fabrics:
                    rinfo = roll_calc_info.get(id(fabric))
                    if not rinfo:
                        continue
                    rr = int(rinfo['data_start']) + li * MAX_TREE_ROWS_PER_LOT + j
                    if rr <= int(rinfo['data_end']):
                        used_refs.append(f"N('{roll_calc_ref}'!${rinfo['used_m_col']}${rr})")
                total_used_expr = '+'.join(used_refs) if used_refs else '0'

                # V93: chuyển đầu tấm chỉ áp dụng khi trùng đủ LOT + LOT GHI TRÊN CÂY + SỐ CÂY.
                # Hai cây cùng số nhưng khác LOT ghi trên cây là hai cây độc lập.
                seen_count = (
                    f'COUNTIFS(\'{edit_sheet_ref}\'!${col_letter(vbs+2)}${lot_data_first_row}:'
                    f'${col_letter(vbs+2)}{vr},{lot_ref},'
                    f'\'{edit_sheet_ref}\'!${col_letter(vbs+1)}${lot_data_first_row}:'
                    f'${col_letter(vbs+1)}{vr},{mark_ref},'
                    f'\'{edit_sheet_ref}\'!${col_letter(vbs+3)}${lot_data_first_row}:'
                    f'${col_letter(vbs+3)}{vr},{roll_ref})'
                )
                if vr < lot_data_last_row:
                    later_m = f"'{edit_sheet_ref}'!${col_letter(vbs+4)}${vr+1}:${col_letter(vbs+4)}${lot_data_last_row}"
                    later_l = f"'{edit_sheet_ref}'!${col_letter(vbs+2)}${vr+1}:${col_letter(vbs+2)}${lot_data_last_row}"
                    later_k = f"'{edit_sheet_ref}'!${col_letter(vbs+1)}${vr+1}:${col_letter(vbs+1)}${lot_data_last_row}"
                    later_r = f"'{edit_sheet_ref}'!${col_letter(vbs+3)}${vr+1}:${col_letter(vbs+3)}${lot_data_last_row}"
                    later_f = f"'{edit_sheet_ref}'!${col_letter(vbs)}${vr+1}:${col_letter(vbs)}${lot_data_last_row}"
                    later_nonblank = f'SUMIFS({later_m},{later_l},{lot_ref},{later_k},{mark_ref},{later_r},{roll_ref},{later_f},"<>")'
                    later_same = f'SUMIFS({later_m},{later_l},{lot_ref},{later_k},{mark_ref},{later_r},{roll_ref},{later_f},{fab_ref})'
                    transfer_out_expr = f'IF(({seen_count})=1,MAX(0,({later_nonblank})-({later_same})),0)'
                else:
                    transfer_out_expr = '0'

                remain_expr = f'MAX(0,N({meter_ref})-({total_used_expr})-({transfer_out_expr}))'
                valid_expr = f'AND({lot_ref}<>"",{roll_ref}<>"",N({meter_ref})>0,({remain_expr})>0)'
                vals = [
                    f'=IF({valid_expr},{lot_ref},"")',
                    f'=IF({valid_expr},{mark_ref},"")',
                    f'=IF({valid_expr},{roll_ref},"")',
                    f'=IF({valid_expr},ROUND(({remain_expr}),2),"")',
                ]
                for ci, val in enumerate(vals, start=1):
                    c = remain_ws.cell(remain_row, ci, val)
                    c.border = edit_border
                    c.font = edit_font
                    c.alignment = Alignment(horizontal='center', vertical='center')
                remain_ws.cell(remain_row, 4).number_format = '0.00'
                remain_row += 1

        # Nếu không có cây nào vẫn để một dòng trống có khung.
        if remain_row == 5:
            for ci in range(1, 5):
                remain_ws.cell(5, ci).border = edit_border
            remain_row = 6
        remain_ws.column_dimensions['A'].width = 16
        remain_ws.column_dimensions['B'].width = 20
        remain_ws.column_dimensions['C'].width = 14
        remain_ws.column_dimensions['D'].width = 20
        remain_ws.freeze_panes = 'A5'
        remain_ws.auto_filter.ref = f'A4:D{max(4, remain_row-1)}'
        remain_ws.sheet_properties.pageSetUpPr.fitToPage = True
        remain_ws.page_setup.orientation = remain_ws.ORIENTATION_PORTRAIT
        remain_ws.page_setup.paperSize = remain_ws.PAPERSIZE_A4
        remain_ws.page_setup.fitToWidth = 1
        remain_ws.page_setup.fitToHeight = 0
        remain_ws.print_title_rows = '1:4'
        remain_ws.print_area = f'A1:D{max(5, remain_row-1)}'

        # V50: tô màu để phân biệt cây đã dùng/chưa dùng trong SỬA PHÂN CÂY.
        used_fill = PatternFill('solid', fgColor='E2F0D9')      # xanh nhạt
        unused_fill = PatternFill('solid', fgColor='E7E6E6')    # xám nhạt
        for _block in lot_blocks:
            _bs=int(_block['start_col'])
            _be=int(_block['end_col'])
            _status_col=col_letter(_bs+5)
            _rng=f'{col_letter(_bs)}{lot_data_first_row}:{col_letter(_be)}{lot_data_last_row}'
            edit_ws.conditional_formatting.add(
                _rng, FormulaRule(formula=[f'${_status_col}{lot_data_first_row}="ĐÃ DÙNG"'], stopIfTrue=False, fill=used_fill))
            edit_ws.conditional_formatting.add(
                _rng, FormulaRule(formula=[f'${_status_col}{lot_data_first_row}="CHƯA DÙNG"'], stopIfTrue=False, fill=unused_fill))

        # V84: sheet SỐ MÉT LOT CÒN LẠI không cần tô màu trạng thái.

        # ===== SHEET PHÂN CÂY - FORM SHADING BAND =====
        # Bố cục theo mẫu người dùng: 4 bàn ngang / cụm, mỗi bàn 7 cột.
        # Cột: LOT | LOT ghi trên cây | cây (roll#) | Chiều dài (Y) | Chiều dài (M)
        #      | số lá (tiêu đề cột hiển thị chiều dài sơ đồ) | đầu tấm.
        roll_results = [r for r in results if bool(r.get('fabric', {}).get('export_roll', True))]
        roll_sheet_needed = bool(roll_results)
        if roll_sheet_needed:
            roll_ws = wb.create_sheet("PHÂN CÂY")
            roll_ws.sheet_view.showGridLines = False
            # V95: khóa 4 dòng đầu; khi cuộn, dòng 1-4 luôn hiển thị.
            roll_ws.freeze_panes = 'A5'

            # ---------- style ----------
            shade_font = Font(name='Times New Roman', size=9)
            shade_font_bold = Font(name='Times New Roman', size=9, bold=True)
            shade_font_title = Font(name='Times New Roman', size=14, bold=True)
            shade_font_info = Font(name='Times New Roman', size=9, bold=True)
            shade_thin = Side(style='thin', color='808080')
            shade_medium = Side(style='medium', color='000000')
            shade_border = Border(left=shade_thin, right=shade_thin, top=shade_thin, bottom=shade_thin)
            shade_center = Alignment(horizontal='center', vertical='center', wrap_text=True)
            shade_left = Alignment(horizontal='left', vertical='center', wrap_text=False)

            # 4 block x 6 cột, giữa block chừa 1 cột như form mẫu.
            block_starts = [1, 9, 17, 25]  # A, I, Q, Y
            block_width = 7
            last_col_idx = 31  # AE

            # Độ rộng cột gần form mẫu.
            block_widths = [7.6, 8.8, 6.0, 7.5, 7.5, 6.5, 7.0]
            for bs in block_starts:
                for off, width in enumerate(block_widths):
                    roll_ws.column_dimensions[col_letter(bs + off)].width = width
            for gap in (8, 16, 24):
                roll_ws.column_dimensions[col_letter(gap)].width = 2.0

            def _set_range_border(ws2, min_row, min_col, max_row, max_col, outer=shade_medium):
                """Kẻ viền mảnh bên trong và viền ngoài đậm cho một block."""
                for r2 in range(min_row, max_row + 1):
                    for c2 in range(min_col, max_col + 1):
                        cell = ws2.cell(r2, c2)
                        cell.border = Border(
                            left=outer if c2 == min_col else shade_thin,
                            right=outer if c2 == max_col else shade_thin,
                            top=outer if r2 == min_row else shade_thin,
                            bottom=outer if r2 == max_row else shade_thin,
                        )

            def _safe_merge(ws2, start_row, start_col, end_row, end_col):
                try:
                    ws2.merge_cells(start_row=start_row, start_column=start_col,
                                    end_row=end_row, end_column=end_col)
                except Exception:
                    pass

            # ---------- Header chung ----------
            _safe_merge(roll_ws, 1, 1, 1, last_col_idx - 3)
            roll_ws.cell(1, 1, 'BẢNG PHÂN LOT MÀU/SHADING BAND')
            roll_ws.cell(1, 1).font = shade_font_title
            roll_ws.cell(1, 1).alignment = shade_center
            roll_ws.row_dimensions[1].height = 25

            # V89: PHÂN CÂY lấy THÔNG TIN CHUNG trực tiếp từ sheet BIỂU CẮT bằng công thức.
            # Nhờ vậy nếu sửa KHÁCH HÀNG / MÃ HÀNG / ĐỢT / MÙA / MÀU / CODE / DATE
            # trên BIỂU CẮT sau khi xuất, PHÂN CÂY cũng tự cập nhật theo.
            _safe_merge(roll_ws, 1, last_col_idx - 2, 2, last_col_idx)
            roll_ws.cell(1, last_col_idx - 2, f"='{main_sheet_ref}'!$O$1")
            roll_ws.cell(1, last_col_idx - 2).font = Font(name='Times New Roman', size=9, bold=True)
            roll_ws.cell(1, last_col_idx - 2).alignment = shade_center
            _set_range_border(roll_ws, 1, last_col_idx - 2, 2, last_col_idx)

            # Logo vùng A2:B4.
            if getattr(self, 'logo_path', None) and os.path.isfile(self.logo_path):
                try:
                    logo2 = XLImage(self.logo_path)
                    logo2.width = 95
                    logo2.height = 70
                    logo2.anchor = 'A2'
                    roll_ws.add_image(logo2)
                except Exception:
                    pass

            # BIỂU CẮT lưu thông tin chuẩn ở C3/C4, H3/H4 và cột MÀU động.
            # Công thức dưới đây bỏ phần nhãn trước dấu ':' rồi gắn nhãn đúng của PHÂN CÂY.
            def _cut_info_value(cell_ref):
                src = f"'{main_sheet_ref}'!${cell_ref}"
                return f'IFERROR(TRIM(MID({src},FIND(":",{src})+1,999)),"")'

            customer_expr = _cut_info_value('C$3')
            style_expr = _cut_info_value('C$4')
            batch_expr = _cut_info_value('H$3')
            season_expr = _cut_info_value('H$4')
            color_src_cell = f"{col_letter(color_col_idx)}$3"
            color_expr = _cut_info_value(color_src_cell)
            code_date_ref = f"'{main_sheet_ref}'!$O$1"
            date_expr = f'IFERROR(TRIM(MID({code_date_ref},FIND("DATE:",{code_date_ref})+5,999)),"")'

            # Trái: khách hàng + mã hàng.
            _safe_merge(roll_ws, 2, 3, 2, 10)
            roll_ws.cell(2, 3, f'="KHÁCH HÀNG (BUYER) : "&({customer_expr})')
            _safe_merge(roll_ws, 3, 3, 3, 10)
            roll_ws.cell(3, 3, f'="MÃ HÀNG (STYLE) : "&({style_expr})')

            # Giữa: ĐỢT + MÙA.
            _safe_merge(roll_ws, 2, 11, 2, 16)
            roll_ws.cell(2, 11, f'="ĐỢT (BATCH) : "&({batch_expr})')
            _safe_merge(roll_ws, 3, 11, 3, 16)
            roll_ws.cell(3, 11, f'="MÙA (SEASON) : "&({season_expr})')

            # V98: chuyển MÀU xuống dưới MÙA để phần PO của từng loại vải có nhiều chỗ hơn.
            # DATE giữ bên phải; dòng 4 dành riêng cho MÀU.
            _safe_merge(roll_ws, 3, 17, 3, 24)
            roll_ws.cell(3, 17, f'="DATE: "&({date_expr})')
            _safe_merge(roll_ws, 4, 11, 4, 24)
            roll_ws.cell(4, 11, f'="MÀU (COLOR) : "&({color_expr})')

            for rr, cc in ((2,3),(3,3),(2,11),(3,11),(3,17),(4,11)):
                roll_ws.cell(rr, cc).font = shade_font_info
                roll_ws.cell(rr, cc).alignment = shade_center

            # Viền nhẹ phần thông tin đầu trang.
            for r2 in range(1, 5):
                for c2 in range(1, last_col_idx + 1):
                    if roll_ws.cell(r2, c2).border == Border():
                        roll_ws.cell(r2, c2).border = Border(bottom=shade_thin)

            current_row_roll = 5

            # Mỗi loại vải có phần thông tin riêng rồi các bàn theo nhóm 4.
            for res in roll_results:
                fabric = res['fabric']
                # Đồng bộ lại LOT tự động trước khi lập sheet.
                self._sync_roll_lots(fabric)

                # V98: PO ở PHÂN CÂY chỉ là TÊN hiển thị do người dùng chọn riêng.
                # KHÔNG ảnh hưởng số lượng/tính toán: phần tính vẫn dùng toàn bộ PO áp dụng của loại vải.
                roll_po_names = self._fabric_roll_po_names(fabric)
                po_text = ' + '.join(roll_po_names)
                _safe_merge(roll_ws, current_row_roll, 1, current_row_roll, 10)
                roll_ws.cell(current_row_roll, 1,
                             f"CHỦNG LOẠI VẢI (KIND OF FABRIC): {fabric.get('name','')}")
                roll_ws.cell(current_row_roll, 1).font = shade_font_info
                roll_ws.cell(current_row_roll, 1).alignment = shade_center
                _safe_merge(roll_ws, current_row_roll, 11, current_row_roll, last_col_idx)
                safe_po_text = str(po_text or '').replace('"', '""')
                roll_ws.cell(current_row_roll, 11, f'="PO: {safe_po_text}"')
                roll_ws.cell(current_row_roll, 11).font = shade_font_info
                roll_ws.cell(current_row_roll, 11).alignment = shade_center
                for c2 in range(1, last_col_idx + 1):
                    roll_ws.cell(current_row_roll, c2).border = Border(bottom=shade_medium)
                current_row_roll += 1

                tables = res.get('cutting_tables', []) or []
                helper = supp_lot_helper_info.get(id(fabric), {})
                rcinfo = roll_calc_info.get(id(fabric), {})
                rc_data_start = int(rcinfo.get('data_start', 0) or 0)
                rc_alloc_cols = list(rcinfo.get('alloc_cols', []) or [])
                rc_rank_cols = list(rcinfo.get('rank_cols', []) or [])
                rc_remnant_cols = list(rcinfo.get('remnant_cols', []) or [])
                roll_calc_ref_pc = roll_calc_ws.title.replace("'", "''")
                main_rows_pc_all = list(helper.get('main_rows', []) or [])
                # V82: PHÂN CÂY giữ đủ bàn thực tế + đúng 3 bàn dự phòng như BIỂU CẮT.
                table_slot_count = min(len(main_rows_pc_all), len(tables) + RESERVE_TABLES_PER_FABRIC)
                table_indexes = list(range(table_slot_count))
                real_indexes = [i for i, t in enumerate(tables) if int(t.get('plies', 0) or 0) > 0]
                short_idx = None
                if real_indexes:
                    min_len_pc = min(float(tables[i].get('length',0) or 0) for i in real_indexes)
                    short_idx = max(i for i in real_indexes if abs(float(tables[i].get('length',0) or 0)-min_len_pc)<1e-9)
                if not table_indexes:
                    current_row_roll += 2
                    continue

                # V100: khung mỗi nhóm bàn chỉ cao theo số cây thực tế dự kiến của bàn
                # có nhiều cây nhất trong nhóm + số dòng trống do người dùng chọn.
                # Không còn lấy tổng số cây của cả loại vải + 12 nên tránh lãng phí giấy.
                # Biến tổng cây vẫn giữ để dùng riêng cho bảng tổng hợp cuối loại vải.
                initial_active_tree_count = sum(
                    1 for rr in (fabric.get('rolls', []) or [])
                    if str(rr.get('roll','') or '').strip() and float(rr.get('length',0) or 0) > 0
                )
                extra_blank_rows_pc = self._get_roll_extra_blank_rows(silent=True)

                def _estimate_table_roll_counts(_fabric, _tables):
                    _reserve_m, _reserve_plies = self._fabric_roll_reserve_settings(_fabric)
                    _states = []
                    for _i, _r in enumerate((_fabric or {}).get('rolls', []) or []):
                        try:
                            _length = max(0.0, float(_r.get('length', 0) or 0))
                        except Exception:
                            _length = 0.0
                        if _length <= 0:
                            continue
                        _states.append({
                            'source_index': _i,
                            'lot': str(_r.get('lot','') or '').strip(),
                            'remaining': _length,
                            'had_alloc': False,
                        })
                    _lot_order = {}
                    for _st in _states:
                        if _st['lot'] not in _lot_order:
                            _lot_order[_st['lot']] = len(_lot_order) + 1
                    _counts = []
                    _eps = 1e-9
                    for _t in (_tables or []):
                        try:
                            _target = max(0, int(_t.get('plies', 0) or 0))
                            _mpp = max(0.0, float(_t.get('length', 0) or 0)) * 1.01
                        except Exception:
                            _target, _mpp = 0, 0.0
                        if _target <= 0 or _mpp <= 0:
                            _counts.append(0)
                            continue
                        _cands = []
                        for _st in _states:
                            _raw_cap = max(0, int((_st['remaining'] + _eps) // _mpp))
                            if _raw_cap > 0:
                                _rem_after_raw = max(0.0, _st['remaining'] - _raw_cap * _mpp)
                                _reserve_cap = (max(0, _raw_cap - _reserve_plies)
                                                if _rem_after_raw < _reserve_m - _eps else _raw_cap)
                            else:
                                _reserve_cap = 0
                            _cap = 0 if (_st['had_alloc'] and _reserve_cap < 3) else _reserve_cap
                            if _cap <= 0:
                                continue
                            if _cap <= _target:
                                _rem_full = max(0.0, _st['remaining'] - _cap * _mpp)
                                _fit = ((_target - _cap) * 100000000
                                        + round(_rem_full * 1000) * 1000
                                        + (100000 - _cap))
                            else:
                                _rem_finish = max(0.0, _st['remaining'] - _target * _mpp)
                                _fit = (1000000000000
                                        + round(_rem_finish * 1000) * 1000
                                        + (_cap - _target))
                            if not _st['had_alloc']:
                                _fit += 100000000000000
                            _cands.append((_lot_order.get(_st['lot'], 10**9), _fit,
                                           _st['source_index'], _cap, _st))
                        _cands.sort(key=lambda x: (x[0], x[1], x[2]))
                        _prior_capacity = 0
                        _used_rows = 0
                        for _lotord, _fit, _src, _cap, _st in _cands:
                            _need = max(0, _target - _prior_capacity)
                            if _need <= 0:
                                break
                            _alloc = min(_cap, _need)
                            if _alloc <= 0:
                                continue
                            _st['remaining'] = max(0.0, _st['remaining'] - _alloc * _mpp)
                            _st['had_alloc'] = True
                            _prior_capacity += _cap
                            _used_rows += 1
                        _counts.append(_used_rows)
                    return _counts

                _initial_tables_pc = _excel_initial_tables(res)
                _table_roll_counts_pc = _estimate_table_roll_counts(fabric, _initial_tables_pc)
                # V88: ghi nhớ nhóm cuối để đặt bảng TỔNG HỢP song song với bàn cuối
                # nếu hàng đó vẫn còn cột trống. Chỉ khi đủ 4 block mới xuống hàng dưới.
                last_group_title_row = None
                last_group_total_row = None
                last_group_slots = 0

                # 4 bàn ngang / nhóm.
                for group_pos in range(0, len(table_indexes), 4):
                    group = table_indexes[group_pos:group_pos + 4]
                    real_rows_in_group = max(
                        [(_table_roll_counts_pc[i] if i < len(_table_roll_counts_pc) else 0)
                         for i in group] or [0]
                    )
                    # Ít nhất 1 dòng dữ liệu; bàn dự phòng vẫn có đúng số dòng trống người dùng chọn.
                    body_rows = max(1, min(80, int(real_rows_in_group) + int(extra_blank_rows_pc)))
                    title_row = current_row_roll
                    header_row = title_row + 1
                    data_start = header_row + 1
                    total_row = data_start + body_rows

                    for slot, table_idx in enumerate(group):
                        bs = block_starts[slot]
                        be = bs + block_width - 1
                        table = tables[table_idx] if table_idx < len(tables) else {'table': f'B{table_idx+1}', 'length': 0, 'plies': 0, 'ratio_map': {}}
                        table_name = str(table.get('table', f'B{table_idx+1}'))
                        marker_len = float(table.get('length', 0) or 0)
                        is_short = (table_idx == short_idx)

                        # Title block.
                        _safe_merge(roll_ws, title_row, bs, title_row, be)
                        main_rows_pc = helper.get('main_rows', []) or []
                        mr_pc = int(main_rows_pc[table_idx]) if table_idx < len(main_rows_pc) else 0
                        active_expr_pc = f"TRIM('{main_sheet_ref}'!C{mr_pc})<>\"\"" if mr_pc else 'FALSE'
                        # V90: chỉ hiển thị số bàn. Không gắn nhãn "BÀN NGẮN CUỐI"
                        # vì khi người dùng thêm bàn dự phòng trong Excel, nhãn tĩnh đó
                        # không thể tự chuyển sang bàn mới cuối cùng.
                        title = f"BÀN {table_name.replace('B','',1)}"
                        roll_ws.cell(title_row, bs, f'=IF({active_expr_pc},"{title}","")' if mr_pc else '')
                        roll_ws.cell(title_row, bs).font = shade_font_bold
                        roll_ws.cell(title_row, bs).alignment = shade_center
                        roll_ws.row_dimensions[title_row].height = 21

                        # Header 7 cột. Cột 6 dùng chính chiều dài sơ đồ làm tiêu đề.
                        header_vals = [
                            'LOT', 'LOT\nGHI TRÊN\nCÂY', 'cây\n(roll#)', 'Chiều\ndài (Y)',
                            'Chiều\ndài (M)', '', 'đầu tấm'
                        ]
                        for off, hv in enumerate(header_vals):
                            if off == 5:
                                val = f"=IF({active_expr_pc},N('{main_sheet_ref}'!D{mr_pc}),\"\")" if mr_pc else ''
                            else:
                                safe_hv = str(hv).replace('"','""')
                                val = f'=IF({active_expr_pc},"{safe_hv}","")' if mr_pc else ''
                            cell = roll_ws.cell(header_row, bs + off, val)
                            cell.font = shade_font_bold
                            cell.alignment = shade_center
                        if mr_pc:
                            roll_ws.cell(header_row, bs + 5).number_format = '0.00'
                        roll_ws.row_dimensions[header_row].height = 50

                        # V54: nén cây đang dùng lên ngay dưới tiêu đề, không để dòng trống ở giữa.
                        # AGGREGATE tìm cây thứ n có số lá > 0 của đúng bàn hiện tại.
                        for j in range(body_rows):
                            r2 = data_start + j
                            if table_idx < len(rc_alloc_cols) and rc_data_start > 0:
                                ac = rc_alloc_cols[table_idx]
                                rk = rc_rank_cols[table_idx] if table_idx < len(rc_rank_cols) else ''
                                rc_r1 = rc_data_start
                                rc_r2 = int(rcinfo.get('data_end', 0) or 0)
                                if rk and rc_r2 >= rc_r1:
                                    pos_expr = f"IFERROR(MATCH({j+1},'{roll_calc_ref_pc}'!${rk}${rc_r1}:${rk}${rc_r2},0),999999)"
                                else:
                                    pos_expr = '999999'
                                tree_plies = f"IFERROR(INDEX('{roll_calc_ref_pc}'!${ac}${rc_r1}:${ac}${rc_r2},{pos_expr}),0)"
                                lot_src = f"IFERROR(INDEX('{roll_calc_ref_pc}'!$C${rc_r1}:$C${rc_r2},{pos_expr}),\"\")"
                                mark_src = f"IFERROR(INDEX('{roll_calc_ref_pc}'!$D${rc_r1}:$D${rc_r2},{pos_expr}),\"\")"
                                roll_src = f"IFERROR(INDEX('{roll_calc_ref_pc}'!$E${rc_r1}:$E${rc_r2},{pos_expr}),\"\")"
                                meter_src = f"IFERROR(N(INDEX('{roll_calc_ref_pc}'!$F${rc_r1}:$F${rc_r2},{pos_expr})),0)"
                                main_rows_pc = helper.get('main_rows', []) or []
                                mpp_ref = f"(N('{main_sheet_ref}'!D{main_rows_pc[table_idx]})*1.01)" if table_idx < len(main_rows_pc) else '0'
                                # Tổng mét cây đã dùng ở các bàn trước, lấy cùng vị trí nguồn.
                                prev_terms=[]
                                for pti in range(min(table_idx,len(rc_alloc_cols))):
                                    pac=rc_alloc_cols[pti]
                                    if pti < len(main_rows_pc):
                                        prev_terms.append(f"IFERROR(INDEX('{roll_calc_ref_pc}'!${pac}${rc_r1}:${pac}${rc_r2},{pos_expr}),0)*(N('{main_sheet_ref}'!D{main_rows_pc[pti]})*1.01)")
                                used_before_tree = '+'.join(prev_terms) if prev_terms else '0'
                                start_available = f'MAX(0,({meter_src})-({used_before_tree}))'
                                rem_tree = f'MAX(0,({start_available})-({tree_plies})*({mpp_ref}))'
                                formulas = [
                                    f'=IF(({tree_plies})>0,{lot_src},"")',
                                    f'=IF(({tree_plies})>0,{mark_src},"")',
                                    f'=IF(({tree_plies})>0,{roll_src},"")',
                                    f'=IF(({tree_plies})>0,IFERROR(({start_available})/0.9144,""),"")',
                                    f'=IF(({tree_plies})>0,{start_available},"")',
                                    f'=IF(({tree_plies})>0,{tree_plies},"")',
                                    f'=IF(({tree_plies})>0,{rem_tree},"")',
                                ]
                                for off, val in enumerate(formulas):
                                    cell = roll_ws.cell(r2, bs + off, val)
                                    cell.font = shade_font; cell.alignment = shade_center
                                for off in (3,4,6): roll_ws.cell(r2, bs + off).number_format='0.00'
                            else:
                                for off in range(7): roll_ws.cell(r2, bs + off, '')
                            roll_ws.row_dimensions[r2].height = 20

                        # Dòng tổng động theo các LOT đang thực sự dùng ở bàn này.
                        # LEN chỉ đếm cây đang hiển thị thật; COUNTIF("<>") có thể
                        # đếm cả ô công thức trả về chuỗi rỗng và làm hiện số cây sai.
                        roll_ws.cell(total_row, bs + 2, f'=IF({active_expr_pc},SUMPRODUCT(--(LEN({col_letter(bs+2)}{data_start}:{col_letter(bs+2)}{total_row-1})>0)),"")')
                        roll_ws.cell(total_row, bs + 3, f'=IF({active_expr_pc},SUM({col_letter(bs+3)}{data_start}:{col_letter(bs+3)}{total_row-1}),"")')
                        roll_ws.cell(total_row, bs + 4, f'=IF({active_expr_pc},SUM({col_letter(bs+4)}{data_start}:{col_letter(bs+4)}{total_row-1}),"")')
                        roll_ws.cell(total_row, bs + 5, f'=IF({active_expr_pc},SUM({col_letter(bs+5)}{data_start}:{col_letter(bs+5)}{total_row-1}),"")')
                        # V50: TỔNG ĐẦU TẤM không cộng phần còn lại của cây nếu cây đó
                        # còn được chuyển sang một bàn phía sau. Chỉ cộng đầu tấm cuối cùng
                        # của cây sau lần sử dụng cuối.
                        if table_idx < len(rc_remnant_cols) and rc_data_start > 0:
                            _remc = rc_remnant_cols[table_idx]
                            _rc_end = int(rcinfo.get('data_end', 0) or 0)
                            _rem_total = f"SUM('{roll_calc_ref_pc}'!${_remc}${rc_data_start}:${_remc}${_rc_end})"
                            roll_ws.cell(total_row, bs + 6, f'=IF({active_expr_pc},{_rem_total},"")')
                        else:
                            roll_ws.cell(total_row, bs + 6, f'=IF({active_expr_pc},SUM({col_letter(bs+6)}{data_start}:{col_letter(bs+6)}{total_row-1}),"")')
                        for off in range(7):
                            c = roll_ws.cell(total_row, bs + off)
                            c.font = shade_font_bold
                            c.alignment = shade_center
                        for off in (3, 4, 6):
                            roll_ws.cell(total_row, bs + off).number_format = '0.00'

                        _set_range_border(roll_ws, title_row, bs, total_row, be)
                        # V64: bàn dự phòng chưa có dữ liệu được ẩn bằng định dạng điều kiện.
                        # Khi người dùng thêm bàn vào BIỂU CẮT, khối tự hiện lại mà không cần VBA.
                        if mr_pc:
                            _white = 'FFFFFF'
                            _wb = Border(left=Side(style='thin', color=_white), right=Side(style='thin', color=_white),
                                         top=Side(style='thin', color=_white), bottom=Side(style='thin', color=_white))
                            _rule = FormulaRule(formula=[f"TRIM('{main_sheet_ref}'!$C${mr_pc})=\"\""],
                                                stopIfTrue=True,
                                                font=Font(color=_white),
                                                fill=PatternFill('solid', fgColor=_white),
                                                border=_wb)
                            roll_ws.conditional_formatting.add(
                                f"{col_letter(bs)}{title_row}:{col_letter(be)}{total_row}", _rule)

                    last_group_title_row = title_row
                    last_group_total_row = total_row
                    last_group_slots = len(group)
                    current_row_roll = total_row + 2

                # Bố trí: nếu nhóm cuối chỉ có 1-3 bàn thì bảng tổng hợp nằm ngay
                # block kế bên bàn cuối. Nếu nhóm cuối đã đủ 4 bàn thì mới xuống hàng dưới.
                if last_group_title_row is not None and 0 < last_group_slots < 4:
                    summary_title_row = last_group_title_row
                    sbs = block_starts[last_group_slots]
                    summary_next_row_base = int(last_group_total_row or summary_title_row) + 2
                else:
                    summary_title_row = current_row_roll
                    sbs = block_starts[0]
                    summary_next_row_base = None
                summary_header_row = summary_title_row + 1
                # Số dòng vừa đủ cây thực tế + số dòng dư đã chọn trên phần mềm.
                summary_body_rows = max(4, min(80, int(initial_active_tree_count) + int(requested_extra_rows)))
                summary_data_start = summary_header_row + 1
                summary_total_row = summary_data_start + summary_body_rows
                sbe = sbs + block_width - 1

                _safe_merge(roll_ws, summary_title_row, sbs, summary_title_row, sbe)
                roll_ws.cell(summary_title_row, sbs, 'TỔNG HỢP CÂY ĐÃ DÙNG / MÉT CÒN LẠI')
                roll_ws.cell(summary_title_row, sbs).font = shade_font_bold
                roll_ws.cell(summary_title_row, sbs).alignment = shade_center
                roll_ws.row_dimensions[summary_title_row].height = max(
                    float(roll_ws.row_dimensions[summary_title_row].height or 0), 21)

                # Chỉ giữ đúng 4 thông tin người dùng yêu cầu:
                # LOT | LOT GHI TRÊN CÂY | SỐ CÂY | SỐ MÉT CÒN LẠI.
                roll_ws.cell(summary_header_row, sbs, 'LOT')
                roll_ws.cell(summary_header_row, sbs + 1, 'LOT\nGHI TRÊN\nCÂY')
                roll_ws.cell(summary_header_row, sbs + 2, 'SỐ CÂY')
                _safe_merge(roll_ws, summary_header_row, sbs + 3, summary_header_row, sbe)
                roll_ws.cell(summary_header_row, sbs + 3, 'SỐ MÉT CÒN LẠI')
                for cc in range(sbs, sbe + 1):
                    roll_ws.cell(summary_header_row, cc).font = shade_font_bold
                    roll_ws.cell(summary_header_row, cc).alignment = shade_center
                roll_ws.row_dimensions[summary_header_row].height = max(
                    float(roll_ws.row_dimensions[summary_header_row].height or 0), 50)

                rc_end_summary = int(rcinfo.get('data_end', 0) or 0)
                rc_remain_col_summary = str(rcinfo.get('remaining_m_col', '') or '')
                rc_remain_rank_col_summary = str(rcinfo.get('remaining_rank_col', '') or '')
                if (rc_data_start > 0 and rc_end_summary >= rc_data_start and
                        rc_remain_col_summary and rc_remain_rank_col_summary):
                    lot_rng_s = f"'{roll_calc_ref_pc}'!$C${rc_data_start}:$C${rc_end_summary}"
                    mark_rng_s = f"'{roll_calc_ref_pc}'!$D${rc_data_start}:$D${rc_end_summary}"
                    roll_rng_s = f"'{roll_calc_ref_pc}'!$E${rc_data_start}:$E${rc_end_summary}"
                    remain_rng_s = f"'{roll_calc_ref_pc}'!${rc_remain_col_summary}${rc_data_start}:${rc_remain_col_summary}${rc_end_summary}"
                    remain_rank_rng_s = f"'{roll_calc_ref_pc}'!${rc_remain_rank_col_summary}${rc_data_start}:${rc_remain_rank_col_summary}${rc_end_summary}"

                    for j in range(summary_body_rows):
                        rr_sum = summary_data_start + j
                        # MATCH trên helper rank liên tục 1..N: công thức đơn giản, không mảng.
                        pos_expr_s = f'IFERROR(MATCH({j+1},{remain_rank_rng_s},0),999999)'
                        vals_s = [
                            f'=IFERROR(INDEX({lot_rng_s},{pos_expr_s}),"")',
                            f'=IFERROR(INDEX({mark_rng_s},{pos_expr_s}),"")',
                            f'=IFERROR(INDEX({roll_rng_s},{pos_expr_s}),"")',
                            f'=IFERROR(IF(INDEX({roll_rng_s},{pos_expr_s})="","",ROUND(N(INDEX({remain_rng_s},{pos_expr_s})),2)),"")',
                        ]
                        for off, val in enumerate(vals_s[:3]):
                            cell = roll_ws.cell(rr_sum, sbs + off, val)
                            cell.font = shade_font
                            cell.alignment = shade_center
                        _safe_merge(roll_ws, rr_sum, sbs + 3, rr_sum, sbe)
                        c_rem = roll_ws.cell(rr_sum, sbs + 3, vals_s[3])
                        c_rem.font = shade_font
                        c_rem.alignment = shade_center
                        c_rem.number_format = '0.00'
                        roll_ws.row_dimensions[rr_sum].height = max(
                            float(roll_ws.row_dimensions[rr_sum].height or 0), 20)
                else:
                    for j in range(summary_body_rows):
                        rr_sum = summary_data_start + j
                        for off in range(3):
                            roll_ws.cell(rr_sum, sbs + off, '')
                        _safe_merge(roll_ws, rr_sum, sbs + 3, rr_sum, sbe)
                        roll_ws.cell(rr_sum, sbs + 3, '')
                        roll_ws.row_dimensions[rr_sum].height = max(
                            float(roll_ws.row_dimensions[rr_sum].height or 0), 20)

                _safe_merge(roll_ws, summary_total_row, sbs, summary_total_row, sbs + 1)
                roll_ws.cell(summary_total_row, sbs, 'TỔNG')
                roll_ws.cell(summary_total_row, sbs).font = shade_font_bold
                roll_ws.cell(summary_total_row, sbs).alignment = shade_center
                roll_ws.cell(summary_total_row, sbs + 2,
                    f'=SUMPRODUCT(--(LEN({col_letter(sbs+2)}{summary_data_start}:{col_letter(sbs+2)}{summary_total_row-1})>0))')
                _safe_merge(roll_ws, summary_total_row, sbs + 3, summary_total_row, sbe)
                roll_ws.cell(summary_total_row, sbs + 3,
                    f'=SUM({col_letter(sbs+3)}{summary_data_start}:{col_letter(sbs+3)}{summary_total_row-1})')
                for cc in range(sbs, sbe + 1):
                    roll_ws.cell(summary_total_row, cc).font = shade_font_bold
                    roll_ws.cell(summary_total_row, cc).alignment = shade_center
                roll_ws.cell(summary_total_row, sbs + 3).number_format = '0.00'
                _set_range_border(roll_ws, summary_title_row, sbs, summary_total_row, sbe)

                # Nếu đặt song song thì chiều cao phần loại vải vẫn theo block bàn cuối;
                # nếu bảng tổng hợp dài hơn thì lấy dòng thấp hơn. Nếu không còn cột thì
                # tổng hợp nằm dưới và current_row_roll theo đúng đáy bảng tổng hợp.
                if summary_next_row_base is not None:
                    current_row_roll = max(summary_next_row_base, summary_total_row + 2)
                else:
                    current_row_roll = summary_total_row + 2

                # V90: bỏ dòng TỔNG VẢI ... / ĐÃ DÙNG / CÒN ở cuối mỗi loại vải.
                # current_row_roll đã nằm sau bảng tổng hợp và chừa sẵn khoảng cách,
                # nên loại vải tiếp theo bắt đầu ngay sau đó.

            # ---------- Print setup ----------
            roll_ws.sheet_properties.pageSetUpPr.fitToPage = True
            roll_ws.page_setup.orientation = roll_ws.ORIENTATION_LANDSCAPE
            roll_ws.page_setup.paperSize = roll_ws.PAPERSIZE_A4
            roll_ws.page_setup.fitToWidth = 1
            roll_ws.page_setup.fitToHeight = 0
            roll_ws.page_margins.left = 0.08
            roll_ws.page_margins.right = 0.08
            roll_ws.page_margins.top = 0.15
            roll_ws.page_margins.bottom = 0.15
            roll_ws.page_margins.header = 0.0
            roll_ws.page_margins.footer = 0.0
            roll_ws.print_options.horizontalCentered = True
            # V100: cố định đúng 4 dòng đầu; khi in cũng chỉ lặp lại dòng 1-4.
            # A5 nghĩa là giữ nguyên các dòng 1-4; dữ liệu từ dòng 5 trở đi mới cuộn.
            roll_ws.freeze_panes = 'A5'
            roll_ws.print_title_rows = '1:4'
            roll_ws.print_area = f'A1:AE{max(5, current_row_roll - 1)}'
            roll_ws.freeze_panes = 'A5'

        # V48: Bỏ hoàn toàn khóa/mật khẩu bảo vệ sheet.
        # Tất cả ô trong file Excel xuất ra đều có thể chỉnh sửa trực tiếp.
        for _ws_unprotect in wb.worksheets:
            _ws_unprotect.protection.sheet = False

        self._export_progress(94, 'Đang hoàn thiện định dạng Excel')
        self._export_progress(96, 'Đang ghi file Excel xuống ổ đĩa')
        wb.save(filename)



# ===== V48: BỎ KHÓA EXCEL + PHÂN CÂY CỐ ĐỊNH ĐẾN DÒNG 3 =====
from datetime import datetime
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.pagebreak import Break
APP_TITLE = "PHÂN BỔ SỐ BÀN CẮT / BIỂU 10"

def safe_int(value, default=0):
    try:
        return int(str(value).strip().replace(",", ""))
    except Exception:
        return default


def split_tables(total, round_qty=50, last_limit=75):
    """Chia số lượng theo logic bàn cuối của người dùng."""
    total = max(0, int(total))
    round_qty = max(1, int(round_qty))
    last_limit = max(round_qty, int(last_limit))

    if total <= 0:
        return []
    if total <= round_qty:
        return [total]

    full = total // round_qty
    rem = total % round_qty

    if rem == 0:
        return [round_qty] * full

    candidate_last = round_qty + rem
    if candidate_last <= last_limit:
        # Giữ tổng số bàn = full, dồn phần dư vào bàn cuối
        if full == 1:
            return [candidate_last]
        return [round_qty] * (full - 1) + [candidate_last]

    # Bàn cuối vượt ngưỡng -> tách phần dư thành bàn tiếp theo
    return [round_qty] * full + [rem]


def next_light_start(end_no, step=10):
    """Số bắt đầu Ánh kế tiếp: làm tròn lên theo chục rồi +1.
    Ví dụ Ánh A kết thúc 204 -> Ánh B bắt đầu 211.
    Nếu kết thúc đúng 200 -> Ánh kế tiếp bắt đầu 201.
    """
    end_no = int(end_no)
    step = max(1, int(step))
    return int(math.ceil(end_no / step) * step) + 1


def size_end_with_lights(start_no, lights, light_step=10):
    """Tính số kết thúc thực tế của một cỡ, có tính khoảng làm tròn giữa các Ánh."""
    seq = int(start_no)
    last_end = seq - 1
    for i, light in enumerate(lights):
        qty = int(light.get("qty", 0))
        if qty <= 0:
            continue
        last_end = seq + qty - 1
        if i < len(lights) - 1:
            seq = next_light_start(last_end, light_step)
    return last_end


class SizeRow:
    def __init__(self, parent, index, on_delete):
        self.frame = ttk.Frame(parent)
        self.index_var = tk.StringVar(value=str(index))
        self.size_var = tk.StringVar(value="")
        self.start_var = tk.StringVar(value="")
        self.on_delete = on_delete
        self.light_rows = []

        # Cột trái dùng chung cho cả cỡ. Dòng ánh đầu tiên nằm cùng hàng với tên cỡ.
        self.lbl_index = ttk.Label(self.frame, textvariable=self.index_var, width=4, anchor="center")
        self.ent_size = ttk.Entry(self.frame, textvariable=self.size_var, width=14, justify="center")
        self.ent_start = ttk.Entry(self.frame, textvariable=self.start_var, width=14, justify="center")
        self.btn_del = tk.Button(
            self.frame, text="Xóa cỡ", width=8, command=lambda: on_delete(self),
            bg="#d9534f", fg="white", activebackground="#c9302c", relief="flat"
        )

        self.lbl_index.grid(row=0, column=0, padx=(2, 4), pady=3, sticky="ew")
        self.ent_size.grid(row=0, column=1, padx=4, pady=3, sticky="ew")
        self.ent_start.grid(row=0, column=5, padx=4, pady=3, sticky="ew")
        self.btn_del.grid(row=0, column=6, padx=(4, 2), pady=3)

        self.frame.columnconfigure(1, weight=1)
        self.frame.columnconfigure(2, weight=1)
        self.frame.columnconfigure(3, weight=1)
        self.frame.columnconfigure(5, weight=1)

        self.add_light_row(first=True)

    def add_light_row(self, first=False):
        row_index = len(self.light_rows)
        qty_var = tk.StringVar(value="")
        light_var = tk.StringVar(value="A" if row_index == 0 else "")

        ent_qty = ttk.Entry(self.frame, textvariable=qty_var, width=14, justify="center")
        ent_light = ttk.Entry(self.frame, textvariable=light_var, width=10, justify="center")
        btn_add = tk.Button(
            self.frame, text="+ ÁNH", width=7, command=self.add_light_row,
            bg="#5bc0de", fg="white", activebackground="#31b0d5", relief="flat"
        )
        btn_remove = None
        if not first:
            btn_remove = tk.Button(
                self.frame, text="−", width=3,
                command=lambda: self.remove_light_row(holder),
                bg="#f0ad4e", fg="white", activebackground="#ec971f", relief="flat"
            )

        holder = {
            "qty_var": qty_var, "light_var": light_var,
            "ent_qty": ent_qty, "ent_light": ent_light,
            "btn_add": btn_add, "btn_remove": btn_remove
        }
        self.light_rows.append(holder)
        self._regrid_light_rows()
        return holder

    def remove_light_row(self, holder):
        if holder not in self.light_rows or len(self.light_rows) <= 1:
            return
        for key in ("ent_qty", "ent_light", "btn_add", "btn_remove"):
            w = holder.get(key)
            if w is not None:
                w.destroy()
        self.light_rows.remove(holder)
        self._regrid_light_rows()

    def _regrid_light_rows(self):
        for i, holder in enumerate(self.light_rows):
            r = i
            holder["ent_qty"].grid(row=r, column=2, padx=4, pady=3, sticky="ew")
            holder["ent_light"].grid(row=r, column=3, padx=4, pady=3, sticky="ew")
            # Chỉ hiện nút + ÁNH trên dòng ánh cuối cùng để giao diện gọn hơn.
            holder["btn_add"].grid_forget()
            if holder.get("btn_remove") is not None:
                holder["btn_remove"].grid(row=r, column=4, padx=(0, 2), pady=3, sticky="w")
        if self.light_rows:
            last = self.light_rows[-1]
            last["btn_add"].grid(row=len(self.light_rows)-1, column=4, padx=(0, 2), pady=3, sticky="e")

        # Tên cỡ / số bắt đầu / nút xóa luôn nằm ở dòng đầu.
        self.lbl_index.grid(row=0, column=0, padx=(2, 4), pady=3, sticky="ew")
        self.ent_size.grid(row=0, column=1, padx=4, pady=3, sticky="ew")
        self.ent_start.grid(row=0, column=5, padx=4, pady=3, sticky="ew")
        self.btn_del.grid(row=0, column=6, padx=(4, 2), pady=3)

    def set_first_light(self, qty, light="A"):
        if not self.light_rows:
            self.add_light_row(first=True)
        self.light_rows[0]["qty_var"].set(str(qty))
        self.light_rows[0]["light_var"].set(str(light))

    def grid(self, row):
        self.frame.grid(row=row, column=0, sticky="ew")

    def destroy(self):
        self.frame.destroy()

    def get(self):
        lights = []
        for holder in self.light_rows:
            qty_text = holder["qty_var"].get().strip()
            light_text = holder["light_var"].get().strip()
            qty = safe_int(qty_text, 0)
            if not qty_text and not light_text:
                continue
            lights.append({
                "qty": qty,
                "light": light_text,
            })
        return {
            "size": self.size_var.get().strip(),
            "lights": lights,
            "qty": sum(x["qty"] for x in lights),
            "start_no": safe_int(self.start_var.get(), 0),
        }


class AuxCutTablePanel(tk.Frame):
    def __init__(self, master=None, mode="cut", initial=None, owner=None):
        # V47: Frame nhúng trực tiếp trong menu PHÂN SỐ CẮT & BIỂU 10.
        super().__init__(master, bg="#eef3f8")
        self.launch_mode = mode
        self.owner = owner
        self.logo_path = ""
        self.size_rows = []

        self._build_style()
        self._build_ui()
        self._add_default_rows()
        # Một bộ dữ liệu duy nhất dùng chung cho hai kiểu xuất.
        if initial:
            self.apply_initial_info(initial, overwrite=True)
        self.set_mode(mode)

    def _build_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("TFrame", background="#eef3f8")
        style.configure("Card.TFrame", background="white")
        style.configure("TLabel", background="#eef3f8", font=("Arial", 10))
        style.configure("Card.TLabel", background="white", font=("Arial", 10))
        style.configure("Header.TLabel", background="#1f4e78", foreground="white", font=("Arial", 10, "bold"), padding=6)
        style.configure("Title.TLabel", background="#eef3f8", foreground="#17365d", font=("Arial", 18, "bold"))
        style.configure("TEntry", padding=5)

    def _build_ui(self):
        # Header fixed
        header = ttk.Frame(self)
        header.pack(fill="x", padx=14, pady=(12, 6))
        if self.launch_mode == "both":
            panel_title = "BIỂU PHÂN BỔ SỐ BÀN CẮT"
        else:
            panel_title = "BIỂU 10" if self.launch_mode == "form10" else "BIỂU PHÂN BỔ SỐ BÀN CẮT"
        ttk.Label(header, text=panel_title, style="Title.TLabel").pack(side="left")

        self.btn_export = tk.Button(
            header, text="XUẤT BẢNG CẮT", command=self.export_excel,
            bg="#1f77b4", fg="white", activebackground="#155d8f",
            font=("Arial", 11, "bold"), padx=18, pady=8, relief="flat"
        )
        self.btn_export.pack(side="right")
        self.btn_export_form10 = tk.Button(
            header, text="XUẤT FORM 10", command=self.export_form10,
            bg="#7b4ab5", fg="white", activebackground="#63389a",
            font=("Arial", 11, "bold"), padx=18, pady=8, relief="flat"
        )
        self.btn_export_form10.pack(side="right", padx=(0, 8))

        # Main scroll area
        outer = ttk.Frame(self)
        outer.pack(fill="both", expand=True, padx=14, pady=(0, 10))
        canvas = tk.Canvas(outer, bg="#eef3f8", highlightthickness=0)
        vbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vbar.set)
        vbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        self.body = ttk.Frame(canvas)
        win = canvas.create_window((0, 0), window=self.body, anchor="nw")

        def on_configure(_e=None):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfigure(win, width=canvas.winfo_width())
        self.body.bind("<Configure>", on_configure)
        canvas.bind("<Configure>", on_configure)
        self.bind("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

        # Info card
        info = ttk.Frame(self.body, style="Card.TFrame", padding=12)
        info.pack(fill="x", pady=(0, 10))
        ttk.Label(info, text="THÔNG TIN CHUNG", style="Header.TLabel").grid(row=0, column=0, columnspan=5, sticky="ew", pady=(0, 10))
        tk.Button(
            info, text="↻ CẬP NHẬT THÔNG TIN", command=self.update_common_from_main,
            bg="#27ae60", fg="white", activebackground="#1e8449",
            font=("Arial", 9, "bold"), padx=10, pady=4, relief="flat"
        ).grid(row=0, column=5, sticky="e", pady=(0, 10))

        self.customer = tk.StringVar(value="TOMMY")
        self.style_code = tk.StringVar(value="7808")
        self.color = tk.StringVar(value="Blue")
        self.batch = tk.StringVar(value="3")
        self.po = tk.StringVar(value="")
        self.season = tk.StringVar(value="")
        self.date = tk.StringVar(value=datetime.now().strftime("%d/%m/%Y"))
        self.round_qty = tk.StringVar(value="50")
        self.last_limit = tk.StringVar(value="75")

        fields = [
            ("KHÁCH HÀNG", self.customer), ("MÃ HÀNG", self.style_code), ("MÀU", self.color),
            ("ĐỢT", self.batch), ("MÙA", self.season), ("PO", self.po),
            ("DATE", self.date), ("SL LÀM TRÒN", self.round_qty), ("GIỚI HẠN BÀN CUỐI", self.last_limit),
        ]
        for i, (label, var) in enumerate(fields):
            r = 1 + i // 3
            c = (i % 3) * 2
            ttk.Label(info, text=label + ":", style="Card.TLabel").grid(row=r, column=c, sticky="w", padx=(0, 6), pady=5)
            ttk.Entry(info, textvariable=var).grid(row=r, column=c + 1, sticky="ew", padx=(0, 16), pady=5)

        note_start = ttk.Label(
            info,
            text="SỐ BẮT ĐẦU: chỉ cần nhập cỡ đầu. Cỡ để trống sẽ tự nối tiếp theo mốc làm tròn; cỡ nào nhập số riêng sẽ bắt đầu lại từ số đó.",
            style="Card.TLabel", foreground="#555555"
        )
        note_start.grid(row=4, column=0, columnspan=6, sticky="w", pady=(6, 4))

        ttk.Label(info, text="LOGO:", style="Card.TLabel").grid(row=5, column=0, sticky="w", pady=5)
        self.logo_label = ttk.Label(info, text="Chưa chọn logo", style="Card.TLabel")
        self.logo_label.grid(row=5, column=1, columnspan=3, sticky="w", pady=5)
        tk.Button(info, text="Chọn logo", command=self.choose_logo, bg="#5bc0de", fg="white", relief="flat", padx=10, pady=4).grid(row=5, column=4, sticky="e", padx=4)
        tk.Button(info, text="Bỏ logo", command=self.clear_logo, bg="#888888", fg="white", relief="flat", padx=10, pady=4).grid(row=5, column=5, sticky="w", padx=4)

        for c in [1, 3, 5]:
            info.columnconfigure(c, weight=1)

        self.update_status_var = tk.StringVar(value="Cập nhật dùng chung cho BẢNG CẮT và FORM 10")
        ttk.Label(info, textvariable=self.update_status_var, style="Card.TLabel",
                  foreground="#1f6aa5").grid(row=6, column=0, columnspan=6, sticky="w", pady=(6, 0))

        # V96: dữ liệu cập nhật từ menu BIỂU CẮT dùng chung cho cả PHÂN SỐ CẮT và BIỂU 10.

        # Sizes card
        card = ttk.Frame(self.body, style="Card.TFrame", padding=12)
        card.pack(fill="both", expand=True)
        top = ttk.Frame(card, style="Card.TFrame")
        top.pack(fill="x")
        ttk.Label(top, text="DANH SÁCH CỠ", style="Header.TLabel").pack(side="left", fill="x", expand=True)
        tk.Button(top, text="+ THÊM CỠ", command=self.add_size_row, bg="#5cb85c", fg="white", relief="flat", padx=12, pady=6).pack(side="right", padx=(8,0))
        tk.Button(top, text="↻ SL + ÁNH...", command=self.open_qty_light_update_dialog,
                  bg="#d68910", fg="white", relief="flat", padx=12, pady=6).pack(side="right", padx=(8,0))
        tk.Button(top, text="↻ CẬP NHẬT CỠ", command=self.update_sizes_from_main,
                  bg="#2980b9", fg="white", relief="flat", padx=12, pady=6).pack(side="right", padx=(8,0))

        self.rows_holder = ttk.Frame(card, style="Card.TFrame")
        self.rows_holder.pack(fill="x", pady=(8, 4))

        cols = ttk.Frame(self.rows_holder, style="Card.TFrame")
        cols.grid(row=0, column=0, sticky="ew")
        headers = [("#", 4), ("CỠ", 14), ("SỐ LƯỢNG ÁNH", 14), ("ÁNH", 10), ("THÊM ÁNH", 9), ("SỐ BẮT ĐẦU", 14), ("", 8)]
        for j, (h, w) in enumerate(headers):
            ttk.Label(cols, text=h, style="Card.TLabel", font=("Arial", 10, "bold"), width=w, anchor="center").grid(row=0, column=j, padx=4, pady=3, sticky="ew")
        cols.columnconfigure(1, weight=1)
        cols.columnconfigure(2, weight=1)
        cols.columnconfigure(3, weight=1)
        cols.columnconfigure(5, weight=1)
        self.rows_holder.columnconfigure(0, weight=1)

        note = ttk.Label(
            card,
            text="Quy tắc: bàn cuối có thể lớn hơn số làm tròn nhưng không vượt giới hạn. Nếu vượt giới hạn thì tách sang bàn tiếp.",
            style="Card.TLabel", foreground="#555555"
        )
        note.pack(anchor="w", pady=(6, 0))

        # Bottom fixed actions
        bottom = ttk.Frame(self)
        bottom.pack(fill="x", padx=14, pady=(0, 12))
        tk.Button(bottom, text="THÊM CỠ", command=self.add_size_row, bg="#5cb85c", fg="white", relief="flat", padx=14, pady=7).pack(side="left")
        tk.Button(bottom, text="XÓA TẤT CẢ CỠ", command=self.clear_sizes, bg="#d9534f", fg="white", relief="flat", padx=14, pady=7).pack(side="left", padx=8)
        self.btn_export_bottom = tk.Button(bottom, text="XUẤT BẢNG CẮT", command=self.export_excel, bg="#1f77b4", fg="white", relief="flat", font=("Arial", 11, "bold"), padx=18, pady=8)
        self.btn_export_bottom.pack(side="right")
        self.btn_export_form10_bottom = tk.Button(bottom, text="XUẤT FORM 10", command=self.export_form10, bg="#7b4ab5", fg="white", relief="flat", font=("Arial", 11, "bold"), padx=18, pady=8)
        self.btn_export_form10_bottom.pack(side="right", padx=(0, 8))

    def _get_main_owner(self):
        owner = getattr(self, "owner", None)
        if owner is None:
            raise ValueError("Không tìm thấy dữ liệu ở menu BIỂU CẮT.")
        try:
            if hasattr(owner, "_sync_po_grid_from_ui"):
                owner._sync_po_grid_from_ui()
        except Exception:
            pass
        return owner

    def update_common_from_main(self, show_message=True):
        """V96: chỉ cập nhật THÔNG TIN CHUNG, không thay cỡ / số lượng / ánh."""
        try:
            owner = self._get_main_owner()
            self.apply_initial_info(owner._collect_aux_initial_info(), overwrite=True)
            msg = "Đã cập nhật THÔNG TIN CHUNG từ BIỂU CẮT"
            if hasattr(self, "update_status_var"):
                self.update_status_var.set(msg)
            if show_message:
                messagebox.showinfo("Cập nhật", msg, parent=self.winfo_toplevel())
        except Exception as e:
            messagebox.showerror("Lỗi cập nhật", str(e), parent=self.winfo_toplevel())

    def update_sizes_from_main(self, show_message=True):
        """V96: cập nhật danh sách CỠ; giữ nguyên SỐ BẮT ĐẦU và SL/ÁNH của cỡ trùng tên."""
        try:
            owner = self._get_main_owner()
            main_sizes = list(getattr(owner, "sizes", []) or [])
            if not main_sizes:
                raise ValueError("Menu BIỂU CẮT chưa có danh sách cỡ.")

            old = {}
            for row in self.size_rows:
                try:
                    name = row.size_var.get().strip()
                    if not name:
                        continue
                    old[name.upper()] = {
                        "start": row.start_var.get().strip(),
                        "lights": [
                            {
                                "qty": h["qty_var"].get().strip(),
                                "light": h["light_var"].get().strip(),
                            }
                            for h in row.light_rows
                        ],
                    }
                except Exception:
                    pass

            for row in list(self.size_rows):
                row.destroy()
            self.size_rows.clear()

            for i, sd in enumerate(main_sizes):
                name = str(sd.get("name", sd.get("key", "")) or "").strip()
                row = self.add_size_row()
                row.size_var.set(name)
                prev = old.get(name.upper())
                if prev:
                    lights = prev.get("lights", []) or []
                    if lights:
                        first = lights[0]
                        row.set_first_light(first.get("qty", ""), first.get("light", ""))
                        for extra in lights[1:]:
                            h = row.add_light_row(first=False)
                            h["qty_var"].set(str(extra.get("qty", "") or ""))
                            h["light_var"].set(str(extra.get("light", "") or ""))
                    row.start_var.set(prev.get("start", ""))
                else:
                    row.set_first_light("", "")
                    row.start_var.set("1" if i == 0 else "")

            self._regrid_rows()
            msg = f"Đã cập nhật {len(main_sizes)} cỡ từ BIỂU CẮT"
            if hasattr(self, "update_status_var"):
                self.update_status_var.set(msg)
            if show_message:
                messagebox.showinfo("Cập nhật cỡ", msg, parent=self.winfo_toplevel())
        except Exception as e:
            messagebox.showerror("Lỗi cập nhật cỡ", str(e), parent=self.winfo_toplevel())

    @staticmethod
    def _distribute_integer_total(total, ordered_lots, weights):
        """Chia tổng nguyên theo trọng số và giữ đúng tổng bằng phương pháp phần dư lớn nhất."""
        total = max(0, int(total or 0))
        lots = list(ordered_lots or [])
        if not lots:
            return {}
        if len(lots) == 1:
            return {lots[0]: total}
        vals = [max(0, int(weights.get(x, 0) or 0)) for x in lots]
        sw = sum(vals)
        if sw <= 0:
            q, r = divmod(total, len(lots))
            return {lot: q + (1 if i < r else 0) for i, lot in enumerate(lots)}
        exact = [total * v / sw for v in vals]
        base = [int(math.floor(x)) for x in exact]
        remain = total - sum(base)
        order = sorted(range(len(lots)), key=lambda i: (-(exact[i] - base[i]), i))
        for i in order[:remain]:
            base[i] += 1
        return {lot: base[i] for i, lot in enumerate(lots)}

    def _set_row_lights(self, row, lot_qty_pairs):
        pairs = [(str(lot or ""), max(0, int(qty or 0))) for lot, qty in (lot_qty_pairs or [])]
        if not pairs:
            pairs = [("", 0)]
        while len(row.light_rows) > 1:
            row.remove_light_row(row.light_rows[-1])
        row.set_first_light(pairs[0][1], pairs[0][0])
        for lot, qty in pairs[1:]:
            h = row.add_light_row(first=False)
            h["qty_var"].set(str(qty))
            h["light_var"].set(lot)

    def open_qty_light_update_dialog(self):
        """V96: chọn PO lấy số lượng và chọn LOT/ÁNH cần đưa sang PHÂN SỐ CẮT / BIỂU 10."""
        try:
            owner = self._get_main_owner()
        except Exception as e:
            messagebox.showerror("Lỗi", str(e), parent=self.winfo_toplevel())
            return

        po_names = [str(p.get("po", "") or "").strip() for p in getattr(owner, "po_list", []) or []]
        po_names = [x for x in po_names if x]
        if not po_names:
            messagebox.showwarning("Chưa có PO", "Hãy nhập PO ở menu BIỂU CẮT trước.", parent=self.winfo_toplevel())
            return

        fabrics = list(getattr(owner, "fabric_list", []) or [])
        fabric_names = [str(f.get("name", "") or "").strip() for f in fabrics if str(f.get("name", "") or "").strip()]

        top = tk.Toplevel(self.winfo_toplevel())
        top.title("CẬP NHẬT SỐ LƯỢNG + ÁNH")
        top.transient(self.winfo_toplevel())
        top.grab_set()
        top.geometry("760x560")
        top.minsize(680, 480)
        top.configure(bg="#eef3f8")

        tk.Label(top, text="CẬP NHẬT SỐ LƯỢNG + ÁNH TỪ BIỂU CẮT",
                 font=("Arial", 14, "bold"), bg="#eef3f8", fg="#17365d").pack(pady=(14, 8))
        tk.Label(top, text="Chọn PO dùng để lấy SỐ LƯỢNG và chọn LOT dùng làm ÁNH. "
                                "Nếu chọn nhiều ÁNH, số lượng được chia theo tỷ lệ phân LOT hiện tại của loại vải nguồn.",
                 font=("Arial", 9), bg="#eef3f8", fg="#555555", wraplength=700, justify="left").pack(padx=18, anchor="w")

        source_frame = tk.Frame(top, bg="white", bd=1, relief="solid")
        source_frame.pack(fill="x", padx=18, pady=(10, 8))
        tk.Label(source_frame, text="Loại vải nguồn:", font=("Arial", 10, "bold"), bg="white").pack(side="left", padx=10, pady=8)
        source_var = tk.StringVar(value="")
        source_combo = ttk.Combobox(source_frame, textvariable=source_var, values=fabric_names,
                                    state="readonly" if fabric_names else "disabled", width=36)
        source_combo.pack(side="left", padx=(0, 10), pady=8)
        preferred = next((n for n in fabric_names if "CHÍNH" in n.upper() or "CHINH" in n.upper()), "")
        if not preferred and fabric_names:
            preferred = fabric_names[0]
        source_var.set(preferred)

        body = tk.Frame(top, bg="#eef3f8")
        body.pack(fill="both", expand=True, padx=18, pady=4)
        po_box = tk.LabelFrame(body, text="PO LẤY SỐ LƯỢNG", font=("Arial", 10, "bold"), bg="white", padx=8, pady=8)
        lot_box = tk.LabelFrame(body, text="ÁNH / LOT CẦN CẬP NHẬT", font=("Arial", 10, "bold"), bg="white", padx=8, pady=8)
        po_box.pack(side="left", fill="both", expand=True, padx=(0, 5))
        lot_box.pack(side="left", fill="both", expand=True, padx=(5, 0))

        po_vars = {name: tk.BooleanVar(value=True) for name in po_names}
        po_all_var = tk.BooleanVar(value=True)
        def set_all_pos():
            v = bool(po_all_var.get())
            for vv in po_vars.values(): vv.set(v)
        tk.Checkbutton(po_box, text="TẤT CẢ PO", variable=po_all_var, command=set_all_pos,
                       bg="white", font=("Arial", 9, "bold")).grid(row=0, column=0, columnspan=3, sticky="w")
        for i, name in enumerate(po_names):
            tk.Checkbutton(po_box, text=name, variable=po_vars[name], bg="white", anchor="w").grid(
                row=1 + i // 3, column=i % 3, sticky="w", padx=4, pady=2)

        lot_vars = {}
        lot_all_var = tk.BooleanVar(value=True)
        lot_checks_holder = tk.Frame(lot_box, bg="white")
        lot_checks_holder.pack(fill="both", expand=True)

        def available_lots():
            fname = source_var.get().strip()
            fabric = next((f for f in fabrics if str(f.get("name", "") or "").strip() == fname), None)
            names = []
            if fabric is not None:
                try:
                    for x in owner._fabric_lot_names(fabric):
                        x = str(x or "").strip()
                        if x and x not in names: names.append(x)
                except Exception:
                    pass
            for gr in getattr(owner, "global_lot_rows", []) or []:
                x = str(gr.get("lot", "") or "").strip()
                if x and x not in names: names.append(x)
            if not names:
                names = ["CHƯA CÓ LOT"]
            return names

        def rebuild_lots(event=None):
            for w in lot_checks_holder.winfo_children(): w.destroy()
            lot_vars.clear()
            names = available_lots()
            lot_all_var.set(True)
            def set_all_lots():
                v = bool(lot_all_var.get())
                for vv in lot_vars.values(): vv.set(v)
            tk.Checkbutton(lot_checks_holder, text="TẤT CẢ ÁNH", variable=lot_all_var,
                           command=set_all_lots, bg="white", font=("Arial", 9, "bold")).grid(
                               row=0, column=0, columnspan=3, sticky="w")
            for i, name in enumerate(names):
                vv = tk.BooleanVar(value=True)
                lot_vars[name] = vv
                tk.Checkbutton(lot_checks_holder, text=name, variable=vv, bg="white", anchor="w").grid(
                    row=1 + i // 3, column=i % 3, sticky="w", padx=4, pady=2)
        source_combo.bind('<<ComboboxSelected>>', rebuild_lots)
        rebuild_lots()

        def apply_update():
            selected_pos = [n for n, v in po_vars.items() if bool(v.get())]
            selected_lots = [n for n, v in lot_vars.items() if bool(v.get())]
            if not selected_pos:
                messagebox.showwarning("Chưa chọn PO", "Hãy tích ít nhất 1 PO.", parent=top); return
            if not selected_lots:
                messagebox.showwarning("Chưa chọn ÁNH", "Hãy tích ít nhất 1 ÁNH/LOT.", parent=top); return

            # Cập nhật cỡ trước nhưng giữ số bắt đầu nếu cỡ đã có.
            self.update_sizes_from_main(show_message=False)
            row_by_name = {r.size_var.get().strip().upper(): r for r in self.size_rows}
            size_defs = list(getattr(owner, "sizes", []) or [])
            po_map = {str(p.get("po", "") or "").strip(): p for p in getattr(owner, "po_list", []) or []}

            targets = {}
            for sd in size_defs:
                key = sd.get("key")
                name = str(sd.get("name", key) or key).strip()
                targets[key] = sum(max(0, int((po_map.get(pn) or {}).get(key, 0) or 0)) for pn in selected_pos)

            # Lấy trọng số phân LOT thực tế của loại vải nguồn (nếu có).
            weights = {sd.get("key"): {lot: 0 for lot in selected_lots} for sd in size_defs}
            source_name = source_var.get().strip()
            if source_name:
                try:
                    results, err = owner.calculate_cutting_plan()
                    if not err:
                        res = next((r for r in (results or [])
                                    if str(r.get("fabric", {}).get("name", "") or "").strip() == source_name), None)
                        if res:
                            for tb in (res.get("preview_tables") or res.get("cutting_tables") or []):
                                lot = str(tb.get("lot", "") or "").strip() or "CHƯA CÓ LOT"
                                if lot not in selected_lots:
                                    continue
                                for key, qty in (tb.get("sizes", {}) or {}).items():
                                    if key in weights:
                                        weights[key][lot] = weights[key].get(lot, 0) + max(0, int(qty or 0))
                except Exception:
                    pass

            for sd in size_defs:
                key = sd.get("key")
                name = str(sd.get("name", key) or key).strip()
                row = row_by_name.get(name.upper())
                if row is None:
                    continue
                allocation = self._distribute_integer_total(targets.get(key, 0), selected_lots, weights.get(key, {}))
                self._set_row_lights(row, [(lot, allocation.get(lot, 0)) for lot in selected_lots])

            self.po.set(" + ".join(selected_pos))
            msg = f"Đã cập nhật SL của {len(selected_pos)} PO | {len(selected_lots)} ÁNH"
            if hasattr(self, "update_status_var"):
                self.update_status_var.set(msg)
            try: top.destroy()
            except Exception: pass
            messagebox.showinfo("Cập nhật hoàn tất", msg, parent=self.winfo_toplevel())

        buttons = tk.Frame(top, bg="#eef3f8")
        buttons.pack(fill="x", padx=18, pady=(8, 14))
        tk.Button(buttons, text="HỦY", command=top.destroy, bg="#7f8c8d", fg="white",
                  relief="flat", padx=18, pady=7).pack(side="right")
        tk.Button(buttons, text="CẬP NHẬT", command=apply_update, bg="#27ae60", fg="white",
                  font=("Arial", 10, "bold"), relief="flat", padx=22, pady=7).pack(side="right", padx=(0, 8))

    def sync_from_main(self):
        """Tương thích lệnh cũ: mở hộp chọn PO + ÁNH thay vì đồng bộ toàn bộ tự động."""
        self.open_qty_light_update_dialog()

    def set_mode(self, mode="both"):
        """V47: một panel dùng chung. mode='both' hiện đồng thời XUẤT BẢNG CẮT và XUẤT FORM 10."""
        self.launch_mode = mode

        # Ẩn trước để pack lại đúng thứ tự, tránh trùng nút khi đổi mode.
        for b in (getattr(self, "btn_export", None), getattr(self, "btn_export_form10", None),
                  getattr(self, "btn_export_bottom", None), getattr(self, "btn_export_form10_bottom", None)):
            if b is not None:
                try:
                    b.pack_forget()
                except Exception:
                    pass

        if mode == "form10":
            if hasattr(self, "btn_export_form10"):
                self.btn_export_form10.pack(side="right", padx=(0, 8))
            if hasattr(self, "btn_export_form10_bottom"):
                self.btn_export_form10_bottom.pack(side="right", padx=(0, 8))
        elif mode == "cut":
            if hasattr(self, "btn_export"):
                self.btn_export.pack(side="right")
            if hasattr(self, "btn_export_bottom"):
                self.btn_export_bottom.pack(side="right")
        else:
            # Giống bản cũ: cùng một dữ liệu, hai nút xuất cùng xuất hiện.
            if hasattr(self, "btn_export"):
                self.btn_export.pack(side="right")
            if hasattr(self, "btn_export_form10"):
                self.btn_export_form10.pack(side="right", padx=(0, 8))
            if hasattr(self, "btn_export_bottom"):
                self.btn_export_bottom.pack(side="right")
            if hasattr(self, "btn_export_form10_bottom"):
                self.btn_export_form10_bottom.pack(side="right", padx=(0, 8))

    def apply_initial_info(self, initial, overwrite=False):
        """Điền thông tin chung từ TÁC NGHIỆP CẮT vào công cụ ghép; không đụng dữ liệu cỡ đã nhập."""
        if not initial:
            return
        mapping = {
            "customer": getattr(self, "customer", None),
            "style_code": getattr(self, "style_code", None),
            "color": getattr(self, "color", None),
            "batch": getattr(self, "batch", None),
            "season": getattr(self, "season", None),
            "date": getattr(self, "date", None),
            "po": getattr(self, "po", None),
        }
        for key, var in mapping.items():
            if var is None:
                continue
            value = str(initial.get(key, "") or "").strip()
            if not value:
                continue
            try:
                if overwrite or not str(var.get() or "").strip():
                    var.set(value)
            except Exception:
                pass

        logo = str(initial.get("logo", "") or "").strip()
        if logo and os.path.exists(logo):
            self.logo_path = logo
            try:
                self.logo_label.configure(text=os.path.basename(logo))
            except Exception:
                pass

    def refresh_source_fabrics(self):
        """V43: cập nhật danh sách loại vải có thể dùng làm nguồn LOT/ÁNH."""
        names = []
        owner = getattr(self, "owner", None)
        if owner is not None:
            for f in getattr(owner, "fabric_list", []) or []:
                name = str(f.get("name", "") or "").strip()
                if name and name not in names:
                    names.append(name)
        try:
            self.source_fabric_combo["values"] = names
        except Exception:
            pass
        current = str(getattr(self, "source_fabric_var", tk.StringVar()).get() or "").strip()
        if current in names:
            return
        preferred = next((n for n in names if "CHÍNH" in n.upper() or "CHINH" in n.upper()), "")
        if not preferred and names:
            preferred = names[0]
        if preferred:
            self.source_fabric_var.set(preferred)

    def _replace_size_rows_from_sync(self, size_payloads):
        """Thay danh sách cỡ bằng dữ liệu đã liên kết, giữ số bắt đầu cũ nếu trùng tên cỡ."""
        old_starts = {}
        for row in self.size_rows:
            try:
                name = row.size_var.get().strip().upper()
                if name:
                    old_starts[name] = row.start_var.get().strip()
            except Exception:
                pass
        for row in list(self.size_rows):
            row.destroy()
        self.size_rows.clear()

        for idx, payload in enumerate(size_payloads):
            row = self.add_size_row()
            name = str(payload.get("size", "") or "").strip()
            row.size_var.set(name)
            lights = payload.get("lights", []) or []
            if not lights:
                lights = [{"qty": int(payload.get("qty", 0) or 0), "light": "CHƯA CÓ LOT"}]
            # Xóa các dòng ánh mặc định thừa và ghi dòng đầu.
            first = lights[0]
            row.set_first_light(int(first.get("qty", 0) or 0), str(first.get("light", "") or ""))
            for extra in lights[1:]:
                h = row.add_light_row(first=False)
                h["qty_var"].set(str(int(extra.get("qty", 0) or 0)))
                h["light_var"].set(str(extra.get("light", "") or ""))

            old = old_starts.get(name.upper(), "")
            if old:
                row.start_var.set(old)
            elif idx == 0:
                row.start_var.set("1")
            else:
                row.start_var.set("")
        self._regrid_rows()

    def _add_default_rows(self):
        defaults = [("XS", 204, "A", 1), ("S", 1, "A", ""), ("M", 1152, "A", ""), ("L", 1152, "A", "")]
        for s, q, a, st in defaults:
            row = self.add_size_row()
            row.size_var.set(s)
            row.set_first_light(q, a)
            row.start_var.set(str(st))

    def add_size_row(self):
        row = SizeRow(self.rows_holder, len(self.size_rows) + 1, self.delete_size_row)
        self.size_rows.append(row)
        self._regrid_rows()
        return row

    def delete_size_row(self, row):
        if row in self.size_rows:
            self.size_rows.remove(row)
            row.destroy()
            self._regrid_rows()

    def clear_sizes(self):
        if not messagebox.askyesno("Xác nhận", "Xóa toàn bộ danh sách cỡ?"):
            return
        for row in self.size_rows:
            row.destroy()
        self.size_rows.clear()
        self.add_size_row()

    def _regrid_rows(self):
        for i, row in enumerate(self.size_rows, start=1):
            row.index_var.set(str(i))
            row.grid(i)

    def choose_logo(self):
        path = filedialog.askopenfilename(
            title="Chọn logo",
            filetypes=[("Image", "*.png *.jpg *.jpeg *.bmp"), ("All files", "*.*")]
        )
        if path:
            self.logo_path = path
            self.logo_label.configure(text=os.path.basename(path))

    def clear_logo(self):
        self.logo_path = ""
        self.logo_label.configure(text="Chưa chọn logo")

    def _aux_project_logo_payload(self):
        """V113: nhúng logo riêng của menu PHÂN SỐ CẮT / FORM 10 vào dự án."""
        path = str(getattr(self, 'logo_path', '') or '').strip()
        if not path or not os.path.isfile(path):
            return None
        try:
            if os.path.getsize(path) > 8 * 1024 * 1024:
                return {'name': os.path.basename(path), 'path': path, 'embedded': False}
            with open(path, 'rb') as f:
                raw = f.read()
            return {
                'name': os.path.basename(path),
                'path': path,
                'embedded': True,
                'data_base64': base64.b64encode(raw).decode('ascii'),
            }
        except Exception:
            return {'name': os.path.basename(path), 'path': path, 'embedded': False}

    def get_project_state(self):
        """V113: lấy TRẠNG THÁI THÔ của menu dùng chung BẢNG CẮT + FORM 10.

        Không gọi collect_data() để vẫn lưu được cả khi người dùng đang nhập dở
        hoặc còn ô trống. Khi mở lại dự án, nội dung các ô được trả về đúng như lúc lưu.
        """
        rows = []
        for row in list(getattr(self, 'size_rows', []) or []):
            try:
                lights = []
                for holder in list(getattr(row, 'light_rows', []) or []):
                    lights.append({
                        'qty': str(holder['qty_var'].get()),
                        'light': str(holder['light_var'].get()),
                    })
                rows.append({
                    'size': str(row.size_var.get()),
                    'start': str(row.start_var.get()),
                    'lights': lights,
                })
            except Exception:
                continue

        def _v(name, default=''):
            var = getattr(self, name, None)
            try:
                return str(var.get()) if var is not None else str(default)
            except Exception:
                return str(default)

        return {
            'version': 1,
            'launch_mode': str(getattr(self, 'launch_mode', 'both') or 'both'),
            'customer': _v('customer'),
            'style_code': _v('style_code'),
            'color': _v('color'),
            'batch': _v('batch'),
            'po': _v('po'),
            'season': _v('season'),
            'date': _v('date'),
            'round_qty': _v('round_qty', '50'),
            'last_limit': _v('last_limit', '75'),
            'rows': rows,
            'logo': self._aux_project_logo_payload(),
        }

    def _restore_aux_project_logo(self, logo_info):
        """V113: khôi phục logo riêng của BẢNG CẮT / FORM 10."""
        if not isinstance(logo_info, dict):
            return
        path = str(logo_info.get('path', '') or '').strip()
        restored = None
        try:
            if logo_info.get('embedded') and logo_info.get('data_base64'):
                name = str(logo_info.get('name', '') or 'aux_project_logo.png')
                ext = os.path.splitext(name)[1].lower()
                if ext not in ('.png', '.jpg', '.jpeg', '.bmp', '.webp'):
                    ext = '.png'
                owner = getattr(self, 'owner', None)
                if owner is not None and hasattr(owner, '_logo_config_dir'):
                    folder = owner._logo_config_dir()
                else:
                    folder = os.path.dirname(os.path.abspath(__file__))
                restored = os.path.join(folder, 'project_aux_logo' + ext)
                raw = base64.b64decode(str(logo_info.get('data_base64')).encode('ascii'))
                with open(restored, 'wb') as f:
                    f.write(raw)
            elif path and os.path.isfile(path):
                restored = path
        except Exception:
            restored = path if path and os.path.isfile(path) else None
        if restored and os.path.isfile(restored):
            self.logo_path = restored
            try:
                self.logo_label.configure(text=str(logo_info.get('name', '') or os.path.basename(restored)))
            except Exception:
                pass

    def apply_project_state(self, state):
        """V113: nạp lại dữ liệu dùng chung của XUẤT BẢNG CẮT và XUẤT FORM 10."""
        if not isinstance(state, dict):
            return

        mapping = {
            'customer': 'customer',
            'style_code': 'style_code',
            'color': 'color',
            'batch': 'batch',
            'po': 'po',
            'season': 'season',
            'date': 'date',
            'round_qty': 'round_qty',
            'last_limit': 'last_limit',
        }
        for key, attr in mapping.items():
            var = getattr(self, attr, None)
            if var is None:
                continue
            try:
                var.set(str(state.get(key, '') if state.get(key, '') is not None else ''))
            except Exception:
                pass

        # Xóa các dòng mặc định rồi dựng lại đúng số cỡ / số ánh đã lưu.
        for row in list(getattr(self, 'size_rows', []) or []):
            try:
                row.destroy()
            except Exception:
                pass
        self.size_rows.clear()

        for item in state.get('rows') or []:
            if not isinstance(item, dict):
                continue
            row = self.add_size_row()
            row.size_var.set(str(item.get('size', '') or ''))
            row.start_var.set(str(item.get('start', '') or ''))
            lights = item.get('lights') or []
            if not isinstance(lights, list):
                lights = []
            if not lights:
                lights = [{'qty': '', 'light': ''}]

            first = lights[0] if isinstance(lights[0], dict) else {}
            row.set_first_light(
                str(first.get('qty', '') if first.get('qty', '') is not None else ''),
                str(first.get('light', '') if first.get('light', '') is not None else '')
            )
            for extra in lights[1:]:
                if not isinstance(extra, dict):
                    continue
                h = row.add_light_row(first=False)
                h['qty_var'].set(str(extra.get('qty', '') if extra.get('qty', '') is not None else ''))
                h['light_var'].set(str(extra.get('light', '') if extra.get('light', '') is not None else ''))

        # Dự án có thể được lưu khi danh sách cỡ trống; vẫn giữ một dòng để tiếp tục nhập.
        if not self.size_rows:
            self.add_size_row()
        self._regrid_rows()

        try:
            self.set_mode(str(state.get('launch_mode', 'both') or 'both'))
        except Exception:
            self.set_mode('both')
        self._restore_aux_project_logo(state.get('logo'))
        if hasattr(self, 'update_status_var'):
            self.update_status_var.set('Đã khôi phục dữ liệu BẢNG CẮT + FORM 10 từ dự án')

    def collect_data(self):
        sizes = []
        for row in self.size_rows:
            d = row.get()
            if not d["size"] and d["qty"] == 0:
                continue
            if not d["size"]:
                raise ValueError("Có dòng chưa nhập tên cỡ.")
            if not d["lights"]:
                raise ValueError(f"Cỡ {d['size']} chưa có Ánh / số lượng.")
            for light in d["lights"]:
                if light["qty"] <= 0:
                    raise ValueError(f"Cỡ {d['size']} - Ánh {light['light']} phải có số lượng > 0.")
            if d["qty"] <= 0:
                raise ValueError(f"Cỡ {d['size']} phải có tổng số lượng > 0.")
            sizes.append(d)
        if not sizes:
            raise ValueError("Chưa có cỡ để xuất.")

        round_qty = safe_int(self.round_qty.get(), 0)
        last_limit = safe_int(self.last_limit.get(), 0)
        if round_qty <= 0:
            raise ValueError("Số lượng làm tròn phải > 0.")
        if last_limit < round_qty:
            raise ValueError("Giới hạn bàn cuối phải >= số lượng làm tròn.")

        # Logic số bắt đầu không cần chế độ chọn:
        # - Cỡ đầu tiên phải có số bắt đầu.
        # - Cỡ nào để trống sẽ tự bắt đầu sau mốc làm tròn kế tiếp của cỡ trước.
        #   Ví dụ cỡ trước 1-252, làm tròn 50 -> cỡ kế tiếp bắt đầu 301.
        # - Nếu người dùng nhập số bắt đầu ở bất kỳ cỡ nào, số đó được ưu tiên;
        #   các cỡ để trống phía sau lại tiếp tục tự tính từ cỡ vừa nhập đó.
        if sizes[0]["start_no"] <= 0:
            raise ValueError(f"Cỡ đầu tiên ({sizes[0]['size']}) phải nhập Số bắt đầu > 0.")

        current_start = sizes[0]["start_no"]
        for i, d in enumerate(sizes):
            if i == 0:
                d["start_no"] = current_start
            elif d["start_no"] > 0:
                current_start = d["start_no"]
            else:
                d["start_no"] = current_start

            # Trong cùng một cỡ, Ánh sau được làm tròn theo chục:
            # ví dụ Ánh A kết thúc 204 -> Ánh B bắt đầu 211.
            # Vì có thể phát sinh khoảng trống giữa các Ánh, số kết thúc của cỡ
            # phải tính theo từng Ánh thay vì chỉ start + tổng SL - 1.
            end_no = size_end_with_lights(d["start_no"], d["lights"], 10)
            current_start = int(math.ceil(end_no / round_qty) * round_qty) + 1

        return {
            "customer": self.customer.get().strip(),
            "style_code": self.style_code.get().strip(),
            "color": self.color.get().strip(),
            "batch": self.batch.get().strip(),
            "po": self.po.get().strip(),
            "season": self.season.get().strip(),
            "date": self.date.get().strip(),
            "round_qty": round_qty,
            "last_limit": last_limit,
            "sizes": sizes,
            "total": sum(x["qty"] for x in sizes),
            "logo": self.logo_path,
        }

    def export_excel(self):
        if Workbook is None:
            messagebox.showerror("Thiếu thư viện", "Chưa có openpyxl.\nMở CMD và chạy: pip install openpyxl pillow")
            return
        try:
            data = self.collect_data()
        except ValueError as e:
            messagebox.showwarning("Kiểm tra dữ liệu", str(e))
            return

        path = filedialog.asksaveasfilename(
            title="Lưu file Excel",
            defaultextension=".xlsx",
            filetypes=[("Excel Workbook", "*.xlsx")],
            initialfile=_suggest_excel_filename("PHÂN SỐ CẮT", data.get("style_code", ""), data.get("batch", ""))
        )
        if not path:
            return

        try:
            self.build_workbook(data, path)
            messagebox.showinfo("Thành công", f"Đã xuất file Excel:\n{path}")
        except Exception as e:
            messagebox.showerror("Lỗi xuất Excel", str(e))

    def export_form10(self):
        """Xuất BIỂU GIAO NHẬN HÀNG - FORM 10 từ cùng dữ liệu bảng cắt."""
        if Workbook is None:
            messagebox.showerror("Thiếu thư viện", "Chưa có openpyxl.\nMở CMD và chạy: pip install openpyxl pillow")
            return
        try:
            data = self.collect_data()
        except ValueError as e:
            messagebox.showwarning("Kiểm tra dữ liệu", str(e))
            return

        path = filedialog.asksaveasfilename(
            title="Lưu GIAO NHAN HANG",
            defaultextension=".xlsx",
            filetypes=[("Excel Workbook", "*.xlsx")],
            initialfile=_suggest_excel_filename("FORM 10", data.get("style_code", ""), data.get("batch", ""))
        )
        if not path:
            return

        try:
            self.build_form10_workbook(data, path)
            messagebox.showinfo("Thành công", f"Đã xuất FORM 10:\n{path}")
        except Exception as e:
            messagebox.showerror("Lỗi xuất FORM 10", str(e))

    def build_form10_workbook(self, data, path):
        """
        Tạo FORM 10 theo cùng logic sắp xếp với FORM BẢNG CẮT:
        - A4 ngang, in cố định 85%; phần nội dung bảng kết thúc ở hàng 41.
        - Trong cùng một cột có thể xếp nhiều cỡ/Ánh nếu còn đủ chiều cao.
        - Nếu khối kế tiếp không còn vừa toàn bộ phần trống thì chuyển sang cột bên cạnh.
        - Nếu một khối dài thì chỉ ngắt theo cụm 10 dòng số thứ tự; không để 1-2 dòng lẻ ở cuối cột.
        - Khi hết các cột ngang của một trang thì tự sang trang A4 kế tiếp.
        - Số thứ tự vẫn lấy liên tục từ dữ liệu bảng cắt, mỗi dòng FORM 10 là 10 sản phẩm.
        """
        wb = Workbook()
        ws = wb.active
        ws.title = "FORM 10"
        ws.sheet_view.showGridLines = True

        # FORM 10: A4 ngang, sát mép. Ở mức in 84%, hàng 41 là đáy vùng nội dung.
        ws.page_setup.orientation = "landscape"
        ws.page_setup.paperSize = ws.PAPERSIZE_A4
        # FORM 10 dùng tỉ lệ in cố định 85% theo yêu cầu.
        # Không dùng Fit-to-Width vì Excel sẽ tự đổi % tùy máy in.
        ws.page_setup.scale = 82
        ws.page_setup.fitToWidth = None
        ws.page_setup.fitToHeight = None
        ws.sheet_properties.pageSetUpPr.fitToPage = False
        ws.page_margins.left = 0.05
        ws.page_margins.right = 0.05
        ws.page_margins.top = 0.10
        ws.page_margins.bottom = 0.10
        ws.page_margins.header = 0.0
        ws.page_margins.footer = 0.0
        ws.print_options.horizontalCentered = True

        # FORM 10 rộng 10 cột/khối:
        # SL | Số thứ tự (3 cột) | TT (2) | TS (2) | TAY (2).
        # Xếp 3 khối trên một hàng A4, chừa 1 cột làm khoảng cách.
        starts = [1, 12, 23]  # A, L, W
        block_width = 10
        first_data_top = 5
        fixed_page_bottom_row = 40
        page_body_rows = fixed_page_bottom_row - first_data_top + 1
        page_bottom_offset = page_body_rows - 1
        gap_rows = 2

        # Chiều cao dòng cố định để giới hạn A4 ổn định.
        title_h = 22
        head_h = 20
        data_h = 18
        blank_h = 15
        for r in range(1, 4):
            ws.row_dimensions[r].height = 20
        ws.row_dimensions[1].height = 25

        # Giữ 3 khối nằm trọn 1 trang A4 ngang ở mức in 85%.
        # 6 cột NHẬN/PHÁT khoảng 45 px/cột; các cột còn lại thu gọn vừa đủ.
        # SL | số đầu | - | số cuối | TT(N/P) | TS(N/P) | TAY(N/P)
        block_widths = [4.2, 6.5, 1.6, 6.5, 6.1, 6.1, 6.1, 6.1, 6.1, 6.1]
        for c0 in starts:
            for off, w in enumerate(block_widths):
                ws.column_dimensions[get_column_letter(c0 + off)].width = w
            # cột khoảng cách giữa các khối
            if c0 + block_width <= 30:
                ws.column_dimensions[get_column_letter(c0 + block_width)].width = 2.0

        thin = Side(style="thin", color="000000")
        medium = Side(style="medium", color="000000")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        title_font = Font(name="Times New Roman", size=18, bold=True)
        info_font = Font(name="Times New Roman", size=11, bold=True)
        block_title_font = Font(name="Times New Roman", size=12, bold=True)
        head_font = Font(name="Times New Roman", size=10, bold=True)
        data_font = Font(name="Times New Roman", size=10)
        # Màu tiêu đề khối FORM 10: CỠ / SL / ÁNH.
        # Dùng xanh nhạt để dễ phân biệt nhưng vẫn in rõ trên A4.
        block_title_fill = PatternFill("solid", fgColor="B8CCE4")

        def draw_page_header(page_top):
            """Vẽ phần thông tin chung ở đầu mỗi trang A4."""
            base = page_top - 4
            ws.merge_cells(start_row=base, start_column=8, end_row=base, end_column=20)
            c = ws.cell(base, 8, "BIỂU GIAO NHẬN HÀNG")
            c.font = title_font
            c.alignment = Alignment(horizontal="center", vertical="center")

            items = [
                (base + 1, 4, f"KHÁCH HÀNG : {data['customer']}"),
                (base + 1, 12, f"ĐỢT : {data['batch']}"),
                (base + 1, 18, f"MÙA : {data.get('season', '')}"),
                (base + 1, 27, f"PO : {data['po']}"),
                (base + 2, 4, f"MÃ HÀNG : {data['style_code']}"),
                (base + 2, 13, f"MÀU : {data['color']}"),
                (base + 2, 20, f"TỔNG SỐ LƯỢNG : {data['total']}"),
            ]
            for rr, cc, vv in items:
                cell = ws.cell(rr, cc, vv)
                cell.font = info_font
                cell.alignment = Alignment(vertical="center")

        draw_page_header(first_data_top)

        # Trạng thái đóng gói giống bảng cắt.
        page_index = 0
        slot = 0
        page_top = first_data_top
        page_bottom = page_top + page_bottom_offset
        cursor_row = page_top
        last_used_row = 3
        page_break_rows = []
        # Các dòng trống được chèn sau mỗi 10 dòng số thứ tự.
        # Excel chỉ cho đặt chiều cao theo CẢ HÀNG, không theo từng khối cột,
        # nên sẽ chỉ thu xuống 12 px khi hàng đó không chứa dữ liệu của khối khác.
        form10_blank_rows = set()

        def new_slot():
            nonlocal page_index, slot, page_top, page_bottom, cursor_row
            slot += 1
            if slot >= len(starts):
                slot = 0
                page_index += 1
                page_top = first_data_top + page_index * page_body_rows
                page_bottom = page_top + page_bottom_offset
                cursor_row = page_top
                page_break_rows.append(page_top)
            else:
                cursor_row = page_top

        def rows_for_light(qty):
            return int(math.ceil(qty / 10.0))

        def full_block_capacity(start_row):
            # 3 dòng tiêu đề, phần còn lại dành cho các dòng số.
            return max(0, page_bottom - (start_row + 3) + 1)

        def rows_fit_from(start_row, data_count):
            return start_row + 3 + data_count - 1 <= page_bottom

        def make_form10_rows(qty, seq_start):
            """
            Tạo các dòng FORM 10. Sau mỗi 10 dòng số thứ tự, nếu vẫn còn dữ liệu
            thì chèn 1 dòng trống. Dòng trống được đánh dấu bằng None.
            """
            rows = []
            remain = qty
            num = seq_start
            data_row_count = 0
            while remain > 0:
                q = min(10, remain)
                end_num = num + q - 1
                rows.append((q, num, end_num))
                data_row_count += 1
                num = end_num + 1
                remain -= q
                if data_row_count % 10 == 0 and remain > 0:
                    rows.append(None)
            return rows

        def split_row_groups(rows):
            """Chia dữ liệu thành các cụm tối đa 10 dòng số thứ tự.
            Dòng None (khoảng cách sau 10 dòng) luôn đi cùng cụm 10 dòng PHÍA TRƯỚC.
            Nhờ vậy khi một phần được chuyển sang cột mới sẽ không bao giờ có
            dòng trống đầu tiên ngay dưới hàng NHẬN/PHÁT.
            """
            groups = []
            cur = []
            data_count = 0
            for row in rows:
                if row is None:
                    # Khoảng cách sau 10 dòng phải thuộc cụm vừa kết thúc,
                    # không được trở thành dòng đầu của cụm tiếp theo.
                    if cur:
                        cur.append(None)
                    elif groups:
                        groups[-1].append(None)
                    continue

                cur.append(row)
                data_count += 1
                if data_count == 10:
                    groups.append(cur)
                    cur = []
                    data_count = 0

            if cur:
                groups.append(cur)
            return groups

        def take_groups_that_fit(groups, capacity):
            """Lấy số cụm 10 dòng lớn nhất còn vừa cột hiện tại.
            Không tách 1-2 dòng lẻ của cụm kế tiếp xuống cuối cột.
            """
            if capacity <= 0 or not groups:
                return [], 0
            chosen = []
            used = 0
            for group in groups:
                glen = len(group)
                if used + glen > capacity:
                    break
                chosen.extend(group)
                used += glen
            return chosen, used

        def draw_form10_block(size_name, light_name, light_total_qty, rows_data,
                              r0, c0, continued=False):
            nonlocal last_used_row
            c1 = c0 + block_width - 1
            # Dòng dữ liệu đầu tiên nằm ngay dưới hàng tiêu đề, không chèn dòng cách ở đầu khối.
            data_start = r0 + 3
            data_end = data_start + len(rows_data) - 1

            ws.row_dimensions[r0].height = title_h
            ws.row_dimensions[r0 + 1].height = head_h
            ws.row_dimensions[r0 + 2].height = head_h
            for rr in range(data_start, data_end + 1):
                ws.row_dimensions[rr].height = data_h

            # Dòng tiêu đề cỡ / SL / ánh. Viết tắt SL và bỏ dấu "-" để tránh đè chữ.
            # Tiêu đề chia theo tỉ lệ mới: CỠ 4 cột | SL 3 cột | ÁNH 3 cột.
            ws.merge_cells(start_row=r0, start_column=c0, end_row=r0, end_column=c0 + 3)
            ws.cell(r0, c0, f"CỠ {size_name}" + (" (tiếp)" if continued else ""))
            ws.merge_cells(start_row=r0, start_column=c0 + 4, end_row=r0, end_column=c0 + 6)
            ws.cell(r0, c0 + 4, f"SL: {light_total_qty}")
            ws.merge_cells(start_row=r0, start_column=c0 + 7, end_row=r0, end_column=c1)
            ws.cell(r0, c0 + 7, f"ÁNH {light_name}" if str(light_name).strip() else "")

            for cc in range(c0, c1 + 1):
                ws.cell(r0, cc).font = block_title_font
                ws.cell(r0, cc).alignment = Alignment(horizontal="center", vertical="center")
                ws.cell(r0, cc).fill = block_title_fill

            # Chia rõ 3 ô tiêu đề CỠ | SL | ÁNH bằng viền đậm.
            # Các ô merge vẫn được viền lại toàn vùng để khi in không bị mất đường chia.
            title_sections = [
                (c0, c0 + 3),      # CỠ: 4 cột
                (c0 + 4, c0 + 6),  # SL: 3 cột
                (c0 + 7, c1),      # ÁNH: 3 cột
            ]
            for sec_start, sec_end in title_sections:
                for cc in range(sec_start, sec_end + 1):
                    left_side = medium if cc == sec_start else thin
                    right_side = medium if cc == sec_end else thin
                    ws.cell(r0, cc).border = Border(
                        left=left_side,
                        right=right_side,
                        top=medium,
                        bottom=medium,
                    )

            # Header 2 tầng.
            ws.merge_cells(start_row=r0 + 1, start_column=c0, end_row=r0 + 2, end_column=c0)
            ws.cell(r0 + 1, c0, "SL")
            ws.merge_cells(start_row=r0 + 1, start_column=c0 + 1, end_row=r0 + 2, end_column=c0 + 3)
            ws.cell(r0 + 1, c0 + 1, "Số thứ tự")
            ws.merge_cells(start_row=r0 + 1, start_column=c0 + 4, end_row=r0 + 1, end_column=c0 + 5)
            ws.cell(r0 + 1, c0 + 4, "TT")
            ws.merge_cells(start_row=r0 + 1, start_column=c0 + 6, end_row=r0 + 1, end_column=c0 + 7)
            ws.cell(r0 + 1, c0 + 6, "TS")
            ws.merge_cells(start_row=r0 + 1, start_column=c0 + 8, end_row=r0 + 1, end_column=c0 + 9)
            ws.cell(r0 + 1, c0 + 8, "TAY")
            ws.cell(r0 + 2, c0 + 4, "NHẬN")
            ws.cell(r0 + 2, c0 + 5, "PHÁT")
            ws.cell(r0 + 2, c0 + 6, "NHẬN")
            ws.cell(r0 + 2, c0 + 7, "PHÁT")
            ws.cell(r0 + 2, c0 + 8, "NHẬN")
            ws.cell(r0 + 2, c0 + 9, "PHÁT")

            for rr in (r0 + 1, r0 + 2):
                for cc in range(c0, c1 + 1):
                    ws.cell(rr, cc).font = head_font
                    ws.cell(rr, cc).alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

            # Dữ liệu.
            for i, row_data in enumerate(rows_data):
                rr = data_start + i
                if row_data is None:
                    # Dòng trống sau mỗi 10 dòng số thứ tự.
                    # Ghi nhận để xử lý chiều cao 12 px sau khi vẽ toàn bộ các khối,
                    # tránh làm thấp một hàng đang có dữ liệu ở khối bên cạnh.
                    form10_blank_rows.add(rr)
                    for cc in range(c0, c1 + 1):
                        ws.cell(rr, cc, None)
                        ws.cell(rr, cc).font = data_font
                        ws.cell(rr, cc).alignment = Alignment(horizontal="center", vertical="center")
                else:
                    q, num, end_num = row_data
                    ws.cell(rr, c0, q)
                    ws.cell(rr, c0 + 1, num)
                    ws.cell(rr, c0 + 2, "-")
                    ws.cell(rr, c0 + 3, end_num)
                    for cc in range(c0, c1 + 1):
                        ws.cell(rr, cc).font = data_font
                        ws.cell(rr, cc).alignment = Alignment(horizontal="center", vertical="center")

            # Kẻ ô + viền ngoài đậm cho các dòng bình thường.
            # Dòng r0 (CỠ / SL / ÁNH) đã có viền đậm riêng ở trên nên không ghi đè.
            for rr in range(r0 + 1, data_end + 1):
                for cc in range(c0, c1 + 1):
                    ws.cell(rr, cc).border = border
            for cc in range(c0, c1 + 1):
                top = ws.cell(r0, cc)
                bottom = ws.cell(data_end, cc)
                top.border = Border(top=medium, left=top.border.left, right=top.border.right, bottom=top.border.bottom)
                bottom.border = Border(bottom=medium, left=bottom.border.left, right=bottom.border.right, top=bottom.border.top)
            for rr in range(r0, data_end + 1):
                left = ws.cell(rr, c0)
                right = ws.cell(rr, c1)
                left.border = Border(left=medium, right=left.border.right, top=left.border.top, bottom=left.border.bottom)
                right.border = Border(right=medium, left=right.border.left, top=right.border.top, bottom=right.border.bottom)

            # Dòng ngăn cách sau mỗi 10 dòng số thứ tự theo mẫu:
            # - cao khoảng 12 px (~9 pt)
            # - không có đường dọc chia ô bên trong
            # - có đường ngang mảnh ở trên và dưới
            # - hai cạnh ngoài vẫn đậm để khung CỠ liền mạch.
            for i, row_data in enumerate(rows_data):
                if row_data is None:
                    rr = data_start + i
                    ws.row_dimensions[rr].height = 9
                    for cc in range(c0, c1 + 1):
                        left_side = medium if cc == c0 else Side(style=None)
                        right_side = medium if cc == c1 else Side(style=None)
                        ws.cell(rr, cc).border = Border(
                            left=left_side,
                            right=right_side,
                            top=thin,
                            bottom=thin,
                        )

            last_used_row = max(last_used_row, data_end)
            return data_end

        # Mỗi Ánh là một khối, nhưng toàn bộ khối được xếp theo logic giống bảng cắt.
        # Trong cùng một cột có thể có nhiều size/Ánh nếu còn vừa.
        for item in data["sizes"]:
            seq = item["start_no"]
            for light_index, light in enumerate(item["lights"]):
                all_rows = make_form10_rows(light["qty"], seq)
                light_end = seq + light["qty"] - 1
                if light_index < len(item["lights"]) - 1:
                    seq = next_light_start(light_end, 10)
                else:
                    seq = light_end + 1

                # Nếu đang ở giữa cột và toàn bộ khối không vừa thì chuyển sang cột kế bên.
                # Không nhét vài dòng của một size/Ánh mới vào cuối cột cũ.
                if cursor_row > page_top and not rows_fit_from(cursor_row, len(all_rows)):
                    new_slot()

                groups = split_row_groups(all_rows)
                first_part = True
                while groups:
                    cap = full_block_capacity(cursor_row)
                    if cap <= 0:
                        new_slot()
                        cap = full_block_capacity(cursor_row)

                    chunk, used = take_groups_that_fit(groups, cap)

                    # Nếu cột hiện tại chỉ còn chỗ cho 1-2 dòng lẻ của cụm kế tiếp
                    # thì không đặt các dòng đó ở đây; chuyển cả cụm 10 dòng sang cột kế bên.
                    if not chunk:
                        new_slot()
                        cap = full_block_capacity(cursor_row)
                        chunk, used = take_groups_that_fit(groups, cap)

                    # Trường hợp cực đoan: một cụm vẫn không vừa trang (thực tế khó xảy ra),
                    # lấy theo sức chứa để tránh vòng lặp vô hạn.
                    if not chunk:
                        first_group = groups[0]
                        used = min(cap, len(first_group))
                        chunk = first_group[:used]
                        groups[0] = first_group[used:]
                        if not groups[0]:
                            groups.pop(0)
                    else:
                        remaining = used
                        while groups and remaining >= len(groups[0]):
                            remaining -= len(groups[0])
                            groups.pop(0)

                    c0 = starts[slot]
                    data_end = draw_form10_block(
                        item["size"], light["light"], light["qty"], chunk,
                        cursor_row, c0, continued=not first_part
                    )
                    first_part = False

                    if groups:
                        # Còn dữ liệu: chuyển sang cột kế bên, luôn bắt đầu bằng nguyên cụm 10 dòng.
                        new_slot()
                    else:
                        # Khối hoàn tất: chừa 2 dòng, rồi size/Ánh kế tiếp có thể nằm ngay dưới.
                        for rr in range(data_end + 1, data_end + 1 + gap_rows):
                            ws.row_dimensions[rr].height = blank_h
                        cursor_row = data_end + 1 + gap_rows

        # Tất cả các hàng ngăn cách sau mỗi 10 dòng đều thu xuống 12 px (~9 pt).
        # Phần viền của chính khối đã được xóa trong draw_form10_block().
        for rr in sorted(form10_blank_rows):
            ws.row_dimensions[rr].height = 9

        for br in sorted(set(page_break_rows)):
            try:
                ws.row_breaks.append(Break(id=br - 1))
            except Exception:
                pass

        ws.freeze_panes = "A5"
        ws.print_title_rows = "1:4"
        # 3 khối tới AF. In 85%; tổng chiều rộng được khống chế để không phát sinh trang ngang phụ.
        ws.print_area = f"A1:AF{max(last_used_row, page_bottom)}"
        wb.save(path)

    def build_workbook(self, data, path):
        wb = Workbook()
        ws = wb.active
        ws.title = "PHAN BO BAN CAT"
        ws.sheet_view.showGridLines = True

        # A4 ngang, sát mép. Theo mẫu người dùng, vùng nội dung của 1 trang kết thúc ở dòng 55.
        # Không giới hạn số bàn cố định: chỉ khi khối chạm dòng 55 mới chuyển sang cột bên cạnh.
        ws.page_setup.orientation = "landscape"
        ws.page_setup.paperSize = ws.PAPERSIZE_A4
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.page_margins.left = 0.05
        ws.page_margins.right = 0.05
        ws.page_margins.top = 0.10
        ws.page_margins.bottom = 0.10
        ws.page_margins.header = 0.0
        ws.page_margins.footer = 0.0
        ws.print_options.horizontalCentered = True
        ws.print_title_rows = "1:5"

        starts = [1, 9, 17, 25]  # A, I, Q, Y
        block_width = 7
        first_data_top = 6

        # Chiều cao dòng được ấn định để việc tính hết chiều cao A4 là ổn định.
        header_row_heights = {1: 20, 2: 20, 3: 20, 4: 20, 5: 15}
        title_h = 24      # dòng SIZE
        subhead_h = 22    # dòng tiêu đề cột
        data_h = 15       # mỗi bàn
        blank_h = 15      # dòng trống
        gap_rows = 2      # 2 dòng trống giữa 2 cỡ
        for r, h in header_row_heights.items():
            ws.row_dimensions[r].height = h

        # Theo ảnh kiểm tra của người dùng: hàng 55 là mép dưới A4.
        # Trang đầu bắt đầu phần bảng ở hàng 6, vì vậy mỗi trang dành các hàng 6..55 cho bảng.
        fixed_page_bottom_row = 55
        page_body_rows = fixed_page_bottom_row - first_data_top + 1
        page_bottom_offset = page_body_rows - 1

        for col in range(1, 33):
            ws.column_dimensions[get_column_letter(col)].width = 6.5

        ws.column_dimensions["A"].width = 7.2
        ws.column_dimensions["B"].width = 7.2

        # Logo phủ/co giãn trong A1:B4.
        if data["logo"] and os.path.exists(data["logo"]):
            try:
                img = XLImage(data["logo"])
                img.width = 100
                img.height = 106
                ws.add_image(img, "A1")
            except Exception:
                pass

        ws.merge_cells("I1:R2")
        t = ws["I1"]
        t.value = "BIỂU PHÂN BỔ SỐ BÀN CẮT"
        t.font = Font(name="Times New Roman", size=20, bold=True)
        t.alignment = Alignment(horizontal="center", vertical="center")

        info_font = Font(name="Times New Roman", size=11, bold=True)
        info_cells = {
            "E3": f"KHÁCH HÀNG : {data['customer']}",
            "E4": f"MÃ HÀNG : {data['style_code']}",
            "J4": f"MÀU : {data['color']}",
            "O4": f"ĐỢT : {data['batch']}",
            "R4": f"TỔNG SỐ LƯỢNG : {data['total']}",
            "Y4": f"PO : {data['po']}",
            "AC3": f"DATE : {data['date']}",
        }
        for addr, val in info_cells.items():
            ws[addr] = val
            ws[addr].font = info_font
            ws[addr].alignment = Alignment(vertical="center")

        thin = Side(style="thin", color="000000")
        medium = Side(style="medium", color="000000")
        border_thin = Border(left=thin, right=thin, top=thin, bottom=thin)
        fill_head = PatternFill("solid", fgColor="F2F2F2")
        font_head = Font(name="Times New Roman", size=10, bold=True)
        font_data = Font(name="Times New Roman", size=10)
        font_size_title = Font(name="Times New Roman", size=20, bold=True)

        # Vị trí đóng gói hiện tại: mỗi trang có 4 cột khối.
        page_index = 0
        slot = 0
        cursor_row = first_data_top
        page_top = first_data_top
        page_bottom = page_top + page_bottom_offset
        last_used_row = first_data_top
        page_break_rows = []

        def new_slot():
            nonlocal page_index, slot, cursor_row, page_top, page_bottom
            slot += 1
            if slot >= 4:
                slot = 0
                page_index += 1
                page_top = first_data_top + page_index * page_body_rows
                page_bottom = page_top + page_bottom_offset
                cursor_row = page_top
                page_break_rows.append(page_top)
            else:
                cursor_row = page_top

        def rows_fit_from(start_row, table_count):
            # 2 dòng tiêu đề + số dòng bàn
            return start_row + 2 + table_count - 1 <= page_bottom

        def full_block_capacity(start_row):
            # số bàn tối đa còn vừa từ dòng hiện tại tới hết chiều cao trang
            return max(0, page_bottom - (start_row + 2) + 1)

        def draw_block(item, rows_data, r0, c0, table_no_start, continued=False):
            nonlocal last_used_row
            c1 = c0 + block_width - 1
            r_head2 = r0 + 1
            data_start = r0 + 2
            data_end = data_start + len(rows_data) - 1

            ws.row_dimensions[r0].height = title_h
            ws.row_dimensions[r_head2].height = subhead_h
            for rr in range(data_start, data_end + 1):
                ws.row_dimensions[rr].height = data_h

            ws.cell(r0, c0, "SIZE")
            ws.merge_cells(start_row=r0, start_column=c0 + 1, end_row=r0, end_column=c1)
            ws.cell(r0, c0 + 1, item["size"] if not continued else f"{item['size']} (tiếp)")
            ws.cell(r0, c0).font = font_head
            ws.cell(r0, c0).alignment = Alignment(horizontal="center", vertical="center")
            ws.cell(r0, c0 + 1).font = font_size_title
            ws.cell(r0, c0 + 1).alignment = Alignment(horizontal="center", vertical="center")

            ws.cell(r_head2, c0, "SL size")
            ws.cell(r_head2, c0 + 1, "Ánh")
            ws.cell(r_head2, c0 + 2, "Số bàn")
            ws.cell(r_head2, c0 + 3, "SL Bàn")
            ws.merge_cells(start_row=r_head2, start_column=c0 + 4, end_row=r_head2, end_column=c1)
            ws.cell(r_head2, c0 + 4, "Số thứ tự")
            for cc in range(c0, c1 + 1):
                cell = ws.cell(r_head2, cc)
                cell.font = font_head
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.fill = fill_head

            if data_end >= data_start:
                # SL size là tổng của tất cả các Ánh trong cỡ.
                if data_end > data_start:
                    ws.merge_cells(start_row=data_start, start_column=c0, end_row=data_end, end_column=c0)
                ws.cell(data_start, c0, item["qty"])
                ws.cell(data_start, c0).font = Font(name="Times New Roman", size=11, bold=True)
                ws.cell(data_start, c0).alignment = Alignment(horizontal="center", vertical="center")

                # Cột Ánh: gộp riêng từng nhóm Ánh. Nếu một Ánh bị tách sang cột kế tiếp
                # thì tên Ánh vẫn được lặp lại ở phần tiếp theo để dễ đọc.
                group_start = 0
                while group_start < len(rows_data):
                    light_name = rows_data[group_start][3]
                    group_end = group_start
                    while group_end + 1 < len(rows_data) and rows_data[group_end + 1][3] == light_name:
                        group_end += 1
                    rr1 = data_start + group_start
                    rr2 = data_start + group_end
                    if rr2 > rr1:
                        ws.merge_cells(start_row=rr1, start_column=c0 + 1, end_row=rr2, end_column=c0 + 1)
                    ws.cell(rr1, c0 + 1, light_name)
                    ws.cell(rr1, c0 + 1).font = Font(name="Times New Roman", size=11, bold=True)
                    ws.cell(rr1, c0 + 1).alignment = Alignment(horizontal="center", vertical="center")
                    group_start = group_end + 1

            for j, row_data in enumerate(rows_data):
                q, seq_start, seq_end, light_name, local_table_no = row_data
                rr = data_start + j
                # Khi tách sang Ánh/LOT mới, Số bàn đánh lại từ 1.
                ws.cell(rr, c0 + 2, local_table_no)
                ws.cell(rr, c0 + 3, q)
                ws.cell(rr, c0 + 4, seq_start)
                ws.cell(rr, c0 + 5, "->")
                ws.cell(rr, c0 + 6, seq_end)
                for cc in range(c0 + 2, c1 + 1):
                    ws.cell(rr, cc).font = font_data
                    ws.cell(rr, cc).alignment = Alignment(horizontal="center", vertical="center")

            for rr in range(r0, data_end + 1):
                for cc in range(c0, c1 + 1):
                    ws.cell(rr, cc).border = border_thin
            for cc in range(c0, c1 + 1):
                top_cell = ws.cell(r0, cc)
                top_cell.border = Border(top=medium, left=top_cell.border.left, right=top_cell.border.right, bottom=top_cell.border.bottom)
                bot_cell = ws.cell(data_end, cc)
                bot_cell.border = Border(bottom=medium, left=bot_cell.border.left, right=bot_cell.border.right, top=bot_cell.border.top)
            for rr in range(r0, data_end + 1):
                lc = ws.cell(rr, c0)
                rc = ws.cell(rr, c1)
                lc.border = Border(left=medium, right=lc.border.right, top=lc.border.top, bottom=lc.border.bottom)
                rc.border = Border(right=medium, left=rc.border.left, top=rc.border.top, bottom=rc.border.bottom)

            widths = [8.5, 5.5, 6.5, 7.0, 8.0, 4.0, 8.0]
            for off, w in enumerate(widths):
                ws.column_dimensions[get_column_letter(c0 + off)].width = w

            last_used_row = max(last_used_row, data_end)
            return data_end

        for item in data["sizes"]:
            # Mỗi cỡ có thể có nhiều Ánh/LOT. Số thứ tự sản phẩm chạy liên tiếp,
            # nhưng Số bàn sẽ đánh lại từ 1 khi sang Ánh/LOT mới.
            seq = item["start_no"]
            all_rows = []
            for light_index, light in enumerate(item["lights"]):
                tables = split_tables(light["qty"], data["round_qty"], data["last_limit"])
                light_end = seq - 1
                # Mỗi Ánh/LOT là một nhóm riêng: Số bàn luôn bắt đầu lại từ 1.
                for local_table_no, q in enumerate(tables, start=1):
                    seq_start = seq
                    seq_end = seq + q - 1
                    all_rows.append((q, seq_start, seq_end, light["light"], local_table_no))
                    seq = seq_end + 1
                    light_end = seq_end
                # Ánh kế tiếp bắt đầu ở mốc chục kế tiếp + 1.
                # Ví dụ Ánh A kết thúc 204 -> Ánh B bắt đầu 211.
                if light_index < len(item["lights"]) - 1 and light_end >= 0:
                    seq = next_light_start(light_end, 10)

            total_needed = 2 + len(all_rows)
            remaining_capacity = full_block_capacity(cursor_row)
            full_column_capacity = full_block_capacity(page_top)

            # Quy tắc xếp cỡ mới:
            # - Chỉ đặt cỡ tiếp theo xuống dưới cỡ trước khi TOÀN BỘ cỡ đó còn vừa
            #   trong phần chiều cao A4 còn lại (sau 2 dòng trống).
            # - Nếu không vừa thì chuyển cỡ đó sang khối/cột bên cạnh ngay từ đầu.
            # - Với cỡ rất dài hơn 1 cột A4, cũng KHÔNG dùng vài dòng trống còn lại
            #   của cột trước để bắt đầu cỡ mới; cỡ dài sẽ bắt đầu ở đầu cột mới rồi
            #   mới tách phần tiếp sang các cột kế tiếp.
            if cursor_row > page_top and not rows_fit_from(cursor_row, len(all_rows)):
                new_slot()

            pos = 0
            table_no = 1
            first_part = True
            while pos < len(all_rows):
                cap = full_block_capacity(cursor_row)
                if cap <= 0:
                    new_slot()
                    cap = full_block_capacity(cursor_row)

                take = min(cap, len(all_rows) - pos)
                chunk = all_rows[pos:pos + take]
                c0 = starts[slot]
                data_end = draw_block(item, chunk, cursor_row, c0, table_no, continued=not first_part)
                pos += take
                table_no += take
                first_part = False

                if pos < len(all_rows):
                    # Cỡ còn tiếp: đã hết chiều cao A4 -> sang cột bên cạnh.
                    new_slot()
                else:
                    # Cỡ đã xong. Để trống đúng 2 dòng rồi ưu tiên cỡ tiếp theo ở dưới
                    # nếu còn vừa trong cùng cột A4.
                    for rr in range(data_end + 1, data_end + 1 + gap_rows):
                        ws.row_dimensions[rr].height = blank_h
                    cursor_row = data_end + 1 + gap_rows

        # Ngắt trang dọc sau khi dùng hết 4 cột ngang.
        for br in sorted(set(page_break_rows)):
            try:
                ws.row_breaks.append(Break(id=br - 1))
            except Exception:
                pass

        ws.freeze_panes = "A6"
        ws.print_area = f"A1:AF{max(last_used_row, page_bottom)}"
        wb.save(path)




if __name__ == "__main__":
    root = tk.Tk()
    app = CuttingPlanApp(root)
    root.mainloop()
